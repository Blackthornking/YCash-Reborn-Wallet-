// This is a basic smoke test for the YCash wallet app.
//
// The default Flutter template test that `flutter create` generates
// pumps a `MyApp` widget and checks a counter increments. This app has
// neither — its root widget is `YcashRebornApp` (lib/app/app.dart), wired
// up through Riverpod, so the smoke test below pumps that instead and
// just confirms the app builds and renders without throwing.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:ycash_reborn/app/app.dart';

void main() {
  testWidgets('App builds and renders without throwing', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(
      const ProviderScope(
        child: YcashRebornApp(),
      ),
    );

    // YcashRebornApp does an async onboarding/secure-storage check in
    // initState before it can build its router. In the test environment
    // there's no secure storage plugin registered, so this will resolve
    // to the error state rather than hang — either way, let it settle.
    await tester.pump(const Duration(seconds: 1));

    // Whichever state it lands in (busy, error, or the real router), a
    // MaterialApp should have been rendered rather than a crash.
    expect(find.byType(MaterialApp), findsOneWidget);
  });
}
