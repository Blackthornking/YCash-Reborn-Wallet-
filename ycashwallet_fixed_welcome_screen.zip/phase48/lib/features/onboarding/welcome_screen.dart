import 'package:flutter/material.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

class WelcomeScreen extends StatelessWidget {
  final VoidCallback onCreateNew;
  final VoidCallback onRestore;

  const WelcomeScreen({
    super.key,
    required this.onCreateNew,
    required this.onRestore,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [YColors.spaceDeep, Color(0xFF0B0905)],
            ),
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(YSpacing.xl),
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: MediaQuery.of(context).size.height -
                    MediaQuery.of(context).padding.top -
                    MediaQuery.of(context).padding.bottom -
                    (YSpacing.xl * 2),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  YEnter(
                    child: Image.asset(
                      'assets/branding/ycash_logo.png',
                      width: 230,
                      fit: BoxFit.contain,
                      excludeFromSemantics: true,
                    ),
                  ),
                  const SizedBox(height: YSpacing.lg),
                  YEnter(
                    delay: const Duration(milliseconds: 100),
                    child: Semantics(
                      header: true,
                      label: 'Your Money. Your Privacy. Your Freedom.',
                      child: const Text(
                        'Your Money. Your Privacy. Your Freedom.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: YColors.textPrimary,
                          fontSize: 27,
                          fontWeight: FontWeight.w800,
                          height: 1.15,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: YSpacing.sm),
                  YEnter(
                    delay: const Duration(milliseconds: 150),
                    child: Semantics(
                      label:
                          'YCash gives you control over your money with privacy, security, and freedom at its core.',
                      child: const Text(
                        'YCash gives you control over your money with privacy, security, and freedom at its core.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: YColors.textSecondary,
                          fontSize: 15,
                          height: 1.45,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: YSpacing.lg),
                  YEnter(
                    delay: const Duration(milliseconds: 210),
                    child: const Column(
                      children: [
                        _FeatureCard(
                          icon: Icons.shield_outlined,
                          title: 'Private by Design',
                          description: 'Protect your financial privacy.',
                        ),
                        SizedBox(height: YSpacing.sm),
                        _FeatureCard(
                          icon: Icons.key_outlined,
                          title: 'You Control Your Keys',
                          description: 'Your wallet. Your money. Your control.',
                        ),
                        SizedBox(height: YSpacing.sm),
                        _FeatureCard(
                          icon: Icons.public_outlined,
                          title: 'Built for Freedom',
                          description:
                              'Decentralised money without unnecessary restrictions.',
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: YSpacing.xl),
                  YEnter(
                    delay: const Duration(milliseconds: 280),
                    child: SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: onCreateNew,
                        child: const Text('Create New Wallet'),
                      ),
                    ),
                  ),
                  const SizedBox(height: YSpacing.md),
                  YEnter(
                    delay: const Duration(milliseconds: 340),
                    child: SizedBox(
                      width: double.infinity,
                      child: OutlinedButton(
                        onPressed: onRestore,
                        child: const Text('Restore Existing Wallet'),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;

  const _FeatureCard({
    required this.icon,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: '$title. $description',
      child: ExcludeSemantics(
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(YSpacing.md),
          decoration: BoxDecoration(
            color: YColors.spaceSurfaceRaised,
            borderRadius: BorderRadius.circular(YRadius.button),
            border: Border.all(color: const Color(0xFF3B2A08)),
          ),
          child: Row(
            children: [
              Icon(icon, color: YColors.shieldedPrimary, size: 28),
              const SizedBox(width: YSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: YColors.textPrimary,
                        fontWeight: FontWeight.w700,
                        fontSize: 15,
                      ),
                    ),
                    const SizedBox(height: YSpacing.xs),
                    Text(
                      description,
                      style: const TextStyle(
                        color: YColors.textSecondary,
                        fontSize: 13,
                        height: 1.3,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
