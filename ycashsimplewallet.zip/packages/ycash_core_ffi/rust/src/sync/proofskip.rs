//! AWBS ProofSkip — reserved cryptographic fast path.
//!
//! This module is intentionally LOCKED. It contains no code path used by the
//! production scanner and cannot skip a block. Enabling it requires a future
//! protocol/server design that authenticates an ownership-filter result; a
//! client must never trust an unauthenticated "no wallet outputs" assertion.

pub const PROOFSKIP_ENABLED: bool = false;
pub const PROOFSKIP_PROTOCOL_VERSION: u32 = 1;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProofSkipState {
    Locked,
}

pub fn state() -> ProofSkipState { ProofSkipState::Locked }

/// Fail closed until the future authenticated server protocol is implemented.
pub fn authorize() -> Result<(), &'static str> {
    Err("AWBS ProofSkip is locked; no block may be skipped")
}
