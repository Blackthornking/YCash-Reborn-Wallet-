//! Phase 42: scanner-to-storage ingestion boundary for exact Sapling state.
//!
//! This module deliberately separates transport from cryptographic trial decryption.
//! A source must provide only records that it has authenticated using the pinned Ycash
//! scanner; this layer validates shape, persists atomically, and advances scan state.

use rusqlite::{params, Connection, Transaction};
use crate::wallet::WalletError;
use crate::tx::phase41::{decode_witness, SAPLING_TREE_DEPTH};

#[derive(Debug, Clone)]
pub struct ScannedSaplingNote {
    pub note_id: String,
    pub account_id: i64,
    pub value: u64,
    pub position: u64,
    pub note_commitment: [u8; 32],
    pub anchor: [u8; 32],
    pub diversifier: [u8; 11],
    pub pk_d: [u8; 32],
    pub rcm: [u8; 32],
    /// Exactly 32 sibling+direction entries encoded by Phase 41.
    pub witness_v2: Vec<u8>,
    pub spending_key_handle: String,
}

#[derive(Debug, Clone)]
pub struct ScanBatch {
    pub scanned_height: u32,
    pub notes: Vec<ScannedSaplingNote>,
    pub spent_nullifiers: Vec<(String, u32)>,
}

#[derive(Debug, thiserror::Error)]
pub enum Phase42Error {
    #[error("empty note id")] EmptyNoteId,
    #[error("empty spending key handle")] EmptyKeyHandle,
    #[error("invalid witness: {0}")] Witness(String),
    #[error("storage: {0}")] Storage(String),
}

fn validate(note: &ScannedSaplingNote) -> Result<(), Phase42Error> {
    if note.note_id.is_empty() { return Err(Phase42Error::EmptyNoteId); }
    if note.spending_key_handle.is_empty() { return Err(Phase42Error::EmptyKeyHandle); }
    let path = decode_witness(&note.witness_v2).map_err(|e| Phase42Error::Witness(e.to_string()))?;
    if path.len() != SAPLING_TREE_DEPTH { return Err(Phase42Error::Witness("wrong tree depth".into())); }
    Ok(())
}

/// Atomically persists scanner-authenticated state. No synthetic witnesses are created.
pub fn apply_scan_batch(conn: &mut Connection, batch: &ScanBatch) -> Result<(), Phase42Error> {
    for note in &batch.notes { validate(note)?; }
    let tx = conn.transaction().map_err(|e| Phase42Error::Storage(e.to_string()))?;
    apply_in_tx(&tx, batch)?;
    tx.commit().map_err(|e| Phase42Error::Storage(e.to_string()))?;
    Ok(())
}

fn apply_in_tx(tx: &Transaction<'_>, batch: &ScanBatch) -> Result<(), Phase42Error> {
    // Prepare once per atomic batch. This removes repeated SQL compilation from
    // large AWBS commits while preserving the same transaction and statements.
    let mut note_stmt = tx.prepare_cached(
        "INSERT OR REPLACE INTO authenticated_notes(note_id,account_id,value,position,note_commitment,anchor,witness,spending_key_handle,spent) VALUES(?1,?2,?3,?4,?5,?6,?7,?8,0)")
        .map_err(|e| Phase42Error::Storage(e.to_string()))?;
    let mut material_stmt = tx.prepare_cached(
        "INSERT OR REPLACE INTO sapling_note_material(note_id,diversifier,pk_d,rcm,witness_v2) VALUES(?1,?2,?3,?4,?5)")
        .map_err(|e| Phase42Error::Storage(e.to_string()))?;
    let mut nf_stmt = tx.prepare_cached(
        "INSERT OR REPLACE INTO nullifiers(nullifier,height) VALUES(?1,?2)")
        .map_err(|e| Phase42Error::Storage(e.to_string()))?;

    for n in &batch.notes {
        note_stmt.execute(params![n.note_id,n.account_id,n.value as i64,n.position as i64,n.note_commitment.to_vec(),n.anchor.to_vec(),n.witness_v2,n.spending_key_handle])
            .map_err(|e| Phase42Error::Storage(e.to_string()))?;
        material_stmt.execute(params![n.note_id,n.diversifier.to_vec(),n.pk_d.to_vec(),n.rcm.to_vec(),n.witness_v2])
            .map_err(|e| Phase42Error::Storage(e.to_string()))?;
    }
    for (nf,height) in &batch.spent_nullifiers {
        nf_stmt.execute(params![nf,*height as i64])
            .map_err(|e| Phase42Error::Storage(e.to_string()))?;
    }
    tx.execute("INSERT INTO scan_state(id,scanned_height) VALUES(1,?1) ON CONFLICT(id) DO UPDATE SET scanned_height=excluded.scanned_height", params![batch.scanned_height as i64])
        .map_err(|e| Phase42Error::Storage(e.to_string()))?;
    Ok(())
}

pub fn mark_spent_by_nullifier(conn: &Connection, nullifier: &str) -> Result<(), WalletError> {
    conn.execute("INSERT OR IGNORE INTO nullifiers(nullifier,height) VALUES(?1,0)", params![nullifier])
        .map_err(|e| WalletError::Storage(e.to_string()))?;
    Ok(())
}
