import 'dart:async';
import 'dart:io';
import 'dart:isolate';
import 'package:path_provider/path_provider.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ycash_core/ycash_core.dart';
import 'config.dart';

/// Plain data for [_openNative] -- deliberately NOT a method parameter list
/// on [SimpleWallet], and [_openNative] deliberately lives at top level
/// (outside any class), so nothing in its scope can accidentally pull in
/// `this`. `_open` (the instance method below) also touches instance fields
/// like `_seed`/`opened` right after its Isolate.run call; if the isolate
/// closure were written directly inside that instance method, the Dart
/// compiler shares one capture context per method scope, so the *whole*
/// SimpleWallet instance -- including its live `Timer? _poll` -- gets
/// bundled into the closure even though the closure body never references
/// `this`. A Timer can't cross an isolate boundary, so that surfaces at
/// runtime as "Invalid argument(s): ... object is unsendable ... Class:
/// _Timer ... <- Instance of 'SimpleWallet'". Keeping the isolate body in a
/// top-level function with only value arguments avoids that entirely.
class _OpenArgs {
  final List<String> servers;
  final String dataDir;
  final String seed;
  final bool isNew;
  final bool replace;
  /// Unix seconds for when this wallet was first used, if the person knows.
  /// Resolved to a block height inside the isolate, once a server has been
  /// configured, and used as the wallet's birthday.
  final int? birthdaySeconds;
  const _OpenArgs({
    required this.servers,
    required this.dataDir,
    required this.seed,
    required this.isNew,
    required this.replace,
    this.birthdaySeconds,
  });
}

/// Configure + open the native wallet, trying each candidate server in turn.
///
/// Opening is not a local operation: `LightClientConfig::create` resolves the
/// host, then makes a real `GetLightdInfo` call before any wallet file is
/// touched. So one unreachable endpoint previously failed the entire wallet
/// open, and the app surfaced that as a fatal "could not open the saved
/// wallet" screen with no way forward. Walking the list means a dead or
/// renamed endpoint degrades to "try the next one" instead.
///
/// Returns the server that actually worked, so the UI can show it.
Future<String> _openNative(_OpenArgs args) => Isolate.run(() {
  final n = YcashCoreNative.instance;
  final failures = <String>[];

  for (final server in args.servers) {
    try {
      n.configure(server: server, dataDir: args.dataDir);
      if (args.replace) {
        try { n.wipeYecWallet(); } catch (_) {}
      }
      // Birthday resolution happens here, after configure(), because the
      // date -> height lookup needs a server but not an open wallet.
      //
      // Without a birthday a restore defaults to the Ycash fork (570,000) and
      // has to scan ~2.46 million blocks. The server answers GetTreeState, so
      // a wallet can legitimately start at any height with a correct
      // commitment tree -- there is no reason to make someone who knows they
      // first used the wallet in 2024 scan from 2019.
      var birthday = 0;
      if (args.isNew) {
        birthday = YcashCoreNative.newWalletBirthday;
      } else if (args.birthdaySeconds != null) {
        try {
          birthday = n.serverHeightForTimestamp(args.birthdaySeconds!);
        } catch (_) {
          // Fall back to the fork rather than failing the whole restore.
          birthday = 0;
        }
      }
      n.openYecWallet(args.seed, birthday: birthday);
      return server;
    } catch (e) {
      failures.add('$server -> $e');
    }
  }

  throw StateError(
    'Could not reach any Ycash lightwalletd server.\n\n${failures.join('\n')}',
  );
});

class SimpleSyncStatus {
  final String phase;
  final int height;
  final int tip;
  final int birthday;
  final String? error;
  /// How the native engine established this wallet's scan start -- server
  /// tree state, a bundled checkpoint, or nothing. See lightclient.rs's
  /// last_initial_state_note.
  final String initialState;
  /// Why the last attempt to write the wallet to disk failed, if it did.
  final String? saveError;
  final double lastBatchSecs;
  final double blocksPerSec;
  final int downloadedBytes;
  final int currentBatchSize;
  final int workerCount;
  final int prefetchDepth;
  /// Set when the server refuses transparent-address lookups. Shielded sync
  /// still works in that case, so this is a warning, not a failure. Defaulted
  /// so adding it cannot break any existing call site.
  final String transparentWarning;
  const SimpleSyncStatus(this.phase,this.height,this.tip,this.birthday,this.error,this.initialState,this.saveError,this.lastBatchSecs,this.blocksPerSec,this.downloadedBytes,this.currentBatchSize,this.workerCount,this.prefetchDepth,{this.transparentWarning=''});
  bool get syncing => phase == 'connecting' || phase == 'scanning' || phase == 'fetching_memos';
  bool get failed => phase == 'error';
  double get progress {
    final span=tip-birthday;
    if(span<=0) return tip>0?1:0;
    return ((height-birthday)/span).clamp(0.0,1.0).toDouble();
  }
}

class SimpleWallet {
  final _storage=const FlutterSecureStorage();
  YcashCoreNative? __native;
  /// Lazily loads the native library on first actual use, instead of
  /// eagerly as a field initializer. SimpleWallet itself is constructed as
  /// part of _AppState's own field-initializer chain (see `final
  /// wallet=SimpleWallet();` in app.dart), which runs during State
  /// construction -- before any UI has built, and before app.dart's own
  /// try/catch around the startup check is in scope. A native-library
  /// load failure there had no error boundary around it at all. Deferring
  /// the load to the first real call (hasWallet(), create(), etc. -- all
  /// of which already run inside try/catch in app.dart/onboarding.dart)
  /// means a loading problem surfaces as an ordinary catchable exception
  /// instead of failing during construction.
  YcashCoreNative get _native => __native ??= YcashCoreNative.instance;
  Timer? _poll;
  Timer? _resync;
  bool opened=false;
  String? _seed;
  /// The lightwalletd endpoint this wallet actually connected to, once known.
  String? server;
  final status=StreamController<SimpleSyncStatus>.broadcast();

  Future<String> _dataDir() async {
    final base=await getApplicationSupportDirectory();
    final d=Directory('${base.path}/ycash-simple-wallet');
    if(!await d.exists()) await d.create(recursive:true);
    return d.path;
  }

  Future<bool> hasWallet() async => (await _storage.read(key:'ycash.simple.seed'))?.isNotEmpty == true;

  Future<void> create() async {
    final seed=_native.generateMnemonic();
    await _storage.write(key:'ycash.simple.seed',value:seed);
    await _open(seed, isNew:true);
  }

  /// [firstUsed] is optional. When given, the wallet starts scanning from
  /// that date instead of the Ycash fork.
  Future<void> restore(String seed,{DateTime? firstUsed}) async {
    final clean=seed.trim().replaceAll(RegExp(r'\s+'),' ');
    if(clean.split(' ').length != 24) throw StateError('Enter the 24-word Ycash recovery phrase.');
    await _storage.write(key:'ycash.simple.seed',value:clean);
    await _open(clean, isNew:false, replace:true,
        birthdaySeconds: firstUsed==null ? null : firstUsed.millisecondsSinceEpoch ~/ 1000);
  }

  Future<void> openSaved() async {
    if(opened) return;
    final seed=await _storage.read(key:'ycash.simple.seed');
    if(seed==null || seed.isEmpty) throw StateError('No wallet found.');
    await _open(seed,isNew:false);
  }

  /// Candidate endpoints, with the last one that actually worked moved to
  /// the front. Probing a dead endpoint costs a full connect timeout, so on
  /// every launch after the first this turns a multi-timeout wait into a
  /// single successful connect.
  Future<List<String>> _candidateServers() async {
    final servers=[...YcashConfig.lightwalletdServers];
    try {
      final prefs=await SharedPreferences.getInstance();
      final last=prefs.getString(YcashConfig.lastGoodServerKey);
      if(last!=null && last.isNotEmpty){
        servers.remove(last);
        servers.insert(0,last);
      }
    } catch(_) {}
    return servers;
  }

  Future<void> _rememberServer(String s) async {
    try {
      final prefs=await SharedPreferences.getInstance();
      await prefs.setString(YcashConfig.lastGoodServerKey,s);
    } catch(_) {}
  }

  Future<void> _open(String seed,{required bool isNew,bool replace=false,int? birthdaySeconds}) async {
    final dir=await _dataDir();
    final servers=await _candidateServers();

    // Retry the whole server list a couple of times before giving up. A
    // phone that has just woken, switched networks, or is still bringing
    // Wi-Fi up will fail the first getinfo call and then work fine seconds
    // later; without this that transient failure became a permanent fatal
    // error screen for the whole session.
    Object? lastError;
    for (var attempt = 1; attempt <= YcashConfig.openAttempts; attempt++) {
      try {
        server = await _openNative(_OpenArgs(
          servers: servers,
          dataDir: dir,
          seed: seed,
          isNew: isNew,
          replace: replace && attempt == 1,
          birthdaySeconds: birthdaySeconds,
        ));
        lastError = null;
        if (server != null) await _rememberServer(server!);
        break;
      } catch (e) {
        lastError = e;
        if (attempt < YcashConfig.openAttempts) {
          await Future.delayed(YcashConfig.openRetryDelay);
        }
      }
    }
    if (lastError != null) throw lastError;

    _seed=seed; opened=true;
    startSync();
    _poll?.cancel();
    _poll=Timer.periodic(YcashConfig.statusPoll,(_)=>_emit());
    // The native engine finishes a sync round as soon as it reaches the
    // chain tip and then stops; it also stops after exhausting its internal
    // retries on a network failure. Nothing restarted it, so the wallet
    // synced once at open and then silently went stale -- new blocks and
    // incoming transactions never appeared without the user hitting the
    // manual refresh. startSync() is a no-op while a round is in flight, so
    // this timer is safe to fire unconditionally.
    _resync?.cancel();
    _resync=Timer.periodic(YcashConfig.resyncInterval,(_)=>startSync());
    _emit();
  }

  void _emit() {
    try {
      final s=_native.syncStatus();
      status.add(SimpleSyncStatus(
        s['phase']?.toString()??'idle',
        (s['synced_blocks'] as num?)?.toInt()??0,
        (s['total_blocks'] as num?)?.toInt()??0,
        (s['birthday'] as num?)?.toInt()??YcashConfig.forkHeight,
        s['last_error']?.toString(),
        s['initial_state']?.toString() ?? '',
        s['save_error']?.toString(),
        (s['last_batch_secs'] as num?)?.toDouble()??0,
        (s['blocks_per_sec'] as num?)?.toDouble()??0,
        (s['downloaded_bytes'] as num?)?.toInt()??0,
        (s['current_batch_size'] as num?)?.toInt()??YcashConfig.modernBatchSize,
        (s['worker_count'] as num?)?.toInt()??YcashConfig.modernWorkers,
        (s['prefetch_depth'] as num?)?.toInt()??8,
        transparentWarning: s['transparent_warning']?.toString() ?? '',
      ));
    } catch(_){}
  }

  void startSync() {
    if(!opened || _seed==null) return;
    try {
      final s=_native.syncStatus();
      if(s['is_syncing']==true) return;
      _native.startBatchSync(
        batchSize:YcashConfig.modernBatchSize,
        workers:YcashConfig.modernWorkers,
      );
    } catch(_) {
      // A failed status read or start is not fatal: the resync timer will
      // come back around. Swallowing it here keeps a transient native error
      // from tearing down the UI.
      return;
    }
    _emit();
  }

  /// Flush wallet state to disk. Called when the app is about to be
  /// backgrounded, so scan progress isn't lost if Android reclaims the
  /// process before the next periodic checkpoint.
  /// Re-scan from [from], rebuilding transaction history from that point.
  ///
  /// History is rebuilt rather than merged, so moving the date *earlier*
  /// recovers anything a too-late restore birthday missed. The native side
  /// clears wallet state and re-seeds the starting commitment tree from the
  /// server, so the result matches restoring with that date in the first
  /// place. Funds and the recovery phrase are untouched.
  Future<int> rescanFrom(DateTime from) async {
    // heightForTimestamp binary-searches the chain over gRPC -- up to a dozen
    // round trips with a multi-second timeout each. Running it inline on the
    // UI isolate froze the whole app from the moment Rescan was pressed until
    // it returned, which Android reports as a crash (ANR). The native state
    // is process-global, so an isolate reaches the same open wallet.
    final seconds = from.millisecondsSinceEpoch ~/ 1000;
    final height = await Isolate.run(() {
      return YcashCoreNative.instance.heightForTimestamp(seconds);
    });
    if (height == 0) {
      throw StateError('Could not find a block for that date. Check your connection and try again.');
    }
    // Stops the in-flight sync and restarts from the new height. Also done off
    // the UI isolate: it waits for the running scan to reach a batch boundary.
    await Isolate.run(() {
      YcashCoreNative.instance.rescanFromHeight(height);
    });
    _emit();
    return height;
  }

  void saveNow() {
    if(!opened) return;
    try { _native.save(); } catch(_) {}
  }

  Map<String,dynamic> balances()=>Map<String,dynamic>.from(_native.balances());
  Map<String,dynamic> addresses()=>Map<String,dynamic>.from(_native.addresses());
  List<dynamic> history()=>_native.history();
  Map<String,dynamic> planSend({required String to,required int amount,String? memo})=>
      _native.planSend(to:to,amount:amount,memo:memo);
  String broadcast(Map<String,dynamic> plan)=>_native.broadcastPlan(plan);

  Future<void> wipe() async {
    _poll?.cancel(); _poll=null;
    _resync?.cancel(); _resync=null;
    // The native wipe now stops any in-flight scan and waits for the scan
    // thread to actually exit before deleting the wallet file, so it can
    // block for several seconds. Off the UI isolate, or resetting mid-sync
    // freezes the app.
    try{ await Isolate.run(() { YcashCoreNative.instance.wipeYecWallet(); }); }catch(_){}
    await _storage.delete(key:'ycash.simple.seed');
    // Forget the remembered endpoint too: it is wallet-scoped state and a
    // stale entry would be tried first for whatever wallet comes next.
    try{
      final prefs=await SharedPreferences.getInstance();
      await prefs.remove(YcashConfig.lastGoodServerKey);
    }catch(_){}
    opened=false; _seed=null; server=null;
  }
}
