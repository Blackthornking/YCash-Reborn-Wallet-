class YcashConfig {
  static const ticker = 'YEC';
  static const coinType = 347;
  static const forkHeight = 570000;
  static const saplingActivationHeight = 419200;

  /// Ycash lightwalletd endpoints, tried in order at wallet-open time until
  /// one answers. A single hardcoded endpoint meant any outage, DNS change or
  /// blocked port looked identical to "the wallet is broken" -- and the three
  /// Ycash projects this wallet is derived from each shipped a *different*
  /// default, so there was no way to tell which one was actually current.
  ///
  ///  - lightwalletd.ycash.xyz:443   -- this project's previous default
  ///  - lite.ycash.xyz:9067          -- zwallet's Ycash coin definition
  ///  - lightwalletd2.ycash.xyz:1443 -- upstream yecshell's DEFAULT_SERVER
  ///
  /// A port must always be present: LightClientConfig::create resolves
  /// `host:port` directly and does not infer 443 from the https scheme.
  static const lightwalletdServers = <String>[
    'https://lightwalletd.ycash.xyz:443',
    'https://lite.ycash.xyz:9067',
    'https://lightwalletd2.ycash.xyz:1443',
  ];

  /// Kept for anything that just wants "the" server; the open path uses the
  /// full list above.
  static const lightwalletd = 'https://lightwalletd.ycash.xyz:443';

  static const modernBatchSize = 512;
  static const modernWorkers = 4;

  /// How often the UI re-reads native sync state. The native call takes the
  /// engine's global state lock, which the scanning thread also wants, so
  /// polling several times a second actively slows scanning down on a phone.
  static const statusPoll = Duration(seconds: 1);

  /// How often to kick off another sync round. The native engine returns as
  /// soon as it reaches the chain tip, so without this the wallet would sync
  /// once at open and then never see another block.
  static const resyncInterval = Duration(seconds: 30);

  /// Attempts (per server) when opening the wallet, with a short backoff.
  /// Opening does a live getinfo call, so a phone that has just come back
  /// onto a network can legitimately fail the first try.
  static const openAttempts = 3;
  static const openRetryDelay = Duration(seconds: 3);
}
