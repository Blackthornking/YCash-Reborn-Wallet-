class YcashConfig {
  static const ticker = 'YEC';
  static const coinType = 347;
  static const forkHeight = 570000;
  static const saplingActivationHeight = 419200;
  static const lightwalletd = 'https://lite.ycash.xyz:9067';
  static const modernBatchSize = 512;
  static const modernWorkers = 4;
}
