import 'package:flutter/material.dart';
import '../core/auth.dart';
import '../core/config.dart';
import '../core/wallet.dart';

/// Wallet settings.
///
/// These actions used to live in an overflow menu on the home app bar, where
/// "Reset wallet" sat one tap away from everything else and a destructive
/// action had no room to explain itself. Each entry here says what it does
/// and what it costs before you commit to it.
class Settings extends StatefulWidget {
  final SimpleWallet wallet;

  /// Called after the wallet is wiped so the app can return to onboarding.
  final VoidCallback onWiped;

  const Settings({super.key, required this.wallet, required this.onWiped});

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  bool _lockEnabled = false;
  bool _lockAvailable = false;

  SimpleWallet get wallet => widget.wallet;
  VoidCallback get onWiped => widget.onWiped;

  @override
  void initState() {
    super.initState();
    _loadLock();
  }

  Future<void> _loadLock() async {
    final enabled = await WalletLock.isEnabled();
    final available = await WalletLock.isAvailable();
    if (mounted) setState(() { _lockEnabled = enabled; _lockAvailable = available; });
  }

  Future<void> _toggleLock(bool want) async {
    // Require a successful authentication *before* turning the lock on, so
    // the gate is proven to work on this device before anything depends on
    // it. Turning it off asks too -- otherwise anyone holding an unlocked
    // phone could simply switch the protection off.
    final ok = await WalletLock.authenticate(
      reason: want ? 'Confirm to require unlock' : 'Confirm to remove the unlock requirement');
    if (!ok) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Not changed — authentication failed')));
      }
      return;
    }
    await WalletLock.setEnabled(want);
    if (mounted) setState(() => _lockEnabled = want);

  }

  Future<void> _rescan(BuildContext c) async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: c,
      initialDate: DateTime(now.year - 1, now.month, now.day),
      firstDate: DateTime(2019, 7, 1),
      lastDate: now,
      helpText: 'Rescan from which date?',
    );
    if (picked == null || !c.mounted) return;

    final ok = await showDialog<bool>(
      context: c,
      builder: (d) => AlertDialog(
        title: const Text('Rescan wallet'),
        content: const Text(
          'Transaction history is rebuilt from this date forward. Your funds '
          'and recovery phrase are untouched — this only changes where '
          'scanning starts.\n\n'
          'Pick a date before your first transaction. Anything received '
          'earlier will not be found.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Rescan')),
        ],
      ),
    );
    if (ok != true || !c.mounted) return;

    // Looking up the block height for a date needs a round of network calls,
    // and stopping the running scan waits for a batch boundary. Both can take
    // a few seconds, so keep the screen honest about being busy rather than
    // appearing frozen.
    showDialog<void>(
      context: c,
      barrierDismissible: false,
      builder: (_) => const AlertDialog(
        content: Row(children: [
          CircularProgressIndicator(),
          SizedBox(width: 20),
          Expanded(child: Text('Finding that date on the chain…')),
        ]),
      ),
    );

    try {
      final h = await wallet.rescanFrom(picked);
      if (!c.mounted) return;
      Navigator.pop(c);
      ScaffoldMessenger.of(c).showSnackBar(
        SnackBar(content: Text('Rescanning from block $h')));
    } catch (e) {
      if (!c.mounted) return;
      Navigator.pop(c);
      ScaffoldMessenger.of(c).showSnackBar(
        SnackBar(content: Text('Could not start rescan: $e')));
    }
  }

  Future<void> _reset(BuildContext c) async {
    final ok = await showDialog<bool>(
      context: c,
      builder: (d) => AlertDialog(
        title: const Text('Reset wallet'),
        content: const Text(
          'This deletes the wallet and its recovery phrase from this device. '
          'Anything not backed up elsewhere is gone for good.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(d, true),
            child: const Text('Reset'),
          ),
        ],
      ),
    );
    if (ok != true || !c.mounted) return;

    showDialog<void>(
      context: c,
      barrierDismissible: false,
      builder: (_) => const AlertDialog(
        content: Row(children: [
          CircularProgressIndicator(),
          SizedBox(width: 20),
          Expanded(child: Text('Stopping sync and clearing wallet…')),
        ]),
      ),
    );

    await wallet.wipe();
    if (!c.mounted) return;
    Navigator.pop(c);
    onWiped();
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Settings')),
    body: ListView(children: [
      const _Header('Sync'),
      ListTile(
        leading: const Icon(Icons.sync),
        title: const Text('Sync now'),
        subtitle: const Text('Start a sync round immediately'),
        onTap: () {
          wallet.startSync();
          ScaffoldMessenger.of(c).showSnackBar(
            const SnackBar(content: Text('Syncing')));
        },
      ),
      ListTile(
        leading: const Icon(Icons.restart_alt),
        title: const Text('Rescan from a date'),
        subtitle: const Text('Rebuild history from an earlier point'),
        onTap: () => _rescan(c),
      ),
      ListTile(
        leading: const Icon(Icons.save),
        title: const Text('Save progress now'),
        subtitle: const Text('Write scan progress to disk'),
        onTap: () {
          wallet.saveNow();
          ScaffoldMessenger.of(c).showSnackBar(
            const SnackBar(content: Text('Saved')));
        },
      ),

      const _Header('Network'),
      ListTile(
        leading: const Icon(Icons.dns),
        title: const Text('Server'),
        subtitle: Text(wallet.server ?? YcashConfig.lightwalletd),
      ),

      const _Header('Security'),
      SwitchListTile(
        secondary: const Icon(Icons.fingerprint),
        title: const Text('Require unlock'),
        subtitle: Text(_lockAvailable
          ? 'Ask for biometrics or your device PIN before opening the wallet'
          : 'No screen lock set up on this device'),
        value: _lockEnabled,
        onChanged: _lockAvailable ? (v) => _toggleLock(v) : null,
      ),
      const Padding(
        padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
        child: Text(
          'Your recovery phrase is stored in Android\'s hardware-backed keystore. '
          'This adds a check in front of it. It is not a substitute for writing '
          'the phrase down somewhere safe.',
          style: TextStyle(fontSize: 12),
        ),
      ),

      const _Header('Danger zone'),
      ListTile(
        leading: const Icon(Icons.delete_forever, color: Colors.red),
        title: const Text('Reset wallet', style: TextStyle(color: Colors.red)),
        subtitle: const Text('Delete this wallet and its recovery phrase'),
        onTap: () => _reset(c),
      ),
      const SizedBox(height: 24),
    ]),
  );
}

class _Header extends StatelessWidget {
  final String text;
  const _Header(this.text);
  @override
  Widget build(BuildContext c) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
    child: Text(text.toUpperCase(), style: const TextStyle(
      fontSize: 11, letterSpacing: 1.6, fontWeight: FontWeight.w800)),
  );
}
