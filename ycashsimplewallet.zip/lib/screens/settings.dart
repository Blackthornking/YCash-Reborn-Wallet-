import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/auth.dart';
import '../core/config.dart';
import '../core/pin.dart';
import 'pin.dart';
import '../core/wallet.dart';

/// Wallet settings.
///
/// These actions used to live in an overflow menu on the home app bar, where
/// "Reset wallet" sat one tap away from everything else and a destructive
/// action had no room to explain itself. Each entry here says what it does
/// and what it costs before you commit to it.
class Settings extends StatefulWidget {
  final SimpleWallet wallet;

  /// Called after the wallet is wiped so the app can return to onboarding.
  final VoidCallback onWiped;

  const Settings({super.key, required this.wallet, required this.onWiped});

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  bool _lockEnabled = false;
  bool _lockAvailable = false;
  bool _pinSet = false;

  SimpleWallet get wallet => widget.wallet;
  VoidCallback get onWiped => widget.onWiped;

  @override
  void initState() {
    super.initState();
    _loadLock();
  }

  Future<void> _loadLock() async {
    final enabled = await WalletLock.isEnabled();
    final available = await WalletLock.isAvailable();
    final pin = await WalletPin.isSet();
    if (mounted) setState(() {
      _lockEnabled = enabled; _lockAvailable = available; _pinSet = pin;
    });
  }

  Future<void> _toggleLock(bool want) async {
    // Require a successful authentication *before* turning the lock on, so
    // the gate is proven to work on this device before anything depends on
    // it. Turning it off asks too -- otherwise anyone holding an unlocked
    // phone could simply switch the protection off.
    final ok = await WalletLock.authenticate(
      reason: want ? 'Confirm to require unlock' : 'Confirm to remove the unlock requirement');
    if (!ok) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Not changed — authentication failed')));
      }
      return;
    }
    await WalletLock.setEnabled(want);
    if (mounted) setState(() => _lockEnabled = want);

  }

  /// Show the 24-word recovery phrase.
  ///
  /// Always authenticates first, regardless of the "Require unlock" setting —
  /// this is the one screen that hands over the entire wallet, and someone
  /// holding an already-unlocked phone should still be stopped here. If the
  /// device has no lock at all there is nothing to check against, so the
  /// warning below carries the weight instead.
  Future<void> _showSeed(BuildContext c) async {
    if (await WalletLock.isAvailable()) {
      final ok = await WalletLock.authenticate(
        reason: 'Confirm to reveal your recovery phrase');
      if (!ok) {
        if (c.mounted) {
          ScaffoldMessenger.of(c).showSnackBar(
            const SnackBar(content: Text('Not shown — authentication failed')));
        }
        return;
      }
    }
    // Second factor. Biometrics can be satisfied by a sleeping owner's finger
    // or, on some devices, a face; the PIN has to be known. Revealing the
    // phrase hands over every coin, so it gets both.
    if (!c.mounted) return;
    if (!await PinEntry.ask(c, 'Enter your PIN to reveal the recovery phrase')) return;
    final seed = await wallet.revealSeed();
    if (!c.mounted) return;
    if (seed == null || seed.isEmpty) {
      ScaffoldMessenger.of(c).showSnackBar(
        const SnackBar(content: Text('No recovery phrase stored')));
      return;
    }
    await Navigator.push(c, MaterialPageRoute(builder: (_) => _SeedScreen(seed: seed)));
  }

  Future<void> _rescan(BuildContext c) async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: c,
      initialDate: DateTime(now.year - 1, now.month, now.day),
      firstDate: DateTime(2019, 7, 1),
      lastDate: now,
      helpText: 'Rescan from which date?',
    );
    if (picked == null || !c.mounted) return;

    final ok = await showDialog<bool>(
      context: c,
      builder: (d) => AlertDialog(
        title: const Text('Rescan wallet'),
        content: const Text(
          'Transaction history is rebuilt from this date forward. Your funds '
          'and recovery phrase are untouched — this only changes where '
          'scanning starts.\n\n'
          'Pick a date before your first transaction. Anything received '
          'earlier will not be found.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Rescan')),
        ],
      ),
    );
    if (ok != true || !c.mounted) return;

    // Looking up the block height for a date needs a round of network calls,
    // and stopping the running scan waits for a batch boundary. Both can take
    // a few seconds, so keep the screen honest about being busy rather than
    // appearing frozen.
    showDialog<void>(
      context: c,
      barrierDismissible: false,
      builder: (_) => const AlertDialog(
        content: Row(children: [
          CircularProgressIndicator(),
          SizedBox(width: 20),
          Expanded(child: Text('Finding that date on the chain…')),
        ]),
      ),
    );

    try {
      final h = await wallet.rescanFrom(picked);
      if (!c.mounted) return;
      Navigator.pop(c);
      ScaffoldMessenger.of(c).showSnackBar(
        SnackBar(content: Text('Rescanning from block $h')));
    } catch (e) {
      if (!c.mounted) return;
      Navigator.pop(c);
      ScaffoldMessenger.of(c).showSnackBar(
        SnackBar(content: Text('Could not start rescan: $e')));
    }
  }

  Future<void> _reset(BuildContext c) async {
    final ok = await showDialog<bool>(
      context: c,
      builder: (d) => AlertDialog(
        title: const Text('Reset wallet'),
        content: const Text(
          'This deletes the wallet and its recovery phrase from this device. '
          'Anything not backed up elsewhere is gone for good.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(d, true),
            child: const Text('Reset'),
          ),
        ],
      ),
    );
    if (ok != true || !c.mounted) return;

    // Same reasoning as the recovery phrase: this destroys the only copy of
    // the seed on this device, so it takes biometrics and the PIN.
    if (await WalletLock.isAvailable()) {
      final approved = await WalletLock.authenticate(
        reason: 'Confirm to reset this wallet');
      if (!approved) {
        if (c.mounted) {
          ScaffoldMessenger.of(c).showSnackBar(
            const SnackBar(content: Text('Not reset — authentication failed')));
        }
        return;
      }
    }
    if (!c.mounted) return;
    if (!await PinEntry.ask(c, 'Enter your PIN to reset the wallet')) return;
    if (!c.mounted) return;

    showDialog<void>(
      context: c,
      barrierDismissible: false,
      builder: (_) => const AlertDialog(
        content: Row(children: [
          CircularProgressIndicator(),
          SizedBox(width: 20),
          Expanded(child: Text('Stopping sync and clearing wallet…')),
        ]),
      ),
    );

    await wallet.wipe();
    if (!c.mounted) return;
    Navigator.pop(c);
    onWiped();
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Settings')),
    body: ListView(children: [
      const _Header('Sync'),
      ListTile(
        leading: const Icon(Icons.sync),
        title: const Text('Sync now'),
        subtitle: const Text('Start a sync round immediately'),
        onTap: () {
          wallet.startSync();
          ScaffoldMessenger.of(c).showSnackBar(
            const SnackBar(content: Text('Syncing')));
        },
      ),
      ListTile(
        leading: const Icon(Icons.restart_alt),
        title: const Text('Rescan from a date'),
        subtitle: const Text('Rebuild history from an earlier point'),
        onTap: () => _rescan(c),
      ),
      ListTile(
        leading: const Icon(Icons.save),
        title: const Text('Save progress now'),
        subtitle: const Text('Write scan progress to disk'),
        onTap: () {
          wallet.saveNow();
          ScaffoldMessenger.of(c).showSnackBar(
            const SnackBar(content: Text('Saved')));
        },
      ),

      const _Header('Network'),
      ListTile(
        leading: const Icon(Icons.dns),
        title: const Text('Server'),
        subtitle: Text(wallet.server ?? YcashConfig.lightwalletd),
      ),
      ListTile(
        leading: const Icon(Icons.travel_explore),
        title: const Text('Block explorer'),
        subtitle: const Text(YcashConfig.explorerBase),
        trailing: const Icon(Icons.open_in_new, size: 18),
        onTap: () async {
          final ok = await launchUrl(Uri.parse(YcashConfig.explorerBase),
            mode: LaunchMode.externalApplication);
          if (!ok && c.mounted) {
            ScaffoldMessenger.of(c).showSnackBar(
              const SnackBar(content: Text('Could not open the explorer')));
          }
        },
      ),

      const _Header('Security'),
      SwitchListTile(
        secondary: const Icon(Icons.fingerprint),
        title: const Text('Require unlock'),
        subtitle: Text(_lockAvailable
          ? 'Ask for biometrics or your device PIN before opening the wallet'
          : 'No screen lock set up on this device'),
        value: _lockEnabled,
        onChanged: _lockAvailable ? (v) => _toggleLock(v) : null,
      ),
      const Padding(
        padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
        child: Text(
          'Your recovery phrase is stored in Android\'s hardware-backed keystore. '
          'This adds a check in front of it. It is not a substitute for writing '
          'the phrase down somewhere safe.',
          style: TextStyle(fontSize: 12),
        ),
      ),

      ListTile(
        leading: const Icon(Icons.pin_outlined),
        title: Text(_pinSet ? 'Change PIN' : 'Set a PIN'),
        subtitle: Text(_pinSet
          ? 'Required for the recovery phrase and for resetting'
          : 'Not set — needed before the phrase or reset can be used'),
        onTap: () async {
          // Changing an existing PIN requires the current one first.
          if (_pinSet && !await PinEntry.ask(c, 'Enter your current PIN')) return;
          if (!c.mounted) return;
          final done = await Navigator.push<bool>(c,
            MaterialPageRoute(builder: (_) => const PinSetup()));
          if (done == true) {
            await _loadLock();
            if (c.mounted) {
              ScaffoldMessenger.of(c).showSnackBar(
                const SnackBar(content: Text('PIN saved')));
            }
          }
        },
      ),
      ListTile(
        leading: const Icon(Icons.key),
        title: const Text('Recovery phrase'),
        subtitle: const Text('View your 24 words'),
        onTap: () => _showSeed(c),
      ),

      const _Header('Danger zone'),
      ListTile(
        leading: const Icon(Icons.delete_forever, color: Colors.red),
        title: const Text('Reset wallet', style: TextStyle(color: Colors.red)),
        subtitle: const Text('Delete this wallet and its recovery phrase'),
        onTap: () => _reset(c),
      ),
      const SizedBox(height: 24),
    ]),
  );
}

class _Header extends StatelessWidget {
  final String text;
  const _Header(this.text);
  @override
  Widget build(BuildContext c) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
    child: Text(text.toUpperCase(), style: const TextStyle(
      fontSize: 11, letterSpacing: 1.6, fontWeight: FontWeight.w800)),
  );
}


/// Displays the recovery phrase, numbered.
///
/// Numbering matters: the order is part of the secret, and people copying 24
/// words by hand lose their place. No screenshot blocking here — that would
/// need a platform channel to set FLAG_SECURE, which is worth doing but is a
/// change to the Activity rather than this screen.
class _SeedScreen extends StatelessWidget {
  final String seed;
  const _SeedScreen({required this.seed});

  @override
  Widget build(BuildContext c) {
    final words = seed.trim().split(RegExp(r'\s+'));
    return Scaffold(
      appBar: AppBar(title: const Text('Recovery phrase')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.amber.withValues(alpha: 0.5)),
            borderRadius: BorderRadius.circular(14),
            color: Colors.amber.withValues(alpha: 0.08)),
          child: const Text(
            'Anyone with these 24 words can spend your funds. Write them down '
            'on paper and keep them offline. Never type them into a website, '
            'and never send them to anyone — including anyone claiming to be '
            'support.',
            style: TextStyle(fontSize: 13)),
        ),
        const SizedBox(height: 20),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (var i = 0; i < words.length; i++)
            Container(
              width: 150,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                border: Border.all(color: Theme.of(c).dividerColor),
                borderRadius: BorderRadius.circular(10)),
              child: Row(children: [
                SizedBox(width: 24, child: Text('${i + 1}',
                  style: TextStyle(fontSize: 12, color: Theme.of(c).hintColor))),
                Expanded(child: Text(words[i],
                  style: const TextStyle(fontWeight: FontWeight.w600))),
              ]),
            ),
        ]),
        const SizedBox(height: 24),
        OutlinedButton.icon(
          onPressed: () {
            Clipboard.setData(ClipboardData(text: seed));
            ScaffoldMessenger.of(c).showSnackBar(const SnackBar(
              content: Text('Copied — clear your clipboard when done')));
          },
          icon: const Icon(Icons.copy, size: 18),
          label: const Text('Copy phrase')),
        const SizedBox(height: 32),
      ]));
  }
}
