import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/config.dart';
import '../core/wallet.dart';

String _fmtBytes(int b) {
  if (b >= 1024 * 1024 * 1024) return '${(b / (1024 * 1024 * 1024)).toStringAsFixed(2)} GiB';
  if (b >= 1024 * 1024) return '${(b / (1024 * 1024)).toStringAsFixed(1)} MiB';
  if (b >= 1024) return '${(b / 1024).toStringAsFixed(1)} KiB';
  return '$b B';
}

String _fmtDuration(double seconds) {
  if (seconds <= 0 || seconds.isInfinite || seconds.isNaN) return '—';
  final s = seconds.round();
  if (s < 60) return '${s}s';
  if (s < 3600) return '${s ~/ 60}m ${s % 60}s';
  final h = s ~/ 3600;
  return '${h}h ${(s % 3600) ~/ 60}m';
}

/// Live scanner statistics.
///
/// Everything here is measured, not estimated. Where a figure cannot be
/// derived from what the engine actually reports it is left out rather than
/// filled in with a plausible-looking number — a statistics page that invents
/// values is worse than no page, because it will be trusted.
class ScannerStats extends StatefulWidget {
  final SimpleWallet wallet;
  const ScannerStats({super.key, required this.wallet});
  @override
  State<ScannerStats> createState() => _ScannerStatsState();
}

class _ScannerStatsState extends State<ScannerStats> {
  StreamSubscription? _sub;
  SimpleSyncStatus? _s;
  double _best = 0;

  @override
  void initState() {
    super.initState();
    _loadBest();
    _sub = widget.wallet.status.stream.listen((s) {
      if (!mounted) return;
      setState(() => _s = s);
      _recordBest(s.blocksPerSec);
    });
  }

  Future<void> _loadBest() async {
    try {
      final p = await SharedPreferences.getInstance();
      var v = p.getDouble(YcashConfig.bestBlocksPerSecKey) ?? 0;
      // Discard a record written before the sampler was fixed (see home.dart).
      if (v > YcashConfig.maxPlausibleBlocksPerSec) {
        v = 0;
        await p.remove(YcashConfig.bestBlocksPerSecKey);
      }
      if (mounted) setState(() => _best = v);
    } catch (_) {}
  }

  Future<void> _recordBest(double rate) async {
    if (rate <= _best || rate <= 0) return;
    if (rate > YcashConfig.maxPlausibleBlocksPerSec) return;
    setState(() => _best = rate);
    try {
      final p = await SharedPreferences.getInstance();
      await p.setDouble(YcashConfig.bestBlocksPerSecKey, rate);
    } catch (_) {}
  }

  Future<void> _resetBest() async {
    setState(() => _best = 0);
    try {
      final p = await SharedPreferences.getInstance();
      await p.remove(YcashConfig.bestBlocksPerSecKey);
    } catch (_) {}
  }

  @override
  void dispose() { _sub?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext c) {
    final s = _s;
    if (s == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Scanner statistics')),
        body: const Center(child: Text('Waiting for the first batch…')));
    }

    final remaining = (s.tip - s.height).clamp(0, 1 << 62);
    final eta = s.blocksPerSec > 0 ? remaining / s.blocksPerSec : 0.0;
    final bytesPerBlock = s.height > s.birthday && s.downloadedBytes > 0
      ? s.downloadedBytes / (s.height - s.birthday) : 0.0;
    final mibPerSec = s.lastFetchSecs > 0 && s.currentBatchSize > 0 && bytesPerBlock > 0
      ? (bytesPerBlock * s.currentBatchSize) / s.lastFetchSecs / (1024 * 1024) : 0.0;
    final total = s.lastFetchSecs + s.lastScanSecs;
    final fetchPct = total > 0 ? s.lastFetchSecs / total * 100 : 0.0;
    final scanPct = total > 0 ? s.lastScanSecs / total * 100 : 0.0;

    return Scaffold(
      appBar: AppBar(title: const Text('Scanner statistics')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        _Section('Throughput', [
          _Stat('Blocks/sec (live)', s.liveBlocksPerSec > 0
            ? s.liveBlocksPerSec.toStringAsFixed(1) : '—'),
          _Stat('Blocks/sec (last batch)', s.blocksPerSec.toStringAsFixed(1)),
          _Stat('Best ever', _best > 0 ? '${_best.toStringAsFixed(1)} blocks/s' : '—',
            highlight: true),
          _Stat('Download rate', mibPerSec > 0 ? '${mibPerSec.toStringAsFixed(2)} MiB/s' : '—'),
        ]),
        _Section('Where the time goes', [
          _Stat('Last batch', '${s.lastBatchSecs.toStringAsFixed(2)}s'
            '${s.lastBatchBlocks > 0 ? "  (${s.lastBatchBlocks} blocks)" : ""}'),
          _Stat('Network wait', total > 0
            ? '${s.lastFetchSecs.toStringAsFixed(2)}s  (${fetchPct.toStringAsFixed(0)}%)' : '—'),
          _Stat('Scan work', total > 0
            ? '${s.lastScanSecs.toStringAsFixed(2)}s  (${scanPct.toStringAsFixed(0)}%)' : '—'),
        ]),
        _Section('Cryptography', [
          _Stat('Outputs scanned', '${s.outputsScanned}'),
          _Stat('Successful decryptions', '${s.outputsMatched}'),
          _Stat('Trial decryption time', '${s.cryptoSeconds.toStringAsFixed(1)}s'),
          _Stat('Time per output', s.outputsScanned > 0
            ? '${s.microsPerOutput.toStringAsFixed(1)} µs' : '—'),
          _Stat('Commit time', '${s.commitSeconds.toStringAsFixed(1)}s'),
        ]),
        _Section('Batching', [
          _Stat('Average crypto batch', s.cryptoGroups > 0
            ? '${s.avgCryptoBatch.toStringAsFixed(0)} outputs' : '—',
            highlight: s.cryptoGroups > 0 && s.avgCryptoBatch < 64),
          _Stat('Matcher calls', '${s.cryptoGroups}'),
          _Stat('Prepared-key cache', (s.ivkCacheHits + s.ivkCacheMisses) > 0
            ? '${(s.ivkCacheHits / (s.ivkCacheHits + s.ivkCacheMisses) * 100).toStringAsFixed(1)}% hit'
            : '—'),
          _Stat('Current batch', '${s.currentBatchSize} blocks'),
          _Stat('Workers', '${s.workerCount}'),
          _Stat('Prefetch depth', '${s.prefetchDepth} ranges'),
        ]),
        _Section('Progress', [
          _Stat('Scanned', '${s.height}'),
          _Stat('Chain tip', '${s.tip}'),
          _Stat('Remaining', '$remaining blocks'),
          _Stat('Estimated time left', _fmtDuration(eta)),
          _Stat('Downloaded this run', _fmtBytes(s.downloadedBytes)),
          _Stat('Bytes/block', bytesPerBlock > 0
            ? '${bytesPerBlock.toStringAsFixed(0)} B' : '—'),
        ]),
        _Section('Engine', [
          _Stat('Phase', s.phase),
          _Stat('Scan start', s.initialState.isEmpty ? '—' : s.initialState),
          _Stat('Server', widget.wallet.server ?? YcashConfig.lightwalletd),
        ]),
        const SizedBox(height: 12),
        TextButton(onPressed: _resetBest, child: const Text('Reset best-ever record')),
        const SizedBox(height: 24),
      ]));
  }
}

/// Turns the measured figures into a single verdict and concrete next step.
///
/// The classification below only uses numbers the engine genuinely reports.
/// Metrics that would need instrumentation this build does not have — crypto
/// time per output, cache hit rates, allocation counts, worker utilisation —
/// are deliberately absent rather than approximated.
class ScannerDiagnostics extends StatefulWidget {
  final SimpleWallet wallet;
  const ScannerDiagnostics({super.key, required this.wallet});
  @override
  State<ScannerDiagnostics> createState() => _ScannerDiagnosticsState();
}

class _ScannerDiagnosticsState extends State<ScannerDiagnostics> {
  StreamSubscription? _sub;
  SimpleSyncStatus? _s;
  Map<String, dynamic>? _info;
  String? _infoErr;

  @override
  void initState() {
    super.initState();
    _sub = widget.wallet.status.stream.listen((s) {
      if (mounted) setState(() => _s = s);
    });
    _loadInfo();
  }

  String _panic = '';

  Future<void> _loadInfo() async {
    try {
      final i = await widget.wallet.serverInfoAsync();
      if (mounted) setState(() => _info = i);
    } catch (e) {
      if (mounted) setState(() => _infoErr = '$e');
    }
    try {
      final p = await widget.wallet.lastPanicAsync();
      if (mounted) setState(() => _panic = p);
    } catch (_) {}
  }

  @override
  void dispose() { _sub?.cancel(); super.dispose(); }

  ({String verdict, String detail, String action, Color colour}) _diagnose(SimpleSyncStatus s) {
    final total = s.lastFetchSecs + s.lastScanSecs;

    if (total <= 0) {
      return (
        verdict: 'Not enough data yet',
        detail: 'No batch has completed since this sync started.',
        action: 'Leave the app open until at least one batch finishes.',
        colour: Colors.grey);
    }
    if (s.transparentWarning.isNotEmpty) {
      return (
        verdict: 'Transparent lookups unavailable',
        detail: 'The server refused the transparent-address RPC, so any '
                'balance on an s1… address cannot be detected. Shielded '
                'scanning is unaffected.',
        action: 'Try a different lightwalletd server.',
        colour: Colors.amber);
    }

    final fetchShare = s.lastFetchSecs / total;
    if (fetchShare > 0.6) {
      return (
        verdict: 'Network-bound',
        detail: '${(fetchShare * 100).toStringAsFixed(0)}% of each batch is spent '
                'waiting for compact blocks, not scanning them. More workers '
                'will not help.',
        action: 'A faster connection or a closer server is the only thing that '
                'moves this. Raising prefetch depth may help if the link has '
                'spare bandwidth but high latency.',
        colour: Colors.lightBlueAccent);
    }
    if (fetchShare < 0.25) {
      // Scan-dominated. Batch size matters because the per-batch fixed costs —
      // notably the transparent-address lookups — are amortised over it.
      // Now measurable: if the matcher is being handed only a few outputs per
      // call, the workers are starved no matter how many there are, and the
      // batched-inversion win never materialises either.
      if (s.cryptoGroups > 0 && s.avgCryptoBatch < 64) {
        return (
          verdict: 'Crypto batch starvation',
          detail: 'The matcher averages ${s.avgCryptoBatch.toStringAsFixed(0)} '
                  'outputs per call at ${s.microsPerOutput.toStringAsFixed(1)} µs '
                  'per output. Below ~64 the thread pool cannot be kept busy and '
                  'batched inversion saves almost nothing.',
          action: 'Widen cross-block accumulation so one matcher call spans more '
                  'blocks. Ycash blocks carry very few shielded outputs each, so '
                  'per-block batching is always starved.',
          colour: Colors.orangeAccent);
      }
      if (s.commitNanos > s.cryptoNanos && s.cryptoNanos > 0) {
        return (
          verdict: 'Commit-bound',
          detail: 'Tree and witness appends (${s.commitSeconds.toStringAsFixed(1)}s) '
                  'are taking longer than trial decryption '
                  '(${s.cryptoSeconds.toStringAsFixed(1)}s). That work is '
                  'inherently sequential.',
          action: 'More crypto workers will not help. The gain is in doing fewer '
                  'appends — which means scanning fewer blocks, so set a birthday '
                  'close to your first transaction.',
          colour: Colors.purpleAccent);
      }
      if (s.currentBatchSize < 6000) {
        return (
          verdict: 'Batch-starved',
          detail: 'Scanning dominates, but the batch is only '
                  '${s.currentBatchSize} blocks. Per-batch fixed costs are '
                  'being paid too often.',
          action: 'The adaptive controller should raise this on its own. If it '
                  'stays low, the batch is being timed out and shrunk — raise '
                  'the AWBS floor.',
          colour: Colors.orangeAccent);
      }
      return (
        verdict: 'CPU-bound',
        detail: '${(100 - fetchShare * 100).toStringAsFixed(0)}% of each batch is '
                'trial decryption and commit work, with ${s.workerCount} workers '
                'and ${s.currentBatchSize}-block batches.',
        action: 'Enable LTO and codegen-units=1 in the release profile. Beyond '
                'that, the gain is in cross-block batching so workers see '
                'thousands of outputs at once rather than a handful per block.',
        colour: Colors.greenAccent);
    }
    return (
      verdict: 'Balanced',
      detail: 'Network wait and scan work are within range of each other '
              '(${(fetchShare * 100).toStringAsFixed(0)}% / '
              '${(100 - fetchShare * 100).toStringAsFixed(0)}%).',
      action: 'No single bottleneck dominates. The largest remaining win is not '
              'scanning blocks you do not need — restore from a date close to '
              'your first transaction.',
      colour: Colors.greenAccent);
  }

  @override
  Widget build(BuildContext c) {
    final s = _s;
    if (s == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Diagnostics')),
        body: const Center(child: Text('Waiting for the first batch…')));
    }
    final d = _diagnose(s);
    return Scaffold(
      appBar: AppBar(title: const Text('Diagnostics')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: d.colour.withValues(alpha: 0.10),
            border: Border.all(color: d.colour.withValues(alpha: 0.5)),
            borderRadius: BorderRadius.circular(16)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('BOTTLENECK', style: TextStyle(
              fontSize: 11, letterSpacing: 1.4, fontWeight: FontWeight.w700,
              color: Theme.of(c).hintColor)),
            const SizedBox(height: 6),
            Text(d.verdict, style: TextStyle(
              fontSize: 22, fontWeight: FontWeight.w800, color: d.colour)),
            const SizedBox(height: 12),
            Text(d.detail, style: const TextStyle(fontSize: 14, height: 1.4)),
          ])),
        const SizedBox(height: 20),
        const Text('What to do', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Text(d.action, style: const TextStyle(fontSize: 14, height: 1.4)),
        if (_panic.isNotEmpty) ...[
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.redAccent.withValues(alpha: 0.10),
              border: Border.all(color: Colors.redAccent.withValues(alpha: 0.6)),
              borderRadius: BorderRadius.circular(14)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('LAST NATIVE CRASH', style: TextStyle(
                fontSize: 11, letterSpacing: 1.4, fontWeight: FontWeight.w700,
                color: Colors.redAccent)),
              const SizedBox(height: 8),
              SelectableText(_panic,
                style: const TextStyle(fontFamily: 'monospace', fontSize: 11)),
              const SizedBox(height: 10),
              // Empty after a crash means no Rust code ran -- the process was
              // killed from outside rather than panicking, which points at
              // memory rather than a bug in the wallet.
              Text('Recorded before the process died. If the app vanished but '
                   'nothing appears here, it was killed by Android rather than '
                   'crashing in the wallet.',
                style: TextStyle(fontSize: 11, color: Theme.of(c).hintColor)),
              const SizedBox(height: 6),
              TextButton(
                onPressed: () async {
                  await widget.wallet.clearPanicAsync();
                  if (context.mounted) setState(() => _panic = '');
                },
                child: const Text('Clear')),
            ])),
        ],
        const SizedBox(height: 28),
        const Text('Server consensus', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        if (_infoErr != null)
          Text('Could not read server info: $_infoErr',
            style: const TextStyle(color: Colors.redAccent, fontSize: 12))
        else if (_info == null)
          const Text('Reading…', style: TextStyle(fontSize: 13))
        else ...[
          // This is the value transactions are signed with. If a send is
          // rejected, this is the first number to check.
          _Stat('Consensus branch id', '${_info!['consensus_branch_id'] ?? '—'}', highlight: true),
          _Stat('Chain', '${_info!['chain_name'] ?? '—'}'),
          _Stat('Sapling activation', '${_info!['sapling_activation_height'] ?? '—'}'),
          _Stat('Server block height', '${_info!['latest_block_height'] ?? '—'}'),
          _Stat('Server version', '${_info!['version'] ?? '—'}'),
          _Stat('Vendor', '${_info!['vendor'] ?? '—'}'),
          _Stat('Transparent support', '${_info!['taddr_support'] ?? '—'}'),
        ],
        const SizedBox(height: 28),
        const Text('Measured this batch', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        _Stat('Network wait', '${s.lastFetchSecs.toStringAsFixed(2)}s'),
        _Stat('Scan work', '${s.lastScanSecs.toStringAsFixed(2)}s'),
        _Stat('Batch size', '${s.currentBatchSize} blocks'),
        _Stat('Workers', '${s.workerCount}'),
        _Stat('Throughput', '${s.blocksPerSec.toStringAsFixed(1)} blocks/s'),
        _Stat('Avg crypto batch', s.cryptoGroups > 0
          ? '${s.avgCryptoBatch.toStringAsFixed(0)} outputs' : '—'),
        _Stat('Time per output', s.outputsScanned > 0
          ? '${s.microsPerOutput.toStringAsFixed(1)} µs' : '—'),
        _Stat('Crypto vs commit',
          '${s.cryptoSeconds.toStringAsFixed(1)}s / ${s.commitSeconds.toStringAsFixed(1)}s'),
        const SizedBox(height: 24),
        Text(
          'Crypto time, commit time, decryption counts and cache hit rate are '
          'measured directly. Allocation counts, per-worker utilisation and '
          'thermal state are not shown because this build does not measure '
          'them — an estimate on a diagnostics page would get acted on.',
          style: TextStyle(fontSize: 12, color: Theme.of(c).hintColor)),
        const SizedBox(height: 24),
      ]));
  }
}

class _Section extends StatelessWidget {
  final String title;
  final List<Widget> children;
  const _Section(this.title, this.children);
  @override
  Widget build(BuildContext c) => Column(
    crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(4, 18, 4, 8),
        child: Text(title.toUpperCase(), style: TextStyle(
          fontSize: 11, letterSpacing: 1.4, fontWeight: FontWeight.w700,
          color: Theme.of(c).hintColor))),
      Container(
        decoration: BoxDecoration(
          border: Border.all(color: Theme.of(c).dividerColor),
          borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Column(children: children)),
    ]);
}

class _Stat extends StatelessWidget {
  final String label, value;
  final bool highlight;
  const _Stat(this.label, this.value, {this.highlight = false});
  @override
  Widget build(BuildContext c) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(child: Text(label,
        style: TextStyle(fontSize: 13, color: Theme.of(c).hintColor))),
      const SizedBox(width: 12),
      Flexible(child: Text(value, textAlign: TextAlign.right,
        style: TextStyle(
          fontSize: 13,
          fontWeight: highlight ? FontWeight.w800 : FontWeight.w600,
          color: highlight ? Colors.greenAccent : null))),
    ]));
}


/// Exactly what the wallet believes it holds, as the engine recorded it.
///
/// A transparent input's signature commits to the input's amount and
/// scriptPubKey. The script is checked locally when the input is added -- its
/// pubkey hash must match the signing key -- but the amount is not verified
/// against anything until the network rejects the transaction. So a recorded
/// value that disagrees with the chain produces exactly
/// "mandatory-script-verify-flag-failed" and nothing earlier catches it.
/// Comparing these figures against a block explorer settles that in seconds.
class WalletNotes extends StatefulWidget {
  final SimpleWallet wallet;
  const WalletNotes({super.key, required this.wallet});
  @override
  State<WalletNotes> createState() => _WalletNotesState();
}

class _WalletNotesState extends State<WalletNotes> {
  Map<String, dynamic>? _data;
  String? _err;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    // Off the UI isolate: this takes the native state lock, which a send or a
    // rescan can hold for seconds.
    try {
      final d = await widget.wallet.notesAsync();
      if (mounted) setState(() => _data = d);
    } catch (e) {
      if (mounted) setState(() => _err = '$e');
    }
  }

  List<Widget> _utxoTiles(BuildContext c, String key, String label) {
    final list = (_data?[key] as List?) ?? const [];
    if (list.isEmpty) return [];
    return [
      Padding(
        padding: const EdgeInsets.fromLTRB(4, 20, 4, 8),
        child: Text(label.toUpperCase(), style: TextStyle(
          fontSize: 11, letterSpacing: 1.4, fontWeight: FontWeight.w700,
          color: Theme.of(c).hintColor))),
      for (final u in list)
        Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            border: Border.all(color: Theme.of(c).dividerColor),
            borderRadius: BorderRadius.circular(12)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SelectableText('${(((u['value'] as num?)?.toInt() ?? 0) / 1e8).toStringAsFixed(8)} YEC',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            SelectableText('zatoshi ${u['value'] ?? '—'}',
              style: TextStyle(fontSize: 12, color: Theme.of(c).hintColor)),
            const SizedBox(height: 6),
            SelectableText('${u['address'] ?? '—'}',
              style: const TextStyle(fontFamily: 'monospace', fontSize: 11)),
            const SizedBox(height: 6),
            SelectableText('txid ${u['created_in_txid'] ?? u['txid'] ?? '—'}',
              style: const TextStyle(fontFamily: 'monospace', fontSize: 11)),
            const SizedBox(height: 6),
            SelectableText('output index ${u['output_index'] ?? '—'}  •  height ${u['created_in_block'] ?? u['height'] ?? '—'}',
              style: TextStyle(fontSize: 11, color: Theme.of(c).hintColor)),
            const SizedBox(height: 6),
            SelectableText('script ${u['scriptkey'] ?? '—'}',
              style: const TextStyle(fontFamily: 'monospace', fontSize: 10)),
          ])),
    ];
  }

  @override
  Widget build(BuildContext c) {
    if (_err == null && _data == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Notes and UTXOs')),
        body: const Center(child: CircularProgressIndicator()));
    }
    if (_err != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Notes and UTXOs')),
        body: Center(child: Padding(padding: const EdgeInsets.all(24),
          child: Text('Could not read wallet state:\n\n$_err',
            textAlign: TextAlign.center))));
    }
    final zNotes = (_data?['unspent_notes'] as List?) ?? const [];
    return Scaffold(
      appBar: AppBar(title: const Text('Notes and UTXOs')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(
          'Compare these against a block explorer. The value and script below '
          'are what this wallet signs over — if either disagrees with the '
          'chain, a transparent send will be rejected by the network no matter '
          'how correct the rest of the transaction is.',
          style: TextStyle(fontSize: 12, color: Theme.of(c).hintColor)),
        ..._utxoTiles(c, 'utxos', 'Unspent transparent outputs'),
        ..._utxoTiles(c, 'pending_utxos', 'Pending transparent outputs'),
        ..._utxoTiles(c, 'spent_utxos', 'Spent transparent outputs'),
        Padding(
          padding: const EdgeInsets.fromLTRB(4, 20, 4, 8),
          child: Text('SHIELDED NOTES', style: TextStyle(
            fontSize: 11, letterSpacing: 1.4, fontWeight: FontWeight.w700,
            color: Theme.of(c).hintColor))),
        Text(zNotes.isEmpty ? 'None.' : '${zNotes.length} unspent note(s)',
          style: const TextStyle(fontSize: 13)),
        const SizedBox(height: 32),
      ]));
  }
}
