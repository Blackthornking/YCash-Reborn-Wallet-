import 'package:flutter/material.dart';
import '../core/wallet.dart';
import '../design/tokens.dart';

class Onboarding extends StatefulWidget {
  final SimpleWallet wallet; final VoidCallback onDone;
  const Onboarding({super.key,required this.wallet,required this.onDone});
  @override State<Onboarding> createState()=>_OnboardingState();
}
class _OnboardingState extends State<Onboarding>{
  bool restore=false,busy=false; String? error; final seed=TextEditingController();
  Future<void> go(Future<void> Function() f) async {setState(()=>busy=true); try{await f();if(mounted)widget.onDone();}catch(e){if(mounted)setState(()=>error=e.toString());}finally{if(mounted)setState(()=>busy=false);}}
  @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:Padding(padding:const EdgeInsets.all(24),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const Spacer(), Image.asset('assets/branding/ycash_logo.png',width:64), const SizedBox(height:24),
    const Text('Ycash',style:TextStyle(fontSize:42,fontWeight:FontWeight.w800)),const SizedBox(height:8),
    const Text('A simple Ycash wallet. Send, receive and sync.',style:TextStyle(fontSize:17,color:YColors.textSecondary)),
    const SizedBox(height:36),
    if(restore) ...[
      TextField(controller:seed,maxLines:4,decoration:const InputDecoration(labelText:'24-word recovery phrase')),
      const SizedBox(height:12),
      if(error!=null) Text(error!,style:const TextStyle(color:YColors.danger)),
      const SizedBox(height:12),
      SizedBox(width:double.infinity,child:ElevatedButton(onPressed:busy?null:()=>go(()=>widget.wallet.restore(seed.text)),child:Text(busy?'Opening…':'Restore wallet'))),
      TextButton(onPressed:busy?null:()=>setState(()=>restore=false),child:const Text('Back')),
    ] else ...[
      if(error!=null) Text(error!,style:const TextStyle(color:YColors.danger)),
      SizedBox(width:double.infinity,child:ElevatedButton(onPressed:busy?null:()=>go(widget.wallet.create),child:Text(busy?'Creating…':'Create new wallet'))),
      SizedBox(width:double.infinity,child:OutlinedButton(onPressed:busy?null:()=>setState(()=>restore=true),child:const Text('Restore wallet'))),
    ],
    const Spacer(),
    const Text('Ycash-only • Sapling • no swaps • no legacy wallet import',style:TextStyle(fontSize:12,color:YColors.textMuted)),
  ]))));
}
