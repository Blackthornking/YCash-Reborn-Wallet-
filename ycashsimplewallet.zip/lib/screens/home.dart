import 'dart:async';
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import 'package:decimal/decimal.dart';
import '../core/config.dart';
import '../core/wallet.dart';
import '../design/tokens.dart';

class Home extends StatefulWidget { final SimpleWallet wallet; const Home({super.key,required this.wallet}); @override State<Home> createState()=>_HomeState(); }
class _HomeState extends State<Home>{
  StreamSubscription? sub; SimpleSyncStatus? sync; Map<String,dynamic>? bal; String? address; List<dynamic> history=[];
  Timer? dataTimer;
  @override void initState(){
    super.initState();
    _refresh();
    sub=widget.wallet.status.stream.listen((s){
      if(!mounted)return;
      final wasSyncing=sync?.syncing??false;
      setState(()=>sync=s);
      // Balances, addresses and history were previously read exactly once,
      // in initState, and then only again on a manual pull-to-refresh. So a
      // wallet could scan all the way to the chain tip in the background and
      // still show a zero balance and an empty history until the user
      // happened to swipe down. Refresh on the sync-finished edge.
      if(wasSyncing && !s.syncing) _refresh();
    });
    // And refresh periodically while a long initial scan is running, so
    // incoming transactions appear as they are found rather than only at the
    // very end of a multi-hour catch-up.
    dataTimer=Timer.periodic(const Duration(seconds:5),(_){ if((sync?.syncing??false)) _refresh(); });
  }
  @override void dispose(){sub?.cancel();dataTimer?.cancel();super.dispose();}
  void _refresh(){try{bal=widget.wallet.balances();address=(widget.wallet.addresses()['z_addresses'] as List).first.toString();history=widget.wallet.history();}catch(_){} if(mounted)setState((){});}
  String get _statusLine {
    final s=sync;
    if(s==null) return 'Connecting…';
    if(s.failed) return 'Sync stopped — retrying';
    if(s.phase=='connecting') return 'Connecting to ${widget.wallet.server ?? 'the Ycash network'}…';
    if(s.syncing) return s.tip>0 ? 'Syncing ${s.height} / ${s.tip}' : 'Syncing ${s.height}…';
    return s.height>0 ? 'Synced at ${s.height}' : 'Waiting to sync';
  }
  double get total=>((bal?['spendable_zbalance'] as num?)?.toDouble()??0)/1e8+((bal?['tbalance'] as num?)?.toDouble()??0)/1e8;
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Ycash'),actions:[IconButton(onPressed:(){widget.wallet.startSync();},icon:const Icon(Icons.sync))]),body:RefreshIndicator(onRefresh:()async{widget.wallet.startSync();await Future.delayed(const Duration(milliseconds:400));_refresh();},child:ListView(padding:const EdgeInsets.all(16),children:[
    if(sync?.syncing??false) LinearProgressIndicator(value:sync!.progress),
    const SizedBox(height:16),
    Container(padding:const EdgeInsets.all(24),decoration:BoxDecoration(borderRadius:BorderRadius.circular(28),border:Border.all(color:Theme.of(c).dividerColor)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('BALANCE',style:TextStyle(fontSize:11,letterSpacing:1.6,fontWeight:FontWeight.w800)),
      const SizedBox(height:12),Text('${total.toStringAsFixed(8)} YEC',style:const TextStyle(fontSize:36,fontWeight:FontWeight.w700)),
      const SizedBox(height:10),Text(_statusLine,style:TextStyle(color:Theme.of(c).hintColor)),
      if(sync?.error!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text(sync!.error!,style:const TextStyle(color:YColors.danger))),
    ])),
    const SizedBox(height:16),
    Row(children:[Expanded(child:FilledButton.icon(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>Send(wallet:widget.wallet))),icon:const Icon(Icons.arrow_upward),label:const Text('Send'))),const SizedBox(width:12),Expanded(child:FilledButton.tonalIcon(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>Receive(address:address??''))),icon:const Icon(Icons.qr_code),label:const Text('Receive')))]),
    const SizedBox(height:24),const Text('Recent activity',style:TextStyle(fontSize:18,fontWeight:FontWeight.w700)),
    if(history.isEmpty)const Padding(padding:EdgeInsets.all(20),child:Text('No transactions yet.',textAlign:TextAlign.center))
    else ...history.take(5).map((x)=>ListTile(title:Text(x['txid']?.toString().substring(0,12)??'Transaction'),subtitle:Text(x['datetime']?.toString()??''),trailing:Text('${x['amount']??0}'))),
    const SizedBox(height:24),Text('Ycash-native sync • batch ${YcashConfig.modernBatchSize} • ${YcashConfig.modernWorkers} workers${widget.wallet.server!=null ? '\n${widget.wallet.server}' : ''}',style:TextStyle(fontSize:12,color:Theme.of(c).hintColor)),
  ])));
}

class Receive extends StatelessWidget {final String address;const Receive({super.key,required this.address});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Receive')),body:Padding(padding:const EdgeInsets.all(24),child:Column(children:[const Text('Shielded address',style:TextStyle(fontSize:18,fontWeight:FontWeight.w700)),const SizedBox(height:24),if(address.isNotEmpty)Container(padding:const EdgeInsets.all(16),color:Colors.white,child:QrImageView(data:address,size:230)),const SizedBox(height:20),SelectableText(address,textAlign:TextAlign.center),const SizedBox(height:16),Row(children:[Expanded(child:OutlinedButton(onPressed:()=>Share.share(address),child:const Text('Share'))),const SizedBox(width:10),Expanded(child:OutlinedButton(onPressed:()=>Navigator.pop(c),child:const Text('Done')))])])));
}

class Send extends StatefulWidget {final SimpleWallet wallet;const Send({super.key,required this.wallet});@override State<Send> createState()=>_SendState();}
class _SendState extends State<Send>{final a=TextEditingController(),m=TextEditingController(),amt=TextEditingController();bool busy=false;String? err;
Future<void> go()async{setState(()=>err=null);int amount;try{amount=(Decimal.parse(amt.text.trim())*Decimal.fromInt(100000000)).toBigInt().toInt();}catch(_){setState(()=>err='Enter a valid YEC amount');return;}if(a.text.trim().isEmpty){setState(()=>err='Enter a Ycash address');return;}setState(()=>busy=true);try{final p=widget.wallet.planSend(to:a.text.trim(),amount:amount,memo:m.text.trim().isEmpty?null:m.text.trim());if(!mounted)return;final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Confirm send'),content:Text('Send ${amount/1e8} YEC\\nFee ${(p['fee']??0)/1e8} YEC'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Send'))]));if(ok==true){final tx=widget.wallet.broadcast(p);if(mounted){ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Sent: $tx')));Navigator.pop(context);}}}catch(e){if(mounted)setState(()=>err='Send failed: $e');}finally{if(mounted)setState(()=>busy=false);}}
@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Send')),body:ListView(padding:const EdgeInsets.all(24),children:[TextField(controller:a,decoration:const InputDecoration(labelText:'Ycash recipient address')),const SizedBox(height:12),TextField(controller:amt,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Amount (YEC)')),const SizedBox(height:12),TextField(controller:m,decoration:const InputDecoration(labelText:'Memo (optional)'),maxLines:2),if(err!=null)Padding(padding:const EdgeInsets.symmetric(vertical:12),child:Text(err!,style:const TextStyle(color:YColors.danger))),const SizedBox(height:20),FilledButton(onPressed:busy?null:go,child:Text(busy?'Sending…':'Review and send'))]));}
