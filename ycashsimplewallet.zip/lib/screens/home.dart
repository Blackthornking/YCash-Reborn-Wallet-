import 'dart:async';
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import 'package:decimal/decimal.dart';
import '../core/config.dart';
import '../core/wallet.dart';
import '../design/tokens.dart';

class Home extends StatefulWidget {
  final SimpleWallet wallet;
  /// Called after the wallet has been wiped, so the app can drop back to
  /// onboarding. SimpleWallet.wipe() existed but was wired to nothing, which
  /// left clearing the app's storage in Android settings as the only way to
  /// start over -- awkward when a wallet has to be recreated between test
  /// builds.
  final VoidCallback onWiped;
  const Home({super.key,required this.wallet,required this.onWiped});
  @override State<Home> createState()=>_HomeState();
}
class _HomeState extends State<Home>{
  StreamSubscription? sub; SimpleSyncStatus? sync; Map<String,dynamic>? bal; String? address; List<dynamic> history=[];
  /// The wallet's transparent address. Only the shielded one was ever shown,
  /// so there was no way to check whether the t-address the wallet is
  /// actually watching matches the one that received a transparent payment.
  String? taddress;
  Timer? dataTimer;
  /// First block height seen this session, so the screen can show how far
  /// this wallet actually has to scan. A wallet seeded from the bundled
  /// checkpoint table starts around block 960,000; one seeded from the
  /// server's own tree state starts near the chain tip. Showing it makes
  /// which of the two happened obvious at a glance.
  int? startHeight;
  @override void initState(){
    super.initState();
    _refresh();
    sub=widget.wallet.status.stream.listen((s){
      if(!mounted)return;
      final wasSyncing=sync?.syncing??false;
      setState((){
        sync=s;
        if(startHeight==null && s.height>0) startHeight=s.height;
      });
      // Balances, addresses and history were previously read exactly once,
      // in initState, and then only again on a manual pull-to-refresh. So a
      // wallet could scan all the way to the chain tip in the background and
      // still show a zero balance and an empty history until the user
      // happened to swipe down. Refresh on the sync-finished edge.
      if(wasSyncing && !s.syncing) _refresh();
    });
    // And refresh periodically while a long initial scan is running, so
    // incoming transactions appear as they are found rather than only at the
    // very end of a multi-hour catch-up.
    dataTimer=Timer.periodic(const Duration(seconds:5),(_){ if((sync?.syncing??false)) _refresh(); });
  }
  @override void dispose(){sub?.cancel();dataTimer?.cancel();super.dispose();}
  void _refresh(){try{
    bal=widget.wallet.balances();
    final addrs=widget.wallet.addresses();
    address=(addrs['z_addresses'] as List).first.toString();
    final t=addrs['t_addresses'] as List?;
    taddress=(t==null||t.isEmpty)?null:t.first.toString();
    history=widget.wallet.history();
  }catch(_){} if(mounted)setState((){});}
  /// Always keep the block numbers on screen.
  ///
  /// Previously the 'connecting' phase replaced them with just the server
  /// name -- but the engine re-enters that phase at the start of *every*
  /// sync round, including each automatic retry after a dropped connection.
  /// So a perfectly normal reconnect made the height and tip disappear and
  /// looked exactly like the scan had cut out and reset, when in fact it
  /// resumes from where it got to. The phase is now a prefix on the numbers
  /// rather than a replacement for them.
  String get _statusLine {
    final s=sync;
    if(s==null) return 'Connecting…';
    final pct=s.tip>0 ? ' (${(s.progress*100).toStringAsFixed(1)}%)' : '';
    final at=s.tip>0 ? '${s.height} / ${s.tip}$pct' : '${s.height}';
    switch(s.phase){
      case 'connecting':     return 'Reconnecting · $at';
      case 'scanning':       return 'Scanning $at';
      case 'fetching_memos': return 'Finishing up · $at';
      case 'error':          return 'Connection dropped, retrying · $at';
      default:               return s.height>0 ? 'Synced at ${s.height}' : 'Waiting to sync';
    }
  }
  double get total=>((bal?['spendable_zbalance'] as num?)?.toDouble()??0)/1e8+((bal?['tbalance'] as num?)?.toDouble()??0)/1e8;
  /// Re-scan from an earlier date.
  ///
  /// This is what makes choosing a restore date safe: pick an optimistic one,
  /// and if the balance comes up short, come back here with an earlier date
  /// instead of wiping the wallet and retyping the seed phrase.
  Future<void> _rescan() async {
    final now=DateTime.now();
    final picked=await showDatePicker(
      context:context,
      initialDate:DateTime(now.year-1,now.month,now.day),
      firstDate:DateTime(2019,7,1),
      lastDate:now,
      helpText:'Rescan from which date?',
    );
    if(picked==null || !mounted) return;
    final ok=await showDialog<bool>(context:context,builder:(d)=>AlertDialog(
      title:const Text('Rescan wallet'),
      content:const Text('Transaction history is rebuilt from this date forward. Your funds and recovery phrase are untouched — this only changes where scanning starts.'),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(d,false),child:const Text('Cancel')),
        FilledButton(onPressed:()=>Navigator.pop(d,true),child:const Text('Rescan')),
      ]));
    if(ok!=true) return;
    setState((){ startHeight=null; });
    try {
      final h=await widget.wallet.rescanFrom(picked);
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Rescanning from block $h')));
    } catch(e) {
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Could not start rescan: $e')));
    }
  }

  Future<void> _reset() async {
    final ok=await showDialog<bool>(context:context,builder:(d)=>AlertDialog(
      title:const Text('Reset wallet'),
      content:const Text('This deletes the wallet and its recovery phrase from this device. Anything not backed up elsewhere is gone for good.'),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(d,false),child:const Text('Cancel')),
        FilledButton(onPressed:()=>Navigator.pop(d,true),child:const Text('Reset')),
      ]));
    if(ok!=true) return;
    await widget.wallet.wipe();
    widget.onWiped();
  }
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Ycash'),actions:[
      IconButton(onPressed:(){widget.wallet.startSync();},icon:const Icon(Icons.sync)),
      PopupMenuButton<String>(
        onSelected:(v){ if(v=='reset') _reset(); if(v=='rescan') _rescan(); },
        itemBuilder:(_)=>const [
          PopupMenuItem(value:'rescan',child:Text('Rescan from a date')),
          PopupMenuItem(value:'reset',child:Text('Reset wallet')),
        ],
      ),
    ]),body:RefreshIndicator(onRefresh:()async{widget.wallet.startSync();await Future.delayed(const Duration(milliseconds:400));_refresh();},child:ListView(padding:const EdgeInsets.all(16),children:[
    if(sync?.syncing??false) LinearProgressIndicator(value:sync!.progress),
    const SizedBox(height:16),
    Container(padding:const EdgeInsets.all(24),decoration:BoxDecoration(borderRadius:BorderRadius.circular(28),border:Border.all(color:Theme.of(c).dividerColor)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('BALANCE',style:TextStyle(fontSize:11,letterSpacing:1.6,fontWeight:FontWeight.w800)),
      const SizedBox(height:12),Text('${total.toStringAsFixed(8)} YEC',style:const TextStyle(fontSize:36,fontWeight:FontWeight.w700)),
      const SizedBox(height:10),Text(_statusLine,style:TextStyle(color:Theme.of(c).hintColor)),
      if(startHeight!=null && (sync?.tip??0)>startHeight!)
        Padding(padding:const EdgeInsets.only(top:6),child:Text('Started scanning at block $startHeight — ${(sync!.tip-startHeight!)} blocks to cover',style:TextStyle(fontSize:12,color:Theme.of(c).hintColor))),
      if((sync?.initialState??'').isNotEmpty)
        Padding(padding:const EdgeInsets.only(top:6),child:Text('Scan start: ${sync!.initialState}',style:TextStyle(fontSize:11,color:Theme.of(c).hintColor))),
      if(sync?.saveError!=null)
        Padding(padding:const EdgeInsets.only(top:8),child:Text('Could not save progress: ${sync!.saveError}',style:const TextStyle(color:YColors.danger,fontSize:12))),
      if(sync?.error!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text(sync!.error!,style:const TextStyle(color:YColors.danger))),
      if(sync!=null) ...[
        const SizedBox(height:14),
        const Text('AWBS LIVE',style:TextStyle(fontSize:11,letterSpacing:1.6,fontWeight:FontWeight.w800)),
        const SizedBox(height:8),
        Text('${sync!.blocksPerSec.toStringAsFixed(0)} blocks/s  •  batch ${sync!.currentBatchSize}  •  ${sync!.workerCount} workers',style:TextStyle(fontSize:12,color:Theme.of(c).hintColor)),
        Text('Last batch: ${sync!.lastBatchSecs.toStringAsFixed(2)}s  •  prefetch ${sync!.prefetchDepth}  •  ${(sync!.downloadedBytes/1048576).toStringAsFixed(1)} MiB',style:TextStyle(fontSize:12,color:Theme.of(c).hintColor)),
      ],
    ])),
    const SizedBox(height:16),
    Row(children:[Expanded(child:FilledButton.icon(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>Send(wallet:widget.wallet))),icon:const Icon(Icons.arrow_upward),label:const Text('Send'))),const SizedBox(width:12),Expanded(child:FilledButton.tonalIcon(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>Receive(address:address??'',taddress:taddress))),icon:const Icon(Icons.qr_code),label:const Text('Receive')))]),
    const SizedBox(height:24),const Text('Recent activity',style:TextStyle(fontSize:18,fontWeight:FontWeight.w700)),
    if(history.isEmpty)const Padding(padding:EdgeInsets.all(20),child:Text('No transactions yet.',textAlign:TextAlign.center))
    else ...history.take(5).map((x)=>ListTile(title:Text(x['txid']?.toString().substring(0,12)??'Transaction'),subtitle:Text(x['datetime']?.toString()??''),trailing:Text('${x['amount']??0}'))),
    const SizedBox(height:24),Text('Ycash AWBS • adaptive batch (start ${YcashConfig.modernBatchSize}) • ${YcashConfig.modernWorkers} workers${widget.wallet.server!=null ? '\n${widget.wallet.server}' : ''}',style:TextStyle(fontSize:12,color:Theme.of(c).hintColor)),
  ])));
}

class Receive extends StatelessWidget {
  final String address;
  /// The transparent address, shown so it can be compared against the
  /// address a transparent payment was actually sent to. A restored wallet
  /// only derives t-address index 0 until the gap rule extends it, so if the
  /// funds went to a later index this screen is where that becomes visible.
  final String? taddress;
  const Receive({super.key,required this.address,this.taddress});
  @override Widget build(BuildContext c)=>Scaffold(
    appBar:AppBar(title:const Text('Receive')),
    body:ListView(padding:const EdgeInsets.all(24),children:[
      const Text('Shielded address',style:TextStyle(fontSize:18,fontWeight:FontWeight.w700)),
      const SizedBox(height:24),
      if(address.isNotEmpty)Center(child:Container(padding:const EdgeInsets.all(16),color:Colors.white,child:QrImageView(data:address,size:230))),
      const SizedBox(height:20),
      SelectableText(address,textAlign:TextAlign.center),
      const SizedBox(height:16),
      Row(children:[
        Expanded(child:OutlinedButton(onPressed:()=>Share.share(address),child:const Text('Share'))),
        const SizedBox(width:10),
        Expanded(child:OutlinedButton(onPressed:()=>Navigator.pop(c),child:const Text('Done'))),
      ]),
      if(taddress!=null)...[
        const SizedBox(height:32),
        const Divider(),
        const SizedBox(height:16),
        const Text('Transparent address',style:TextStyle(fontSize:18,fontWeight:FontWeight.w700)),
        const SizedBox(height:12),
        SelectableText(taddress!,textAlign:TextAlign.center),
        const SizedBox(height:10),
        OutlinedButton(onPressed:()=>Share.share(taddress!),child:const Text('Share transparent address')),
      ],
    ]));
}

class Send extends StatefulWidget {final SimpleWallet wallet;const Send({super.key,required this.wallet});@override State<Send> createState()=>_SendState();}
class _SendState extends State<Send>{final a=TextEditingController(),m=TextEditingController(),amt=TextEditingController();bool busy=false;String? err;
Future<void> go()async{setState(()=>err=null);int amount;try{amount=(Decimal.parse(amt.text.trim())*Decimal.fromInt(100000000)).toBigInt().toInt();}catch(_){setState(()=>err='Enter a valid YEC amount');return;}if(a.text.trim().isEmpty){setState(()=>err='Enter a Ycash address');return;}setState(()=>busy=true);try{final p=widget.wallet.planSend(to:a.text.trim(),amount:amount,memo:m.text.trim().isEmpty?null:m.text.trim());if(!mounted)return;final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Confirm send'),content:Text('Send ${amount/1e8} YEC\\nFee ${(p['fee']??0)/1e8} YEC'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Send'))]));if(ok==true){final tx=widget.wallet.broadcast(p);if(mounted){ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Sent: $tx')));Navigator.pop(context);}}}catch(e){if(mounted)setState(()=>err='Send failed: $e');}finally{if(mounted)setState(()=>busy=false);}}
@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Send')),body:ListView(padding:const EdgeInsets.all(24),children:[TextField(controller:a,decoration:const InputDecoration(labelText:'Ycash recipient address')),const SizedBox(height:12),TextField(controller:amt,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Amount (YEC)')),const SizedBox(height:12),TextField(controller:m,decoration:const InputDecoration(labelText:'Memo (optional)'),maxLines:2),if(err!=null)Padding(padding:const EdgeInsets.symmetric(vertical:12),child:Text(err!,style:const TextStyle(color:YColors.danger))),const SizedBox(height:20),FilledButton(onPressed:busy?null:go,child:Text(busy?'Sending…':'Review and send'))]));}
