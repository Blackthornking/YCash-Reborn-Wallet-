import 'package:flutter/material.dart';
import 'core/auth.dart';
import 'core/pin.dart';
import 'screens/pin.dart';
import 'core/wallet.dart';
import 'screens/home.dart';
import 'screens/onboarding.dart';
import 'screens/fatal_error.dart';

class YcashSimpleApp extends StatefulWidget { const YcashSimpleApp({super.key}); @override State<YcashSimpleApp> createState()=>_AppState(); }
class _AppState extends State<YcashSimpleApp> with WidgetsBindingObserver {
  final wallet=SimpleWallet();
  bool? exists;
  String? startupError;

  /// Held rather than created inline in [build]. `FutureBuilder(future:
  /// wallet.openSaved(), ...)` written directly in build() starts a *new*
  /// wallet open on every single rebuild -- including the rebuild triggered
  /// by the error screen's own retry button -- so a slow or failing open
  /// could stack several concurrent native opens against the same wallet
  /// file. Creating it once and reusing it means one open per attempt.
  Future<void>? _openFuture;

  /// _AppState builds the MaterialApp, so its own `context` sits *above* the
  /// Navigator and MaterialApp's ScaffoldMessenger. Pushing a route or showing
  /// a snackbar with it throws "No Navigator widget found". These keys reach
  /// the ones MaterialApp creates.
  final _navKey = GlobalKey<NavigatorState>();
  final _msgKey = GlobalKey<ScaffoldMessengerState>();

  /// Whether the unlock gate is currently satisfied. Null while we're still
  /// working out whether a gate applies at all.
  bool? _unlocked;
  DateTime? _backgroundedAt;

  @override void initState(){super.initState(); WidgetsBinding.instance.addObserver(this); _check();}

  @override void dispose(){WidgetsBinding.instance.removeObserver(this); super.dispose();}

  /// Flush the wallet to disk on the way out.
  ///
  /// This app has no foreground service, so scanning effectively only runs
  /// while it is on screen, and Android freezes then reclaims the process
  /// whenever it likes. Without this, everything scanned since the last
  /// periodic checkpoint was thrown away every time the app was backgrounded
  /// -- which is why a long restore appeared to start over each time.
  @override void didChangeAppLifecycleState(AppLifecycleState state){
    if(state==AppLifecycleState.paused ||
       state==AppLifecycleState.hidden ||
       state==AppLifecycleState.detached){
      wallet.saveNow();
      _backgroundedAt = DateTime.now();
    }
    if(state==AppLifecycleState.resumed){
      // Re-lock only after a real absence. Re-prompting on every glance back
      // at sync progress would train people to dismiss the prompt, and syncing
      // continues natively either way, so there's nothing to gain from it.
      final since=_backgroundedAt;
      if(since!=null && DateTime.now().difference(since) > WalletLock.relockAfter){
        if(_unlocked==true) setState(()=>_unlocked=false);
      }
      _backgroundedAt=null;
    }
  }

  /// Satisfy the unlock gate, if one is configured.
  ///
  /// Biometrics alone are enough to open the app — that is the point of the
  /// split. The PIN is a second factor reserved for the two irreversible
  /// actions in Settings, and is offered here only as a fallback for when
  /// biometrics fail or are not enrolled.
  Future<void> _unlock() async {
    if(!await WalletLock.isEnabled()){
      if(mounted) setState(()=>_unlocked=true);
      return;
    }
    final ok=await WalletLock.authenticate();
    if(mounted) setState(()=>_unlocked=ok);
  }

  Future<void> _unlockWithPin() async {
    if(!await WalletPin.isSet()){
      _msgKey.currentState?.showSnackBar(const SnackBar(
        content:Text('No PIN set. Use biometrics, or set a PIN in Settings.')));
      return;
    }
    final navContext=_navKey.currentContext;
    if(navContext==null) return;
    final ok=await PinEntry.ask(navContext,'Enter your PIN to unlock');
    if(mounted && ok) setState(()=>_unlocked=true);
  }

  Future<void> _check() async {
    setState(()=>startupError=null);
    try {
      final e=await wallet.hasWallet();
      if(mounted)setState(()=>exists=e);
      // Only gate an existing wallet. During onboarding there is no seed to
      // protect yet, and prompting before one exists is just confusing.
      if(e){ await _unlock(); } else if(mounted){ setState(()=>_unlocked=true); }
    } catch (err, stack) {
      // Without this, an exception here (native library load failure,
      // secure-storage plugin not registered, anything) left `exists` at
      // null forever -- initState calls _check() without awaiting or
      // catching it, so nothing ever called setState again, and the app
      // sat on the loading spinner below permanently with no visible
      // indication anything had gone wrong.
      debugPrint('Startup check failed: $err\n$stack');
      if(mounted)setState(()=>startupError='$err\n\n$stack');
    }
  }

  void _retryOpen(){ setState(()=>_openFuture=null); }

  @override Widget build(BuildContext c){
    if(startupError!=null) return FatalErrorScreen(message:startupError!, onRetry:_check);
    if(exists==null) return const MaterialApp(home:Scaffold(body:Center(child:CircularProgressIndicator())));
    return MaterialApp(
      navigatorKey:_navKey,
      scaffoldMessengerKey:_msgKey,
      title:'Yodl',
      debugShowCheckedModeBanner:false,
      theme:ThemeData(useMaterial3:true,brightness:Brightness.dark,scaffoldBackgroundColor:const Color(0xFF080807)),
      home: (exists! && _unlocked!=true)
        ? Scaffold(body:Center(child:Padding(padding:const EdgeInsets.all(32),child:Column(
            mainAxisAlignment:MainAxisAlignment.center,children:[
              const Icon(Icons.lock_outline,size:48),
              const SizedBox(height:20),
              const Text('Wallet locked',style:TextStyle(fontSize:20,fontWeight:FontWeight.w700)),
              const SizedBox(height:8),
              Text('Unlock to view your balance and send.',
                textAlign:TextAlign.center,style:TextStyle(color:Theme.of(c).hintColor)),
              const SizedBox(height:24),
              FilledButton.icon(onPressed:_unlock,
                icon:const Icon(Icons.fingerprint),label:const Text('Unlock')),
              const SizedBox(height:8),
              TextButton(onPressed:_unlockWithPin,child:const Text('Use PIN instead')),
            ]))))
        : exists! ? FutureBuilder(future:_openFuture??=wallet.openSaved(),builder:(c,s){
        if(s.hasError){
          return FatalErrorScreen(
            message:'Could not connect to a Ycash server and open the saved wallet:\n\n${s.error}',
            onRetry:_retryOpen,
          );
        }
        if(s.connectionState!=ConnectionState.done){
          return const Scaffold(body:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
            CircularProgressIndicator(),
            SizedBox(height:20),
            Text('Connecting to the Ycash network…'),
          ])));
        }
        return Home(wallet:wallet,onWiped:(){ setState((){ exists=false; _openFuture=null; }); });
      }) : Onboarding(wallet:wallet,onDone:()async{
            setState((){exists=true;_unlocked=true;});
            // Prompt once, straight after setup, so a PIN exists before the
            // actions that require it are ever reached. Skippable: a wallet
            // without one still works, and Settings says what needs it.
            final navContext=_navKey.currentContext;
            if(!await WalletPin.isSet() && navContext!=null && navContext.mounted){
              await Navigator.push<bool>(navContext,
                MaterialPageRoute(builder:(_)=>const PinSetup()));
            }
          }),
    );
  }
}
