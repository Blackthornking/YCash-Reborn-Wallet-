import 'package:flutter/material.dart';
import 'core/wallet.dart';
import 'screens/home.dart';
import 'screens/onboarding.dart';
import 'screens/fatal_error.dart';

class YcashSimpleApp extends StatefulWidget { const YcashSimpleApp({super.key}); @override State<YcashSimpleApp> createState()=>_AppState(); }
class _AppState extends State<YcashSimpleApp> {
  final wallet=SimpleWallet();
  bool? exists;
  String? startupError;
  @override void initState(){super.initState(); _check();}
  Future<void> _check() async {
    setState(()=>startupError=null);
    try {
      final e=await wallet.hasWallet();
      if(mounted)setState(()=>exists=e);
    } catch (err, stack) {
      // Without this, an exception here (native library load failure,
      // secure-storage plugin not registered, anything) left `exists` at
      // null forever -- initState calls _check() without awaiting or
      // catching it, so nothing ever called setState again, and the app
      // sat on the loading spinner below permanently with no visible
      // indication anything had gone wrong.
      debugPrint('Startup check failed: $err\n$stack');
      if(mounted)setState(()=>startupError='$err\n\n$stack');
    }
  }
  @override Widget build(BuildContext c){
    if(startupError!=null) return FatalErrorScreen(message:startupError!, onRetry:_check);
    if(exists==null) return const MaterialApp(home:Scaffold(body:Center(child:CircularProgressIndicator())));
    return MaterialApp(
      title:'Ycash',
      debugShowCheckedModeBanner:false,
      theme:ThemeData(useMaterial3:true,brightness:Brightness.dark,scaffoldBackgroundColor:const Color(0xFF080807)),
      home: exists! ? FutureBuilder(future:wallet.openSaved(),builder:(c,s){
        if(s.hasError)return FatalErrorScreen(message:'Could not open the saved wallet:\n\n${s.error}\n\n${s.stackTrace}', onRetry:()=>setState((){}));
        if(s.connectionState!=ConnectionState.done)return const Scaffold(body:Center(child:CircularProgressIndicator()));
        return Home(wallet:wallet);
      }) : Onboarding(wallet:wallet,onDone:()=>setState(()=>exists=true)),
    );
  }
}
