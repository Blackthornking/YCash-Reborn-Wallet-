# What was stopping this wallet from connecting and syncing

## 1. The wallet could never open at all (this was the blocker)

`packages/ycash_core_ffi/rust/vendor/yecshell-lib/zcash-params/` contains only
a `.gitkeep`. The two real Sapling parameter files are ~51 MB and are not
committed.

But `LightClient::read_sapling_params()` did this:

```rust
self.sapling_output.extend_from_slice(SaplingParams::get("sapling-output.params").unwrap().as_ref());
```

`rust_embed`'s `get()` returns `None` for a file that isn't there, so that
`unwrap()` panicked — and it is called from **every** path that opens a wallet:
`new`, `new_from_phrase`, `read_from_buffer` and `read_from_disk`.

So `ycash_yecshell_open` failed before a single packet was ever sent to
lightwalletd. Everything downstream — connecting, syncing, balances, history —
was unreachable, because there was never an open `LightClient` for
`with_client` to hand out.

**Fixed:** the parameters are now optional. They are loaded from the embedded
copy if present, then from `<wallet data dir>/zcash-params/` if not, and
missing parameters are logged rather than fatal. Syncing never needed them —
only signing does.

`ycash_yecshell_broadcast_plan` now checks `has_sapling_params()` first and
returns a clear message instead of failing inside the prover. Run
`scripts/fetch_ycash_params.sh` and rebuild to enable sending.

## 2. New wallets were seeded at block 960,000

`lightclient/checkpoints.rs` tops out at mainnet block 960,000; Ycash is past
3,000,000. `get_closest_checkpoint` therefore returned 960,000 for *any*
birthday above it, so a wallet created today started ~2,000,000 blocks behind
instead of at the tip.

The mirror image was also wrong: a restore with a birthday below 600,000 (the
table's lowest entry) got no initial block at all and began scanning from the
Ycash fork with an **empty** commitment tree — Ycash inherited a non-empty
Sapling tree from Zcash at the fork, so witnesses built that way are invalid.

**Fixed:** `set_wallet_initial_state` now asks the server for its own tree
state via `GetTreeState` (added to `proto/service.proto` and
`grpcconnector::get_tree_state`) and falls back to the bundled checkpoints
exactly as before if the server answers `Unimplemented`. No regression if the
RPC isn't supported.

## 3. One hardcoded server, no fallback, no retry

`LightClientConfig::create` resolves the host and makes a live `GetLightdInfo`
call before touching any wallet file, so one unreachable endpoint failed the
whole open — and the app turned that into a fatal error screen.

The three Ycash codebases this is derived from each ship a different default
(`lite.ycash.xyz:9067`, `lightwalletd.ycash.xyz:443`,
`lightwalletd2.ycash.xyz:1443`).

**Fixed:** `YcashConfig.lightwalletdServers` is now an ordered list, tried in
turn at open time, with 3 attempts and a short backoff around the whole list.
The connected endpoint is recorded and shown on the home screen.

## 4. Sync ran exactly once and then stopped

The native engine returns as soon as it reaches the tip, and also gives up
after exhausting its internal retries. Nothing ever restarted it, so the
wallet went stale after its first round and new blocks only arrived if the
user hit refresh manually. (`do_sync_with_options` even has a comment
referring to "the Dart side's periodic resync timer" — there wasn't one.)

**Fixed:** `SimpleWallet` now runs a 30s resync timer; `startSync()` is a
no-op while a round is already in flight.

## 5. Smaller things

- `app.dart` called `wallet.openSaved()` inline in `build()`, starting a fresh
  native open on every rebuild. The future is now created once.
- Balances/addresses/history were read once in `initState` and then only on
  pull-to-refresh, so a wallet could sync to the tip and still show zero. They
  now refresh while syncing and on the sync-finished edge.
- Status polling was every 250 ms; each poll takes the engine's global state
  lock that the scanner also wants. Now 1 s.
- `startSync()` uses `YcashConfig.modernBatchSize`/`modernWorkers` and no
  longer throws out of the timer if the engine isn't ready.

## Still outstanding

- Sending needs `scripts/fetch_ycash_params.sh` + a rebuild.
- None of this has been compiled or run — there's no Rust toolchain or network
  in the environment these changes were made in. It needs a real CI build.
