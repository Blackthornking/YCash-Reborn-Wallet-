import 'dart:async';
import 'dart:io';
import 'dart:isolate';
import 'package:path_provider/path_provider.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:ycash_core/ycash_core.dart';
import 'config.dart';

/// Plain data for [_openNative] -- deliberately NOT a method parameter list
/// on [SimpleWallet], and [_openNative] deliberately lives at top level
/// (outside any class), so nothing in its scope can accidentally pull in
/// `this`. `_open` (the instance method below) also touches instance fields
/// like `_seed`/`opened` right after its Isolate.run call; if the isolate
/// closure were written directly inside that instance method, the Dart
/// compiler shares one capture context per method scope, so the *whole*
/// SimpleWallet instance -- including its live `Timer? _poll` -- gets
/// bundled into the closure even though the closure body never references
/// `this`. A Timer can't cross an isolate boundary, so that surfaces at
/// runtime as "Invalid argument(s): ... object is unsendable ... Class:
/// _Timer ... <- Instance of 'SimpleWallet'". Keeping the isolate body in a
/// top-level function with only value arguments avoids that entirely.
class _OpenArgs {
  final String server;
  final String dataDir;
  final String seed;
  final bool isNew;
  final bool replace;
  const _OpenArgs({
    required this.server,
    required this.dataDir,
    required this.seed,
    required this.isNew,
    required this.replace,
  });
}

Future<void> _openNative(_OpenArgs args) => Isolate.run(() {
  final n = YcashCoreNative.instance;
  n.configure(server: args.server, dataDir: args.dataDir);
  if (args.replace) {
    try { n.wipeYecWallet(); } catch (_) {}
  }
  n.openYecWallet(args.seed, birthday: args.isNew ? YcashCoreNative.newWalletBirthday : 0);
});

class SimpleSyncStatus {
  final String phase;
  final int height;
  final int tip;
  final int birthday;
  final String? error;
  const SimpleSyncStatus(this.phase,this.height,this.tip,this.birthday,this.error);
  bool get syncing => phase == 'connecting' || phase == 'scanning' || phase == 'fetching_memos';
  double get progress {
    final span=tip-birthday;
    if(span<=0) return tip>0?1:0;
    return ((height-birthday)/span).clamp(0.0,1.0).toDouble();
  }
}

class SimpleWallet {
  final _storage=const FlutterSecureStorage();
  YcashCoreNative? __native;
  /// Lazily loads the native library on first actual use, instead of
  /// eagerly as a field initializer. SimpleWallet itself is constructed as
  /// part of _AppState's own field-initializer chain (see `final
  /// wallet=SimpleWallet();` in app.dart), which runs during State
  /// construction -- before any UI has built, and before app.dart's own
  /// try/catch around the startup check is in scope. A native-library
  /// load failure there had no error boundary around it at all. Deferring
  /// the load to the first real call (hasWallet(), create(), etc. -- all
  /// of which already run inside try/catch in app.dart/onboarding.dart)
  /// means a loading problem surfaces as an ordinary catchable exception
  /// instead of failing during construction.
  YcashCoreNative get _native => __native ??= YcashCoreNative.instance;
  Timer? _poll;
  bool opened=false;
  String? _seed;
  final status=StreamController<SimpleSyncStatus>.broadcast();

  Future<String> _dataDir() async {
    final base=await getApplicationSupportDirectory();
    final d=Directory('${base.path}/ycash-simple-wallet');
    if(!await d.exists()) await d.create(recursive:true);
    return d.path;
  }

  Future<bool> hasWallet() async => (await _storage.read(key:'ycash.simple.seed'))?.isNotEmpty == true;

  Future<void> create() async {
    final seed=_native.generateMnemonic();
    await _storage.write(key:'ycash.simple.seed',value:seed);
    await _open(seed, isNew:true);
  }

  Future<void> restore(String seed) async {
    final clean=seed.trim().replaceAll(RegExp(r'\s+'),' ');
    if(clean.split(' ').length != 24) throw StateError('Enter the 24-word Ycash recovery phrase.');
    await _storage.write(key:'ycash.simple.seed',value:clean);
    await _open(clean, isNew:false, replace:true);
  }

  Future<void> openSaved() async {
    final seed=await _storage.read(key:'ycash.simple.seed');
    if(seed==null || seed.isEmpty) throw StateError('No wallet found.');
    await _open(seed,isNew:false);
  }

  Future<void> _open(String seed,{required bool isNew,bool replace=false}) async {
    final dir=await _dataDir();
    await _openNative(_OpenArgs(
      server: YcashConfig.lightwalletd,
      dataDir: dir,
      seed: seed,
      isNew: isNew,
      replace: replace,
    ));
    _seed=seed; opened=true;
    startSync();
    _poll?.cancel();
    _poll=Timer.periodic(const Duration(milliseconds:250),(_)=>_emit());
    _emit();
  }

  void _emit() {
    try {
      final s=_native.syncStatus();
      status.add(SimpleSyncStatus(
        s['phase']?.toString()??'idle',
        (s['synced_blocks'] as num?)?.toInt()??0,
        (s['total_blocks'] as num?)?.toInt()??0,
        (s['birthday'] as num?)?.toInt()??YcashConfig.forkHeight,
        s['last_error']?.toString(),
      ));
    } catch(_){}
  }

  void startSync() {
    if(!opened && _seed==null) return;
    final s=_native.syncStatus();
    if(s['is_syncing']==true) return;
    _native.startSync();
    _emit();
  }

  Map<String,dynamic> balances()=>Map<String,dynamic>.from(_native.balances());
  Map<String,dynamic> addresses()=>Map<String,dynamic>.from(_native.addresses());
  List<dynamic> history()=>_native.history();
  Map<String,dynamic> planSend({required String to,required int amount,String? memo})=>
      _native.planSend(to:to,amount:amount,memo:memo);
  String broadcast(Map<String,dynamic> plan)=>_native.broadcastPlan(plan);

  Future<void> wipe() async {
    _poll?.cancel(); _poll=null;
    try{_native.wipeYecWallet();}catch(_){}
    await _storage.delete(key:'ycash.simple.seed');
    opened=false; _seed=null;
  }
}
