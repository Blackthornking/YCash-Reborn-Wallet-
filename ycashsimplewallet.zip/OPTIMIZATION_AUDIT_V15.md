# Yodl V15 speed-stack audit

Implemented against the supplied Yodl.zip, using the supplied AWBS V14 project as the reference.

## Implemented

1. Cross-block crypto look-ahead: bounded AWBS windows are decrypted ahead of ordered wallet commits.
2. Low-output parallelism: the previous 256-output gate was reduced to an adaptive 16-output gate; cross-block flattening supplies larger batches on Ycash.
3. Cross-block batch matching: outputs from multiple blocks are flattened, grouped by ZIP-212 enforcement, matched, and reconstructed by exact block/output coordinates.
4. Single-pass matched-note materialization: batch decryption returns note material so successful outputs do not run Sapling trial decryption a second time.
5. Adaptive witness update: parallel witness append is used for sufficiently large witness sets; small sets use a cheaper sequential loop.
6. Transaction clone reduction: spends are moved out of each transaction for the worker instead of cloning the whole compact transaction.
7. Nullifier prefix index: tracked nullifiers are indexed once per block; final equality remains constant-time.
8. Single protobuf parse: the sync loop parses compact blocks once and passes decoded blocks into the scanner.
9. Workload-adaptive default worker selection based on AWBS window size and CPU count; explicit worker counts remain respected.
10. Allocation reuse: cross-block crypto scratch vectors are retained and reused between AWBS windows.
11. Persistent HTTP/2 full-transaction connection with bounded concurrent requests (16 at a time).
12. Reused Tokio runtime for the full-transaction batch path, avoiding repeated runtime construction.

## Safety invariants retained

- Ordered wallet/tree/witness state commits.
- Exact block height + block hash matching for speculative crypto results.
- Fail-closed speculative cache on mismatch/reorg.
- ZIP-212 enforcement grouped by height.
- Existing wallet transaction and note serialization types.
- ProofSkip remains locked and cannot skip a block.

## Build verification limitation

The supplied environment does not contain `cargo` or `rustc`, so a native Rust compilation/test run could not be executed here. Archive integrity was verified with `unzip -t`, and source-level feature checks were run for every optimization above.

## V16 implementation pass

A V16 implementation pass was applied to the supplied archive. See `OPTIMIZATION_IMPLEMENTED_V16.md` for the exact changes and validation caveat.
