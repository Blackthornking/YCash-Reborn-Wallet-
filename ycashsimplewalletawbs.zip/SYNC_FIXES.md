# What was stopping this wallet from connecting and syncing

## 1. The wallet could never open at all (this was the blocker)

`packages/ycash_core_ffi/rust/vendor/yecshell-lib/zcash-params/` contains only
a `.gitkeep`. The two real Sapling parameter files are ~51 MB and are not
committed.

But `LightClient::read_sapling_params()` did this:

```rust
self.sapling_output.extend_from_slice(SaplingParams::get("sapling-output.params").unwrap().as_ref());
```

`rust_embed`'s `get()` returns `None` for a file that isn't there, so that
`unwrap()` panicked — and it is called from **every** path that opens a wallet:
`new`, `new_from_phrase`, `read_from_buffer` and `read_from_disk`.

So `ycash_yecshell_open` failed before a single packet was ever sent to
lightwalletd. Everything downstream — connecting, syncing, balances, history —
was unreachable, because there was never an open `LightClient` for
`with_client` to hand out.

**Fixed:** the parameters are now optional. They are loaded from the embedded
copy if present, then from `<wallet data dir>/zcash-params/` if not, and
missing parameters are logged rather than fatal. Syncing never needed them —
only signing does.

`ycash_yecshell_broadcast_plan` now checks `has_sapling_params()` first and
returns a clear message instead of failing inside the prover. Run
`scripts/fetch_ycash_params.sh` and rebuild to enable sending.

## 2. New wallets were seeded at block 960,000

`lightclient/checkpoints.rs` tops out at mainnet block 960,000; Ycash is past
3,000,000. `get_closest_checkpoint` therefore returned 960,000 for *any*
birthday above it, so a wallet created today started ~2,000,000 blocks behind
instead of at the tip.

The mirror image was also wrong: a restore with a birthday below 600,000 (the
table's lowest entry) got no initial block at all and began scanning from the
Ycash fork with an **empty** commitment tree — Ycash inherited a non-empty
Sapling tree from Zcash at the fork, so witnesses built that way are invalid.

**Fixed:** `set_wallet_initial_state` now asks the server for its own tree
state via `GetTreeState` (added to `proto/service.proto` and
`grpcconnector::get_tree_state`) and falls back to the bundled checkpoints
exactly as before if the server answers `Unimplemented`. No regression if the
RPC isn't supported.

## 3. One hardcoded server, no fallback, no retry

`LightClientConfig::create` resolves the host and makes a live `GetLightdInfo`
call before touching any wallet file, so one unreachable endpoint failed the
whole open — and the app turned that into a fatal error screen.

The three Ycash codebases this is derived from each ship a different default
(`lite.ycash.xyz:9067`, `lightwalletd.ycash.xyz:443`,
`lightwalletd2.ycash.xyz:1443`).

**Fixed:** `YcashConfig.lightwalletdServers` is now an ordered list, tried in
turn at open time, with 3 attempts and a short backoff around the whole list.
The connected endpoint is recorded and shown on the home screen.

## 4. Sync ran exactly once and then stopped

The native engine returns as soon as it reaches the tip, and also gives up
after exhausting its internal retries. Nothing ever restarted it, so the
wallet went stale after its first round and new blocks only arrived if the
user hit refresh manually. (`do_sync_with_options` even has a comment
referring to "the Dart side's periodic resync timer" — there wasn't one.)

**Fixed:** `SimpleWallet` now runs a 30s resync timer; `startSync()` is a
no-op while a round is already in flight.

## 5. Smaller things

- `app.dart` called `wallet.openSaved()` inline in `build()`, starting a fresh
  native open on every rebuild. The future is now created once.
- Balances/addresses/history were read once in `initState` and then only on
  pull-to-refresh, so a wallet could sync to the tip and still show zero. They
  now refresh while syncing and on the sync-finished edge.
- Status polling was every 250 ms; each poll takes the engine's global state
  lock that the scanner also wants. Now 1 s.
- `startSync()` uses `YcashConfig.modernBatchSize`/`modernWorkers` and no
  longer throws out of the timer if the engine isn't ready.

## Still outstanding

- Sending needs `scripts/fetch_ycash_params.sh` + a rebuild.
- None of this has been compiled or run — there's no Rust toolchain or network
  in the environment these changes were made in. It needs a real CI build.

---

# Round 2 — after the first on-device run

The wallet now opens, connects and scans. Three follow-up symptoms:

## Long "Connecting to the Ycash network…" at startup

The device connected to `lite.ycash.xyz:9067` — the *second* entry in the
list. So every launch was paying `lightwalletd.ycash.xyz:443`'s full 30s
connect timeout before falling through to the one that works.

**Fixed:** `lite.ycash.xyz:9067` is now first; `CONNECT_TIMEOUT_SECS` is 15s
instead of 30s; and the endpoint that actually worked is remembered in
shared_preferences and tried ahead of the list on every later launch, so after
the first run there is no probing at all.

## "Cuts out sometimes" (the screenshot)

It wasn't cutting out — the display was. `do_sync_internal` sets the phase
back to `Connecting` at the start of *every* sync round, including each
automatic retry after a dropped connection, and the status line replaced the
block numbers with just the server name whenever that happened. The scan
resumes from where it got to; only the numbers vanished.

**Fixed:** the phase is now a prefix on the numbers, never a replacement:
`Scanning 961,234 / 3,027,063 (0.1%)`, `Reconnecting · 961,234 / …`,
`Connection dropped, retrying · 961,234 / …`.

## Scan progress was thrown away on interruption

This is the serious one. `persist_yec_wallet` ran only *after*
`do_sync_with_options` returned. An initial scan from block 960,000 to a tip
past 3,000,000 takes hours on a phone and wrote nothing to disk in the
meantime — so Android reclaiming the process, the battery dying, or swiping
the app away discarded all of it, and the next launch restarted from 960,000.
The initial sync could never finish.

**Fixed:** a saver thread now checkpoints the wallet every 90s while a sync is
running, guarded by a new `SAVE_LOCK` so a checkpoint can never interleave
with the final save or a send. The wallet's block list is capped at
`MAX_REORG` entries, so each save is small.

## New: the screen now shows where the scan started

`Started scanning at block N — M blocks to cover`. If N is around 960,000 the
server did not answer `GetTreeState` and the wallet fell back to the bundled
checkpoint table. If N is near the chain tip, the tree-state path worked.

---

# Round 3 — "it started at the fork"

Starting at block 570,000 narrows it down a lot, and the news is not good.

`LightWallet::last_scanned_height()` falls back to `min_scan_height() - 1`
(569,999) when the wallet has **no initial block at all**. So "started at the
fork" means `set_initial_block` never took: `GetTreeState` was not answered
*and* the bundled checkpoint lookup returned `None`.

The checkpoint lookup returns `None` for any height below the table's first
entry, which is 600,000. A restore defaults to a birthday of 570,000 (the
fork), so it falls straight through that hole.

## Why that matters more than the scan length

With no initial block, scanning begins at 570,000 against an **empty** Sapling
commitment tree. Ycash inherited a *non-empty* tree from Zcash at the fork, so
every witness built from that point is computed against the wrong tree. The
balance would eventually display correctly, but the anchors would not match the
real chain and **the wallet would not be able to spend** — after grinding
through 2.45 million blocks.

## Fixed

`set_wallet_initial_state` now falls back in three steps:

1. server `GetTreeState` at the birthday,
2. closest bundled checkpoint at or below the birthday,
3. **the earliest bundled checkpoint (600,000)** if the birthday is below the
   table entirely.

Step 3 is new. It costs the ~30,000 blocks between the fork and 600,000 (about
three weeks of July/August 2019) and in exchange gives a real commitment tree.

## New diagnostic on screen

The home screen now shows a **"Scan start:"** line, fed from a new
`initial_state` field in the native sync status. It reads one of:

- `server tree state at N` — `GetTreeState` works. Restores and new wallets can
  start anywhere, and a date-based restore becomes worth building.
- `bundled checkpoint 960000 (GetTreeState unavailable: <reason>)`
- `earliest bundled checkpoint 600000 (requested 570000, GetTreeState unavailable: <reason>)`
- `NONE - scanning from the fork with an empty tree` — should no longer happen.

The `<reason>` text is the actual gRPC error, which tells us whether the server
genuinely lacks the RPC or whether my proto addition is wrong.

## Also

`modernBatchSize` raised 512 -> 2000. Each batch costs one `GetBlockRange`
round trip plus one `GetAddressTxids` call per transparent address, and those
are paid per batch regardless of size — at 512 that was roughly 4,800 extra
connection setups across a full catch-up.

---

# Round 4 — GetTreeState works

Confirmed on device: a new wallet reported `Scan start: server tree state at
3028340` and was synced immediately; a restore reported `server tree state at
569999`. So `lite.ycash.xyz:9067` does answer `GetTreeState`, the commitment
tree is correct in both cases, and a wallet can legitimately start scanning
from *any* height.

That makes the 2.46-million-block restore unnecessary, and it makes the
"starts over every time" problem fixable from both ends.

## Restore can now start from a date

The restore screen has an optional "when did you first use this wallet?" date.
It is resolved to a height by a new
`ycash_yecshell_server_height_for_timestamp` FFI call, which needs only the
configured endpoint and not an open wallet — the existing
`height_for_timestamp` goes through `with_client`, which is too late to choose
that wallet's own birthday.

Left blank, it behaves as before and scans from the fork.

## Progress is no longer lost on backgrounding

There is no foreground service here, so scanning only really runs while the
app is on screen, and Android freezes then reclaims the process at will.
Anything scanned since the last periodic checkpoint was discarded every time.

- New `ycash_yecshell_save` FFI, called from a `WidgetsBindingObserver` in
  app.dart on `paused`/`hidden`/`detached`.
- Periodic checkpoint interval 90s -> 30s.

## Save failures are now visible

Every save site did `let _ = persist_yec_wallet(..)`, so a wallet that could
not be written looked identical to one that could. The last failure is now
recorded and surfaced as `save_error` in the sync status, shown on the home
screen as "Could not save progress: …".


# Round 5 — AWBS integration

The scanner from the `ycashwalletone` design is retained as the native `ycash_batch_scan` engine in this project. An AWBS controller now sits above it and adapts the next compact-block range from measured batch time: 2,000-block baseline, 500 minimum, 4,000 maximum, +25% after a fast (<2s) batch and -25% after a slow (>6s) batch. The existing one-batch prefetch remains bounded for Android memory safety, and adaptive decisions never alter the order of wallet commits.
