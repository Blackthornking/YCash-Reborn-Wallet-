# Ycash Adaptive Batch Warp Scanner (AWBS) — WarpCore V8

This build integrates the scanner already present in `ycashwalletone` and puts
an adaptive controller around it in `ycashsimplewallet`.

## What is preserved

- The existing native `ycash_batch_scan` implementation is retained unchanged.
- Sapling trial-decryption remains parallelized through the existing worker pool.
- Compact blocks are fetched through the existing shared gRPC connection.
- Blocks are committed to the wallet in strict chain order.
- Reorg detection and retry behavior remain in the existing scanner path.
- The wallet serialization, addresses, balances, transaction format and network
  protocol are not changed.

## AWBS controller

AWBS measures each completed batch on the actual device, including compact-block
receive, native scanning and the transparent-address tail.

- Starting batch: **2,000 blocks** (the current wallet setting).
- Minimum adaptive batch: **1,000**.
- Maximum adaptive batch: **10,000**.
- If a batch completes in under ~2 seconds, the next batch grows by 25%.
- If it takes over ~8 seconds, the next batch shrinks by 25%.
- Otherwise the current size is retained.
- The size is clamped to the safe 1,000..10,000 range.

The controller only changes newly queued requests after the current batch has
fully completed; already-prefetched ranges keep their exact captured bounds. It never changes the order of wallet commits.

## Why this is the right layer

The scanner is the expensive cryptographic engine. AWBS does not duplicate or
replace it. It controls how much work is handed to that scanner at once,
allowing fast devices/network paths to amortize RPC overhead while preventing
slow phones from accumulating oversized compact-block buffers.

## Current pipeline

`lightwalletd -> shared HTTP/2 channel -> bounded RPC fetch pool -> deep prefetch
queue -> parallel cryptographic detection -> ordered wallet/tree commit ->
transparent transaction scan -> immediate continuation`

WarpCore keeps up to 8 future ranges queued, using a separate bounded 4-worker
RPC fetch pool. Fetched compact blocks remain decoded protobuf objects until the
ordered scanner consumes them, eliminating the old encode/reparse step.

## WarpCore V8 implementation

`lightwalletd -> shared HTTP/2 channel -> bounded RPC fetch pool -> deep prefetch queue -> parallel cryptographic detection -> ordered wallet/tree commit -> transparent transaction scan -> immediate continuation`

CPU worker count is automatic when the caller passes 0, bounded by the native
engine to 2..12. The app uses automatic mode and reports the actual worker count
in AWBS LIVE.

## Validation required on-device

The build environment here does not contain a Rust toolchain, so the native
crate cannot be compiled in this environment. Before shipping, run:

1. `cargo fmt --check` / project formatter.
2. Android release/debug build.
3. New-wallet sync from the current server tree state.
4. Existing-wallet resume after interruption/backgrounding.
5. 2,000-block starting batch and observe AWBS growth/shrink in logs.
6. Reorg/retry test.
7. Balance/history/address regression tests.
8. Send/signing regression with Sapling parameters installed.

No signature or wallet serialization changes are introduced by AWBS.
