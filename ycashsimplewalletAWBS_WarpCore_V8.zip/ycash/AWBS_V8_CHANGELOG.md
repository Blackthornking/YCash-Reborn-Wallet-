# AWBS WarpCore V8 — Deep Overlapped Sync

- Added a bounded RPC fetch pool (4 fetch workers) feeding the existing 8-range prefetch window.
- Preserved a single shared tonic HTTP/2 channel for all compact-block range requests.
- Added a decoded `CompactBlock` scanner entry point so WarpCore no longer encodes each protobuf block to bytes and immediately parses it back. The legacy byte-based scanner remains unchanged for compatibility.
- Preserved strict height ordering, reorg detection, commitment-tree insertion, witness updates, wallet transaction mutation, transparent scanning, and checkpoint/resume behavior.
- The app's normal sync entry now starts at 2,000 blocks and lets native AWBS choose the CPU worker count automatically (bounded 2..12); the live UI reports the actual worker count.
- Kept adaptive batch control bounded at 1,000..10,000 blocks, with 25% growth after fast batches and 25% backoff after slow batches.
- Prefetched ranges retain their exact start/end heights; an adaptive decision only affects newly queued ranges, preventing in-flight ranges from being silently resized.
- No changes to wallet/key serialization, transaction serialization, signature format, or verification behavior.

## Pipeline

`RPC fetch -> deep prefetch -> parallel crypto -> ordered commit -> transparent tail -> next range`

The RPC stage is allowed to run ahead while the ordered scanner is busy. The final wallet state remains deterministic and chain ordered.

## Build note

This source package was updated in an environment without Flutter/Rust toolchains, so a native APK cannot be compiled here. Run the project's Android build on a machine with Flutter, Android SDK/NDK and Rust/NDK targets installed.
