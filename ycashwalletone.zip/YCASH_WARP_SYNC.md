# Ycash Warp Sync

This project now uses a Ycash-native Warp-style compact-block pipeline in the
vendored `yecshell-lib` synchronizer.

## What changed

- Compact-block ranges are fetched into bounded in-memory batches.
- Up to two ranges are prefetched concurrently.
- Network transfer overlaps the existing Ycash scanner and its elliptic-curve
  / batched Sapling trial-decryption work.
- Wallet state is still scanned and committed strictly in block-height order.
- A range is validated for contiguous height and exact requested length before
  it is scanned.
- Prefetched ranges are discarded and rebuilt after a detected reorg.
- The existing Ycash batch trial-decryption engine is untouched.
- The existing batch size and worker-count FFI controls remain compatible.

## Safety/invariants

The optimization changes scheduling and transport overlap only. It does not
change note-decryption semantics, wallet key material, transaction formats,
or the sequential wallet-state rules enforced by `scan_block_with_pool`.

The prefetch queue is bounded to two ranges to prevent unbounded memory growth.
If a range fetch fails, the existing synchronizer retry path receives the error.

## Runtime pipeline

`lightwalletd -> prefetched compact ranges -> existing Ycash batch scanner -> ordered wallet commit`

The old callback-based `fetch_blocks` primitive remains available for other
callers. The synchronizer uses the new `fetch_blocks_vec` primitive so network
I/O can run independently of block scanning.
