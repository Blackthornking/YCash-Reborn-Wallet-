# Phase 48 — Real Regtest Execution Harness

## Added
- Fail-closed `ycashd` regtest harness entry point.
- Records the exact node version used for evidence.
- Creates an artifact directory for real execution output.
- Refuses to generate or label synthetic CompactBlock bytes as regtest evidence.

## Required pass evidence
1. `ycashd` available and started in regtest.
2. Compatible compact-block/lightwallet service captures bytes from that node.
3. A wallet-owned Sapling output is scanned through the Phase 46 adapter.
4. The resulting note and chain metadata reach authenticated storage atomically.

## Current status
**HARNESS BUILT — NOT EXECUTED.** No `ycashd` binary or compatible lightwallet service was available in this build environment, so no pass claim is made.
