# Phase 17 — Real Sapling Integration Preparation

## Completed in this package

- Added a production upstream lock manifest.
- Added Rust integration metadata that rejects an unpinned production state.
- Preserved the Ycash-only, Sapling-only architecture.
- Kept Orchard and Halo2 out of the wallet core.
- Defined the required validation gates before enabling real spending.

## Required before claiming real-money functionality

1. Pin immutable commits for all upstream components.
2. Vendor or lock the exact source revisions.
3. Compile the complete Rust workspace.
4. Verify Ycash key and `ys...` address test vectors.
5. Perform compact-block trial decryption against a Ycash lightwallet server.
6. Verify detected notes, nullifiers and balances against an independent Ycash wallet/node.
7. Test reorg and rewind handling.
8. Build and submit test transactions to a controlled environment before mainnet spending.
9. Run dependency and security review.

## Important

This package does **not** claim that Phase 17 has safely enabled spending. The supplied archives and current project structure are not enough to honestly certify a production Sapling signer without pinning, compiling and validating the exact Ycash-compatible upstream revisions.
