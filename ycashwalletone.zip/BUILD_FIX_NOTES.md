Ycash One build fix (2026-09-09)

Root cause: the Android build invokes Cargo in packages/warp_api_ffi/native/zcash-sync.
That manifest's dependency graph reaches Orchard 0.12, which requires yanked core2 ^0.3.

Fix: the actual zcash-sync workspace now contains a [patch.crates-io] override for core2,
using a local compatibility package backed by corez. Existing halo2 recovery patches are
kept in the same single patch table.

Validation performed here: ZIP integrity and manifest structure were checked. Full Android
Cargo/NDK compilation cannot be executed in this environment because cargo is unavailable.
