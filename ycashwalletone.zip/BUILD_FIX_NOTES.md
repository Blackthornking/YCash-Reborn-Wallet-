Build dependency fix

Replaced yanked crates.io orchard = "0.3.0" dependencies with the historical hhanh00/orchard git revision 9862176. This matches the upstream ZWallet patch configuration bundled with this project and is intended to preserve the old zcash-warpsync API compatibility.

The packaging environment used here does not include Cargo, so this archive was integrity-checked but not fully compiled. Run the Android CI build next to validate dependency resolution and expose any subsequent compiler errors.
