import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../design/tokens.dart';
import '../design/widgets.dart';
import '../core/providers.dart';
import 'router.dart';

/// Root widget. Onboarding completion is derived from whether a seed and a
/// security method (biometrics-capable device, or an app password) are
/// already in place, via [onboardingStatusProvider] — there's no separate
/// "onboarding done" flag to drift out of sync with the actual wallet
/// state.
///
/// The router itself (`_router`) is built exactly once — lazily, on first
/// use, via `late final` — and its
/// `hasCompletedOnboarding` closure always does a live `ref.read` of
/// [onboardingStatusProvider] rather than capturing a value computed at
/// boot. That matters because go_router only re-runs `redirect` when a
/// navigation happens — it doesn't poll — so the two places that change
/// the right answer (finishing onboarding, wiping the wallet) explicitly
/// update the provider *before* they navigate, and the redirect that fires
/// from that navigation call sees the fresh value immediately, instead of
/// only after the next cold start re-reads storage.
class YcashRebornApp extends ConsumerStatefulWidget {
  const YcashRebornApp({super.key});

  @override
  ConsumerState<YcashRebornApp> createState() => _YcashRebornAppState();
}

class _YcashRebornAppState extends ConsumerState<YcashRebornApp> {
  late final GoRouter _router = buildRouter(
    hasCompletedOnboarding: () => ref.read(onboardingStatusProvider).valueOrNull ?? false,
  );

  @override
  Widget build(BuildContext context) {
    final status = ref.watch(onboardingStatusProvider);

    // Only gate on the *initial* load/failure (no value yet at all) — once
    // we have a value, later refreshes/errors on this provider shouldn't
    // yank the user back to a bare spinner or error screen out from under
    // whatever they're doing.
    if (!status.hasValue) {
      if (status.hasError) {
        // Previously unguarded: a secure-storage read failure at boot left
        // every single launch stuck on a bare spinner forever, since the
        // router never got built and nothing else in the tree could ever
        // run. This is the one spot where that would hit every user, every
        // cold start — now it's a retryable error like everywhere else.
        YHaptics.warn();
        return MaterialApp(
          theme: buildYcashLightTheme(),
          darkTheme: buildYcashTheme(),
          themeMode: ref.watch(themeModeProvider).valueOrNull ?? ThemeMode.dark,
          home: Scaffold(
            body: Center(
              child: YErrorState(
                message: 'Could not start Ycash.',
                onRetry: () => ref.invalidate(onboardingStatusProvider),
              ),
            ),
          ),
        );
      }
      return MaterialApp(
        theme: buildYcashLightTheme(),
        darkTheme: buildYcashTheme(),
        themeMode: ref.watch(themeModeProvider).valueOrNull ?? ThemeMode.dark,
        home: const _YCashStartupScreen(),
      );
    }

    return MaterialApp.router(
      title: 'Ycash',
      theme: buildYcashLightTheme(),
      darkTheme: buildYcashTheme(),
      themeMode: ref.watch(themeModeProvider).valueOrNull ?? ThemeMode.dark,
      routerConfig: _router,
    );
  }
}


class _YCashStartupScreen extends StatelessWidget {
  const _YCashStartupScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Semantics(
        label: 'Ycash wallet starting securely',
        child: SizedBox.expand(
          child: Image.asset(
            'assets/branding/startup_page.png',
            fit: BoxFit.cover,
            filterQuality: FilterQuality.high,
            excludeFromSemantics: true,
          ),
        ),
      ),
    );
  }
}
