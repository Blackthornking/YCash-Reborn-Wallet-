import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../design/tokens.dart';
import '../design/widgets.dart';
import '../core/providers.dart';
import 'router.dart';

/// Root widget. Onboarding completion is derived from whether a seed and a
/// security method (biometrics-capable device, or an app PIN) are already
/// in place — there's no separate "onboarding done" flag to drift out of
/// sync with the actual wallet state.
class YcashRebornApp extends ConsumerStatefulWidget {
  const YcashRebornApp({super.key});

  @override
  ConsumerState<YcashRebornApp> createState() => _YcashRebornAppState();
}

class _YcashRebornAppState extends ConsumerState<YcashRebornApp> {
  GoRouter? _router;
  bool? _onboardingDone;
  Object? _checkError;

  @override
  void initState() {
    super.initState();
    _checkOnboarding();
  }

  Future<void> _checkOnboarding() async {
    setState(() => _checkError = null);
    try {
      final vault = ref.read(seedVaultProvider);
      final backedUp = await vault.isBackupConfirmed;
      if (!mounted) return;
      setState(() {
        _onboardingDone = backedUp;
        _router = buildRouter(hasCompletedOnboarding: () => _onboardingDone ?? false);
      });
    } catch (e) {
      // Previously unguarded: a secure-storage read failure at boot left
      // every single launch stuck on a bare spinner forever, since
      // `_router` never got built and nothing else in the tree could ever
      // run. This is the one spot where that would hit every user, every
      // cold start — now it's a retryable error like everywhere else.
      YHaptics.warn();
      if (mounted) setState(() => _checkError = e);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_router == null) {
      return MaterialApp(
        theme: buildYcashLightTheme(),
        darkTheme: buildYcashTheme(),
        themeMode: ref.watch(themeModeProvider).valueOrNull ?? ThemeMode.dark,
        home: _checkError != null
            ? Scaffold(
                body: Center(
                  child: YErrorState(
                    message: 'Could not start Ycash.',
                    onRetry: _checkOnboarding,
                  ),
                ),
              )
            : const _YCashStartupScreen(),
      );
    }
    return MaterialApp.router(
      title: 'Ycash',
      theme: buildYcashLightTheme(),
      darkTheme: buildYcashTheme(),
      themeMode: ref.watch(themeModeProvider).valueOrNull ?? ThemeMode.dark,
      routerConfig: _router,
    );
  }
}


class _YCashStartupScreen extends StatelessWidget {
  const _YCashStartupScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Semantics(
        label: 'Ycash wallet starting securely',
        child: SizedBox.expand(
          child: Image.asset(
            'assets/branding/startup_page.png',
            fit: BoxFit.cover,
            filterQuality: FilterQuality.high,
            excludeFromSemantics: true,
          ),
        ),
      ),
    );
  }
}
