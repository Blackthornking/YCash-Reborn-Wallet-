import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app/app.dart';
import 'core/background_sync/background_sync.dart';
import 'core/crypto_bridge/ycash_core_ffi_engine.dart';
import 'core/providers.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Registers the callback dispatcher WorkManager relaunches into for the
  // background-sync job (Settings > Network > Background sync). Cheap and
  // idempotent -- safe to call on every cold start regardless of whether
  // the job ends up actually scheduled.
  await BackgroundSyncScheduler.initialize();

  runApp(
    ProviderScope(
      overrides: [
        engineProvider.overrideWithValue(YcashCoreFfiEngine()),
      ],
      child: const YcashRebornApp(),
    ),
  );
}
