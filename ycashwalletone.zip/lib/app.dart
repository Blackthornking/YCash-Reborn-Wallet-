import 'package:flutter/material.dart';
import 'core/wallet.dart';
import 'screens/home.dart';
import 'screens/onboarding.dart';

class YcashSimpleApp extends StatefulWidget { const YcashSimpleApp({super.key}); @override State<YcashSimpleApp> createState()=>_AppState(); }
class _AppState extends State<YcashSimpleApp> {
  final wallet=SimpleWallet();
  bool? exists;
  @override void initState(){super.initState(); _check();}
  Future<void> _check() async { final e=await wallet.hasWallet(); if(mounted)setState(()=>exists=e); }
  @override Widget build(BuildContext c){
    if(exists==null) return const MaterialApp(home:Scaffold(body:Center(child:CircularProgressIndicator())));
    return MaterialApp(
      title:'Ycash',
      debugShowCheckedModeBanner:false,
      theme:ThemeData(useMaterial3:true,brightness:Brightness.dark,scaffoldBackgroundColor:const Color(0xFF080807)),
      home: exists! ? FutureBuilder(future:wallet.openSaved(),builder:(c,s){
        if(s.hasError)return Onboarding(wallet:wallet,onDone:()=>setState(()=>exists=true));
        if(s.connectionState!=ConnectionState.done)return const Scaffold(body:Center(child:CircularProgressIndicator()));
        return Home(wallet:wallet);
      }) : Onboarding(wallet:wallet,onDone:()=>setState(()=>exists=true)),
    );
  }
}
