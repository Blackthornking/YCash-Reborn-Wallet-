import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'permission_rationale.dart';

/// Explains camera use once, before the first time a QR scanner is opened
/// (mobile_scanner requests the actual OS camera permission itself once the
/// scanner starts). Later opens skip the dialog -- Android already asked,
/// and if the person denied it, mobile_scanner's own screen shows a
/// retry-capable error state rather than a silent black preview.
///
/// Returns true if the scanner should be opened (either the rationale was
/// already shown before, or the person just chose "Continue").
Future<bool> ensureCameraRationaleShown(BuildContext context) async {
  const key = 'ycash.permissions.camera_explained_v1';
  try {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getBool(key) == true) return true;

    if (!context.mounted) return true;
    final proceed = await showPermissionRationale(
      context,
      icon: Icons.qr_code_scanner,
      title: 'Allow camera access?',
      message: 'Ycash uses your camera only to scan a Ycash address QR '
          'code. Nothing is recorded or sent anywhere.',
    );
    if (proceed) await prefs.setBool(key, true);
    return proceed;
  } catch (_) {
    return true;
  }
}
