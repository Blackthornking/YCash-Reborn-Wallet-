import 'package:flutter/material.dart';

/// Shows a plain-language explanation of why a permission is needed,
/// *before* the OS permission prompt itself fires. Android's own dialog
/// only shows the permission name -- this is where the "why" goes.
///
/// Returns true if the person chose to continue (the caller should then
/// make the actual OS permission request), false if they dismissed it or
/// tapped "Not now" (the caller should skip the request rather than
/// surprise them with a system dialog they didn't expect).
Future<bool> showPermissionRationale(
  BuildContext context, {
  required IconData icon,
  required String title,
  required String message,
}) async {
  final proceed = await showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder: (ctx) => AlertDialog(
      icon: Icon(icon),
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(false),
          child: const Text('Not now'),
        ),
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(true),
          child: const Text('Continue'),
        ),
      ],
    ),
  );
  return proceed ?? false;
}
