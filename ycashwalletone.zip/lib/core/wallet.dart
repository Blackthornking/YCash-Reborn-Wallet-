import 'dart:async';
import 'dart:io';
import 'dart:isolate';
import 'package:path_provider/path_provider.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:ycash_core/ycash_core.dart';
import 'config.dart';

class SimpleSyncStatus {
  final String phase;
  final int height;
  final int tip;
  final int birthday;
  final String? error;
  const SimpleSyncStatus(this.phase,this.height,this.tip,this.birthday,this.error);
  bool get syncing => phase == 'connecting' || phase == 'scanning' || phase == 'fetching_memos';
  double get progress {
    final span=tip-birthday;
    if(span<=0) return tip>0?1:0;
    return ((height-birthday)/span).clamp(0.0,1.0).toDouble();
  }
}

class SimpleWallet {
  final _storage=const FlutterSecureStorage();
  final _native=YcashCoreNative.instance;
  Timer? _poll;
  bool opened=false;
  String? _seed;
  final status=StreamController<SimpleSyncStatus>.broadcast();

  Future<String> _dataDir() async {
    final base=await getApplicationSupportDirectory();
    final d=Directory('${base.path}/ycash-simple-wallet');
    if(!await d.exists()) await d.create(recursive:true);
    return d.path;
  }

  Future<bool> hasWallet() async => (await _storage.read(key:'ycash.simple.seed'))?.isNotEmpty == true;

  Future<void> create() async {
    final seed=_native.generateMnemonic();
    await _storage.write(key:'ycash.simple.seed',value:seed);
    await _open(seed, isNew:true);
  }

  Future<void> restore(String seed) async {
    final clean=seed.trim().replaceAll(RegExp(r'\\s+'),' ');
    if(clean.split(' ').length != 24) throw StateError('Enter the 24-word Ycash recovery phrase.');
    await _storage.write(key:'ycash.simple.seed',value:clean);
    await _open(clean, isNew:false, replace:true);
  }

  Future<void> openSaved() async {
    final seed=await _storage.read(key:'ycash.simple.seed');
    if(seed==null || seed.isEmpty) throw StateError('No wallet found.');
    await _open(seed,isNew:false);
  }

  Future<void> _open(String seed,{required bool isNew,bool replace=false}) async {
    final dir=await _dataDir();
    await Isolate.run(() {
      final n=YcashCoreNative.instance;
      n.configure(server:YcashConfig.lightwalletd,dataDir:dir);
      if(replace) {
        try { n.wipeYecWallet(); } catch (_) {}
      }
      n.openYecWallet(seed,birthday:isNew?YcashCoreNative.newWalletBirthday:0);
    });
    _seed=seed; opened=true;
    startSync();
    _poll?.cancel();
    _poll=Timer.periodic(const Duration(milliseconds:250),(_)=>_emit());
    _emit();
  }

  void _emit() {
    try {
      final s=_native.syncStatus();
      status.add(SimpleSyncStatus(
        s['phase']?.toString()??'idle',
        (s['synced_blocks'] as num?)?.toInt()??0,
        (s['total_blocks'] as num?)?.toInt()??0,
        (s['birthday'] as num?)?.toInt()??YcashConfig.forkHeight,
        s['last_error']?.toString(),
      ));
    } catch(_){}
  }

  void startSync() {
    if(!opened && _seed==null) return;
    final s=_native.syncStatus();
    if(s['is_syncing']==true) return;
    _native.startBatchSync(batchSize:YcashConfig.modernBatchSize,workers:YcashConfig.modernWorkers);
    _emit();
  }

  Map<String,dynamic> balances()=>Map<String,dynamic>.from(_native.balances());
  Map<String,dynamic> addresses()=>Map<String,dynamic>.from(_native.addresses());
  List<dynamic> history()=>_native.history();
  Map<String,dynamic> planSend({required String to,required int amount,String? memo})=>
      _native.planSend(to:to,amount:amount,memo:memo);
  String broadcast(Map<String,dynamic> plan)=>_native.broadcastPlan(plan);

  Future<void> wipe() async {
    _poll?.cancel(); _poll=null;
    try{_native.wipeYecWallet();}catch(_){}
    await _storage.delete(key:'ycash.simple.seed');
    opened=false; _seed=null;
  }
}
