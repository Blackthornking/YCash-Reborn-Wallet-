import 'dart:convert';
import 'dart:math';
import 'dart:ffi';
import 'dart:io';

import 'package:ffi/ffi.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';

enum GateReason { revealSeedOrKeys, confirmSend, confirmShield, confirmUnshield, changeSecuritySettings, wipeWallet, enableBiometrics }

class BiometricAuthResult {
  final bool authenticated;
  final String? error;
  const BiometricAuthResult(this.authenticated, [this.error]);
}

/// PIN verification uses Argon2id in the Rust native layer. The encrypted
/// record is additionally protected by a non-exportable Android Keystore key.
class BiometricGate {
  BiometricGate({LocalAuthentication? localAuth, FlutterSecureStorage? storage})
      : _localAuth = localAuth ?? LocalAuthentication(),
        _storage = storage ?? const FlutterSecureStorage();

  final LocalAuthentication _localAuth;
  final FlutterSecureStorage _storage;

  static const _pinRecordKey = 'ycash.security.pin_record.v3';
  static const _legacyPinRecordKey = 'ycash.security.pin_record.v2';
  static const _legacyPinHashKey = 'ycash.security.pin_hash';
  static const _channel = MethodChannel('com.ycashfoundation.ycash/security');

  // OWASP-style interactive baseline. Kept explicit in the stored record for
  // future parameter upgrades.
  static const _memoryKiB = 65536;
  static const _iterations = 3;
  static const _parallelism = 1;
  static const _saltBytes = 16;

  Future<bool> get canUseBiometrics async {
    try => await _localAuth.isDeviceSupported() && await _localAuth.canCheckBiometrics;
    catch (_) => false;
  }

  Future<bool> get hasPinFallback async =>
      (await _storage.read(key: _pinRecordKey)) != null ||
      (await _storage.read(key: _legacyPinRecordKey)) != null ||
      (await _storage.read(key: _legacyPinHashKey)) != null;

  String _reasonText(GateReason reason) => switch (reason) {
    GateReason.revealSeedOrKeys => 'Authenticate to view your recovery phrase',
    GateReason.confirmSend => 'Authenticate to send funds',
    GateReason.confirmShield => 'Authenticate to shield funds',
    GateReason.confirmUnshield => 'Authenticate to unshield funds',
    GateReason.changeSecuritySettings => 'Authenticate to change security settings',
    GateReason.wipeWallet => 'Authenticate to erase this wallet',
    GateReason.enableBiometrics => 'Authenticate to enable biometric protection',
  };

  Future<BiometricAuthResult> authenticateBiometricsOnly(GateReason reason) async {
    if (!await canUseBiometrics) return const BiometricAuthResult(false, 'no_biometrics_use_pin');
    try {
      final ok = await _localAuth.authenticate(localizedReason: _reasonText(reason), options: const AuthenticationOptions(stickyAuth: true, biometricOnly: true));
      return ok ? const BiometricAuthResult(true) : const BiometricAuthResult(false, 'Authentication failed');
    } catch (e) { return BiometricAuthResult(false, e.toString()); }
  }

  Future<BiometricAuthResult> authenticate(GateReason reason) async {
    if (!await canUseBiometrics) return const BiometricAuthResult(false, 'no_biometrics_use_pin');
    try {
      final ok = await _localAuth.authenticate(localizedReason: _reasonText(reason), options: const AuthenticationOptions(stickyAuth: true, biometricOnly: false));
      return ok ? const BiometricAuthResult(true) : const BiometricAuthResult(false, 'Authentication failed');
    } catch (e) { return BiometricAuthResult(false, e.toString()); }
  }

  Future<void> setPin(String pin) async {
    if (pin.length < 6 || !RegExp(r'^\d+$').hasMatch(pin)) throw ArgumentError('PIN must contain at least 6 digits.');
    final salt = List<int>.generate(_saltBytes, (_) => Random.secure().nextInt(256));
    final saltB64 = base64UrlEncode(salt).replaceAll('=', '');
    final derived = _argon2id(pin, saltB64, _memoryKiB, _iterations, _parallelism);
    final record = jsonEncode({
      'v': 3, 'kdf': 'Argon2id', 'm': _memoryKiB, 't': _iterations,
      'p': _parallelism, 's': saltB64, 'd': derived,
    });
    final protected = await _channel.invokeMethod<String>('protect', {'plaintext': record});
    if (protected == null) throw StateError('Android Keystore failed to protect PIN record');
    await _storage.write(key: _pinRecordKey, value: protected);
    await _storage.delete(key: _legacyPinRecordKey);
    await _storage.delete(key: _legacyPinHashKey);
  }

  Future<bool> verifyPin(String pin) async {
    final protected = await _storage.read(key: _pinRecordKey);
    if (protected == null) return false;
    try {
      final encoded = await _channel.invokeMethod<String>('unprotect', {'ciphertext': protected});
      if (encoded == null) return false;
      final r = jsonDecode(encoded) as Map<String, dynamic>;
      if (r['v'] != 3 || r['kdf'] != 'Argon2id') return false;
      final actual = _argon2id(pin, r['s'] as String, r['m'] as int, r['t'] as int, r['p'] as int);
      return _constantTimeEquals(base64Url.decode(_pad(actual)), base64Url.decode(_pad(r['d'] as String)));
    } catch (_) { return false; }
  }

  String _argon2id(String pin, String salt, int memoryKiB, int iterations, int parallelism) {
    if (!Platform.isAndroid && !Platform.isLinux && !Platform.isMacOS && !Platform.isWindows) throw UnsupportedError('Native Argon2id is unavailable');
    final lib = Platform.isAndroid || Platform.isLinux
        ? DynamicLibrary.open('libycash_core.so')
        : Platform.isMacOS ? DynamicLibrary.open('libycash_core.dylib') : DynamicLibrary.open('ycash_core.dll');
    final fn = lib.lookupFunction<Pointer<Utf8> Function(Pointer<Utf8>, Pointer<Utf8>, Uint32, Uint32, Uint32, Pointer<Pointer<Utf8>>), Pointer<Utf8> Function(Pointer<Utf8>, Pointer<Utf8>, int, int, int, Pointer<Pointer<Utf8>>) >('ycash_pin_argon2id');
    final free = lib.lookupFunction<Void Function(Pointer<Utf8>), void Function(Pointer<Utf8>)>('ycash_string_free');
    final p = pin.toNativeUtf8(); final s = salt.toNativeUtf8(); final err = calloc<Pointer<Utf8>>();
    try {
      final out = fn(p, s, memoryKiB, iterations, parallelism, err);
      if (out == nullptr) { final msg = err.value == nullptr ? 'Argon2id failed' : err.value.toDartString(); if (err.value != nullptr) free(err.value); throw StateError(msg); }
      try { return out.toDartString(); } finally { free(out); }
    } finally { calloc.free(p); calloc.free(s); calloc.free(err); }
  }

  String _pad(String s) => s.padRight(s.length + ((4 - s.length % 4) % 4), '=');
  bool _constantTimeEquals(List<int> a, List<int> b) { if (a.length != b.length) return false; var d=0; for (var i=0;i<a.length;i++) d |= a[i]^b[i]; return d==0; }
}
