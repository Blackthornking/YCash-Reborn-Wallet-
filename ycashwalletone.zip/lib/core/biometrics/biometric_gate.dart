import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:ffi';
import 'dart:io';

import 'package:ffi/ffi.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';

enum GateReason { revealSeedOrKeys, confirmSend, confirmShield, confirmUnshield, changeSecuritySettings, wipeWallet, enableBiometrics }

class BiometricAuthResult {
  final bool authenticated;
  final String? error;
  const BiometricAuthResult(this.authenticated, [this.error]);
}

/// Thrown by [BiometricGate.verifyPin] when too many recent PIN attempts
/// have failed. Callers should surface [remaining] to the user rather than
/// retrying immediately.
class PinLockedOutException implements Exception {
  final Duration remaining;
  const PinLockedOutException(this.remaining);

  @override
  String toString() {
    final total = remaining.inSeconds.clamp(0, 1 << 30);
    final m = total ~/ 60;
    final s = total % 60;
    return m > 0
        ? 'Too many incorrect attempts. Try again in ${m}m ${s}s.'
        : 'Too many incorrect attempts. Try again in ${s}s.';
  }
}

/// Thrown when the Android Keystore key protecting the PIN record was
/// permanently invalidated (e.g. the device's screen lock was removed or
/// reset at the OS level). The old encrypted record can never be decrypted
/// again — the user must set a new PIN.
class PinRecordInvalidatedException implements Exception {
  const PinRecordInvalidatedException();

  @override
  String toString() =>
      'Your device security settings changed, so the saved PIN could not be '
      'recovered. Please set a new PIN.';
}

/// PIN verification uses Argon2id in the Rust native layer. The encrypted
/// record is additionally protected by a non-exportable Android Keystore key.
class BiometricGate {
  BiometricGate({LocalAuthentication? localAuth, FlutterSecureStorage? storage})
      : _localAuth = localAuth ?? LocalAuthentication(),
        _storage = storage ?? const FlutterSecureStorage();

  final LocalAuthentication _localAuth;
  final FlutterSecureStorage _storage;

  static const _pinRecordKey = 'ycash.security.pin_record.v3';
  static const _legacyPinRecordKey = 'ycash.security.pin_record.v2';
  static const _legacyPinHashKey = 'ycash.security.pin_hash';
  static const _pinAttemptsKey = 'ycash.security.pin_attempts';
  static const _pinLockedUntilKey = 'ycash.security.pin_locked_until';
  static const _channel = MethodChannel('com.ycashfoundation.ycash/security');

  // Exponential-ish backoff after repeated wrong PINs, keyed by the total
  // number of consecutive failures. Slows scripted/automated brute forcing
  // without ever destroying wallet data.
  static Duration _lockoutFor(int attempts) {
    if (attempts < 3) return Duration.zero;
    if (attempts < 5) return const Duration(seconds: 30);
    if (attempts < 7) return const Duration(minutes: 2);
    if (attempts < 10) return const Duration(minutes: 10);
    return const Duration(minutes: 30);
  }

  // OWASP-style interactive baseline. Kept explicit in the stored record for
  // future parameter upgrades.
  static const _memoryKiB = 65536;
  static const _iterations = 3;
  static const _parallelism = 1;
  static const _saltBytes = 16;

  Future<bool> get canUseBiometrics async {
    try {
      return await _localAuth.isDeviceSupported() && await _localAuth.canCheckBiometrics;
    } catch (_) {
      return false;
    }
  }

  Future<bool> get hasPinFallback async =>
      (await _storage.read(key: _pinRecordKey)) != null ||
      (await _storage.read(key: _legacyPinRecordKey)) != null ||
      (await _storage.read(key: _legacyPinHashKey)) != null;

  String _reasonText(GateReason reason) => switch (reason) {
    GateReason.revealSeedOrKeys => 'Authenticate to view your recovery phrase',
    GateReason.confirmSend => 'Authenticate to send funds',
    GateReason.confirmShield => 'Authenticate to shield funds',
    GateReason.confirmUnshield => 'Authenticate to unshield funds',
    GateReason.changeSecuritySettings => 'Authenticate to change security settings',
    GateReason.wipeWallet => 'Authenticate to erase this wallet',
    GateReason.enableBiometrics => 'Authenticate to enable biometric protection',
  };

  Future<BiometricAuthResult> authenticateBiometricsOnly(GateReason reason) async {
    if (!await canUseBiometrics) return const BiometricAuthResult(false, 'no_biometrics_use_pin');
    try {
      final ok = await _localAuth.authenticate(localizedReason: _reasonText(reason), options: const AuthenticationOptions(stickyAuth: true, biometricOnly: true));
      return ok ? const BiometricAuthResult(true) : const BiometricAuthResult(false, 'Authentication failed');
    } catch (e) { return BiometricAuthResult(false, e.toString()); }
  }

  Future<BiometricAuthResult> authenticate(GateReason reason) async {
    if (!await canUseBiometrics) return const BiometricAuthResult(false, 'no_biometrics_use_pin');
    try {
      final ok = await _localAuth.authenticate(localizedReason: _reasonText(reason), options: const AuthenticationOptions(stickyAuth: true, biometricOnly: false));
      return ok ? const BiometricAuthResult(true) : const BiometricAuthResult(false, 'Authentication failed');
    } catch (e) { return BiometricAuthResult(false, e.toString()); }
  }

  Future<void> setPin(String pin) async {
    if (pin.length < 6 || !RegExp(r'^\d+$').hasMatch(pin)) throw ArgumentError('PIN must contain at least 6 digits.');
    final salt = List<int>.generate(_saltBytes, (_) => Random.secure().nextInt(256));
    final saltB64 = base64UrlEncode(salt).replaceAll('=', '');
    final derived = _argon2id(pin, saltB64, _memoryKiB, _iterations, _parallelism);
    final record = jsonEncode({
      'v': 3, 'kdf': 'Argon2id', 'm': _memoryKiB, 't': _iterations,
      'p': _parallelism, 's': saltB64, 'd': derived,
    });
    final protected = await _protect(record);
    await _storage.write(key: _pinRecordKey, value: protected);
    await _storage.delete(key: _legacyPinRecordKey);
    await _storage.delete(key: _legacyPinHashKey);
    // A fresh PIN clears any prior lockout — the old failure count no
    // longer applies to a PIN the user hasn't tried yet.
    await _clearLockout();
  }

  /// Verifies [pin] against the stored record.
  ///
  /// Throws [PinLockedOutException] if too many recent attempts have
  /// failed, and [PinRecordInvalidatedException] if the OS invalidated the
  /// Keystore key backing the record (the record is unrecoverable and the
  /// user must set a new PIN).
  Future<bool> verifyPin(String pin) async {
    final lockedUntil = await _lockedUntil();
    if (lockedUntil != null) {
      final remaining = lockedUntil.difference(DateTime.now());
      if (remaining > Duration.zero) throw PinLockedOutException(remaining);
    }

    final protected = await _storage.read(key: _pinRecordKey);
    if (protected == null) return false;

    // Decrypting the stored record is separate from checking the PIN
    // against it: a reauth prompt being dismissed or a Keystore error here
    // isn't evidence of a wrong PIN guess, so it must not feed the lockout
    // counter (that would let flaky auth prompts lock a legitimate user
    // out just as effectively as wrong guesses would).
    final String encoded;
    try {
      encoded = await _unprotect(protected);
    } on PinRecordInvalidatedException {
      rethrow;
    }

    try {
      final r = jsonDecode(encoded) as Map<String, dynamic>;
      if (r['v'] != 3 || r['kdf'] != 'Argon2id') {
        await _recordFailure();
        return false;
      }
      final actual = _argon2id(pin, r['s'] as String, r['m'] as int, r['t'] as int, r['p'] as int);
      final match = _constantTimeEquals(
        base64Url.decode(_pad(actual)),
        base64Url.decode(_pad(r['d'] as String)),
      );
      if (match) {
        await _clearLockout();
        return true;
      }
      await _recordFailure();
      return false;
    } catch (_) {
      await _recordFailure();
      return false;
    }
  }

  /// How much longer PIN entry is locked out, or null if it's open now.
  Future<Duration?> get pinLockoutRemaining async {
    final lockedUntil = await _lockedUntil();
    if (lockedUntil == null) return null;
    final remaining = lockedUntil.difference(DateTime.now());
    return remaining > Duration.zero ? remaining : null;
  }

  Future<DateTime?> _lockedUntil() async {
    final raw = await _storage.read(key: _pinLockedUntilKey);
    final ms = raw == null ? null : int.tryParse(raw);
    return ms == null ? null : DateTime.fromMillisecondsSinceEpoch(ms);
  }

  Future<void> _recordFailure() async {
    final raw = await _storage.read(key: _pinAttemptsKey);
    final attempts = (int.tryParse(raw ?? '0') ?? 0) + 1;
    await _storage.write(key: _pinAttemptsKey, value: attempts.toString());
    final lockout = _lockoutFor(attempts);
    if (lockout > Duration.zero) {
      final until = DateTime.now().add(lockout);
      await _storage.write(key: _pinLockedUntilKey, value: until.millisecondsSinceEpoch.toString());
    }
  }

  Future<void> _clearLockout() async {
    await _storage.delete(key: _pinAttemptsKey);
    await _storage.delete(key: _pinLockedUntilKey);
  }

  /// Invokes the platform security channel, transparently handling the two
  /// recoverable native error codes:
  ///  - `AUTH_REQUIRED`: the Keystore key's recent-unlock window lapsed.
  ///    Prompt the user to authenticate, then retry once.
  ///  - `KEY_INVALIDATED`: the key can never be used again. Drop the local
  ///    record and surface [PinRecordInvalidatedException].
  // Native calls and the reauth prompt they can trigger must never hang the
  // UI indefinitely: if the system auth activity is torn down mid-prompt
  // (e.g. a config change) the result can be lost and the Future would
  // otherwise never complete, leaving the caller stuck on "Please wait".
  static const _secureCallTimeout = Duration(seconds: 30);

  Future<String> _invokeSecure(String method, Map<String, dynamic> args, {bool retried = false}) async {
    try {
      final result = await _channel
          .invokeMethod<String>(method, args)
          .timeout(_secureCallTimeout);
      if (result == null) throw StateError('$method returned no result');
      return result;
    } on TimeoutException {
      throw StateError(
        'Security check timed out. Please try again.',
      );
    } on PlatformException catch (e) {
      if (e.code == 'AUTH_REQUIRED' && !retried) {
        final reauthed = await _localAuth
            .authenticate(
              localizedReason: 'Confirm your device unlock to continue',
              options: const AuthenticationOptions(stickyAuth: true, biometricOnly: false),
            )
            .timeout(_secureCallTimeout, onTimeout: () => false);
        if (!reauthed) throw StateError('Authentication required to continue');
        return _invokeSecure(method, args, retried: true);
      }
      if (e.code == 'KEY_INVALIDATED') {
        await _storage.delete(key: _pinRecordKey);
        throw const PinRecordInvalidatedException();
      }
      if (e.code == 'NO_DEVICE_CREDENTIAL') {
        throw StateError(
          'Your device has no screen lock (PIN, pattern, password, or '
          'fingerprint) set up. Please set one in your device settings, '
          'then try again.',
        );
      }
      rethrow;
    }
  }

  Future<String> _protect(String plaintext) => _invokeSecure('protect', {'plaintext': plaintext});
  Future<String> _unprotect(String ciphertext) => _invokeSecure('unprotect', {'ciphertext': ciphertext});

  String _argon2id(String pin, String salt, int memoryKiB, int iterations, int parallelism) {
    if (!Platform.isAndroid && !Platform.isLinux && !Platform.isMacOS && !Platform.isWindows) throw UnsupportedError('Native Argon2id is unavailable');
    final lib = Platform.isAndroid || Platform.isLinux
        ? DynamicLibrary.open('libycash_core.so')
        : Platform.isMacOS ? DynamicLibrary.open('libycash_core.dylib') : DynamicLibrary.open('ycash_core.dll');
    final fn = lib.lookupFunction<Pointer<Utf8> Function(Pointer<Utf8>, Pointer<Utf8>, Uint32, Uint32, Uint32, Pointer<Pointer<Utf8>>), Pointer<Utf8> Function(Pointer<Utf8>, Pointer<Utf8>, int, int, int, Pointer<Pointer<Utf8>>) >('ycash_pin_argon2id');
    final free = lib.lookupFunction<Void Function(Pointer<Utf8>), void Function(Pointer<Utf8>)>('ycash_string_free');
    final p = pin.toNativeUtf8(); final s = salt.toNativeUtf8(); final err = calloc<Pointer<Utf8>>();
    try {
      final out = fn(p, s, memoryKiB, iterations, parallelism, err);
      if (out == nullptr) { final msg = err.value == nullptr ? 'Argon2id failed' : err.value.toDartString(); if (err.value != nullptr) free(err.value); throw StateError(msg); }
      try { return out.toDartString(); } finally { free(out); }
    } finally { calloc.free(p); calloc.free(s); calloc.free(err); }
  }

  String _pad(String s) => s.padRight(s.length + ((4 - s.length % 4) % 4), '=');
  bool _constantTimeEquals(List<int> a, List<int> b) { if (a.length != b.length) return false; var d=0; for (var i=0;i<a.length;i++) d |= a[i]^b[i]; return d==0; }
}
