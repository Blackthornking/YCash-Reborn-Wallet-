/// Keeps the wallet caught up while the app isn't open, via an Android
/// WorkManager periodic job -- the same mechanism zodl/Zashi's own
/// `SyncWorker` uses (see their `work/SyncWorker.kt` and `work/WorkIds.kt`):
/// a daily job timed for a randomized early-morning window.
///
/// Two differences from zodl's own defaults, both deliberate:
///  - zodl requires the device to be charging; this does not. Charging
///    isn't something most people have any control over at sync time, and
///    dropping it means the job actually gets a chance to run on a normal
///    day instead of only overnight while plugged in.
///  - zodl always restricts itself to an unmetered (Wi-Fi) connection.
///    Here that's only true in [BackgroundSyncMode.wifiOnly]; the default
///    [BackgroundSyncMode.always] runs on any network.
///
/// The wallet itself is reopened from the Keystore-only cache in
/// [SeedVault.readBackgroundSyncCache] -- see the comment there for why a
/// second, password-free copy of the seed exists at all.
library background_sync;

import 'dart:async';
import 'dart:math';

import 'package:workmanager/workmanager.dart';
import 'package:ycash_core/ycash_core.dart';

import '../crypto_bridge/wallet_paths.dart';
import '../secure_storage/seed_vault.dart';
import '../settings_store/settings_store.dart';

const backgroundSyncTaskName = 'ycash.background_sync.task';
const _uniqueWorkName = 'ycash.background_sync.periodic';

/// Upper bound on how long a single background round is allowed to run.
/// Android gives background jobs a limited execution window (roughly ten
/// minutes on modern versions); this stays safely under that so the OS
/// never has to kill the job mid-write.
const _syncBudget = Duration(minutes: 9);

/// Entry point WorkManager relaunches a headless Flutter engine into.
/// Must stay a top-level function with this exact pragma -- Dart's AOT
/// compiler otherwise tree-shakes it, and WorkManager's saved callback
/// handle resolves to nothing at runtime.
@pragma('vm:entry-point')
void backgroundSyncCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    try {
      await _runBackgroundSyncRound();
    } catch (_) {
      // Nothing to report to -- there's no UI here. WorkManager will just
      // try again on its own schedule regardless.
    }
    return true;
  });
}

Future<void> _runBackgroundSyncRound() async {
  final settings = SettingsStore();
  final mode = await settings.getBackgroundSyncMode();
  if (mode == BackgroundSyncMode.off) return;

  final vault = SeedVault();
  final seed = await vault.readBackgroundSyncCache();
  // Null means either background sync was only just turned on and the
  // wallet hasn't been unlocked since, or there's no wallet on this
  // install at all yet -- either way, nothing to do this round.
  if (seed == null) return;

  final native = YcashCoreNative.instance;
  final server = await settings.getServerUrl();
  final dataDir = await ycashWalletDir();
  native.configure(server: server, dataDir: dataDir);
  native.openYecWallet(seed);
  native.startSync();

  final deadline = DateTime.now().add(_syncBudget);
  while (DateTime.now().isBefore(deadline)) {
    await Future.delayed(const Duration(seconds: 3));
    final status = native.syncStatus();
    if (status['is_syncing'] != true) break;
  }
}

class BackgroundSyncScheduler {
  BackgroundSyncScheduler._();

  /// Call once from `main()`, before `runApp`.
  static Future<void> initialize() =>
      Workmanager().initialize(backgroundSyncCallbackDispatcher);

  /// Registers or cancels the periodic job to match [mode]. Safe to call
  /// any time the mode changes, and also once at startup (after a normal
  /// unlock) so upgrading installs that have never touched the new
  /// Settings row still end up with the job registered per the
  /// [BackgroundSyncMode.always] default.
  static Future<void> apply(BackgroundSyncMode mode) async {
    if (mode == BackgroundSyncMode.off) {
      await Workmanager().cancelByUniqueName(_uniqueWorkName);
      return;
    }
    await Workmanager().registerPeriodicTask(
      _uniqueWorkName,
      backgroundSyncTaskName,
      frequency: const Duration(hours: 24),
      initialDelay: _delayUntilNextSyncWindow(),
      existingWorkPolicy: ExistingPeriodicWorkPolicy.replace,
      constraints: Constraints(
        networkType: mode == BackgroundSyncMode.wifiOnly
            ? NetworkType.unmetered
            : NetworkType.connected,
        requiresStorageNotLow: true,
      ),
    );
  }

  /// Same idea as zodl's `SyncWorker.calculateTargetTimeDifference()`:
  /// aim for a random minute between 3 and 4 a.m. local time, today if
  /// that hasn't passed yet, otherwise tomorrow, so installs don't all
  /// hit the server in the same instant.
  static Duration _delayUntilNextSyncWindow() {
    final now = DateTime.now();
    var target = DateTime(now.year, now.month, now.day, 3, Random().nextInt(60));
    if (!target.isAfter(now)) target = target.add(const Duration(days: 1));
    return target.difference(now);
  }
}
