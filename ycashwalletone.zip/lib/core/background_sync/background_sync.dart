/// Background wallet synchronization.
///
/// "On" and "Wi-Fi only" share the same mechanism: a dataSync foreground
/// service keeps the Flutter/Rust wallet process alive and polls the native
/// sync engine every 30 seconds, updating a low-priority notification with
/// progress. The only difference is that "Wi-Fi only" checks the device's
/// current connection on every tick and idles (no sync call, no network use)
/// whenever it isn't Wi-Fi, instead of not running the service at all.
///
/// The service stays up and keeps ticking for its whole budget window even
/// once it has caught up to the tip -- "Continuous" means continuous, so
/// catching up and then having nothing new for a while is a normal steady
/// state, not a reason to stop. Each tick still nudges the native side so a
/// newly mined block is picked up within one interval. WorkManager remains
/// as an hourly fallback for the window after the foreground service's
/// budget has expired and before the app is next opened. To avoid two
/// isolates opening the same on-disk wallet.dat at once (yecshell-lib has no
/// file locking of its own), the foreground service writes a heartbeat
/// timestamp on every tick, and the WorkManager round skips itself whenever
/// that heartbeat is fresh.
///
/// Android 15+ limits dataSync foreground services to six hours in a rolling
/// 24-hour period. We stop at five and a half hours so we remain below that
/// hard limit. Bringing Ycash back to the foreground lets Android grant a
/// fresh window; the app's lifecycle hook re-starts the service if needed.
library background_sync;

import 'dart:async';
import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart' show BuildContext;
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:workmanager/workmanager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ycash_core/ycash_core.dart';

import '../crypto_bridge/wallet_paths.dart';
import '../secure_storage/seed_vault.dart';
import '../settings_store/settings_store.dart';

const backgroundSyncTaskName = 'ycash.background_sync.task';
const _uniqueWorkName = 'ycash.background_sync.periodic';

/// WorkManager's per-job execution budget. This is deliberately below the
/// platform's normal background execution window.
const _syncBudget = Duration(minutes: 9);

/// Both "On" and "Wi-Fi only" already get continuous, 30-second-granularity
/// coverage from the foreground service below while it's alive. This
/// periodic job is only a fallback for the window after the foreground
/// service's budget has expired and before the app is next opened.
const _periodicFallbackFrequency = Duration(hours: 1);

/// Android 15 gives dataSync foreground services a maximum of six hours per
/// 24 hours. Leave headroom for platform scheduling/teardown.
const _foregroundServiceBudget = Duration(hours: 5, minutes: 30);
const _foregroundServiceInterval = Duration(seconds: 30);

const _foregroundServiceId = 906701;
const _foregroundChannelId = 'ycash_background_sync';
const _notificationPermissionPromptedKey =
    'ycash.notifications.permission_prompted_v1';
const _batteryOptimizationPromptedKey =
    'ycash.battery_optimization.permission_prompted_v1';

/// Updated on every foreground-service tick; read by the WorkManager round
/// so it can skip itself while the service is already syncing, rather than
/// opening the same wallet.dat from a second isolate at the same time.
const _fgsHeartbeatKey = 'ycash.background_sync.fgs_heartbeat_v1';

/// How long a heartbeat is trusted. Comfortably wider than the 30-second
/// tick interval so a single slow/missed tick doesn't let the WorkManager
/// round sneak in.
const _fgsHeartbeatFreshness = Duration(minutes: 2);

/// Entry point WorkManager relaunches into.
@pragma('vm:entry-point')
void backgroundSyncCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    try {
      await _runBackgroundSyncRound();
      return true;
    } catch (_) {
      return false;
    }
  });
}

/// Entry point used by flutter_foreground_task's Android service isolate.
@pragma('vm:entry-point')
void startForegroundSyncCallback() {
  FlutterForegroundTask.setTaskHandler(_YcashForegroundSyncHandler());
}

Future<void> _writeFgsHeartbeat(DateTime timestamp) async {
  try {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_fgsHeartbeatKey, timestamp.toIso8601String());
  } catch (_) {
    // Worst case the WorkManager round below also runs; that's a wasted
    // sync attempt, not a correctness problem.
  }
}

Future<bool> _fgsRecentlyActive() async {
  try {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_fgsHeartbeatKey);
    if (raw == null) return false;
    final last = DateTime.tryParse(raw);
    if (last == null) return false;
    return DateTime.now().difference(last) < _fgsHeartbeatFreshness;
  } catch (_) {
    return false;
  }
}

Future<bool> _isOnWifi() async {
  try {
    final results = await Connectivity().checkConnectivity();
    return results.contains(ConnectivityResult.wifi);
  } catch (_) {
    // Fail safe: if we can't tell, don't spend the user's mobile data.
    return false;
  }
}

class _YcashForegroundSyncHandler extends TaskHandler {
  final YcashCoreNative _native = YcashCoreNative.instance;
  DateTime? _startedAt;
  bool _walletReady = false;

  /// Guards against overlapping ticks. onRepeatEvent fires unconditionally
  /// every 30s regardless of whether the previous tick finished, so without
  /// this a slow syncStatus()/updateService() round can leave two ticks in
  /// flight at once — and whichever updateService() call happens to land
  /// last "wins", which isn't necessarily the most recent one. That shows up
  /// as the notification freezing on, or even reverting to, a stale count.
  bool _tickBusy = false;

  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {
    _startedAt = timestamp;
    await _writeFgsHeartbeat(timestamp);

    // The normal path starts the service immediately after the foreground
    // wallet has been opened, so syncStatus() succeeds and we avoid opening
    // the on-disk wallet twice. If Android recreates the service after the
    // process was killed, syncStatus() fails and we recover from the secure,
    // unattended seed cache instead.
    _walletReady = await _ensureNativeWalletReady();
    if (!_walletReady) return;

    if (await _shouldIdleForWifi()) return;

    try {
      _native.startSync();
    } catch (_) {}

    // Reflect real status right away instead of leaving the static
    // "Starting…" notification text in place until the first scheduled
    // onRepeatEvent, which flutter_foreground_task fires only *after* the
    // 30s interval elapses, not immediately on start.
    unawaited(_tick(timestamp));
  }

  @override
  void onRepeatEvent(DateTime timestamp) {
    unawaited(_tick(timestamp));
  }

  Future<void> _tick(DateTime timestamp) async {
    if (_tickBusy) return;
    _tickBusy = true;
    try {
      await _doTick(timestamp);
    } finally {
      _tickBusy = false;
    }
  }

  Future<void> _doTick(DateTime timestamp) async {
    final started = _startedAt;
    if (started != null && timestamp.difference(started) >= _foregroundServiceBudget) {
      // Stop before Android's 6-hour dataSync limit is reached on Android 15+.
      unawaited(FlutterForegroundTask.stopService());
      return;
    }

    await _writeFgsHeartbeat(timestamp);

    if (await _shouldIdleForWifi()) {
      FlutterForegroundTask.updateService(
        notificationTitle: 'Ycash background sync',
        notificationText: 'Waiting for Wi-Fi…',
      );
      return;
    }

    if (!_walletReady) {
      unawaited(_recoverAndSync());
      return;
    }

    try {
      final status = _native.syncStatus();
      final synced = (status['synced_blocks'] as num?)?.toInt() ?? 0;
      final total = (status['total_blocks'] as num?)?.toInt() ?? 0;
      final syncing = status['is_syncing'] == true;

      // "Continuous" mode means continuous: catching up to the tip and
      // having nothing new for a while is a normal steady state, not a
      // reason to stop. Keep nudging startSync() every tick so a newly
      // mined block is picked up promptly -- the service is only ever torn
      // down by the ~5.5h budget above or by the person turning background
      // sync off, never just because a given tick found nothing to do.
      if (!syncing) {
        try {
          _native.startSync();
        } catch (_) {}
      }

      final text = syncing
          ? (total > 0
              ? 'Syncing securely • $synced / $total'
              : 'Connecting securely to the Ycash network')
          : 'Caught up • $synced blocks';
      FlutterForegroundTask.updateService(
        notificationTitle: 'Ycash background sync',
        notificationText: text,
      );
    } catch (_) {
      // The next event retries. Do not tear down the foreground service for a
      // transient lightwalletd/network error.
      FlutterForegroundTask.updateService(
        notificationTitle: 'Ycash background sync',
        notificationText: 'Waiting for the Ycash network…',
      );
    }
  }

  /// True when the running mode is Wi-Fi only and the device currently
  /// isn't on Wi-Fi -- the service stays alive (so it notices the moment
  /// Wi-Fi returns) but does no network work in the meantime.
  Future<bool> _shouldIdleForWifi() async {
    final mode = await SettingsStore().getBackgroundSyncMode();
    if (mode != BackgroundSyncMode.wifiOnly) return false;
    return !await _isOnWifi();
  }

  Future<void> _recoverAndSync() async {
    _walletReady = await _ensureNativeWalletReady();
    if (_walletReady) {
      try {
        _native.startSync();
      } catch (_) {}
    }
  }

  Future<bool> _ensureNativeWalletReady() async {
    // If the UI isolate already opened/configured the native wallet, this is
    // cheap and avoids a second open of the same on-disk wallet.
    try {
      _native.syncStatus();
      return true;
    } catch (_) {
      // Continue to the unattended recovery path below.
    }

    try {
      final settings = SettingsStore();
      final seed = await SeedVault().readBackgroundSyncCache();
      if (seed == null || seed.isEmpty) return false;
      final server = await settings.getServerUrl();
      final dataDir = await ycashWalletDir();
      _native.configure(server: server, dataDir: dataDir);
      _native.openYecWallet(seed);
      return true;
    } catch (_) {
      return false;
    }
  }

  @override
  Future<void> onDestroy(DateTime timestamp) async {
    // Do not wipe/close the native wallet here. The foreground service may be
    // destroyed by Android's time limit while the main Flutter isolate is
    // still alive, and the existing WorkManager fallback must retain access
    // to the same wallet data.
  }

  @override
  void onReceiveData(Object data) {}

  @override
  void onNotificationButtonPressed(String id) {}

  @override
  void onNotificationPressed() {}

  @override
  void onNotificationDismissed() {}
}

Future<void> _runBackgroundSyncRound() async {
  final settings = SettingsStore();
  final mode = await settings.getBackgroundSyncMode();
  if (mode == BackgroundSyncMode.off) return;

  // The foreground service already covers this case continuously; skip so
  // we don't open the same wallet.dat from two isolates at the same time.
  if (await _fgsRecentlyActive()) return;

  if (mode == BackgroundSyncMode.wifiOnly && !await _isOnWifi()) return;

  final vault = SeedVault();
  final seed = await vault.readBackgroundSyncCache();
  if (seed == null) return;

  final native = YcashCoreNative.instance;
  final server = await settings.getServerUrl();
  final dataDir = await ycashWalletDir();
  native.configure(server: server, dataDir: dataDir);
  native.openYecWallet(seed);
  native.startSync();

  final deadline = DateTime.now().add(_syncBudget);
  while (DateTime.now().isBefore(deadline)) {
    await Future.delayed(const Duration(seconds: 3));
    final status = native.syncStatus();
    if (status['is_syncing'] != true) break;
  }
}

class BackgroundSyncScheduler {
  BackgroundSyncScheduler._();

  /// Call once from main(), before runApp.
  static Future<void> initialize() async {
    await Workmanager().initialize(backgroundSyncCallbackDispatcher);

    // flutter_foreground_task needs its communication port registered before
    // the Android service can start. The service itself is Android-only, but
    // init() is harmless on other Flutter targets.
    FlutterForegroundTask.initCommunicationPort();
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: _foregroundChannelId,
        channelName: 'Ycash background sync',
        channelDescription: 'Keeps the Ycash wallet synchronized while locked.',
        channelImportance: NotificationChannelImportance.DEFAULT,
        priority: NotificationPriority.DEFAULT,
        onlyAlertOnce: true,
        showBadge: false,
      ),
      iosNotificationOptions: const IOSNotificationOptions(
        showNotification: false,
        playSound: false,
      ),
      foregroundTaskOptions: ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.repeat(30000),
        autoRunOnBoot: false,
        autoRunOnMyPackageReplaced: false,
        allowWakeLock: true,
        allowWifiLock: true,
      ),
    );
  }

  /// Requests notification permission directly on the first app launch, if
  /// it isn't already granted -- no explanatory dialog in front of it, just
  /// the OS prompt itself.
  ///
  /// Android 13+ requires POST_NOTIFICATIONS for visible notifications, and
  /// background sync's default mode ("On") needs it from the moment a
  /// fresh install first opens.
  ///
  /// `context` is accepted (and `context.mounted` checked before the async
  /// gap) for parity with the call site in app.dart, but no dialog is shown
  /// on it. The "already prompted" flag is set once the OS has actually
  /// been asked (or the permission was already granted), so we don't ask
  /// again on every cold start; [ensureNotificationPermission] covers the
  /// case where it's still missing later (e.g. the person denied the OS
  /// prompt itself, or revoked it afterwards).
  static Future<void> requestNotificationPermissionOnFirstInstall(
      BuildContext context) async {
    if (!Platform.isAndroid) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool(_notificationPermissionPromptedKey) == true) return;

      if (await FlutterForegroundTask.checkNotificationPermission() ==
          NotificationPermission.granted) {
        await prefs.setBool(_notificationPermissionPromptedKey, true);
        return;
      }

      if (!context.mounted) return;
      await FlutterForegroundTask.requestNotificationPermission();
      await prefs.setBool(_notificationPermissionPromptedKey, true);
    } catch (_) {
      // Do not prevent the wallet from opening if the permission API is not
      // available on an older Android version/vendor build.
    }
  }

  /// Same direct-request flow as above, for the moment the person turns
  /// background sync on (or from Off to a syncing mode) in Settings, in
  /// case the first-install prompt was missed or the permission was since
  /// revoked. Also safe to call when permission is already granted (no-op)
  /// or on iOS (no-op).
  static Future<void> ensureNotificationPermission(
      BuildContext context) async {
    if (!Platform.isAndroid) return;
    try {
      if (await FlutterForegroundTask.checkNotificationPermission() ==
          NotificationPermission.granted) {
        return;
      }

      if (!context.mounted) return;
      await FlutterForegroundTask.requestNotificationPermission();
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_notificationPermissionPromptedKey, true);
    } catch (_) {}
  }

  /// Requests an exemption from Doze/App Standby battery optimizations
  /// directly, once, on first install (mirrors
  /// [requestNotificationPermissionOnFirstInstall]).
  ///
  /// Without this exemption, a dataSync foreground service is nominally
  /// still allowed network access while the phone is locked on stock
  /// Android, but many OEM battery managers throttle or kill it anyway --
  /// this is the most likely reason background sync stalls specifically
  /// once the screen is off/locked, since nothing previously asked for the
  /// exemption at all.
  static Future<void> requestBatteryOptimizationExemptionOnFirstInstall(
      BuildContext context) async {
    if (!Platform.isAndroid) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool(_batteryOptimizationPromptedKey) == true) return;

      if (await FlutterForegroundTask.isIgnoringBatteryOptimizations) {
        await prefs.setBool(_batteryOptimizationPromptedKey, true);
        return;
      }

      if (!context.mounted) return;
      await FlutterForegroundTask.requestIgnoreBatteryOptimization();
      await prefs.setBool(_batteryOptimizationPromptedKey, true);
    } catch (_) {
      // Do not prevent the wallet from opening if the permission API is not
      // available on an older Android version/vendor build.
    }
  }

  /// Same direct-request flow as above, for the moment the person turns
  /// background sync on in Settings, in case the first-install prompt was
  /// missed or the exemption was since revoked.
  static Future<void> ensureBatteryOptimizationExemption(
      BuildContext context) async {
    if (!Platform.isAndroid) return;
    try {
      if (await FlutterForegroundTask.isIgnoringBatteryOptimizations) return;

      if (!context.mounted) return;
      await FlutterForegroundTask.requestIgnoreBatteryOptimization();
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_batteryOptimizationPromptedKey, true);
    } catch (_) {}
  }

  /// Registers/cancels the WorkManager fallback and, on Android, starts or
  /// stops the continuous foreground service. "On" and "Wi-Fi only" both
  /// run the service; the service itself is what enforces the Wi-Fi gate
  /// for the latter (see _shouldIdleForWifi above).
  static Future<void> apply(BackgroundSyncMode mode) async {
    if (mode == BackgroundSyncMode.off) {
      await Workmanager().cancelByUniqueName(_uniqueWorkName);
      await stopForegroundService();
      return;
    }

    final wifiOnly = mode == BackgroundSyncMode.wifiOnly;
    await Workmanager().registerPeriodicTask(
      _uniqueWorkName,
      backgroundSyncTaskName,
      frequency: _periodicFallbackFrequency,
      initialDelay: Duration.zero,
      existingWorkPolicy: ExistingPeriodicWorkPolicy.replace,
      constraints: Constraints(
        networkType: wifiOnly ? NetworkType.unmetered : NetworkType.connected,
        requiresStorageNotLow: true,
      ),
    );

    await startForegroundService();
  }

  static Future<void> startForegroundService() async {
    if (!Platform.isAndroid) return;

    try {
      if (await FlutterForegroundTask.isRunningService) return;

      // Deliberately does *not* request notification permission here --
      // that always goes through an explained flow first (the first-install
      // prompt in app.dart, or ensureNotificationPermission from the
      // Settings toggle). This just starts the service; if permission
      // isn't granted, Android simply won't show the notification, but
      // sync itself still runs.
      await FlutterForegroundTask.startService(
        serviceId: _foregroundServiceId,
        notificationTitle: 'Ycash background sync',
        notificationText: 'Starting secure wallet synchronization…',
        notificationIcon: null,
        notificationInitialRoute: '/',
        callback: startForegroundSyncCallback,
      );

      // Best-effort, no-dialog fallback: the explained battery-optimization
      // flow (first-install prompt / Settings toggle) already asks for this
      // with context up front, but apply() can also be reached from paths
      // that don't have a BuildContext at all (e.g. AppLockScreen after a
      // routine unlock). Silently re-checking here means a device that
      // revoked the exemption after granting it once still gets asked
      // again, instead of the service quietly running unexempted from then
      // on. isIgnoringBatteryOptimizations/requestIgnoreBatteryOptimization
      // show their own system dialog when needed, no rationale text of
      // ours required for this fallback path.
      try {
        if (!await FlutterForegroundTask.isIgnoringBatteryOptimizations) {
          await FlutterForegroundTask.requestIgnoreBatteryOptimization();
        }
      } catch (_) {}
    } catch (_) {
      // WorkManager remains registered as the fallback if the device/vendor
      // refuses the foreground-service start (for example, a vendor-specific
      // background restriction).
    }
  }

  static Future<void> stopForegroundService() async {
    if (!Platform.isAndroid) return;
    try {
      if (await FlutterForegroundTask.isRunningService) {
        await FlutterForegroundTask.stopService();
      }
    } catch (_) {}
  }

  /// Called when the app returns to the foreground. Android 15 resets the
  /// dataSync time budget when the user brings the app back, so this also
  /// recovers cleanly after our five-and-a-half-hour service window expires.
  static Future<void> ensureForegroundServiceIfEnabled() async {
    if (!Platform.isAndroid) return;
    try {
      final mode = await SettingsStore().getBackgroundSyncMode();
      if (mode == BackgroundSyncMode.always || mode == BackgroundSyncMode.wifiOnly) {
        await startForegroundService();
      }
    } catch (_) {}
  }
}
