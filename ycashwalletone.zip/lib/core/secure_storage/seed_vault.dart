import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../biometrics/biometric_gate.dart';

/// Recovery seed storage. Protected solely by the device's own
/// biometric/PIN/pattern lock via a hardware-backed (StrongBox/TEE)
/// Android Keystore key -- there is no separate app password anymore.
/// That key requires authentication within the last 30 seconds to unlock
/// (see MainActivity.kt's `AUTH_VALIDITY_SECONDS`), so [writeSecured] and
/// [readSecured] only ever work immediately after a
/// [BiometricGate.authenticate] call succeeds.
///
/// [readWithPassword] and the `v2`/`v3` records below are legacy-migration
/// only: installs from before biometrics-only unlock had a second,
/// password-derived Argon2id envelope wrapping the seed. [AppLockScreen]
/// uses [hasLegacyPasswordSeed]/[readWithPassword] to do a one-time
/// migration -- decrypt with the old password, [writeSecured] the result,
/// [clearLegacyPasswordSeed]. Nothing writes a new password-wrapped record
/// anymore.
class SeedVault {
  SeedVault({FlutterSecureStorage? storage, BiometricGate? gate})
      : _storage = storage ?? const FlutterSecureStorage(),
        _gate = gate ?? BiometricGate();

  final FlutterSecureStorage _storage;
  final BiometricGate _gate;

  /// Keystore-only record -- no password. The only seed record a fresh
  /// install, or anything post-migration, ever writes.
  static const _seedKey = 'ycash.wallet.seed_phrase.v4';
  // Legacy, password-wrapped records from before biometrics-only unlock.
  // Read-only migration targets -- see class doc above.
  static const _legacyPasswordSeedKeyV3 = 'ycash.wallet.seed_phrase.v3';
  static const _legacyPasswordSeedKeyV2 = 'ycash.wallet.seed_phrase.v2';
  static const _backupConfirmedKey = 'ycash.wallet.backup_confirmed';
  // Second, Keystore-only envelope purely so the background-sync worker
  // can reopen the wallet unattended. Protected by a *separate* native
  // Keystore key with no setUserAuthenticationRequired at all (see
  // MainActivity.kt's class doc) -- BiometricGate.protectUnattended /
  // unprotectUnattended, not the 30-second-gated protect/unprotect used
  // everywhere else in this class. That's a deliberate, real reduction in
  // protection for this one cached copy: anything running as this app can
  // decrypt it at any time, not just within 30 seconds of a device
  // unlock. Same trust model zodl/Zashi's own background sync uses.
  static const _bgSyncSeedKey = 'ycash.wallet.seed_phrase.bg_sync_cache';

  static const _channel = MethodChannel('com.ycashfoundation.ycash/security');

  /// Stores the seed behind the hardware-backed Keystore envelope alone.
  /// Call within ~30 seconds of a successful [BiometricGate.authenticate]
  /// call -- in practice, immediately after it succeeds.
  Future<void> writeSecured(String seedPhrase) async {
    final wrapped = await _gate.protect(seedPhrase);
    await _storage.write(key: _seedKey, value: wrapped);
  }

  /// Reads the seed. [auth] must be a *just-succeeded*
  /// [BiometricGate.authenticate] result -- same 30-second window as
  /// [writeSecured]. Throws [PasswordRecordInvalidatedException] if the
  /// device's screen lock was reset/removed since the seed was saved --
  /// the Keystore key is destroyed when that happens, so restoring from
  /// the recovery phrase is the only way back in at that point.
  Future<String> readSecured(BiometricAuthResult auth) async {
    if (!auth.authenticated) {
      throw StateError('SeedVault.readSecured called without authentication');
    }
    final wrapped = await _storage.read(key: _seedKey);
    if (wrapped == null) throw StateError('No seed phrase stored');
    return _gate.unprotect(wrapped);
  }

  Future<bool> get hasSecuredSeed async =>
      (await _storage.read(key: _seedKey)) != null;

  /// Whether a pre-biometrics-only install still has a password-wrapped
  /// record waiting to be migrated. See the class doc.
  Future<bool> get hasLegacyPasswordSeed async =>
      (await _storage.read(key: _legacyPasswordSeedKeyV3)) != null ||
      (await _storage.read(key: _legacyPasswordSeedKeyV2)) != null;

  /// Migration-only: decrypts a pre-existing password-wrapped seed record.
  /// See the class doc -- nothing writes a new record in this format.
  Future<String> readWithPassword(
      BiometricAuthResult auth, String password) async {
    if (!auth.authenticated) {
      throw StateError('SeedVault.read called without authentication');
    }
    // Gate every legacy decryption through the same throttled password
    // check used everywhere else, directly here.
    if (!await _gate.verifyPassword(password)) {
      throw StateError('Incorrect password');
    }
    var key = _legacyPasswordSeedKeyV3;
    var raw = await _storage.read(key: key);
    if (raw == null) {
      key = _legacyPasswordSeedKeyV2;
      raw = await _storage.read(key: key);
    }
    if (raw == null) throw StateError('No seed phrase stored');
    final r = jsonDecode(raw) as Map<String, dynamic>;
    if (r['kdf'] != 'Argon2id') throw StateError('Unsupported seed vault format');
    final String derivedKey;
    if (r['v'] == 3) {
      derivedKey = _gate.derivePasswordKeyWithParams(
        password, r['s'] as String,
        memoryKiB: r['m'] as int, iterations: r['t'] as int, parallelism: r['p'] as int,
      );
    } else if (r['v'] == 2) {
      // Legacy record: no KDF params were stored, so it can only be
      // re-derived correctly as long as BiometricGate's current defaults
      // still match what it was originally written with.
      derivedKey = _gate.derivePasswordKey(password, r['s'] as String);
    } else {
      throw StateError('Unsupported seed vault format');
    }
    final inner = await _gate.unprotect(r['c'] as String);
    final seed = await _channel
        .invokeMethod<String>('passwordUnwrap', {'ciphertext': inner, 'key': derivedKey});
    if (seed == null) throw StateError('Incorrect password or corrupted seed');
    return seed;
  }

  /// Deletes the legacy password-wrapped record(s) once [readWithPassword]
  /// has successfully migrated them via [writeSecured].
  Future<void> clearLegacyPasswordSeed() async {
    await _storage.delete(key: _legacyPasswordSeedKeyV3);
    await _storage.delete(key: _legacyPasswordSeedKeyV2);
  }

  Future<void> markBackupConfirmed() =>
      _storage.write(key: _backupConfirmedKey, value: 'true');
  Future<bool> get isBackupConfirmed async =>
      (await _storage.read(key: _backupConfirmedKey)) == 'true';

  /// Refreshes the Keystore-only copy of the seed the background-sync
  /// worker reads. Call this right after any normal unlock or onboarding
  /// completion, i.e. whenever the plaintext seed is already in hand.
  /// Uses [BiometricGate.protectUnattended] -- a separate, ungated key
  /// from [writeSecured]'s -- specifically so this works from a headless
  /// background isolate with no auth prompt available.
  Future<void> writeBackgroundSyncCache(String seedPhrase) async {
    final wrapped = await _gate.protectUnattended(seedPhrase);
    await _storage.write(key: _bgSyncSeedKey, value: wrapped);
  }

  /// Returns null if background sync has never run yet on this install
  /// (nobody has unlocked since it was enabled) rather than throwing, so
  /// the worker can just skip the round.
  Future<String?> readBackgroundSyncCache() async {
    final wrapped = await _storage.read(key: _bgSyncSeedKey);
    if (wrapped == null) return null;
    return _gate.unprotectUnattended(wrapped);
  }

  Future<void> clearBackgroundSyncCache() => _storage.delete(key: _bgSyncSeedKey);

  Future<void> wipe() async {
    await _storage.delete(key: _seedKey);
    await _storage.delete(key: _legacyPasswordSeedKeyV3);
    await _storage.delete(key: _legacyPasswordSeedKeyV2);
    await _storage.delete(key: _backupConfirmedKey);
    await _storage.delete(key: _bgSyncSeedKey);
  }
}
