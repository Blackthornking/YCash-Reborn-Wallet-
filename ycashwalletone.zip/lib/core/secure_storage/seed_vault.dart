import 'dart:convert';
import 'dart:math';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../biometrics/biometric_gate.dart';

/// Recovery seed storage uses two independent envelopes:
///   seed -> AES-256-GCM(password-derived Argon2id key) -> AES-256-GCM(Android Keystore)
/// The outer key requests StrongBox and falls back to hardware-backed TEE.
class SeedVault {
  SeedVault({FlutterSecureStorage? storage, BiometricGate? gate})
      : _storage = storage ?? const FlutterSecureStorage(),
        _gate = gate ?? BiometricGate();

  final FlutterSecureStorage _storage;
  final BiometricGate _gate;
  static const _seedKey = 'ycash.wallet.seed_phrase.v2';
  static const _backupConfirmedKey = 'ycash.wallet.backup_confirmed';
  static const _channel = MethodChannel('com.ycashfoundation.ycash/security');

  Future<void> writeWrapped(String seedPhrase, String password) async {
    final salt = List<int>.generate(16, (_) => Random.secure().nextInt(256));
    final saltB64 = base64UrlEncode(salt).replaceAll('=', '');
    final key = _gate.derivePasswordKey(password, saltB64);
    try {
      final inner = await _channel.invokeMethod<String>('passwordWrap', {
        'plaintext': seedPhrase, 'key': key,
      });
      if (inner == null) throw StateError('Password seed wrapping failed');
      final outer = await _channel.invokeMethod<String>('protect', inner);
      if (outer == null) throw StateError('Keystore seed protection failed');
      final record = jsonEncode({'v': 2, 'kdf': 'Argon2id', 's': saltB64, 'c': outer});
      await _storage.write(key: _seedKey, value: record);
    } finally {
      // Dart strings cannot be reliably zeroized, but do not persist the key.
    }
  }

  Future<String> readWithPassword(BiometricAuthResult auth, String password) async {
    if (!auth.authenticated) throw StateError('SeedVault.read called without authentication');
    final raw = await _storage.read(key: _seedKey);
    if (raw == null) throw StateError('No seed phrase stored');
    final r = jsonDecode(raw) as Map<String, dynamic>;
    if (r['v'] != 2 || r['kdf'] != 'Argon2id') throw StateError('Unsupported seed vault format');
    final key = _gate.derivePasswordKey(password, r['s'] as String);
    final inner = await _channel.invokeMethod<String>('unprotect', {'ciphertext': r['c']});
    if (inner == null) throw StateError('Keystore seed unwrap failed');
    final seed = await _channel.invokeMethod<String>('passwordUnwrap', {'ciphertext': inner, 'key': key});
    if (seed == null) throw StateError('Incorrect password or corrupted seed');
    return seed;
  }

  Future<void> markBackupConfirmed() => _storage.write(key: _backupConfirmedKey, value: 'true');
  Future<bool> get isBackupConfirmed async => (await _storage.read(key: _backupConfirmedKey)) == 'true';
  Future<void> wipe() async { await _storage.delete(key: _seedKey); await _storage.delete(key: _backupConfirmedKey); }
}
