import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Stores the user's own CoinMarketCap API key in Keychain/Keystore-backed
/// secure storage. Kept out of SettingsStore (which uses plain
/// SharedPreferences) because an API key is a credential, not an ordinary
/// preference — same rationale as SeedVault, minus the biometric gate,
/// since this key protects a price feed, not funds.
class PriceApiKeyVault {
  PriceApiKeyVault({FlutterSecureStorage? storage})
      : _storage = storage ?? const FlutterSecureStorage();

  final FlutterSecureStorage _storage;
  static const _cmcApiKeyKey = 'ycash.pricing.coinmarketcap_api_key';

  Future<String?> readCoinMarketCapKey() => _storage.read(key: _cmcApiKeyKey);

  Future<void> writeCoinMarketCapKey(String key) =>
      _storage.write(key: _cmcApiKeyKey, value: key);

  Future<void> clearCoinMarketCapKey() => _storage.delete(key: _cmcApiKeyKey);
}
