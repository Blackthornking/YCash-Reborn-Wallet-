/// Feature flags for the sync system.
///
/// The goal: strip sync down to the smallest thing that can work --
/// wallet opens, connects, runs one sync pass, and the Network & sync
/// page shows real numbers -- confirm *that* is solid, then flip these
/// back on one at a time rather than all at once. Each flag documents
/// exactly what it gates and what stays working with it off, so turning
/// one back on is a single, isolated change instead of guessing which
/// piece of a large diff to re-enable.
///
/// Nothing downstream of these flags was deleted -- every feature they
/// gate is still fully implemented, just short-circuited to an early
/// return at its real entry point(s). See each flag's doc for exactly
/// where.
class SyncFeatureFlags {
  const SyncFeatureFlags._();

  /// The one-time sync kicked off by `openOrCreateWallet` when the wallet
  /// is opened (ycash_core_ffi_engine.dart calls `_native.startSync()` at
  /// the end of it). This *is* "the basic connection" -- leave this on,
  /// or there is nothing for the Network & sync page to ever show.
  static const bool initialSyncOnOpen = true;

  /// The foreground timer that automatically re-triggers a sync every 30s
  /// while the app is open (`_resyncTrigger` in ycash_core_ffi_engine.dart),
  /// so newly-mined blocks and incoming funds keep getting picked up
  /// without the user doing anything.
  ///
  /// With this off: sync still runs once on open (see
  /// [initialSyncOnOpen]), and the Network & sync page's pull-to-refresh
  /// still works (it calls `syncNow()` directly, independent of this
  /// timer) -- there just isn't anything automatic beyond that.
  static const bool foregroundAutoResync = false;

  /// The OS-level background task (WorkManager + Android foreground
  /// service) that keeps syncing while the app isn't open at all --
  /// everything in `BackgroundSyncScheduler.apply()` and
  /// `.ensureForegroundServiceIfEnabled()` (background_sync.dart), which
  /// between them are every real entry point that starts it regardless of
  /// which screen triggers the call (app open, Settings toggle, lock/
  /// unlock, onboarding).
  ///
  /// With this off: the wallet only syncs while the app is actually open
  /// in the foreground. No background-sync notification, no battery-
  /// optimization prompts, no WorkManager job registered.
  static const bool backgroundSync = false;

  /// The Settings > Rescan wallet screen (rescan from a chosen date, or
  /// from the fork launch) -- gated at its one navigation entry point in
  /// settings_screen.dart.
  ///
  /// With this off: the menu row is still visible but disabled, with a
  /// one-line explanation, rather than hidden outright -- so it's obvious
  /// from the running app (not just the source) that this was turned off
  /// on purpose and where to turn it back on.
  static const bool rescanFromDate = false;
}
