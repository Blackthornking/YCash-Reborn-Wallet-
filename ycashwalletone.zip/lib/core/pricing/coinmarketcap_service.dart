import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/ycash_config.dart';

/// Thrown for any CoinMarketCap request that didn't yield a usable price.
/// Kept as a single type with a human-readable [message] so callers (the
/// fiat-rate provider) can log/ignore it uniformly rather than pattern
/// matching on HTTP status codes.
class CoinMarketCapException implements Exception {
  final String message;
  CoinMarketCapException(this.message);
  @override
  String toString() => 'CoinMarketCapException: $message';
}

/// Looks up the price of one YEC in a given fiat currency via
/// CoinMarketCap's `/v2/cryptocurrency/quotes/latest` endpoint.
///
/// This talks to CoinMarketCap directly from the device using the user's
/// own API key. That's simple and keeps the wallet fully self-contained,
/// but it does mean the key lives on-device (readable from an unrooted
/// phone's app storage only via the OS keystore, but still extractable on
/// a compromised device). A production wallet with many users would
/// normally proxy this through a small backend so no key ever ships to a
/// client at all — worth doing before a wide release, not required for
/// this to work today.
class CoinMarketCapService {
  CoinMarketCapService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  /// Returns the price of 1 YEC in [fiatCurrencyCode] (e.g. 'GBP', 'USD'),
  /// or throws [CoinMarketCapException] if the key is missing/invalid, the
  /// currency isn't supported, or the request otherwise fails.
  Future<double> getYecPrice({
    required String apiKey,
    required String fiatCurrencyCode,
  }) async {
    if (apiKey.trim().isEmpty) {
      throw CoinMarketCapException('No CoinMarketCap API key configured');
    }

    final uri = Uri.parse(YcashConfig.coinMarketCapQuotesUrl).replace(
      queryParameters: {
        'symbol': YcashConfig.ticker,
        'convert': fiatCurrencyCode,
      },
    );

    final http.Response response;
    try {
      response = await _client.get(uri, headers: {
        'X-CMC_PRO_API_KEY': apiKey,
        'Accept': 'application/json',
      }).timeout(const Duration(seconds: 12));
    } catch (e) {
      throw CoinMarketCapException('Could not reach CoinMarketCap: $e');
    }

    if (response.statusCode != 200) {
      final reason = _extractErrorMessage(response.body) ?? 'HTTP ${response.statusCode}';
      throw CoinMarketCapException('CoinMarketCap request failed: $reason');
    }

    final Map<String, dynamic> body;
    try {
      body = jsonDecode(response.body) as Map<String, dynamic>;
    } catch (e) {
      throw CoinMarketCapException('Unexpected response from CoinMarketCap');
    }

    final status = body['status'] as Map<String, dynamic>?;
    final errorCode = status?['error_code'];
    if (errorCode != null && errorCode != 0) {
      throw CoinMarketCapException(status?['error_message']?.toString() ?? 'CoinMarketCap error $errorCode');
    }

    try {
      final data = body['data'] as Map<String, dynamic>;
      // v2 quotes returns an array of matches per symbol (there can be more
      // than one listing sharing a ticker) — take the first.
      final entries = data[YcashConfig.ticker] as List<dynamic>;
      final quote = (entries.first as Map<String, dynamic>)['quote'] as Map<String, dynamic>;
      final currencyQuote = quote[fiatCurrencyCode] as Map<String, dynamic>;
      final price = currencyQuote['price'];
      if (price is num) return price.toDouble();
      throw CoinMarketCapException('No price for $fiatCurrencyCode');
    } catch (e) {
      if (e is CoinMarketCapException) rethrow;
      throw CoinMarketCapException('Could not parse CoinMarketCap response: $e');
    }
  }

  String? _extractErrorMessage(String body) {
    try {
      final decoded = jsonDecode(body) as Map<String, dynamic>;
      return (decoded['status'] as Map<String, dynamic>?)?['error_message']?.toString();
    } catch (_) {
      return null;
    }
  }

  void dispose() => _client.close();
}
