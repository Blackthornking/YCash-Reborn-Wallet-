import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/ycash_config.dart';

/// Thrown for any free-price-source request that didn't yield a usable
/// price. Kept as a single type with a human-readable [message], mirroring
/// [CoinMarketCapException], so callers can log/ignore it uniformly.
class FreePriceException implements Exception {
  final String message;
  FreePriceException(this.message);
  @override
  String toString() => 'FreePriceException: $message';
}

/// Fetches YEC's price with no API key at all, no signup, nothing to
/// configure — by chaining two free, public endpoints:
///
///  1. CoinGecko's `/simple/price` for YEC's price in USD. CoinGecko lists
///     Ycash under the coin id `ycash`; this endpoint needs no key, just a
///     modest shared public rate limit.
///  2. exchangerate-api.com's keyless "open access" endpoint for the
///     USD -> [fiatCurrencyCode] rate, so any of the ~160 currencies
///     offered in Settings > Local currency can be served, not just the
///     handful CoinGecko happens to quote directly.
///
/// This is the wallet's default price source. It trades a little precision
/// (two network hops, and the FX leg only updates once a day) for working
/// immediately with nothing to configure. Users who add their own
/// CoinMarketCap key ([CoinMarketCapService]) get a single-hop, more
/// frequently updated quote instead — see `fiatRateProvider`.
class FreePriceService {
  FreePriceService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  /// Returns the price of 1 YEC in [fiatCurrencyCode] (e.g. 'GBP', 'USD'),
  /// or throws [FreePriceException] if either leg fails or the currency
  /// isn't recognized by the FX source.
  Future<double> getYecPrice({required String fiatCurrencyCode}) async {
    final usdPrice = await _fetchYecPriceUsd();
    final code = fiatCurrencyCode.toUpperCase();
    if (code == 'USD') return usdPrice;
    final rate = await _fetchUsdToRate(code);
    return usdPrice * rate;
  }

  Future<double> _fetchYecPriceUsd() async {
    final uri = Uri.parse(YcashConfig.coinGeckoSimplePriceUrl).replace(
      queryParameters: {
        'ids': YcashConfig.coinGeckoId,
        'vs_currencies': 'usd',
      },
    );

    final http.Response response;
    try {
      response = await _client
          .get(uri, headers: {'Accept': 'application/json'})
          .timeout(const Duration(seconds: 12));
    } catch (e) {
      throw FreePriceException('Could not reach CoinGecko: $e');
    }

    if (response.statusCode != 200) {
      throw FreePriceException('CoinGecko request failed: HTTP ${response.statusCode}');
    }

    try {
      final body = jsonDecode(response.body) as Map<String, dynamic>;
      final entry = body[YcashConfig.coinGeckoId] as Map<String, dynamic>?;
      final price = entry?['usd'];
      if (price is num) return price.toDouble();
      throw FreePriceException('CoinGecko returned no USD price for Ycash');
    } catch (e) {
      if (e is FreePriceException) rethrow;
      throw FreePriceException('Could not parse CoinGecko response: $e');
    }
  }

  Future<double> _fetchUsdToRate(String currencyCode) async {
    final uri = Uri.parse('${YcashConfig.openExchangeRatesUrl}/USD');

    final http.Response response;
    try {
      response = await _client
          .get(uri, headers: {'Accept': 'application/json'})
          .timeout(const Duration(seconds: 12));
    } catch (e) {
      throw FreePriceException('Could not reach exchange rate service: $e');
    }

    if (response.statusCode != 200) {
      throw FreePriceException('Exchange rate request failed: HTTP ${response.statusCode}');
    }

    try {
      final body = jsonDecode(response.body) as Map<String, dynamic>;
      if (body['result'] != 'success') {
        throw FreePriceException('Exchange rate service reported an error');
      }
      final rates = body['rates'] as Map<String, dynamic>;
      final rate = rates[currencyCode];
      if (rate is num) return rate.toDouble();
      throw FreePriceException('No exchange rate available for $currencyCode');
    } catch (e) {
      if (e is FreePriceException) rethrow;
      throw FreePriceException('Could not parse exchange rate response: $e');
    }
  }

  void dispose() => _client.close();
}
