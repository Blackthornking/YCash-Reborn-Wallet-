/// Static configuration for the one and only coin this app supports.
///
/// The original project's `CoinBase`/`coins.dart` abstraction existed to
/// support Zcash mainnet, Zcash testnet, and Ycash side by side, plus
/// Unified Addresses and Ledger — none of which Ycash uses. This app drops
/// that abstraction entirely: there is one coin, so there is one config,
/// and every branch that used to say "if coin == ycash" simply no longer
/// exists.
class YcashConfig {
  YcashConfig._();

  static const String appName = 'Ycash';
  static const String ticker = 'YEC';
  static const String currency = 'ycash';
  static const int coinType = 347; // BIP-44 coin type, unchanged from Ywallet
  static const String dbName = 'yec.db';

  /// Ycash never activated Orchard or Unified Addresses; the wallet only
  /// ever needs to speak Sapling (shielded) and transparent.
  static const bool supportsOrchard = false;
  static const bool supportsUnifiedAddresses = false;
  static const bool supportsLedger = false;
  static const bool supportsMultisig = true;

  /// Lightwalletd-compatible sync servers. Configurable in Settings;
  /// this is only the shipped default.
  static const String defaultLightwalletd = 'https://lite.ycash.xyz:9067';

  static const List<String> blockExplorers = [
    'https://yecblockexplorer.com/tx',
  ];

  /// Default transaction fee tiers, in zatoshi-equivalent units, used to
  /// let users pick priority without typing a number. Values inherited
  /// from the coin's historical weights; revisit against current network
  /// conditions before shipping.
  static const Map<String, int> feeTiers = {
    'standard': 5000,
    'priority': 25000,
    'express': 250000,
  };
}
