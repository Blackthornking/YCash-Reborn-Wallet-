import 'dart:async';
import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:ycash_core/ycash_core.dart';

import 'ycash_engine.dart';

/// Ycash adapter backed directly by yecdev/yecshell + libyec.
///
/// The Flutter layer no longer routes wallet state through the dual-coin
/// Zcash/Orchard Warp backend. yecshell owns Ycash Sapling scanning,
/// address derivation, transaction construction and lightwalletd sync.
class YcashCoreFfiEngine implements YcashEngine {
  YcashCoreFfiEngine({YcashCoreNative? native})
      : _native = native ?? YcashCoreNative.instance;

  static const String _defaultYcashLwd = 'https://lightwalletd2.ycash.xyz:1443';

  final YcashCoreNative _native;
  bool _opened = false;
  String? _seedPhrase;
  Timer? _syncPoll;
  final StreamController<SyncStatus> _sync =
      StreamController<SyncStatus>.broadcast();

  Future<String> _walletDir() async {
    final dir = await getApplicationSupportDirectory();
    final walletDir = Directory('${dir.path}/ycash-wallet');
    if (!await walletDir.exists()) await walletDir.create(recursive: true);
    return walletDir.path;
  }

  @override
  Future<void> openOrCreateWallet({String? restoreSeedPhrase}) async {
    final seed = restoreSeedPhrase?.trim();
    if (seed == null || seed.isEmpty) {
      // Keep the existing audited 24-word seed lifecycle as the input to the
      // Ycash light-client. The native yecshell wallet itself stores only an
      // encrypted copy of its seed material.
      _native.createWallet();
      _seedPhrase = _native.exportMnemonic();
      _native.wipeWallet();
    } else {
      _seedPhrase = seed;
    }

    final path = await _walletDir();
    _native.configure(server: _defaultYcashLwd, dataDir: path);
    _native.openYecWallet(_seedPhrase!);

    final addresses = _native.addresses();
    final shielded = (addresses['z_addresses'] as List?)?.cast<String>() ?? const <String>[];
    final transparent = (addresses['t_addresses'] as List?)?.cast<String>() ?? const <String>[];
    if (shielded.isEmpty || !shielded.first.startsWith('ys')) {
      throw StateError('Ycash engine did not derive a Ycash Sapling address');
    }
    if (transparent.isEmpty || !transparent.first.startsWith('s')) {
      throw StateError('Ycash engine did not derive a Ycash transparent address');
    }
    _opened = true;
    // Start the real Ycash light-client sync immediately after the wallet is
    // opened. It runs on the Rust worker thread and does not block Flutter.
    _native.startSync();
  }

  void _requireOpen() {
    if (!_opened) throw StateError('Wallet is not open');
  }

  @override
  Future<String> exportSeedPhrase() async {
    _requireOpen();
    final seed = _seedPhrase;
    if (seed == null || seed.isEmpty) throw StateError('Seed phrase unavailable');
    return seed;
  }

  @override
  Future<void> wipeWallet() async {
    _syncPoll?.cancel();
    _syncPoll = null;
    _native.wipeYecWallet();
    _seedPhrase = null;
    _opened = false;
  }

  @override
  Future<Balances> getBalances() async {
    _requireOpen();
    final b = _native.balances();
    return Balances(
      shieldedZatoshi: (b['spendable_zbalance'] as num?)?.toInt() ?? 0,
      transparentZatoshi: (b['tbalance'] as num?)?.toInt() ?? 0,
    );
  }

  void _publishSync() {
    try {
      final s = _native.syncStatus();
      _sync.add(SyncStatus(
        syncedHeight: (s['synced_blocks'] as num?)?.toInt() ?? 0,
        chainTipHeight: (s['total_blocks'] as num?)?.toInt() ?? 0,
        isSyncing: s['is_syncing'] == true,
      ));
    } catch (_) {}
  }

  @override
  Stream<SyncStatus> watchSyncStatus() {
    _requireOpen();
    _syncPoll ??= Timer.periodic(const Duration(seconds: 2), (_) => _publishSync());
    _publishSync();
    return _sync.stream;
  }

  Future<void> syncNow({String? lightwalletdUrl}) async {
    _requireOpen();
    // The first integration pins the Ycash endpoint. A future UI setting can
    // call configure before opening a wallet if a custom lightwalletd is used.
    _native.startSync();
    _publishSync();
  }

  @override
  Future<String> getShieldedAddress() async {
    _requireOpen();
    final a = _native.addresses();
    final list = (a['z_addresses'] as List?)?.cast<String>() ?? const <String>[];
    if (list.isEmpty || !list.first.startsWith('ys')) {
      throw StateError('Ycash engine returned an invalid shielded address');
    }
    return list.first;
  }

  @override
  Future<String> getTransparentAddress() async {
    _requireOpen();
    final a = _native.addresses();
    final list = (a['t_addresses'] as List?)?.cast<String>() ?? const <String>[];
    if (list.isEmpty || !list.first.startsWith('s')) {
      throw StateError('Ycash engine returned an invalid transparent address');
    }
    return list.first;
  }

  TxPlan _plan(Map<String, dynamic> p) {
    final z = (p['shielded_after'] as num?)?.toInt() ?? 0;
    final t = (p['transparent_after'] as num?)?.toInt() ?? 0;
    return TxPlan(
      feeZatoshi: (p['fee'] as num?)?.toInt() ?? 0,
      amountZatoshi: (p['amount'] as num?)?.toInt() ?? 0,
      resultingBalances: Balances(shieldedZatoshi: z, transparentZatoshi: t),
      nativeRequest: p,
    );
  }

  @override
  Future<TxPlan> planSend({
    required String toAddress,
    required int amountZatoshi,
    String? memo,
    required String feeTier,
  }) async {
    _requireOpen();
    return _plan(_native.planSend(to: toAddress, amount: amountZatoshi, memo: memo));
  }

  @override
  Future<String> broadcastPlannedTx(TxPlan plan) async {
    _requireOpen();
    final request = plan.nativeRequest;
    if (request == null) throw StateError('Transaction plan is missing native request data');
    return _native.broadcastPlan(request);
  }

  @override
  Future<TxPlan> planShield({int? amountZatoshi}) async {
    _requireOpen();
    return _plan(_native.planShield(amount: amountZatoshi ?? 0));
  }

  @override
  Future<TxPlan> planUnshield({int? amountZatoshi}) async {
    _requireOpen();
    return _plan(_native.planUnshield(amount: amountZatoshi ?? 0));
  }

  @override
  Future<List<TxRecord>> getTransactionHistory() async {
    _requireOpen();
    final raw = _native.history();
    return raw.whereType<Map>().map((tx) {
      final map = Map<String, dynamic>.from(tx);
      final timestamp = (map['datetime'] as num?)?.toInt() ?? 0;
      return TxRecord(
        txId: map['txid']?.toString() ?? 'unknown',
        timestamp: DateTime.fromMillisecondsSinceEpoch(timestamp * 1000, isUtc: true),
        amountZatoshi: (map['amount'] as num?)?.toInt() ?? 0,
        isShielded: map['address']?.toString().startsWith('ys') ?? true,
        memo: map['memo']?.toString(),
      );
    }).toList(growable: false);
  }
}
