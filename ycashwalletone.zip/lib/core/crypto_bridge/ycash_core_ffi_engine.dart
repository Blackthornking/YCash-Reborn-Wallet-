import 'dart:async';
import 'dart:isolate';

import 'package:ycash_core/ycash_core.dart';

import '../settings_store/settings_store.dart';
import '../sync_feature_flags.dart';
import 'wallet_paths.dart';
import 'ycash_engine.dart';

/// How long we'll wait for the native wallet-open call — which does a
/// blocking DNS lookup + a synchronous lightwalletd `get_info` round trip
/// on the Rust side — before giving up and surfacing an error instead of
/// hanging indefinitely.
const _openWalletTimeout = Duration(seconds: 25);

/// Opens the Ycash wallet's native connection off the UI isolate.
///
/// `YcashCoreNative.openYecWallet` is a plain synchronous `dart:ffi` call.
/// On the Rust side it resolves DNS and makes an un-timed-out synchronous
/// gRPC call to lightwalletd *before* anything else happens. Calling it
/// directly from the widget tree blocks Flutter's single UI isolate for
/// the duration of that network round trip — with a bad or absent
/// connection, that means the entire app (including unrelated buttons)
/// freezes with no feedback, since no frames can be painted and no gesture
/// events can be processed until the native call returns.
///
/// Running it inside a fresh isolate keeps the UI thread free to paint the
/// "Creating your wallet…" spinner and stay responsive; `YcashCoreNative`
/// re-opens the same underlying shared library from that isolate (cheap —
/// the OS just hands back the already-loaded module) so the native global
/// wallet state, which lives outside the Dart heap entirely, is unaffected.
Future<Map<String, dynamic>> _openWalletOffMainIsolate({
  required String server,
  required String dataDir,
  required String seedPhrase,
  bool wipeExisting = false,
  int birthday = 0,
}) {
  return Isolate.run(() {
    final native = YcashCoreNative.instance;
    native.configure(server: server, dataDir: dataDir);
    // Only for an explicit restore: wipe whatever wallet file is already at
    // dataDir before opening, so the typed seed always recreates the wallet
    // from scratch instead of being handed to the native layer as the
    // decryption key for an existing file it doesn't match. Done here,
    // right after configure() and inside the same isolate call, so dataDir
    // is guaranteed to already be set on the native side before the wipe
    // touches anything.
    if (wipeExisting) {
      native.wipeYecWallet();
    }
    native.openYecWallet(seedPhrase, birthday: birthday);
    return native.addresses();
  }).timeout(
    _openWalletTimeout,
    onTimeout: () => throw StateError(
      'Could not reach the Ycash network. Check your connection and try again.',
    ),
  );
}

/// Ycash adapter backed directly by yecdev/yecshell + libyec.
///
/// The Flutter layer no longer routes wallet state through the dual-coin
/// Zcash/Orchard Warp backend. yecshell owns Ycash Sapling scanning,
/// address derivation, transaction construction and lightwalletd sync.
class YcashCoreFfiEngine implements YcashEngine {
  YcashCoreFfiEngine({YcashCoreNative? native, SettingsStore? settingsStore})
      : _native = native ?? YcashCoreNative.instance,
        _settings = settingsStore ?? SettingsStore();

  final YcashCoreNative _native;
  final SettingsStore _settings;
  bool _opened = false;
  String? _seedPhrase;
  Timer? _syncPoll;
  Timer? _resyncTrigger;
  bool _lastKnownSyncing = false;
  final StreamController<SyncStatus> _sync =
      StreamController<SyncStatus>.broadcast();

  /// How often we kick off a fresh native scan once the wallet is open.
  ///
  /// `openOrCreateWallet` only fires the *first* scan — yecshell's
  /// `do_sync` catches the wallet up to whatever the chain tip was at that
  /// moment and then stops, it does not keep watching for new blocks. If
  /// nothing calls `startSync()` again, `synced_blocks`/`total_blocks`
  /// (and therefore the UI's sync percentage) stay frozen forever, and any
  /// transaction that lands after that point — including money someone
  /// just sent us — never gets scanned into the wallet, so the balance
  /// stays stuck too. This timer is what keeps the wallet caught up.
  static const _resyncInterval = Duration(seconds: 30);

  /// How often we re-read the native sync status while a scan is running.
  ///
  /// The native side already advances `synced_blocks` one block at a time
  /// (see `scan_block_internal` in lightclient.rs), so with the old 2s
  /// interval a batch that blows through a few thousand mostly-empty
  /// blocks in that window only ever got sampled after the jump — the
  /// scanner was moving smoothly the whole time, the UI just wasn't asking
  /// often enough to see it. 250ms makes the individual block increments
  /// actually visible without needing to change the scan/batch engine
  /// itself. `_native.syncStatus()` just reads four fields behind a lock,
  /// so this is cheap even at 4x/sec.
  static const _syncPollInterval = Duration(milliseconds: 250);

  Future<String> _walletDir() => ycashWalletDir();

  @override
  Future<void> openOrCreateWallet(
      {String? restoreSeedPhrase, bool isRestore = false}) async {
    final seed = restoreSeedPhrase?.trim();
    // Whether this call is generating a brand-new seed right now, as
    // opposed to restoring a typed-in seed phrase or routinely reopening an
    // already-synced wallet on unlock (both of which always pass
    // restoreSeedPhrase). Only this path can safely default its birthday
    // to "now" -- a seed that didn't exist a moment ago couldn't have
    // received funds before this moment either.
    final isBrandNew = seed == null || seed.isEmpty;
    if (isBrandNew) {
      // Keep the existing audited 24-word seed lifecycle as the input to the
      // Ycash light-client. The native yecshell wallet itself stores only an
      // encrypted copy of its seed material.
      _native.createWallet();
      _seedPhrase = _native.exportMnemonic();
      _native.wipeWallet();
    } else {
      _seedPhrase = seed;
    }

    final path = await _walletDir();
    final server = await _settings.getServerUrl();
    final addresses = await _openWalletOffMainIsolate(
      server: server,
      dataDir: path,
      seedPhrase: _seedPhrase!,
      // Wipe the on-disk wallet only for a genuine "replace this wallet"
      // restore. Every other caller of openOrCreateWallet (routine
      // biometric reopen on unlock) leaves isRestore at its default of
      // false, so it keeps reopening — never wiping — the same synced file.
      wipeExisting: isRestore,
      // Restoring a typed-in seed or reopening an existing wallet defaults
      // to 0 (the native layer's own Ycash-fork-height fallback), since the
      // real first-use date is unknown and could be years earlier. A
      // brand-new wallet instead gets the "use the current chain tip"
      // sentinel, since it's provably impossible for it to hold anything
      // older than the moment it was created.
      birthday: isBrandNew ? YcashCoreNative.newWalletBirthday : 0,
    );
    final shielded = (addresses['z_addresses'] as List?)?.cast<String>() ?? const <String>[];
    final transparent = (addresses['t_addresses'] as List?)?.cast<String>() ?? const <String>[];
    if (shielded.isEmpty || !shielded.first.startsWith('ys')) {
      throw StateError('Ycash engine did not derive a Ycash Sapling address');
    }
    if (transparent.isEmpty || !transparent.first.startsWith('s')) {
      throw StateError('Ycash engine did not derive a Ycash transparent address');
    }
    _opened = true;
    // Start the real Ycash light-client sync immediately after the wallet is
    // opened. It runs on the Rust worker thread and does not block Flutter.
    if (SyncFeatureFlags.initialSyncOnOpen) {
      _native.startSync();
    }
  }

  void _requireOpen() {
    if (!_opened) throw StateError('Wallet is not open');
  }

  @override
  Future<String> exportSeedPhrase() async {
    _requireOpen();
    final seed = _seedPhrase;
    if (seed == null || seed.isEmpty) throw StateError('Seed phrase unavailable');
    return seed;
  }

  @override
  Future<void> wipeWallet() async {
    _syncPoll?.cancel();
    _syncPoll = null;
    _resyncTrigger?.cancel();
    _resyncTrigger = null;
    _native.wipeYecWallet();
    _seedPhrase = null;
    _opened = false;
  }

  @override
  Future<Balances> getBalances() async {
    _requireOpen();
    final b = _native.balances();
    return Balances(
      shieldedZatoshi: (b['spendable_zbalance'] as num?)?.toInt() ?? 0,
      transparentZatoshi: (b['tbalance'] as num?)?.toInt() ?? 0,
    );
  }

  void _publishSync() {
    try {
      final s = _native.syncStatus();
      final phase = SyncPhase.fromWire(s['phase'] as String?);
      _lastKnownSyncing = phase == SyncPhase.connecting ||
          phase == SyncPhase.scanning ||
          phase == SyncPhase.fetchingMemos;
      _sync.add(SyncStatus(
        phase: phase,
        syncedHeight: (s['synced_blocks'] as num?)?.toInt() ?? 0,
        chainTipHeight: (s['total_blocks'] as num?)?.toInt() ?? 0,
        birthday: (s['birthday'] as num?)?.toInt() ?? 0,
        lastError: s['last_error'] as String?,
      ));
    } catch (_) {}
  }

  @override
  Stream<SyncStatus> watchSyncStatus() {
    _requireOpen();
    _syncPoll ??= Timer.periodic(_syncPollInterval, (_) => _publishSync());
    // Keep re-scanning in the background so newly-mined blocks (and any
    // funds someone just sent us) actually get picked up, and so the sync
    // percentage keeps moving instead of freezing once the first catch-up
    // finishes. Skip firing a new scan while one is already in flight —
    // yecshell serializes scans internally via its own lock, but we'd
    // otherwise spawn a new native thread every interval that just piles
    // up waiting on that lock.
    if (SyncFeatureFlags.foregroundAutoResync) {
      _resyncTrigger ??= Timer.periodic(_resyncInterval, (_) {
        if (!_lastKnownSyncing) _native.startSync();
      });
    }
    // Timer.run (not a direct call) so this fires on the *next* event-loop
    // turn instead of synchronously right here. `_sync` is a broadcast
    // controller with no replay, so a synchronous call fires before the
    // caller (syncStatusProvider's `yield*`) has actually subscribed to
    // the stream returned below -- that event would be silently dropped,
    // and the caller would sit on nothing until the first 250ms timer
    // tick. Deferring by one turn happens after subscription completes,
    // so the first real value arrives essentially immediately instead.
    Timer.run(_publishSync);
    // .distinct() so the fast poll only reaches watchers (HomeScreen,
    // NetworkStatusScreen) when a value actually changed, not on every
    // 250ms tick — see the equality override on SyncStatus.
    return _sync.stream.distinct();
  }

  @override
  Future<void> syncNow({String? lightwalletdUrl}) async {
    _requireOpen();
    // A refresh is only a trigger; the native scanner itself is asynchronous.
    // Do not start another worker while one is already scanning. The native
    // side also enforces single-flight, but checking here avoids needless FFI
    // calls when the user taps refresh repeatedly or returns to this screen
    // while the first scan is still running.
    final current = _native.syncStatus();
    if (current['is_syncing'] == true) {
      _publishSync();
      return;
    }
    // startSync() now uses a mobile-safe 1000-block / 4-worker configuration.
    // The scanner remains the same Ycash batch/EC implementation; this only
    // bounds its peak memory/thread footprint for Android.
    _native.startSync();
    _publishSync();
  }
  @override
  Future<int> estimateHeightForDate(DateTime date) {
    _requireOpen();
    final seconds = date.toUtc().millisecondsSinceEpoch ~/ 1000;
    // The lookup itself is quick (a binary search over single-block
    // fetches), but it's still network I/O making several round trips to
    // lightwalletd. Running it on the UI isolate would freeze frame
    // painting/gestures for however long that takes, the same reason
    // openOrCreateWallet's native call is isolated above.
    return Isolate.run(() => YcashCoreNative.instance.heightForTimestamp(seconds))
        .timeout(_openWalletTimeout, onTimeout: () => throw StateError(
            'Could not reach the Ycash network to look up that date. Check your connection and try again.'));
  }

  @override
  Future<void> rescanFromHeight(int height) async {
    _requireOpen();
    _native.rescanFromHeight(height);
    _publishSync();
  }

  @override
  Future<String> getShieldedAddress() async {
    _requireOpen();
    final a = _native.addresses();
    final list = (a['z_addresses'] as List?)?.cast<String>() ?? const <String>[];
    if (list.isEmpty || !list.first.startsWith('ys')) {
      throw StateError('Ycash engine returned an invalid shielded address');
    }
    return list.first;
  }

  @override
  Future<String> getTransparentAddress() async {
    _requireOpen();
    final a = _native.addresses();
    final list = (a['t_addresses'] as List?)?.cast<String>() ?? const <String>[];
    if (list.isEmpty || !list.first.startsWith('s')) {
      throw StateError('Ycash engine returned an invalid transparent address');
    }
    return list.first;
  }

  TxPlan _plan(Map<String, dynamic> p) {
    final z = (p['shielded_after'] as num?)?.toInt() ?? 0;
    final t = (p['transparent_after'] as num?)?.toInt() ?? 0;
    return TxPlan(
      feeZatoshi: (p['fee'] as num?)?.toInt() ?? 0,
      amountZatoshi: (p['amount'] as num?)?.toInt() ?? 0,
      resultingBalances: Balances(shieldedZatoshi: z, transparentZatoshi: t),
      nativeRequest: p,
    );
  }

  @override
  Future<TxPlan> planSend({
    required String toAddress,
    required int amountZatoshi,
    String? memo,
    required String feeTier,
  }) async {
    _requireOpen();
    return _plan(_native.planSend(to: toAddress, amount: amountZatoshi, memo: memo));
  }

  @override
  Future<String> broadcastPlannedTx(TxPlan plan) async {
    _requireOpen();
    final request = plan.nativeRequest;
    if (request == null) throw StateError('Transaction plan is missing native request data');
    return _native.broadcastPlan(request);
  }

  @override
  Future<TxPlan> planShield({int? amountZatoshi}) async {
    _requireOpen();
    return _plan(_native.planShield(amount: amountZatoshi ?? 0));
  }

  @override
  Future<TxPlan> planUnshield({int? amountZatoshi}) async {
    _requireOpen();
    return _plan(_native.planUnshield(amount: amountZatoshi ?? 0));
  }

  @override
  Future<List<TxRecord>> getTransactionHistory() async {
    _requireOpen();
    final raw = _native.history();
    return raw.whereType<Map>().map((tx) {
      final map = Map<String, dynamic>.from(tx);
      final timestamp = (map['datetime'] as num?)?.toInt() ?? 0;
      return TxRecord(
        txId: map['txid']?.toString() ?? 'unknown',
        timestamp: DateTime.fromMillisecondsSinceEpoch(timestamp * 1000, isUtc: true),
        amountZatoshi: (map['amount'] as num?)?.toInt() ?? 0,
        isShielded: map['address']?.toString().startsWith('ys') ?? true,
        memo: map['memo']?.toString(),
      );
    }).toList(growable: false);
  }
}
