import 'dart:io';

import 'package:path_provider/path_provider.dart';

/// The on-disk directory the native Ycash wallet database lives in.
///
/// Shared between [YcashCoreFfiEngine] (foreground) and the background-sync
/// isolate (`background_sync.dart`) so both always agree on the same path
/// instead of each having their own copy that could drift out of sync.
Future<String> ycashWalletDir() async {
  final dir = await getApplicationSupportDirectory();
  final walletDir = Directory('${dir.path}/ycash-wallet');
  if (!await walletDir.exists()) await walletDir.create(recursive: true);
  return walletDir.path;
}
