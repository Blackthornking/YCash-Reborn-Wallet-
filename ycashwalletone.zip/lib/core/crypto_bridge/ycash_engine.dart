/// The typed Dart-side contract for the Rust crypto/sync engine.
///
/// This file intentionally contains no cryptography. It defines the shape
/// of what the trimmed `ycash_core_ffi` package (built from the existing,
/// proven Sapling code — Orchard, UA, Ledger and Zcash-mainnet/testnet
/// branches removed) exposes to the Flutter app. Implementations live in
/// `packages/ycash_core_ffi`; everything in `lib/` talks to this interface,
/// never to raw FFI calls, so the security-critical boundary stays in one
/// auditable place.
library ycash_engine;

class Balances {
  final int shieldedZatoshi;
  final int transparentZatoshi;
  const Balances(
      {required this.shieldedZatoshi, required this.transparentZatoshi});

  int get totalZatoshi => shieldedZatoshi + transparentZatoshi;
  bool get hasUnshielded => transparentZatoshi > 0;
  bool get hasShielded => shieldedZatoshi > 0;
}

/// Mirrors the Rust `SyncPhase` enum (lightclient.rs) one-for-one. Kept as
/// a real enum rather than a raw string so the UI can exhaustively switch
/// on it and the compiler catches a phase either side forgets to handle,
/// instead of an unmatched string silently falling through to a default.
enum SyncPhase {
  /// No sync attempt is running, and the last one (if any) succeeded.
  idle,
  /// Fetching the current chain tip and establishing the connection,
  /// before any block data has started moving.
  connecting,
  /// Downloading and trial-decrypting blocks. [SyncStatus.syncedHeight]
  /// advances one block at a time during this phase.
  scanning,
  /// All blocks in range are scanned; now fetching full transaction data
  /// (needed for memos) for anything new this round. Balances are already
  /// final by this point -- only memo text can still be missing.
  fetchingMemos,
  /// The most recent attempt gave up after exhausting its retries.
  /// [SyncStatus.lastError] holds the reason.
  error;

  /// Parses the lowercase snake_case string the native side sends
  /// (`SyncPhase::as_str` in lightclient.rs). Falls back to [scanning] for
  /// anything unrecognized (rather than throwing) so that if the two sides
  /// ever drift -- an older app talking to a newer native build, say --
  /// the UI degrades to "something is happening" instead of crashing.
  static SyncPhase fromWire(String? value) => switch (value) {
        'idle' => SyncPhase.idle,
        'connecting' => SyncPhase.connecting,
        'scanning' => SyncPhase.scanning,
        'fetching_memos' => SyncPhase.fetchingMemos,
        'error' => SyncPhase.error,
        _ => SyncPhase.scanning,
      };
}

class SyncStatus {
  final SyncPhase phase;
  final int syncedHeight;
  final int chainTipHeight;
  /// This wallet's birthday -- the height its scan actually starts from,
  /// never before the Ycash fork (see `LightClientConfig::min_scan_height`
  /// on the Rust side). Needed to compute [progress] correctly: a wallet
  /// with birthday 570,000 and nothing scanned yet has done 0% of its own
  /// work, not the ~19% that `syncedHeight / chainTipHeight` alone would
  /// suggest against a tip around 3,000,000.
  final int birthday;
  /// Set when the most recent sync attempt gave up after exhausting its
  /// retries (e.g. the server was unreachable). Null while syncing is
  /// actively progressing or has fully caught up.
  final String? lastError;
  const SyncStatus(
      {required this.phase,
      required this.syncedHeight,
      required this.chainTipHeight,
      required this.birthday,
      this.lastError});

  bool get isSyncing => phase == SyncPhase.connecting ||
      phase == SyncPhase.scanning ||
      phase == SyncPhase.fetchingMemos;

  /// Fraction of *this wallet's* scan range that's done, i.e. relative to
  /// [birthday] rather than to height 0. Blocks before the birthday were
  /// never going to be scanned, so they shouldn't count as "remaining
  /// work" any more than they count as "done work".
  double get progress {
    final span = chainTipHeight - birthday;
    if (span <= 0) return chainTipHeight == 0 ? 0 : 1;
    // num.clamp returns num, not double, even on a double receiver --
    // .toDouble() keeps this getter's declared return type honest instead
    // of relying on an implicit conversion that Dart's sound type system
    // doesn't actually perform.
    return ((syncedHeight - birthday) / span).clamp(0.0, 1.0).toDouble();
  }

  // Value equality so the engine's fast (250ms) status poll can be
  // `.distinct()`-filtered before it reaches widgets that `ref.watch()` it
  // (HomeScreen, NetworkStatusScreen) -- without this, every poll is a
  // "new" object even when nothing actually changed, and each one would
  // trigger a full rebuild of every screen watching it.
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SyncStatus &&
          phase == other.phase &&
          syncedHeight == other.syncedHeight &&
          chainTipHeight == other.chainTipHeight &&
          birthday == other.birthday &&
          lastError == other.lastError);

  @override
  int get hashCode =>
      Object.hash(phase, syncedHeight, chainTipHeight, birthday, lastError);
}

class TxPlan {
  final int feeZatoshi;
  final int amountZatoshi;
  final Balances resultingBalances;
  /// Opaque native request returned by the Ycash light-client. It is kept
  /// inside the typed engine boundary and is not interpreted by the UI.
  final Map<String, dynamic>? nativeRequest;
  const TxPlan({
    required this.feeZatoshi,
    required this.amountZatoshi,
    required this.resultingBalances,
    this.nativeRequest,
  });
}

class TxRecord {
  final String txId;
  final DateTime timestamp;
  final int amountZatoshi; // signed: negative = outgoing
  final bool isShielded;
  final String? memo;
  const TxRecord({
    required this.txId,
    required this.timestamp,
    required this.amountZatoshi,
    required this.isShielded,
    this.memo,
  });
}

abstract class YcashEngine {
  /// Opens the wallet, or creates a new one when [restoreSeedPhrase] is
  /// omitted.
  ///
  /// [isRestore] must be `true` only when the caller is explicitly
  /// replacing whatever wallet currently exists on disk with the one
  /// derived from [restoreSeedPhrase] (i.e. the user typed a recovery
  /// phrase into "Restore wallet"). It defaults to `false` so that the
  /// routine reopen done on every app unlock — which passes the same
  /// on-device seed right back in — never wipes the synced wallet data it
  /// is only trying to reopen.
  Future<void> openOrCreateWallet(
      {String? restoreSeedPhrase, bool isRestore = false});
  Future<String> exportSeedPhrase(); // caller must have passed BiometricGate first
  Future<Balances> getBalances();
  Stream<SyncStatus> watchSyncStatus();

  /// Kicks off another native scan round against the currently-open
  /// wallet, on top of whatever background re-syncing the engine already
  /// does on its own. Exposed so the UI can offer an explicit "refresh
  /// now" affordance (pull-to-refresh, a manual refresh button) instead of
  /// only ever re-reading the last cached status.
  Future<void> syncNow();

  Future<void> wipeWallet(); // deletes the local synced-chain database

  /// Asks the connected server which block height corresponds to [date],
  /// so the caller can show/confirm a starting point before committing to
  /// [rescanFromHeight]. Takes a handful of network round trips, not a
  /// full scan.
  Future<int> estimateHeightForDate(DateTime date);

  /// Rescans starting from [height] instead of the wallet's stored
  /// birthday, discarding and rebuilding transaction history from there
  /// forward. Runs in the background — watch [watchSyncStatus] for
  /// progress the same way as any other sync. Used to speed up recovery
  /// after a wipe or reinstall when the wallet's actual first-use date is
  /// known, instead of always rescanning from Sapling activation.
  Future<void> rescanFromHeight(int height);

  Future<String> getShieldedAddress();
  Future<String> getTransparentAddress();

  Future<TxPlan> planSend(
      {required String toAddress,
      required int amountZatoshi,
      String? memo,
      required String feeTier});
  Future<String> broadcastPlannedTx(TxPlan plan); // returns txid

  /// Builds a plan to move funds from transparent -> shielded pool.
  /// [amountZatoshi] null means "shield everything spendable".
  Future<TxPlan> planShield({int? amountZatoshi});

  /// Builds a plan to move funds from shielded -> transparent pool.
  Future<TxPlan> planUnshield({int? amountZatoshi});

  Future<List<TxRecord>> getTransactionHistory();
}
