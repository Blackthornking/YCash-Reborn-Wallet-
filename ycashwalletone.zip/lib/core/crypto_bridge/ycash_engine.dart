/// The typed Dart-side contract for the Rust crypto/sync engine.
///
/// This file intentionally contains no cryptography. It defines the shape
/// of what the trimmed `ycash_core_ffi` package (built from the existing,
/// proven Sapling code — Orchard, UA, Ledger and Zcash-mainnet/testnet
/// branches removed) exposes to the Flutter app. Implementations live in
/// `packages/ycash_core_ffi`; everything in `lib/` talks to this interface,
/// never to raw FFI calls, so the security-critical boundary stays in one
/// auditable place.
library ycash_engine;

class Balances {
  final int shieldedZatoshi;
  final int transparentZatoshi;
  const Balances(
      {required this.shieldedZatoshi, required this.transparentZatoshi});

  int get totalZatoshi => shieldedZatoshi + transparentZatoshi;
  bool get hasUnshielded => transparentZatoshi > 0;
  bool get hasShielded => shieldedZatoshi > 0;
}

class SyncStatus {
  final int syncedHeight;
  final int chainTipHeight;
  final bool isSyncing;
  /// Set when the most recent sync attempt gave up after exhausting its
  /// retries (e.g. the server was unreachable). Null while syncing is
  /// actively progressing or has fully caught up.
  final String? lastError;
  const SyncStatus(
      {required this.syncedHeight,
      required this.chainTipHeight,
      required this.isSyncing,
      this.lastError});

  double get progress =>
      chainTipHeight == 0 ? 0 : syncedHeight / chainTipHeight;

  // Value equality so the engine's fast (250ms) status poll can be
  // `.distinct()`-filtered before it reaches widgets that `ref.watch()` it
  // (HomeScreen, NetworkStatusScreen) -- without this, every poll is a
  // "new" object even when nothing actually changed, and each one would
  // trigger a full rebuild of every screen watching it.
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SyncStatus &&
          syncedHeight == other.syncedHeight &&
          chainTipHeight == other.chainTipHeight &&
          isSyncing == other.isSyncing &&
          lastError == other.lastError);

  @override
  int get hashCode =>
      Object.hash(syncedHeight, chainTipHeight, isSyncing, lastError);
}

class TxPlan {
  final int feeZatoshi;
  final int amountZatoshi;
  final Balances resultingBalances;
  /// Opaque native request returned by the Ycash light-client. It is kept
  /// inside the typed engine boundary and is not interpreted by the UI.
  final Map<String, dynamic>? nativeRequest;
  const TxPlan({
    required this.feeZatoshi,
    required this.amountZatoshi,
    required this.resultingBalances,
    this.nativeRequest,
  });
}

class TxRecord {
  final String txId;
  final DateTime timestamp;
  final int amountZatoshi; // signed: negative = outgoing
  final bool isShielded;
  final String? memo;
  const TxRecord({
    required this.txId,
    required this.timestamp,
    required this.amountZatoshi,
    required this.isShielded,
    this.memo,
  });
}

abstract class YcashEngine {
  /// Opens the wallet, or creates a new one when [restoreSeedPhrase] is
  /// omitted.
  ///
  /// [isRestore] must be `true` only when the caller is explicitly
  /// replacing whatever wallet currently exists on disk with the one
  /// derived from [restoreSeedPhrase] (i.e. the user typed a recovery
  /// phrase into "Restore wallet"). It defaults to `false` so that the
  /// routine reopen done on every app unlock — which passes the same
  /// on-device seed right back in — never wipes the synced wallet data it
  /// is only trying to reopen.
  Future<void> openOrCreateWallet(
      {String? restoreSeedPhrase, bool isRestore = false});
  Future<String> exportSeedPhrase(); // caller must have passed BiometricGate first
  Future<Balances> getBalances();
  Stream<SyncStatus> watchSyncStatus();

  /// Kicks off another native scan round against the currently-open
  /// wallet, on top of whatever background re-syncing the engine already
  /// does on its own. Exposed so the UI can offer an explicit "refresh
  /// now" affordance (pull-to-refresh, a manual refresh button) instead of
  /// only ever re-reading the last cached status.
  Future<void> syncNow();

  Future<void> wipeWallet(); // deletes the local synced-chain database

  /// Asks the connected server which block height corresponds to [date],
  /// so the caller can show/confirm a starting point before committing to
  /// [rescanFromHeight]. Takes a handful of network round trips, not a
  /// full scan.
  Future<int> estimateHeightForDate(DateTime date);

  /// Rescans starting from [height] instead of the wallet's stored
  /// birthday, discarding and rebuilding transaction history from there
  /// forward. Runs in the background — watch [watchSyncStatus] for
  /// progress the same way as any other sync. Used to speed up recovery
  /// after a wipe or reinstall when the wallet's actual first-use date is
  /// known, instead of always rescanning from Sapling activation.
  Future<void> rescanFromHeight(int height);

  Future<String> getShieldedAddress();
  Future<String> getTransparentAddress();

  Future<TxPlan> planSend(
      {required String toAddress,
      required int amountZatoshi,
      String? memo,
      required String feeTier});
  Future<String> broadcastPlannedTx(TxPlan plan); // returns txid

  /// Builds a plan to move funds from transparent -> shielded pool.
  /// [amountZatoshi] null means "shield everything spendable".
  Future<TxPlan> planShield({int? amountZatoshi});

  /// Builds a plan to move funds from shielded -> transparent pool.
  Future<TxPlan> planUnshield({int? amountZatoshi});

  Future<List<TxRecord>> getTransactionHistory();
}
