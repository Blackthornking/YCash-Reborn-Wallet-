import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/ycash_config.dart';

/// How the wallet keeps itself caught up while the app isn't open, via a
/// periodic OS-level job -- the same mechanism zodl/Zashi use (Android
/// WorkManager) so the balance is already current the next time the app
/// is opened instead of needing to catch up from scratch.
///
///  - [always]: runs on any network, on by default. Matches zodl's own
///    on-by-default background sync, but -- per instruction -- without
///    zodl's Wi-Fi-and-charging-only gating.
///  - [wifiOnly]: same job, but only runs on an unmetered (Wi-Fi)
///    connection, for anyone who'd rather not use mobile data for it.
///  - [off]: the periodic job is cancelled; the wallet only syncs while
///    actually open, same as before this feature existed.
enum BackgroundSyncMode { always, wifiOnly, off }

/// Holds ordinary, non-secret wallet preferences.
class SettingsStore {
  static const _serverUrlKey = 'ycash.settings.server_url';
  static const _localCurrencyKey = 'ycash.settings.local_currency';
  static const _themeModeKey = 'ycash.settings.theme_mode';
  static const _autoShieldKey = 'ycash.settings.auto_shield';
  static const _hideBalanceKey = 'ycash.settings.hide_balance';
  static const _autoShieldMinKey = 'ycash.settings.auto_shield_min';
  static const _autoLockSecondsKey = 'ycash.settings.auto_lock_seconds';
  static const _backgroundSyncModeKey = 'ycash.settings.background_sync_mode';

  Future<String> getServerUrl() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_serverUrlKey) ?? YcashConfig.defaultLightwalletd;
  }
  Future<void> setServerUrl(String url) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_serverUrlKey, url);
  }
  Future<void> resetServerUrl() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_serverUrlKey);
  }

  Future<String> getLocalCurrency() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_localCurrencyKey) ?? 'USD';
  }
  Future<void> setLocalCurrency(String code) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_localCurrencyKey, code);
  }

  Future<ThemeMode> getThemeMode() async {
    final prefs = await SharedPreferences.getInstance();
    switch (prefs.getString(_themeModeKey)) {
      case 'light': return ThemeMode.light;
      case 'system': return ThemeMode.system;
      default: return ThemeMode.dark;
    }
  }
  Future<void> setThemeMode(ThemeMode mode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_themeModeKey, mode.name);
  }

  Future<bool> getAutoShield() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_autoShieldKey) ?? false;
  }
  Future<void> setAutoShield(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_autoShieldKey, enabled);
  }

  Future<bool> getHideBalance() async { final prefs = await SharedPreferences.getInstance(); return prefs.getBool(_hideBalanceKey) ?? false; }
  Future<void> setHideBalance(bool value) async { final prefs = await SharedPreferences.getInstance(); await prefs.setBool(_hideBalanceKey, value); }
  Future<double> getAutoShieldMinimum() async { final prefs = await SharedPreferences.getInstance(); return prefs.getDouble(_autoShieldMinKey) ?? 0; }
  Future<void> setAutoShieldMinimum(double value) async { final prefs = await SharedPreferences.getInstance(); await prefs.setDouble(_autoShieldMinKey, value); }

  /// How long the app can sit in the background before it locks and asks
  /// for the wallet password again. Defaults to 15 seconds; see
  /// [autoLockSecondsOptions] in providers.dart for the values Settings
  /// lets the user pick between.
  Future<int> getAutoLockSeconds() async { final prefs = await SharedPreferences.getInstance(); return prefs.getInt(_autoLockSecondsKey) ?? 15; }
  Future<void> setAutoLockSeconds(int seconds) async { final prefs = await SharedPreferences.getInstance(); await prefs.setInt(_autoLockSecondsKey, seconds); }

  /// Defaults to [BackgroundSyncMode.always] -- on out of the box, same as
  /// zodl. See [BackgroundSyncMode] for what each value does.
  Future<BackgroundSyncMode> getBackgroundSyncMode() async {
    final prefs = await SharedPreferences.getInstance();
    switch (prefs.getString(_backgroundSyncModeKey)) {
      case 'wifiOnly': return BackgroundSyncMode.wifiOnly;
      case 'off': return BackgroundSyncMode.off;
      default: return BackgroundSyncMode.always;
    }
  }
  Future<void> setBackgroundSyncMode(BackgroundSyncMode mode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_backgroundSyncModeKey, mode.name);
  }
}
