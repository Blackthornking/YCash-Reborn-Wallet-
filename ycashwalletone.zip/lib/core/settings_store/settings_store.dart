import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/ycash_config.dart';

/// Holds ordinary, non-secret wallet preferences.
class SettingsStore {
  static const _serverUrlKey = 'ycash.settings.server_url';
  static const _localCurrencyKey = 'ycash.settings.local_currency';
  static const _themeModeKey = 'ycash.settings.theme_mode';
  static const _autoShieldKey = 'ycash.settings.auto_shield';
  static const _hideBalanceKey = 'ycash.settings.hide_balance';
  static const _autoShieldMinKey = 'ycash.settings.auto_shield_min';

  Future<String> getServerUrl() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_serverUrlKey) ?? YcashConfig.defaultLightwalletd;
  }
  Future<void> setServerUrl(String url) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_serverUrlKey, url);
  }
  Future<void> resetServerUrl() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_serverUrlKey);
  }

  Future<String> getLocalCurrency() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_localCurrencyKey) ?? 'USD';
  }
  Future<void> setLocalCurrency(String code) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_localCurrencyKey, code);
  }

  Future<ThemeMode> getThemeMode() async {
    final prefs = await SharedPreferences.getInstance();
    switch (prefs.getString(_themeModeKey)) {
      case 'light': return ThemeMode.light;
      case 'system': return ThemeMode.system;
      default: return ThemeMode.dark;
    }
  }
  Future<void> setThemeMode(ThemeMode mode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_themeModeKey, mode.name);
  }

  Future<bool> getAutoShield() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_autoShieldKey) ?? false;
  }
  Future<void> setAutoShield(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_autoShieldKey, enabled);
  }

  Future<bool> getHideBalance() async { final prefs = await SharedPreferences.getInstance(); return prefs.getBool(_hideBalanceKey) ?? false; }
  Future<void> setHideBalance(bool value) async { final prefs = await SharedPreferences.getInstance(); await prefs.setBool(_hideBalanceKey, value); }
  Future<double> getAutoShieldMinimum() async { final prefs = await SharedPreferences.getInstance(); return prefs.getDouble(_autoShieldMinKey) ?? 0; }
  Future<void> setAutoShieldMinimum(double value) async { final prefs = await SharedPreferences.getInstance(); await prefs.setDouble(_autoShieldMinKey, value); }
}
