import 'package:intl/intl.dart';

/// ISO-style currency choices for the wallet's local-value display.
/// Keeping this local means currency selection works offline and never stores
/// any wallet or address data.
class CurrencyChoice {
  final String code;
  final String name;
  const CurrencyChoice(this.code, this.name);

  String format(num value) {
    try {
      return NumberFormat.currency(name: code, decimalDigits: 2).format(value);
    } catch (_) {
      return '$code ${value.toStringAsFixed(2)}';
    }
  }
}

const List<CurrencyChoice> globalCurrencies = [
  CurrencyChoice('AED','UAE Dirham'), CurrencyChoice('AFN','Afghan Afghani'), CurrencyChoice('ALL','Albanian Lek'), CurrencyChoice('AMD','Armenian Dram'), CurrencyChoice('ANG','Netherlands Antillean Guilder'), CurrencyChoice('AOA','Angolan Kwanza'), CurrencyChoice('ARS','Argentine Peso'), CurrencyChoice('AUD','Australian Dollar'), CurrencyChoice('AWG','Aruban Florin'), CurrencyChoice('AZN','Azerbaijani Manat'),
  CurrencyChoice('BAM','Bosnia-Herzegovina Convertible Mark'), CurrencyChoice('BBD','Barbadian Dollar'), CurrencyChoice('BDT','Bangladeshi Taka'), CurrencyChoice('BGN','Bulgarian Lev'), CurrencyChoice('BHD','Bahraini Dinar'), CurrencyChoice('BIF','Burundian Franc'), CurrencyChoice('BMD','Bermudian Dollar'), CurrencyChoice('BND','Brunei Dollar'), CurrencyChoice('BOB','Bolivian Boliviano'), CurrencyChoice('BRL','Brazilian Real'), CurrencyChoice('BSD','Bahamian Dollar'), CurrencyChoice('BTN','Bhutanese Ngultrum'), CurrencyChoice('BWP','Botswana Pula'), CurrencyChoice('BYN','Belarusian Ruble'), CurrencyChoice('BZD','Belize Dollar'),
  CurrencyChoice('CAD','Canadian Dollar'), CurrencyChoice('CDF','Congolese Franc'), CurrencyChoice('CHF','Swiss Franc'), CurrencyChoice('CLP','Chilean Peso'), CurrencyChoice('CNY','Chinese Yuan'), CurrencyChoice('COP','Colombian Peso'), CurrencyChoice('CRC','Costa Rican Colón'), CurrencyChoice('CUP','Cuban Peso'), CurrencyChoice('CVE','Cape Verdean Escudo'), CurrencyChoice('CZK','Czech Koruna'),
  CurrencyChoice('DJF','Djiboutian Franc'), CurrencyChoice('DKK','Danish Krone'), CurrencyChoice('DOP','Dominican Peso'), CurrencyChoice('DZD','Algerian Dinar'),
  CurrencyChoice('EGP','Egyptian Pound'), CurrencyChoice('ERN','Eritrean Nakfa'), CurrencyChoice('ETB','Ethiopian Birr'), CurrencyChoice('EUR','Euro'),
  CurrencyChoice('FJD','Fijian Dollar'), CurrencyChoice('FKP','Falkland Islands Pound'),
  CurrencyChoice('GBP','British Pound'), CurrencyChoice('GEL','Georgian Lari'), CurrencyChoice('GHS','Ghanaian Cedi'), CurrencyChoice('GIP','Gibraltar Pound'), CurrencyChoice('GMD','Gambian Dalasi'), CurrencyChoice('GNF','Guinean Franc'), CurrencyChoice('GTQ','Guatemalan Quetzal'), CurrencyChoice('GYD','Guyanese Dollar'),
  CurrencyChoice('HKD','Hong Kong Dollar'), CurrencyChoice('HNL','Honduran Lempira'), CurrencyChoice('HTG','Haitian Gourde'), CurrencyChoice('HUF','Hungarian Forint'),
  CurrencyChoice('IDR','Indonesian Rupiah'), CurrencyChoice('ILS','Israeli New Shekel'), CurrencyChoice('INR','Indian Rupee'), CurrencyChoice('IQD','Iraqi Dinar'), CurrencyChoice('IRR','Iranian Rial'), CurrencyChoice('ISK','Icelandic Króna'),
  CurrencyChoice('JMD','Jamaican Dollar'), CurrencyChoice('JOD','Jordanian Dinar'), CurrencyChoice('JPY','Japanese Yen'),
  CurrencyChoice('KES','Kenyan Shilling'), CurrencyChoice('KGS','Kyrgyzstani Som'), CurrencyChoice('KHR','Cambodian Riel'), CurrencyChoice('KMF','Comorian Franc'), CurrencyChoice('KPW','North Korean Won'), CurrencyChoice('KRW','South Korean Won'), CurrencyChoice('KWD','Kuwaiti Dinar'), CurrencyChoice('KYD','Cayman Islands Dollar'), CurrencyChoice('KZT','Kazakhstani Tenge'),
  CurrencyChoice('LAK','Lao Kip'), CurrencyChoice('LBP','Lebanese Pound'), CurrencyChoice('LKR','Sri Lankan Rupee'), CurrencyChoice('LRD','Liberian Dollar'), CurrencyChoice('LSL','Lesotho Loti'), CurrencyChoice('LYD','Libyan Dinar'),
  CurrencyChoice('MAD','Moroccan Dirham'), CurrencyChoice('MDL','Moldovan Leu'), CurrencyChoice('MGA','Malagasy Ariary'), CurrencyChoice('MKD','Macedonian Denar'), CurrencyChoice('MMK','Myanmar Kyat'), CurrencyChoice('MNT','Mongolian Tögrög'), CurrencyChoice('MOP','Macanese Pataca'), CurrencyChoice('MRU','Mauritanian Ouguiya'), CurrencyChoice('MUR','Mauritian Rupee'), CurrencyChoice('MVR','Maldivian Rufiyaa'), CurrencyChoice('MWK','Malawian Kwacha'), CurrencyChoice('MXN','Mexican Peso'), CurrencyChoice('MYR','Malaysian Ringgit'), CurrencyChoice('MZN','Mozambican Metical'),
  CurrencyChoice('NAD','Namibian Dollar'), CurrencyChoice('NGN','Nigerian Naira'), CurrencyChoice('NIO','Nicaraguan Córdoba'), CurrencyChoice('NOK','Norwegian Krone'), CurrencyChoice('NPR','Nepalese Rupee'), CurrencyChoice('NZD','New Zealand Dollar'),
  CurrencyChoice('OMR','Omani Rial'),
  CurrencyChoice('PAB','Panamanian Balboa'), CurrencyChoice('PEN','Peruvian Sol'), CurrencyChoice('PGK','Papua New Guinean Kina'), CurrencyChoice('PHP','Philippine Peso'), CurrencyChoice('PKR','Pakistani Rupee'), CurrencyChoice('PLN','Polish Złoty'), CurrencyChoice('PYG','Paraguayan Guaraní'),
  CurrencyChoice('QAR','Qatari Riyal'),
  CurrencyChoice('RON','Romanian Leu'), CurrencyChoice('RSD','Serbian Dinar'), CurrencyChoice('RUB','Russian Ruble'), CurrencyChoice('RWF','Rwandan Franc'),
  CurrencyChoice('SAR','Saudi Riyal'), CurrencyChoice('SBD','Solomon Islands Dollar'), CurrencyChoice('SCR','Seychellois Rupee'), CurrencyChoice('SDG','Sudanese Pound'), CurrencyChoice('SEK','Swedish Krona'), CurrencyChoice('SGD','Singapore Dollar'), CurrencyChoice('SHP','Saint Helena Pound'), CurrencyChoice('SLE','Sierra Leonean Leone'), CurrencyChoice('SOS','Somali Shilling'), CurrencyChoice('SRD','Surinamese Dollar'), CurrencyChoice('SSP','South Sudanese Pound'), CurrencyChoice('STN','São Tomé and Príncipe Dobra'), CurrencyChoice('SYP','Syrian Pound'), CurrencyChoice('SZL','Swazi Lilangeni'),
  CurrencyChoice('THB','Thai Baht'), CurrencyChoice('TJS','Tajikistani Somoni'), CurrencyChoice('TMT','Turkmenistani Manat'), CurrencyChoice('TND','Tunisian Dinar'), CurrencyChoice('TOP','Tongan Paʻanga'), CurrencyChoice('TRY','Turkish Lira'), CurrencyChoice('TTD','Trinidad and Tobago Dollar'), CurrencyChoice('TWD','New Taiwan Dollar'), CurrencyChoice('TZS','Tanzanian Shilling'),
  CurrencyChoice('UAH','Ukrainian Hryvnia'), CurrencyChoice('UGX','Ugandan Shilling'), CurrencyChoice('USD','US Dollar'), CurrencyChoice('UYU','Uruguayan Peso'), CurrencyChoice('UZS','Uzbekistani Som'),
  CurrencyChoice('VES','Venezuelan Bolívar'), CurrencyChoice('VND','Vietnamese Đồng'), CurrencyChoice('VUV','Vanuatu Vatu'),
  CurrencyChoice('WST','Samoan Tālā'),
  CurrencyChoice('XAF','Central African CFA Franc'), CurrencyChoice('XCD','East Caribbean Dollar'), CurrencyChoice('XOF','West African CFA Franc'), CurrencyChoice('XPF','CFP Franc'),
  CurrencyChoice('YER','Yemeni Rial'),
  CurrencyChoice('ZAR','South African Rand'), CurrencyChoice('ZMW','Zambian Kwacha'), CurrencyChoice('ZWL','Zimbabwean Dollar'),
];

CurrencyChoice currencyByCode(String code) => globalCurrencies.firstWhere(
  (c) => c.code == code,
  orElse: () => CurrencyChoice(code, code),
);
