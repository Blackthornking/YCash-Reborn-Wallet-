import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'crypto_bridge/ycash_engine.dart';
import 'biometrics/biometric_gate.dart';
import 'secure_storage/seed_vault.dart';
import 'settings_store/settings_store.dart';
import 'settings_store/currencies.dart';

final engineProvider = Provider<YcashEngine>((ref) {
  throw UnimplementedError('engineProvider must be overridden with the real ycash_core_ffi engine at startup');
});
final biometricGateProvider = Provider<BiometricGate>((ref) => BiometricGate());
final seedVaultProvider = Provider<SeedVault>((ref) => SeedVault());
final settingsStoreProvider = Provider<SettingsStore>((ref) => SettingsStore());

final themeModeProvider = AsyncNotifierProvider<ThemeModeController, ThemeMode>(ThemeModeController.new);
class ThemeModeController extends AsyncNotifier<ThemeMode> {
  @override
  Future<ThemeMode> build() => ref.read(settingsStoreProvider).getThemeMode();
  Future<void> setMode(ThemeMode mode) async {
    state = AsyncData(mode);
    await ref.read(settingsStoreProvider).setThemeMode(mode);
  }
}

final autoShieldProvider = AsyncNotifierProvider<AutoShieldController, bool>(AutoShieldController.new);
class AutoShieldController extends AsyncNotifier<bool> {
  @override
  Future<bool> build() => ref.read(settingsStoreProvider).getAutoShield();
  Future<void> setEnabled(bool enabled) async {
    state = AsyncData(enabled);
    await ref.read(settingsStoreProvider).setAutoShield(enabled);
  }
}

final transactionHistoryProvider = FutureProvider<List<TxRecord>>((ref) => ref.watch(engineProvider).getTransactionHistory());
final balancesProvider = StreamProvider<Balances>((ref) async* {
  final engine = ref.watch(engineProvider);
  while (true) {
    try { yield await engine.getBalances(); }
    catch (e, st) { yield* Stream<Balances>.error(e, st); }
    await Future.delayed(const Duration(seconds: 5));
  }
});
final syncStatusProvider = StreamProvider<SyncStatus>((ref) => ref.watch(engineProvider).watchSyncStatus());
final localCurrencyProvider = FutureProvider<CurrencyChoice>((ref) async {
  final code = await ref.watch(settingsStoreProvider).getLocalCurrency();
  return currencyByCode(code);
});

final hideBalanceProvider = AsyncNotifierProvider<HideBalanceController, bool>(HideBalanceController.new);
class HideBalanceController extends AsyncNotifier<bool> { @override Future<bool> build()=>ref.read(settingsStoreProvider).getHideBalance(); Future<void> setHidden(bool value) async { state=AsyncData(value); await ref.read(settingsStoreProvider).setHideBalance(value); } }
final autoShieldMinimumProvider = AsyncNotifierProvider<AutoShieldMinimumController, double>(AutoShieldMinimumController.new);
class AutoShieldMinimumController extends AsyncNotifier<double> { @override Future<double> build()=>ref.read(settingsStoreProvider).getAutoShieldMinimum(); Future<void> setMinimum(double value) async { state=AsyncData(value); await ref.read(settingsStoreProvider).setAutoShieldMinimum(value); } }
