import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'crypto_bridge/ycash_engine.dart';
import 'biometrics/biometric_gate.dart';
import 'pricing/coinmarketcap_service.dart';
import 'secure_storage/seed_vault.dart';
import 'secure_storage/price_api_key_vault.dart';
import 'settings_store/settings_store.dart';
import 'settings_store/currencies.dart';

final engineProvider = Provider<YcashEngine>((ref) {
  throw UnimplementedError('engineProvider must be overridden with the real ycash_core_ffi engine at startup');
});
final biometricGateProvider = Provider<BiometricGate>((ref) => BiometricGate());
final seedVaultProvider = Provider<SeedVault>((ref) => SeedVault());
final settingsStoreProvider = Provider<SettingsStore>((ref) => SettingsStore());
final priceApiKeyVaultProvider = Provider<PriceApiKeyVault>((ref) => PriceApiKeyVault());
final coinMarketCapServiceProvider = Provider<CoinMarketCapService>((ref) {
  final service = CoinMarketCapService();
  ref.onDispose(service.dispose);
  return service;
});

final themeModeProvider = AsyncNotifierProvider<ThemeModeController, ThemeMode>(ThemeModeController.new);
class ThemeModeController extends AsyncNotifier<ThemeMode> {
  @override
  Future<ThemeMode> build() => ref.read(settingsStoreProvider).getThemeMode();
  Future<void> setMode(ThemeMode mode) async {
    state = AsyncData(mode);
    await ref.read(settingsStoreProvider).setThemeMode(mode);
  }
}

final autoShieldProvider = AsyncNotifierProvider<AutoShieldController, bool>(AutoShieldController.new);
class AutoShieldController extends AsyncNotifier<bool> {
  @override
  Future<bool> build() => ref.read(settingsStoreProvider).getAutoShield();
  Future<void> setEnabled(bool enabled) async {
    state = AsyncData(enabled);
    await ref.read(settingsStoreProvider).setAutoShield(enabled);
  }
}

final transactionHistoryProvider = FutureProvider<List<TxRecord>>((ref) => ref.watch(engineProvider).getTransactionHistory());
final balancesProvider = StreamProvider<Balances>((ref) async* {
  final engine = ref.watch(engineProvider);
  while (true) {
    try { yield await engine.getBalances(); }
    catch (e, st) { yield* Stream<Balances>.error(e, st); }
    await Future.delayed(const Duration(seconds: 5));
  }
});
final syncStatusProvider = StreamProvider<SyncStatus>((ref) => ref.watch(engineProvider).watchSyncStatus());
final localCurrencyProvider = FutureProvider<CurrencyChoice>((ref) async {
  final code = await ref.watch(settingsStoreProvider).getLocalCurrency();
  return currencyByCode(code);
});

/// The user's own CoinMarketCap API key (Settings > Local currency > Price
/// source). Null means no key has been saved, in which case the fiat
/// estimate is simply not shown — see [fiatRateProvider].
final cmcApiKeyProvider = AsyncNotifierProvider<CmcApiKeyController, String?>(CmcApiKeyController.new);
class CmcApiKeyController extends AsyncNotifier<String?> {
  @override
  Future<String?> build() {
    final key = ref.read(priceApiKeyVaultProvider).readCoinMarketCapKey();
    return key;
  }

  Future<void> setKey(String? key) async {
    final vault = ref.read(priceApiKeyVaultProvider);
    if (key == null || key.trim().isEmpty) {
      await vault.clearCoinMarketCapKey();
      state = const AsyncData(null);
    } else {
      await vault.writeCoinMarketCapKey(key.trim());
      state = AsyncData(key.trim());
    }
  }
}

/// Local-currency value of 1 YEC, for the "≈ X.XX CCY" line under the main
/// balance. Sourced from CoinMarketCap, converted to whatever currency is
/// picked in Settings > Local currency. Returns null (hiding the estimate
/// rather than showing a misleading 0.00) whenever no API key is
/// configured, the currency isn't supported, or the request fails —
/// polls every 90 seconds while a key is present to stay within a free
/// CoinMarketCap plan's call budget.
final fiatRateProvider = StreamProvider<double?>((ref) async* {
  final apiKey = ref.watch(cmcApiKeyProvider).valueOrNull;
  final currency = ref.watch(localCurrencyProvider).valueOrNull;
  if (apiKey == null || apiKey.isEmpty || currency == null) {
    yield null;
    return;
  }
  final service = ref.watch(coinMarketCapServiceProvider);
  while (true) {
    try {
      yield await service.getYecPrice(apiKey: apiKey, fiatCurrencyCode: currency.code);
    } catch (_) {
      // Network hiccup, bad key, or an unsupported currency: hide the
      // estimate for this cycle rather than surfacing an error banner
      // over the wallet's main balance.
      yield null;
    }
    await Future.delayed(const Duration(seconds: 90));
  }
});

final hideBalanceProvider = AsyncNotifierProvider<HideBalanceController, bool>(HideBalanceController.new);
class HideBalanceController extends AsyncNotifier<bool> { @override Future<bool> build()=>ref.read(settingsStoreProvider).getHideBalance(); Future<void> setHidden(bool value) async { state=AsyncData(value); await ref.read(settingsStoreProvider).setHideBalance(value); } }
final autoShieldMinimumProvider = AsyncNotifierProvider<AutoShieldMinimumController, double>(AutoShieldMinimumController.new);
class AutoShieldMinimumController extends AsyncNotifier<double> { @override Future<double> build()=>ref.read(settingsStoreProvider).getAutoShieldMinimum(); Future<void> setMinimum(double value) async { state=AsyncData(value); await ref.read(settingsStoreProvider).setAutoShieldMinimum(value); } }
