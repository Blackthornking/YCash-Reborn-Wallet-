import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/crypto_bridge/ycash_engine.dart';
import '../../core/models/ycash_config.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

class TxDetailScreen extends StatelessWidget {
  final TxRecord tx;
  const TxDetailScreen({super.key, required this.tx});

  @override
  Widget build(BuildContext context) {
    final outgoing = tx.amountZatoshi < 0;
    final amount = (tx.amountZatoshi.abs() / 1e8).toStringAsFixed(8);
    final poolLabel =
        tx.isShielded ? 'Shielded transaction' : 'Transparent transaction';

    return Scaffold(
      appBar: AppBar(title: const Text('Transaction')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(YSpacing.lg),
          child: ListView(
            children: [
              YEnter(
                child: Semantics(
                  // One merged summary — "Sent 0.12340000 YEC, shielded
                  // transaction" — instead of an unlabeled arrow icon
                  // plus two separately-announced text nodes.
                  label:
                      '${outgoing ? 'Sent' : 'Received'} $amount YEC, ${poolLabel.toLowerCase()}',
                  excludeSemantics: true,
                  child: Center(
                    child: Column(
                      children: [
                        Icon(
                          outgoing ? Icons.arrow_upward : Icons.arrow_downward,
                          size: 40,
                          color:
                              outgoing ? YColors.textPrimary : YColors.success,
                        ),
                        const SizedBox(height: YSpacing.sm),
                        Text(
                          '${outgoing ? '-' : '+'}$amount YEC',
                          style: const TextStyle(
                              fontSize: 28, fontWeight: FontWeight.w700),
                        ),
                        Text(
                          poolLabel,
                          style: const TextStyle(color: YColors.textSecondary),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: YSpacing.xl),
              YEnter(
                delay: const Duration(milliseconds: 60),
                child: _DetailRow(
                  label: 'Date',
                  value: DateFormat.yMMMMd().add_jm().format(tx.timestamp),
                ),
              ),
              YEnter(
                delay: const Duration(milliseconds: 120),
                child: _DetailRow(
                  label: 'Transaction ID',
                  value: tx.txId,
                  copyable: true,
                ),
              ),
              if (tx.memo != null && tx.memo!.isNotEmpty)
                YEnter(
                  delay: const Duration(milliseconds: 180),
                  child: _DetailRow(label: 'Memo', value: tx.memo!),
                ),
              const SizedBox(height: YSpacing.lg),
              YEnter(
                delay: const Duration(milliseconds: 240),
                child: OutlinedButton.icon(
                  onPressed: () => _openExplorer(context),
                  icon: const Icon(Icons.open_in_new),
                  label: const Text('View on block explorer'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _openExplorer(BuildContext context) async {
    final uri = Uri.parse('${YcashConfig.blockExplorerTxBase}/${tx.txId}');
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      YHaptics.warn();
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Could not open explorer')));
      }
    }
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  final bool copyable;
  const _DetailRow({required this.label, required this.value, this.copyable = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: YSpacing.sm),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            // "Date: 5 September 2026 at 3:45 PM" as one node instead of
            // the label and value being read as two separate stops.
            child: Semantics(
              label: '$label: $value',
              excludeSemantics: true,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style:
                          const TextStyle(color: YColors.textMuted, fontSize: 12)),
                  const SizedBox(height: 2),
                  Text(value, style: const TextStyle(fontFamily: 'monospace')),
                ],
              ),
            ),
          ),
          if (copyable)
            IconButton(
              icon: const Icon(Icons.copy, size: 18),
              tooltip: 'Copy $label',
              onPressed: () {
                Clipboard.setData(ClipboardData(text: value));
                YHaptics.acknowledge();
                ScaffoldMessenger.of(context)
                    .showSnackBar(SnackBar(content: Text('$label copied')));
              },
            ),
        ],
      ),
    );
  }
}
