import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../../core/providers.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';
import '../shield/shield_flow.dart';

class PoolScreen extends ConsumerStatefulWidget {
  final bool shielded;
  const PoolScreen({super.key, required this.shielded});

  @override
  ConsumerState<PoolScreen> createState() => _PoolScreenState();
}

class _PoolScreenState extends ConsumerState<PoolScreen> {
  String? _address;
  Object? _error;

  @override
  void initState() { super.initState(); _loadAddress(); }

  Future<void> _loadAddress() async {
    setState(() { _address = null; _error = null; });
    try {
      final engine = ref.read(engineProvider);
      final address = widget.shielded ? await engine.getShieldedAddress() : await engine.getTransparentAddress();
      if (mounted) setState(() => _address = address);
    } catch (e) { if (mounted) setState(() => _error = e); }
  }

  @override
  Widget build(BuildContext context) {
    final balances = ref.watch(balancesProvider);
    final accent = widget.shielded ? YColors.shieldedPrimary : YColors.transparentAccent;
    final title = widget.shielded ? 'Shielded' : 'Transparent';
    final subtitle = widget.shielded ? 'Private Sapling funds' : 'Public on-chain funds';
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(YSpacing.lg), children: [
        Container(
          padding: const EdgeInsets.all(YSpacing.lg),
          decoration: BoxDecoration(color: YColors.spaceSurface, borderRadius: BorderRadius.circular(YRadius.card), border: Border.all(color: accent.withValues(alpha: .25))),
          child: balances.when(
            data: (b) {
              final amount = widget.shielded ? b.shieldedZatoshi : b.transparentZatoshi;
              return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [Icon(widget.shielded ? Icons.shield_outlined : Icons.visibility_outlined, color: accent), const SizedBox(width: 8), Text(subtitle, style: const TextStyle(color: YColors.textSecondary))]),
                const SizedBox(height: YSpacing.md),
                Text((amount / 1e8).toStringAsFixed(8), style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w600)),
                const Text('YEC', style: TextStyle(color: YColors.textMuted)),
              ]);
            },
            loading: () => const YBusyState(label: 'Loading balance'),
            error: (_, __) => YErrorState(message: 'Could not load balance.', onRetry: () => ref.invalidate(balancesProvider)),
          ),
        ),
        const SizedBox(height: YSpacing.lg),
        SizedBox(width: double.infinity, child: ElevatedButton.icon(
          icon: Icon(widget.shielded ? Icons.visibility_outlined : Icons.shield_outlined),
          label: Text(widget.shielded ? 'Unshield funds' : 'Shield funds'),
          onPressed: () => runShieldFlow(context, ref, direction: widget.shielded ? ShieldDirection.unshield : ShieldDirection.shield),
        )),
        const SizedBox(height: YSpacing.xl),
        Text('Receiving address', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: YSpacing.sm),
        if (_error != null) YErrorState(message: 'Could not load your address.', onRetry: _loadAddress)
        else if (_address == null) const Padding(padding: EdgeInsets.all(YSpacing.xl), child: Center(child: YBusyState(label: 'Loading address')))
        else ...[
          Center(child: Container(padding: const EdgeInsets.all(YSpacing.md), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(YRadius.card)), child: QrImageView(data: _address!, size: 220))),
          const SizedBox(height: YSpacing.md),
          SelectableText(_address!, textAlign: TextAlign.center, style: const TextStyle(fontFamily: 'monospace', color: YColors.textSecondary)),
          const SizedBox(height: YSpacing.sm),
          OutlinedButton.icon(onPressed: () async { await Clipboard.setData(ClipboardData(text: _address!)); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Address copied'))); }, icon: const Icon(Icons.copy_outlined), label: const Text('Copy address')),
        ],
      ])),
    );
  }
}
