import 'package:flutter/material.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Wallet alerts')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          _Alert(
            icon: Icons.shield_outlined,
            title: 'Privacy alerts',
            subtitle: 'Shielding and privacy events will appear here.',
          ),
          _Alert(
            icon: Icons.account_balance_wallet_outlined,
            title: 'Transaction alerts',
            subtitle: 'Incoming, outgoing and confirmation updates appear here.',
          ),
          _Alert(
            icon: Icons.cloud_outlined,
            title: 'Sync alerts',
            subtitle: 'Important network or sync problems appear here.',
          ),
        ],
      ),
    );
  }
}

class _Alert extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _Alert({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        subtitle: Text(subtitle),
      ),
    );
  }
}
