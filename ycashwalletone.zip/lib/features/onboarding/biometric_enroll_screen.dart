import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/background_sync/background_sync.dart';
import '../../core/biometrics/biometric_gate.dart';
import '../../core/providers.dart';
import '../../core/settings_store/settings_store.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

/// Final onboarding security step.
///
/// There is no wallet password anymore — the seed is protected solely by
/// the device's own fingerprint/face biometric, or (if none is enrolled)
/// its screen-lock PIN/pattern/password, via a hardware-backed Android
/// Keystore key (see SeedVault). Onboarding deliberately refuses to finish
/// without a usable device authentication method rather than falling back
/// to no protection at all — a wallet with real funds shouldn't be
/// reachable by anyone who just picks up the phone.
class BiometricEnrollScreen extends ConsumerStatefulWidget {
  final VoidCallback onDone;
  final String? seedPhraseToWrap;
  const BiometricEnrollScreen({super.key, required this.onDone, this.seedPhraseToWrap});

  @override
  ConsumerState<BiometricEnrollScreen> createState() =>
      _BiometricEnrollScreenState();
}

class _BiometricEnrollScreenState extends ConsumerState<BiometricEnrollScreen> {
  bool _checkingDevice = true;
  bool _deviceAuthAvailable = false;
  bool _biometricsAvailable = false;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _checkDevice();
  }

  Future<void> _checkDevice() async {
    setState(() => _checkingDevice = true);
    final gate = ref.read(biometricGateProvider);
    final deviceAuth = await gate.canUseDeviceAuth;
    final biometrics = await gate.canUseBiometrics;
    if (!mounted) return;
    setState(() {
      _deviceAuthAvailable = deviceAuth;
      _biometricsAvailable = biometrics;
      _checkingDevice = false;
    });
  }

  Future<void> _enableAndContinue() async {
    setState(() {
      _saving = true;
      _error = null;
    });

    final gate = ref.read(biometricGateProvider);
    // biometricOnly: false -- a device with only a PIN/pattern/password
    // and no enrolled biometric is still a valid, protected setup. This is
    // the same call AppLockScreen uses to unlock every time after this.
    final auth = await gate.authenticate(GateReason.appUnlock);

    if (!auth.authenticated) {
      if (mounted) {
        setState(() {
          _saving = false;
          _error = auth.error == 'no_biometrics_use_password'
              ? 'This device has no fingerprint/face, PIN, pattern, or '
                  'password set up. Set one in your device settings, then '
                  'come back.'
              : (auth.error ?? 'Authentication failed');
        });
      }
      return;
    }

    try {
      if (widget.seedPhraseToWrap != null) {
        final vault = ref.read(seedVaultProvider);
        await vault.writeSecured(widget.seedPhraseToWrap!);
        // Restored wallets skip SeedBackupScreen (they're already backed up
        // elsewhere) and so never call this otherwise; harmless to repeat
        // for the create-new path, where it's already been set.
        await vault.markBackupConfirmed();
        // Same best-effort background-sync setup as a normal unlock (see
        // app_lock_screen.dart) -- a brand-new wallet should start out
        // syncing in the background exactly the same as one that's been
        // through a lock/unlock cycle, not need one first.
        try {
          final mode = await ref.read(backgroundSyncModeProvider.future);
          if (mode != BackgroundSyncMode.off) {
            await vault.writeBackgroundSyncCache(widget.seedPhraseToWrap!);
          }
          await BackgroundSyncScheduler.apply(mode);
        } catch (_) {}
      }
      // Refresh the shared onboarding-status provider *before* calling
      // onDone() (which navigates to '/'). Previously the app router's
      // "onboarding complete?" check was a value read once at app boot,
      // long before this screen ever ran — so navigating to '/' here just
      // bounced straight back to /onboarding via the redirect, discarding
      // this screen's progress and leaving the button stuck showing
      // "Please wait…" (since _saving was only ever reset in the catch
      // branch). Refreshing first means the redirect that fires from
      // onDone()'s navigation sees the up-to-date "done" state immediately.
      await ref.read(onboardingStatusProvider.notifier).refresh();
      // The user just authenticated a few seconds ago — the app-wide lock
      // screen (which otherwise always challenges) has nothing to add
      // here, so start this session unlocked.
      ref.read(walletLockedProvider.notifier).state = false;
      if (!mounted) return;
      // Belt-and-suspenders: if onDone() ever doesn't navigate this screen
      // away (e.g. a future caller wires it up differently), the button
      // shouldn't be left stuck on "Please wait…" indefinitely.
      setState(() => _saving = false);
      widget.onDone();
    } catch (e) {
      if (mounted) {
        YHaptics.warn();
        setState(() {
          _saving = false;
          _error = e is PasswordRecordInvalidatedException || e is StateError
              ? e.toString()
              : 'Could not secure your wallet. Please try again.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Secure your wallet')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(YSpacing.lg),
          child: _checkingDevice
              ? const Center(child: YBusyState(label: 'Checking device security'))
              : !_deviceAuthAvailable
                  ? _NoDeviceAuth(onRecheck: _checkDevice)
                  : _SecuritySetup(
                      biometricsAvailable: _biometricsAvailable,
                      saving: _saving,
                      error: _error,
                      onContinue: _enableAndContinue,
                    ),
        ),
      ),
    );
  }
}

/// Shown when the device has no fingerprint/face, PIN, pattern, or
/// password set up at all. There is nothing left for the app to fall back
/// to, so onboarding stops here rather than shipping a wallet with no
/// protection whatsoever.
class _NoDeviceAuth extends StatelessWidget {
  final VoidCallback onRecheck;
  const _NoDeviceAuth({required this.onRecheck});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: YEnter(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.lock_outline, size: 64, color: YColors.danger),
            const SizedBox(height: YSpacing.lg),
            const Text(
              'Set a screen lock to continue',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: YSpacing.sm),
            const Text(
              'This wallet is protected by your device\u2019s own fingerprint, '
              'face unlock, PIN, or pattern instead of a separate password. '
              'This device doesn\u2019t have any of those set up yet — add one '
              'in your device settings, then come back here.',
              textAlign: TextAlign.center,
              style: TextStyle(color: YColors.textSecondary),
            ),
            const SizedBox(height: YSpacing.lg),
            OutlinedButton(onPressed: onRecheck, child: const Text('Check again')),
          ],
        ),
      ),
    );
  }
}

class _SecuritySetup extends StatelessWidget {
  const _SecuritySetup({
    required this.biometricsAvailable,
    required this.saving,
    required this.error,
    required this.onContinue,
  });

  final bool biometricsAvailable;
  final bool saving;
  final String? error;
  final VoidCallback onContinue;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                YEnter(
                  child: Semantics(
                    label: biometricsAvailable
                        ? 'Use your fingerprint or other enrolled biometric to protect your wallet.'
                        : 'Use your device PIN, pattern, or password to protect your wallet.',
                    child: Icon(
                      biometricsAvailable ? Icons.fingerprint : Icons.lock_outline,
                      size: 64,
                      color: YColors.shieldedPrimary,
                    ),
                  ),
                ),
                const SizedBox(height: YSpacing.lg),
                Text(
                  biometricsAvailable
                      ? 'Your fingerprint or face unlocks the wallet and confirms '
                          "sends, shields, and viewing your recovery phrase. If it's "
                          'ever unavailable, your device PIN/pattern/password works '
                          'the same way. There\u2019s no separate wallet password to '
                          'remember — your recovery phrase is the only backup.'
                      : 'Your device PIN, pattern, or password unlocks the wallet '
                          'and confirms sends, shields, and viewing your recovery '
                          'phrase. There\u2019s no separate wallet password to '
                          'remember — your recovery phrase is the only backup.',
                  style: const TextStyle(color: YColors.textSecondary),
                ),
                if (error != null) ...[
                  const SizedBox(height: YSpacing.md),
                  Semantics(
                    liveRegion: true,
                    child: Text(error!, style: const TextStyle(color: YColors.danger)),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: YSpacing.lg),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: saving ? null : onContinue,
            child: Text(saving ? 'Please wait…' : 'Enable & continue'),
          ),
        ),
      ],
    );
  }
}
