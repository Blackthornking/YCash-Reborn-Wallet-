import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/biometrics/biometric_gate.dart';
import '../../core/providers.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

/// Final onboarding security step.
///
/// A PIN is always created as an app-level backup. When biometrics are
/// available, the user can also enable fingerprint/face authentication.
/// This avoids the previous dead-end where "Enable & continue" simply
/// advanced without actually running biometric authentication or creating a
/// PIN fallback.
class BiometricEnrollScreen extends ConsumerStatefulWidget {
  final VoidCallback onDone;
  const BiometricEnrollScreen({super.key, required this.onDone});

  @override
  ConsumerState<BiometricEnrollScreen> createState() =>
      _BiometricEnrollScreenState();
}

class _BiometricEnrollScreenState extends ConsumerState<BiometricEnrollScreen> {
  bool _checkingDevice = true;
  bool _biometricsAvailable = false;
  bool _biometricEnabled = false;
  bool _saving = false;
  final _pinController = TextEditingController();
  final _pinConfirmController = TextEditingController();
  String? _error;

  @override
  void initState() {
    super.initState();
    _checkDevice();
  }

  @override
  void dispose() {
    _pinController.dispose();
    _pinConfirmController.dispose();
    super.dispose();
  }

  Future<void> _checkDevice() async {
    final gate = ref.read(biometricGateProvider);
    final available = await gate.canUseBiometrics;
    if (!mounted) return;
    setState(() {
      _biometricsAvailable = available;
      _checkingDevice = false;
    });
  }

  Future<void> _enableBiometrics() async {
    setState(() {
      _saving = true;
      _error = null;
    });

    final gate = ref.read(biometricGateProvider);
    final auth = await gate.authenticateBiometricsOnly(
      GateReason.enableBiometrics,
    );

    if (!mounted) return;
    setState(() => _saving = false);

    if (!auth.authenticated) {
      setState(() {
        _error = 'Fingerprint authentication was not completed. You can try '
            'again or continue with PIN-only protection.';
      });
      return;
    }

    setState(() {
      _biometricEnabled = true;
      _error = null;
    });
  }

  Future<void> _continue() async {
    final pin = _pinController.text.trim();
    if (pin.length < 6 || !RegExp(r'^\d+$').hasMatch(pin)) {
      YHaptics.warn();
      setState(() => _error = 'PIN must be at least 6 digits');
      return;
    }
    if (pin != _pinConfirmController.text) {
      YHaptics.warn();
      setState(() => _error = "PINs don't match");
      return;
    }

    setState(() {
      _saving = true;
      _error = null;
    });

    try {
      final gate = ref.read(biometricGateProvider);
      await gate.setPin(pin);
      if (!mounted) return;
      widget.onDone();
    } catch (e) {
      if (mounted) {
        YHaptics.warn();
        setState(() {
          _saving = false;
          _error = e is ArgumentError
              ? e.message.toString()
              : e is PinRecordInvalidatedException
                  ? e.toString()
                  : 'Could not save your PIN. Please try again.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Secure your wallet')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(YSpacing.lg),
          child: _checkingDevice
              ? const Center(child: YBusyState(label: 'Checking device security'))
              : _SecuritySetup(
                  biometricsAvailable: _biometricsAvailable,
                  biometricEnabled: _biometricEnabled,
                  saving: _saving,
                  pinController: _pinController,
                  pinConfirmController: _pinConfirmController,
                  error: _error,
                  onEnableBiometrics: _enableBiometrics,
                  onContinue: _continue,
                ),
        ),
      ),
    );
  }
}

class _SecuritySetup extends StatelessWidget {
  const _SecuritySetup({
    required this.biometricsAvailable,
    required this.biometricEnabled,
    required this.saving,
    required this.pinController,
    required this.pinConfirmController,
    required this.error,
    required this.onEnableBiometrics,
    required this.onContinue,
  });

  final bool biometricsAvailable;
  final bool biometricEnabled;
  final bool saving;
  final TextEditingController pinController;
  final TextEditingController pinConfirmController;
  final String? error;
  final VoidCallback onEnableBiometrics;
  final VoidCallback onContinue;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        YEnter(
          child: Semantics(
            label: biometricsAvailable
                ? 'Use your fingerprint or other enrolled biometric, with an app PIN as backup.'
                : 'Protect your wallet with an app PIN.',
            child: Icon(
              biometricEnabled
                  ? Icons.verified_user_outlined
                  : biometricsAvailable
                      ? Icons.fingerprint
                      : Icons.pin_outlined,
              size: 64,
              color: YColors.shieldedPrimary,
            ),
          ),
        ),
        const SizedBox(height: YSpacing.lg),
        Text(
          biometricsAvailable
              ? "Use your fingerprint to confirm sensitive actions. Your app PIN is always available as a backup."
              : 'Set an app PIN to confirm sends, shields, unshields, and viewing your recovery phrase.',
          style: const TextStyle(color: YColors.textSecondary),
        ),
        if (biometricsAvailable) ...[
          const SizedBox(height: YSpacing.md),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: saving || biometricEnabled ? null : onEnableBiometrics,
              icon: Icon(biometricEnabled ? Icons.check : Icons.fingerprint),
              label: Text(
                biometricEnabled ? 'Fingerprint enabled' : 'Enable fingerprint',
              ),
            ),
          ),
        ],
        const SizedBox(height: YSpacing.lg),
        TextField(
          controller: pinController,
          obscureText: true,
          keyboardType: TextInputType.number,
          maxLength: 12,
          decoration: const InputDecoration(
            labelText: 'Create backup PIN',
            hintText: 'At least 6 digits',
          ),
        ),
        const SizedBox(height: YSpacing.sm),
        TextField(
          controller: pinConfirmController,
          obscureText: true,
          keyboardType: TextInputType.number,
          maxLength: 12,
          decoration: const InputDecoration(labelText: 'Confirm backup PIN'),
        ),
        if (error != null) ...[
          const SizedBox(height: YSpacing.sm),
          Semantics(
            liveRegion: true,
            child: Text(error!, style: const TextStyle(color: YColors.danger)),
          ),
        ],
        const Spacer(),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: saving ? null : onContinue,
            child: Text(saving ? 'Please wait…' : 'Continue'),
          ),
        ),
      ],
    );
  }
}
