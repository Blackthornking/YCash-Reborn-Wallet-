import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/background_sync/background_sync.dart';
import '../../core/biometrics/biometric_gate.dart';
import '../../core/providers.dart';
import '../../core/settings_store/settings_store.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

/// Final onboarding security step.
///
/// A wallet password is required and is used to cryptographically wrap the seed. When biometrics are
/// available, the user can also enable fingerprint/face authentication.
/// This avoids the previous dead-end where "Enable & continue" simply
/// advanced without actually running biometric authentication or creating a
/// password fallback.
class BiometricEnrollScreen extends ConsumerStatefulWidget {
  final VoidCallback onDone;
  final String? seedPhraseToWrap;
  const BiometricEnrollScreen({super.key, required this.onDone, this.seedPhraseToWrap});

  @override
  ConsumerState<BiometricEnrollScreen> createState() =>
      _BiometricEnrollScreenState();
}

class _BiometricEnrollScreenState extends ConsumerState<BiometricEnrollScreen> {
  bool _checkingDevice = true;
  bool _biometricsAvailable = false;
  bool _biometricEnabled = false;
  bool _saving = false;
  final _pinController = TextEditingController();
  final _pinConfirmController = TextEditingController();
  String? _error;

  @override
  void initState() {
    super.initState();
    _checkDevice();
  }

  @override
  void dispose() {
    _pinController.dispose();
    _pinConfirmController.dispose();
    super.dispose();
  }

  Future<void> _checkDevice() async {
    final gate = ref.read(biometricGateProvider);
    final available = await gate.canUseBiometrics;
    if (!mounted) return;
    setState(() {
      _biometricsAvailable = available;
      _checkingDevice = false;
    });
  }

  Future<void> _enableBiometrics() async {
    setState(() {
      _saving = true;
      _error = null;
    });

    final gate = ref.read(biometricGateProvider);
    final auth = await gate.authenticateBiometricsOnly(
      GateReason.enableBiometrics,
    );

    if (!mounted) return;
    setState(() => _saving = false);

    if (!auth.authenticated) {
      setState(() {
        _error = 'Fingerprint authentication was not completed. You can try '
            'again or continue with device credential protection.';
      });
      return;
    }

    setState(() {
      _biometricEnabled = true;
      _error = null;
    });
  }

  Future<void> _continue() async {
    final password = _pinController.text;
    final policyError = BiometricGate.passwordPolicyError(password);
    if (policyError != null) {
      YHaptics.warn();
      setState(() => _error = policyError);
      return;
    }
    if (password != _pinConfirmController.text) {
      YHaptics.warn();
      setState(() => _error = "Passwords don't match");
      return;
    }

    setState(() {
      _saving = true;
      _error = null;
    });

    try {
      final gate = ref.read(biometricGateProvider);
      await gate.setPassword(password);
      if (widget.seedPhraseToWrap != null) {
        final vault = ref.read(seedVaultProvider);
        await vault.writeWrapped(widget.seedPhraseToWrap!, password);
        // Restored wallets skip SeedBackupScreen (they're already backed up
        // elsewhere) and so never call this otherwise; harmless to repeat
        // for the create-new path, where it's already been set.
        await vault.markBackupConfirmed();
        // Same best-effort background-sync setup as a normal unlock (see
        // app_lock_screen.dart) -- a brand-new wallet should start out
        // syncing in the background exactly the same as one that's been
        // through a lock/unlock cycle, not need one first.
        try {
          final mode = await ref.read(backgroundSyncModeProvider.future);
          if (mode != BackgroundSyncMode.off) {
            await vault.writeBackgroundSyncCache(widget.seedPhraseToWrap!);
          }
          await BackgroundSyncScheduler.apply(mode);
        } catch (_) {}
      }
      // Refresh the shared onboarding-status provider *before* calling
      // onDone() (which navigates to '/'). Previously the app router's
      // "onboarding complete?" check was a value read once at app boot,
      // long before this screen ever ran — so navigating to '/' here just
      // bounced straight back to /onboarding via the redirect, discarding
      // this screen's progress and leaving the button stuck showing
      // "Please wait…" (since _saving was only ever reset in the catch
      // branch). Refreshing first means the redirect that fires from
      // onDone()'s navigation sees the up-to-date "done" state immediately.
      await ref.read(onboardingStatusProvider.notifier).refresh();
      // The user just set this password a few seconds ago — the app-wide
      // lock screen (which otherwise always challenges for it) has
      // nothing to add here, so start this session unlocked.
      ref.read(walletLockedProvider.notifier).state = false;
      if (!mounted) return;
      // Belt-and-suspenders: if onDone() ever doesn't navigate this screen
      // away (e.g. a future caller wires it up differently), the button
      // shouldn't be left stuck on "Please wait…" indefinitely.
      setState(() => _saving = false);
      widget.onDone();
    } catch (e) {
      if (mounted) {
        YHaptics.warn();
        setState(() {
          _saving = false;
          _error = e is ArgumentError
              ? e.message.toString()
              : e is PasswordRecordInvalidatedException
                  ? e.toString()
                  : e is StateError
                      ? e.message
                      : 'Could not save your password. Please try again.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Secure your wallet')),
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => FocusScope.of(context).unfocus(),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(YSpacing.lg),
            child: _checkingDevice
                ? const Center(child: YBusyState(label: 'Checking device security'))
                : _SecuritySetup(
                    biometricsAvailable: _biometricsAvailable,
                    biometricEnabled: _biometricEnabled,
                    saving: _saving,
                    pinController: _pinController,
                    pinConfirmController: _pinConfirmController,
                    error: _error,
                    onEnableBiometrics: _enableBiometrics,
                    onContinue: _continue,
                  ),
          ),
        ),
      ),
    );
  }
}

class _SecuritySetup extends StatelessWidget {
  const _SecuritySetup({
    required this.biometricsAvailable,
    required this.biometricEnabled,
    required this.saving,
    required this.pinController,
    required this.pinConfirmController,
    required this.error,
    required this.onEnableBiometrics,
    required this.onContinue,
  });

  final bool biometricsAvailable;
  final bool biometricEnabled;
  final bool saving;
  final TextEditingController pinController;
  final TextEditingController pinConfirmController;
  final String? error;
  final VoidCallback onEnableBiometrics;
  final VoidCallback onContinue;

  @override
  Widget build(BuildContext context) {
    // Previously a single Column relying on Spacer() to push the button to
    // the bottom — with no scroll view around it. Spacer() needs the
    // Column's height to be bounded by the screen, so once the on-screen
    // keyboard opened for either password field (or the policy text below
    // made the content a bit taller), the content could exceed the
    // available height and the Continue button would get pushed past the
    // bottom edge or clipped — reachable by neither tap nor scroll, since
    // there was nothing to scroll. Splitting the form into a scrollable
    // region with the button pinned below it (not inside the Spacer'd
    // Column) fixes both: the button is always on-screen, and if the form
    // itself is ever taller than the viewport, it scrolls instead of
    // overflowing.
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                YEnter(
                  child: Semantics(
                    label: biometricsAvailable
                        ? 'Use your fingerprint or other enrolled biometric, with a wallet password as backup.'
                        : 'Protect your wallet with a password.',
                    child: Icon(
                      biometricEnabled
                          ? Icons.verified_user_outlined
                          : biometricsAvailable
                              ? Icons.fingerprint
                              : Icons.lock_outline,
                      size: 64,
                      color: YColors.shieldedPrimary,
                    ),
                  ),
                ),
                const SizedBox(height: YSpacing.lg),
                Text(
                  biometricsAvailable
                      ? "Use your fingerprint to confirm sensitive actions. If it's ever unavailable, your device PIN/pattern/password unlocks the app, and your wallet password below is what actually protects your recovery phrase."
                      : 'Set a wallet password to confirm sends, shields, unshields, and viewing your recovery phrase. This password also encrypts your recovery phrase, so keep it somewhere safe — it cannot be recovered if you forget it.',
                  style: const TextStyle(color: YColors.textSecondary),
                ),
                if (biometricsAvailable) ...[
                  const SizedBox(height: YSpacing.md),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: saving || biometricEnabled ? null : onEnableBiometrics,
                      icon: Icon(biometricEnabled ? Icons.check : Icons.fingerprint),
                      label: Text(
                        biometricEnabled ? 'Fingerprint enabled' : 'Enable fingerprint',
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: YSpacing.lg),
                TextField(
                  controller: pinController,
                  obscureText: true,
                  keyboardType: TextInputType.visiblePassword,
                  decoration: const InputDecoration(
                    labelText: 'Create wallet password',
                    hintText: '8+ characters',
                  ),
                ),
                const SizedBox(height: YSpacing.sm),
                TextField(
                  controller: pinConfirmController,
                  obscureText: true,
                  keyboardType: TextInputType.visiblePassword,
                  decoration: const InputDecoration(labelText: 'Confirm wallet password'),
                  onSubmitted: (_) {
                    if (!saving) onContinue();
                  },
                ),
                const SizedBox(height: YSpacing.sm),
                // Explicit, always-visible statement of the password policy —
                // shown before the user submits, not just as an error afterward.
                Text(
                  BiometricGate.passwordPolicyDescription,
                  style: const TextStyle(color: YColors.textSecondary, fontSize: 12),
                ),
                if (error != null) ...[
                  const SizedBox(height: YSpacing.sm),
                  Semantics(
                    liveRegion: true,
                    child: Text(error!, style: const TextStyle(color: YColors.danger)),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: YSpacing.lg),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: saving ? null : onContinue,
            child: Text(saving ? 'Please wait…' : 'Continue'),
          ),
        ),
      ],
    );
  }
}
