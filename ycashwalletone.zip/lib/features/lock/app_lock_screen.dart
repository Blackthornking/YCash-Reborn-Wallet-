import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/background_sync/background_sync.dart';
import '../../core/biometrics/biometric_gate.dart';
import '../../core/providers.dart';
import '../../core/settings_store/settings_store.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

/// Full-screen gate shown over the rest of the app whenever
/// [walletLockedProvider] is true (see app.dart, which arms it based on
/// the auto-lock timeout).
///
/// Unlocks with the device's own biometric (fingerprint/face) or, if none
/// is enrolled, its screen-lock PIN/pattern/password -- there is no
/// separate wallet password anymore. The OS prompt fires automatically as
/// soon as this screen appears (same as zodl's own app-access lock); the
/// button below is only for retrying after a dismiss or failure.
///
/// The native engine's wallet session lives entirely in this process and
/// is never reopened automatically — [YcashCoreFfiEngine.openOrCreateWallet]
/// is only ever called during onboarding (create or restore). On every
/// fresh app process that starts already-onboarded (the normal case after
/// an auto-lock or app relaunch), this screen is therefore the one place
/// that re-derives the seed from [SeedVault] and reopens the native
/// session before letting the rest of the app back in.
class AppLockScreen extends ConsumerStatefulWidget {
  const AppLockScreen({super.key});

  @override
  ConsumerState<AppLockScreen> createState() => _AppLockScreenState();
}

class _AppLockScreenState extends ConsumerState<AppLockScreen> {
  bool _authenticating = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _unlock());
  }

  Future<void> _unlock() async {
    if (_authenticating) return;
    setState(() {
      _authenticating = true;
      _error = null;
    });

    final gate = ref.read(biometricGateProvider);
    final vault = ref.read(seedVaultProvider);

    try {
      final auth = await gate.authenticate(GateReason.appUnlock);
      if (!auth.authenticated) {
        YHaptics.warn();
        if (mounted) {
          setState(() {
            _authenticating = false;
            _error = auth.error == 'no_biometrics_use_password'
                ? 'Set a screen lock (fingerprint, face, PIN, or pattern) '
                    'on this device to open the wallet.'
                : (auth.error ?? 'Authentication failed');
          });
        }
        return;
      }

      // One-time migration path for installs from before biometrics-only
      // unlock: their seed is still behind the old password envelope. See
      // SeedVault's class doc -- decrypt it once with the password, move
      // it into the new Keystore-only record, and delete the old one.
      // Every unlock after this is password-free.
      final String seed;
      if (await vault.hasSecuredSeed) {
        seed = await vault.readSecured(auth);
      } else if (await vault.hasLegacyPasswordSeed) {
        if (!mounted) return;
        final password = await _promptLegacyPassword();
        if (password == null) {
          setState(() => _authenticating = false);
          return;
        }
        seed = await vault.readWithPassword(auth, password);
        await vault.writeSecured(seed);
        await vault.clearLegacyPasswordSeed();
      } else {
        throw StateError('No wallet found on this device');
      }

      try {
        final engine = ref.read(engineProvider);
        await engine.openOrCreateWallet(restoreSeedPhrase: seed);
      } catch (e) {
        YHaptics.warn();
        if (mounted) {
          setState(() {
            _authenticating = false;
            _error = 'Authenticated, but the wallet could not be reopened: $e';
          });
        }
        return;
      }

      // Best-effort background-sync refresh, same as onboarding completion
      // (see biometric_enroll_screen.dart) -- not allowed to fail the
      // unlock itself.
      try {
        final mode = await ref.read(backgroundSyncModeProvider.future);
        if (mode != BackgroundSyncMode.off) {
          await vault.writeBackgroundSyncCache(seed);
        }
        await BackgroundSyncScheduler.apply(mode);
      } catch (_) {}

      if (!mounted) return;
      setState(() => _authenticating = false);
      ref.read(walletLockedProvider.notifier).state = false;
    } catch (e) {
      YHaptics.warn();
      if (mounted) {
        setState(() {
          _authenticating = false;
          _error = (e is PasswordLockedOutException ||
                  e is PasswordRecordInvalidatedException ||
                  e is StateError)
              ? e.toString()
              : 'Could not unlock the wallet. Please try again.';
        });
      }
    }
  }

  Future<String?> _promptLegacyPassword() async {
    final controller = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('One-time password check'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "Your wallet was set up before biometrics-only unlock. Enter "
              "your old password once to switch over — you won't need it "
              'again after this.',
            ),
            const SizedBox(height: YSpacing.md),
            TextField(
              controller: controller,
              obscureText: true,
              keyboardType: TextInputType.visiblePassword,
              autofocus: true,
              onSubmitted: (v) => Navigator.of(ctx).pop(v),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(controller.text),
            child: const Text('Confirm'),
          ),
        ],
      ),
    );
    controller.dispose();
    return result;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(YSpacing.lg),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.fingerprint,
                    size: 64, color: YColors.textSecondary),
                const SizedBox(height: YSpacing.lg),
                if (_error != null) ...[
                  Semantics(
                    liveRegion: true,
                    child: Text(
                      _error!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: YColors.danger),
                    ),
                  ),
                  const SizedBox(height: YSpacing.lg),
                  FilledButton(onPressed: _unlock, child: const Text('Try again')),
                ] else if (_authenticating) ...[
                  const YBusyState(label: 'Waiting for authentication…'),
                ] else ...[
                  FilledButton(onPressed: _unlock, child: const Text('Unlock')),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
