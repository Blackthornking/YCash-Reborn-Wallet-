import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/providers.dart';
import '../../app/router.dart';
import '../../core/biometrics/biometric_gate.dart';
import '../../core/models/ycash_config.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';
import 'seed_reveal_screen.dart';
import 'server_settings_screen.dart';
import 'currency_settings_screen.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: SafeArea(
        child: ListView(
          children: [
            const _SectionHeader('Security'),
            // MergeSemantics: previously the leading icon, title, and
            // chevron were separate nodes a screen reader stepped through
            // one at a time for what is a single tappable row.
            MergeSemantics(
              child: ListTile(
                leading: const Icon(Icons.key_outlined),
                title: const Text('View recovery phrase'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const SeedRevealScreen()),
                ),
              ),
            ),
            MergeSemantics(
              child: ListTile(
                leading: const Icon(Icons.pin_outlined),
                title: const Text('Change password'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _changePassword(context, ref),
              ),
            ),
            MergeSemantics(child: Consumer(builder:(context,ref,_){final hidden=ref.watch(hideBalanceProvider).valueOrNull??false;return SwitchListTile(secondary:const Icon(Icons.visibility_off_outlined),title:const Text('Hide balances'),subtitle:const Text('Hide wallet amounts when opening the app in public'),value:hidden,onChanged:(v)=>ref.read(hideBalanceProvider.notifier).setHidden(v));})),
            const Divider(),
            const _SectionHeader('Display'),
            Consumer(builder: (context, ref, _) {
              final currency = ref.watch(localCurrencyProvider);
              return MergeSemantics(
                child: ListTile(
                  leading: const Icon(Icons.currency_exchange_outlined),
                  title: const Text('Local currency'),
                  subtitle: Text(currency.value?.name ?? 'Loading…'),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    Text(currency.value?.code ?? 'USD', style: const TextStyle(color: YColors.textSecondary, fontWeight: FontWeight.w700)),
                    const SizedBox(width: 6),
                    const Icon(Icons.chevron_right),
                  ]),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CurrencySettingsScreen())),
                ),
              );
            }),
            MergeSemantics(
              child: Consumer(builder: (context, ref, _) {
                final mode = ref.watch(themeModeProvider).valueOrNull ?? ThemeMode.dark;
                return ListTile(
                  leading: Icon(mode == ThemeMode.light ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
                  title: const Text('Appearance'),
                  subtitle: Text(mode == ThemeMode.light ? 'Light mode' : mode == ThemeMode.system ? 'Follow device' : 'Dark mode'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _chooseTheme(context, ref, mode),
                );
              }),
            ),
            MergeSemantics(
              child: Consumer(builder: (context, ref, _) {
                final enabled = ref.watch(autoShieldProvider).valueOrNull ?? false;
                return SwitchListTile(
                  secondary: const Icon(Icons.auto_awesome_outlined),
                  title: const Text('Automatic shielding'),
                  subtitle: const Text('Keep the wallet ready to shield transparent funds from the dashboard'),
                  value: enabled,
                  onChanged: (v) => ref.read(autoShieldProvider.notifier).setEnabled(v),
                );
              }),
            ),
            Consumer(builder:(context,ref,_){final min=ref.watch(autoShieldMinimumProvider).valueOrNull??0;return ListTile(leading:const Icon(Icons.savings_outlined),title:const Text('Auto-shield minimum'),subtitle:Text(min<=0?'Shield any available amount':'Only amounts above $min YEC'),trailing:const Icon(Icons.chevron_right),onTap:()=>_setAutoShieldMinimum(context,ref,min));}),
            const Divider(),
            const _SectionHeader('Wallet'),
            ListTile(leading:const Icon(Icons.contacts_outlined),title:const Text('Contacts & address book'),subtitle:const Text('Save trusted shielded and transparent addresses'),trailing:const Icon(Icons.chevron_right),onTap:()=>context.pushContacts()),
            ListTile(leading:const Icon(Icons.notifications_none),title:const Text('Wallet alerts'),subtitle:const Text('Privacy, transaction and sync updates'),trailing:const Icon(Icons.chevron_right),onTap:()=>context.pushAlerts()),
            const Divider(),
            const _SectionHeader('Network'),
            MergeSemantics(
              child: ListTile(
                leading: const Icon(Icons.dns_outlined),
                title: const Text('Sync server'),
                trailing: const Icon(Icons.chevron_right),
                onTap: context.pushNetwork,
              ),
            ),
            MergeSemantics(child: ListTile(leading: const Icon(Icons.dns_outlined), title: const Text('Advanced sync server'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ServerSettingsScreen())))),
            const Divider(),
            const _SectionHeader('About'),
            const _AboutTile(),
            MergeSemantics(
              child: ListTile(
                leading: const Icon(Icons.link),
                title: const Text('Block explorer'),
                trailing: const Icon(Icons.open_in_new),
                onTap: () => launchUrl(
                  Uri.parse(YcashConfig.blockExplorers.first),
                  mode: LaunchMode.externalApplication,
                ),
              ),
            ),
            const Divider(),
            const _SectionHeader('Danger zone'),
            MergeSemantics(
              child: ListTile(
                leading: const Icon(Icons.delete_forever, color: YColors.danger),
                title: const Text('Wipe wallet', style: TextStyle(color: YColors.danger)),
                subtitle: const Text('Removes all local data on this device'),
                onTap: () => _wipeWallet(context, ref),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _chooseTheme(BuildContext context, WidgetRef ref, ThemeMode current) async {
    final mode = await showModalBottomSheet<ThemeMode>(
      context: context,
      builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const ListTile(title: Text('Appearance', style: TextStyle(fontWeight: FontWeight.w800))),
        RadioListTile(value: ThemeMode.dark, groupValue: current, onChanged: (v) => Navigator.of(ctx).pop(v), title: const Text('Dark mode')),
        RadioListTile(value: ThemeMode.light, groupValue: current, onChanged: (v) => Navigator.of(ctx).pop(v), title: const Text('Light mode')),
        RadioListTile(value: ThemeMode.system, groupValue: current, onChanged: (v) => Navigator.of(ctx).pop(v), title: const Text('Follow device')),
      ])),
    );
    if (mode != null) await ref.read(themeModeProvider.notifier).setMode(mode);
  }


  Future<void> _setAutoShieldMinimum(BuildContext context, WidgetRef ref, double current) async {
    final controller=TextEditingController(text:current.toStringAsFixed(current==0?0:2));
    final value=await showDialog<double>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Auto-shield minimum'),content:TextField(controller:controller,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Minimum YEC',helperText:'Use 0 to allow any amount')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:(){final v=double.tryParse(controller.text.trim());if(v!=null&&v>=0)Navigator.pop(ctx,v);},child:const Text('Save'))]));
    if(value!=null) await ref.read(autoShieldMinimumProvider.notifier).setMinimum(value);
  }

  Future<void> _changePassword(BuildContext context, WidgetRef ref) async {
    final gate = ref.read(biometricGateProvider);
    final auth = await gate.authenticate(GateReason.changeSecuritySettings);
    if (!auth.authenticated) {
      YHaptics.warn();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(auth.error ?? 'Authentication required')));
      }
      return;
    }
    if (!context.mounted) return;

    final newPin = await showDialog<String>(
      context: context,
      builder: (ctx) => const _ChangePasswordDialog(),
    );
    if (newPin == null) return;

    try {
      await gate.setPassword(newPin);
      if (context.mounted) {
        YHaptics.acknowledge();
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Password updated')));
      }
    } catch (e) {
      YHaptics.warn();
      if (context.mounted) {
        final message = e is PasswordRecordInvalidatedException || e is StateError
            ? e.toString()
            : 'Could not update password';
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(message)));
      }
    }
  }

  Future<void> _wipeWallet(BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Wipe this wallet?'),
        content: const Text(
          "This deletes your wallet from this device. Make sure you've "
          "backed up your recovery phrase — it's the only way to get your "
          'funds back.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Wipe', style: TextStyle(color: YColors.danger)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    final gate = ref.read(biometricGateProvider);
    final auth = await gate.authenticate(GateReason.wipeWallet);
    if (!auth.authenticated) {
      YHaptics.warn();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(auth.error ?? 'Authentication required')));
      }
      return;
    }

    // Previously an unhandled exception here (e.g. secure storage
    // failing to delete) would surface as a silent no-op or a crash,
    // leaving the user unsure whether their wallet was actually wiped.
    try {
      await ref.read(seedVaultProvider).wipe();
      await ref.read(engineProvider).wipeWallet();
      if (context.mounted) {
        Navigator.of(context).popUntil((route) => route.isFirst);
      }
    } catch (e) {
      YHaptics.warn();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Could not fully wipe the wallet. Please try again.')));
      }
    }
  }
}

/// Change-password dialog with its own local validation state.
///
/// Previously "Save" popped the raw text immediately; a too-short password
/// silently did nothing back on the settings screen with no explanation,
/// and there was no confirmation field, so a typo could lock someone out
/// of a wallet-protecting password without them knowing until next unlock.
class _ChangePasswordDialog extends StatefulWidget {
  const _ChangePasswordDialog();

  @override
  State<_ChangePasswordDialog> createState() => _ChangePasswordDialogState();
}

class _ChangePasswordDialogState extends State<_ChangePasswordDialog> {
  final _pinController = TextEditingController();
  final _confirmController = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _pinController.dispose();
    _confirmController.dispose();
    super.dispose();
  }

  void _submit() {
    final pin = _pinController.text;
    final confirm = _confirmController.text;
    if (pin.length < 6 || !RegExp(r'^\d+$').hasMatch(pin)) {
      setState(() => _error = 'password must be at least 6 digits');
      return;
    }
    if (pin != confirm) {
      setState(() => _error = "passwords don't match");
      return;
    }
    Navigator.of(context).pop(pin);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Set a new password'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          TextField(
            controller: _pinController,
            obscureText: true,
            keyboardType: TextInputType.number,
            autofocus: true,
            decoration: const InputDecoration(labelText: 'New password'),
          ),
          const SizedBox(height: YSpacing.sm),
          TextField(
            controller: _confirmController,
            obscureText: true,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Confirm password'),
            onSubmitted: (_) => _submit(),
          ),
          if (_error != null) ...[
            const SizedBox(height: YSpacing.sm),
            Semantics(
              liveRegion: true,
              child: Text(_error!,
                  style: const TextStyle(color: YColors.danger, fontSize: 12)),
            ),
          ],
        ],
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel')),
        TextButton(onPressed: _submit, child: const Text('Save')),
      ],
    );
  }
}

class _AboutTile extends StatelessWidget {
  const _AboutTile();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<PackageInfo>(
      future: PackageInfo.fromPlatform(),
      builder: (context, snapshot) {
        final version = snapshot.data?.version ?? '—';
        return MergeSemantics(
          child: ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('Version'),
            trailing: Text(version, style: const TextStyle(color: YColors.textSecondary)),
          ),
        );
      },
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);

  @override
  Widget build(BuildContext context) {
    return Semantics(
      header: true,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(YSpacing.lg, YSpacing.lg, YSpacing.lg, YSpacing.sm),
        child: Text(
          title.toUpperCase(),
          style: const TextStyle(
            color: YColors.textMuted,
            fontSize: 12,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.8,
          ),
        ),
      ),
    );
  }
}
