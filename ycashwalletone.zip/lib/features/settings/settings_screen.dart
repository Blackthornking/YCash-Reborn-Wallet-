import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/providers.dart';
import '../../app/router.dart';
import '../../core/background_sync/background_sync.dart';
import '../../core/biometrics/biometric_gate.dart';
import '../../core/models/ycash_config.dart';
import '../../core/settings_store/settings_store.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';
import 'seed_reveal_screen.dart';
import 'server_settings_screen.dart';
import 'currency_settings_screen.dart';
import 'rescan_screen.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: SafeArea(
        child: ListView(
          children: [
            const _SectionHeader('Security'),
            // MergeSemantics: previously the leading icon, title, and
            // chevron were separate nodes a screen reader stepped through
            // one at a time for what is a single tappable row.
            MergeSemantics(
              child: ListTile(
                leading: const Icon(Icons.key_outlined),
                title: const Text('View recovery phrase'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const SeedRevealScreen()),
                ),
              ),
            ),
            MergeSemantics(child: Consumer(builder:(context,ref,_){final hidden=ref.watch(hideBalanceProvider).valueOrNull??false;return SwitchListTile(secondary:const Icon(Icons.visibility_off_outlined),title:const Text('Hide balances'),subtitle:const Text('Hide wallet amounts when opening the app in public'),value:hidden,onChanged:(v)=>ref.read(hideBalanceProvider.notifier).setHidden(v));})),
            Consumer(builder: (context, ref, _) {
              final seconds = ref.watch(autoLockSecondsProvider).valueOrNull ?? 15;
              final subtitle = seconds == 0
                  ? 'Ask you to authenticate as soon as the app goes to the background'
                  : 'Ask you to authenticate after ${_autoLockLabel(seconds)} in the background';
              return MergeSemantics(
                child: ListTile(
                  leading: const Icon(Icons.timer_outlined),
                  title: const Text('Auto-lock'),
                  subtitle: Text(subtitle),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _chooseAutoLock(context, ref, seconds),
                ),
              );
            }),
            const Divider(),
            const _SectionHeader('Display'),
            Consumer(builder: (context, ref, _) {
              final currency = ref.watch(localCurrencyProvider);
              return MergeSemantics(
                child: ListTile(
                  leading: const Icon(Icons.currency_exchange_outlined),
                  title: const Text('Local currency'),
                  subtitle: Text(currency.value?.name ?? 'Loading…'),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    Text(currency.value?.code ?? 'USD', style: const TextStyle(color: YColors.textSecondary, fontWeight: FontWeight.w700)),
                    const SizedBox(width: 6),
                    const Icon(Icons.chevron_right),
                  ]),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CurrencySettingsScreen())),
                ),
              );
            }),
            MergeSemantics(
              child: Consumer(builder: (context, ref, _) {
                final mode = ref.watch(themeModeProvider).valueOrNull ?? ThemeMode.dark;
                return ListTile(
                  leading: Icon(mode == ThemeMode.light ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
                  title: const Text('Appearance'),
                  subtitle: Text(mode == ThemeMode.light ? 'Light mode' : mode == ThemeMode.system ? 'Follow device' : 'Dark mode'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _chooseTheme(context, ref, mode),
                );
              }),
            ),
            MergeSemantics(
              child: Consumer(builder: (context, ref, _) {
                final enabled = ref.watch(autoShieldProvider).valueOrNull ?? false;
                return SwitchListTile(
                  secondary: const Icon(Icons.auto_awesome_outlined),
                  title: const Text('Automatic shielding'),
                  subtitle: const Text('Keep the wallet ready to shield transparent funds from the dashboard'),
                  value: enabled,
                  onChanged: (v) => ref.read(autoShieldProvider.notifier).setEnabled(v),
                );
              }),
            ),
            Consumer(builder:(context,ref,_){final min=ref.watch(autoShieldMinimumProvider).valueOrNull??0;return ListTile(leading:const Icon(Icons.savings_outlined),title:const Text('Auto-shield minimum'),subtitle:Text(min<=0?'Shield any available amount':'Only amounts above $min YEC'),trailing:const Icon(Icons.chevron_right),onTap:()=>_setAutoShieldMinimum(context,ref,min));}),
            const Divider(),
            const _SectionHeader('Wallet'),
            ListTile(leading:const Icon(Icons.contacts_outlined),title:const Text('Contacts & address book'),subtitle:const Text('Save trusted shielded and transparent addresses'),trailing:const Icon(Icons.chevron_right),onTap:()=>context.pushContacts()),
            ListTile(leading:const Icon(Icons.notifications_none),title:const Text('Wallet alerts'),subtitle:const Text('Privacy, transaction and sync updates'),trailing:const Icon(Icons.chevron_right),onTap:()=>context.pushAlerts()),
            MergeSemantics(
              child: ListTile(
                leading: const Icon(Icons.history_outlined),
                title: const Text('Rescan wallet'),
                subtitle: const Text('Restore your balance faster after a wipe or reinstall'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const RescanScreen())),
              ),
            ),
            const Divider(),
            const _SectionHeader('Network'),
            MergeSemantics(
              child: ListTile(
                leading: const Icon(Icons.dns_outlined),
                title: const Text('Sync server'),
                trailing: const Icon(Icons.chevron_right),
                onTap: context.pushNetwork,
              ),
            ),
            MergeSemantics(child: ListTile(leading: const Icon(Icons.dns_outlined), title: const Text('Advanced sync server'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ServerSettingsScreen())))),
            Consumer(builder: (context, ref, _) {
              final mode = ref.watch(backgroundSyncModeProvider).valueOrNull ?? BackgroundSyncMode.always;
              return MergeSemantics(
                child: ListTile(
                  leading: const Icon(Icons.sync_outlined),
                  title: const Text('Background sync'),
                  subtitle: Text(_backgroundSyncLabel(mode)),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _chooseBackgroundSync(context, ref, mode),
                ),
              );
            }),
            const Divider(),
            const _SectionHeader('About'),
            const _AboutTile(),
            MergeSemantics(
              child: ListTile(
                leading: const Icon(Icons.link),
                title: const Text('Block explorer'),
                trailing: const Icon(Icons.open_in_new),
                onTap: () => launchUrl(
                  Uri.parse(YcashConfig.blockExplorerUrl),
                  mode: LaunchMode.externalApplication,
                ),
              ),
            ),
            const Divider(),
            const _SectionHeader('Danger zone'),
            MergeSemantics(
              child: ListTile(
                leading: const Icon(Icons.delete_forever, color: YColors.danger),
                title: const Text('Wipe wallet', style: TextStyle(color: YColors.danger)),
                subtitle: const Text('Removes all local data on this device'),
                onTap: () => _wipeWallet(context, ref),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _chooseTheme(BuildContext context, WidgetRef ref, ThemeMode current) async {
    final mode = await showModalBottomSheet<ThemeMode>(
      context: context,
      builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const ListTile(title: Text('Appearance', style: TextStyle(fontWeight: FontWeight.w800))),
        RadioListTile(value: ThemeMode.dark, groupValue: current, onChanged: (v) => Navigator.of(ctx).pop(v), title: const Text('Dark mode')),
        RadioListTile(value: ThemeMode.light, groupValue: current, onChanged: (v) => Navigator.of(ctx).pop(v), title: const Text('Light mode')),
        RadioListTile(value: ThemeMode.system, groupValue: current, onChanged: (v) => Navigator.of(ctx).pop(v), title: const Text('Follow device')),
      ])),
    );
    if (mode != null) await ref.read(themeModeProvider.notifier).setMode(mode);
  }


  Future<void> _setAutoShieldMinimum(BuildContext context, WidgetRef ref, double current) async {
    final controller=TextEditingController(text:current.toStringAsFixed(current==0?0:2));
    final value=await showDialog<double>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Auto-shield minimum'),content:TextField(controller:controller,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Minimum YEC',helperText:'Use 0 to allow any amount')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:(){final v=double.tryParse(controller.text.trim());if(v!=null&&v>=0)Navigator.pop(ctx,v);},child:const Text('Save'))]));
    if(value!=null) await ref.read(autoShieldMinimumProvider.notifier).setMinimum(value);
  }

  Future<void> _chooseAutoLock(BuildContext context, WidgetRef ref, int current) async {
    final seconds = await showModalBottomSheet<int>(
      context: context,
      builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const ListTile(title: Text('Auto-lock', style: TextStyle(fontWeight: FontWeight.w800))),
        for (final option in autoLockSecondsOptions)
          RadioListTile(
            value: option,
            groupValue: current,
            onChanged: (v) => Navigator.of(ctx).pop(v),
            title: Text(_autoLockLabel(option)),
          ),
      ])),
    );
    if (seconds != null) await ref.read(autoLockSecondsProvider.notifier).setSeconds(seconds);
  }

  String _backgroundSyncLabel(BackgroundSyncMode mode) {
    switch (mode) {
      case BackgroundSyncMode.always:
        return 'On \u2014 continuous while the app is closed, on any connection';
      case BackgroundSyncMode.wifiOnly:
        return 'Wi-Fi only \u2014 continuous while the app is closed, but only syncs on Wi-Fi';
      case BackgroundSyncMode.off:
        return 'Off \u2014 only syncs while the app is open';
    }
  }

  Future<void> _chooseBackgroundSync(BuildContext context, WidgetRef ref, BackgroundSyncMode current) async {
    final mode = await showModalBottomSheet<BackgroundSyncMode>(
      context: context,
      builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const ListTile(title: Text('Background sync', style: TextStyle(fontWeight: FontWeight.w800))),
        RadioListTile(
          value: BackgroundSyncMode.always,
          groupValue: current,
          onChanged: (v) => Navigator.of(ctx).pop(v),
          title: const Text('On'),
          subtitle: const Text('Continuous, any connection'),
        ),
        RadioListTile(
          value: BackgroundSyncMode.wifiOnly,
          groupValue: current,
          onChanged: (v) => Navigator.of(ctx).pop(v),
          title: const Text('Wi-Fi only'),
          subtitle: const Text('Continuous, only syncs on Wi-Fi'),
        ),
        RadioListTile(
          value: BackgroundSyncMode.off,
          groupValue: current,
          onChanged: (v) => Navigator.of(ctx).pop(v),
          title: const Text('Off'),
        ),
      ])),
    );
    if (mode == null) return;
    if (mode != BackgroundSyncMode.off) {
      // Explain-then-request, in case the first-install prompt was
      // declined or the permission has since been revoked. No-op if it's
      // already granted.
      await BackgroundSyncScheduler.ensureNotificationPermission(context);
      if (!context.mounted) return;
    }
    await ref.read(backgroundSyncModeProvider.notifier).setMode(mode);
  }

  Future<void> _wipeWallet(BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Wipe this wallet?'),
        content: const Text(
          "This deletes your wallet from this device. Make sure you've "
          "backed up your recovery phrase — it's the only way to get your "
          'funds back.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Wipe', style: TextStyle(color: YColors.danger)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    final gate = ref.read(biometricGateProvider);
    final auth = await gate.authenticate(GateReason.wipeWallet);
    if (!auth.authenticated) {
      YHaptics.warn();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(auth.error ?? 'Authentication required')));
      }
      return;
    }

    // Previously required the wallet password as a second factor here, on
    // top of device auth -- there's no password anymore. Device
    // biometric/PIN/pattern authentication is now the *only* gate on
    // wiping the wallet, same as everywhere else in the app. This is a
    // real reduction in defense-in-depth for this specific action: anyone
    // who can pass the device's own lock screen can now wipe the wallet
    // (though restoring from the recovery phrase is always still
    // possible, so nothing is lost that wasn't already backed up).

    // Previously an unhandled exception here (e.g. secure storage
    // failing to delete) would surface as a silent no-op or a crash,
    // leaving the user unsure whether their wallet was actually wiped.
    try {
      await ref.read(seedVaultProvider).wipe();
      await ref.read(biometricGateProvider).wipePasswordRecords();
      // The two calls above delete the encrypted password/seed *records*;
      // this additionally destroys the underlying hardware-backed
      // Keystore key those records (and biometric/device-credential
      // authentication) were protected by, so nothing from this wallet's
      // security setup survives the wipe.
      await ref.read(biometricGateProvider).wipeNativeKey();
      await ref.read(engineProvider).wipeWallet();
      // vault.wipe() above already cleared the cached background-sync seed
      // copy; this stops the periodic job itself from firing (and finding
      // nothing) until a new wallet is created or restored.
      await BackgroundSyncScheduler.apply(BackgroundSyncMode.off);
      // Mark onboarding as not-done *before* navigating: a raw
      // `Navigator.popUntil` here previously landed back on Home with the
      // wallet gone, because it bypasses go_router's redirect entirely and
      // the router's "onboarding complete?" check was a value frozen at
      // app boot anyway. Updating the provider first, then routing to '/'
      // through go_router, lets the redirect see the fresh "not onboarded"
      // state and send the user to /onboarding.
      ref.read(onboardingStatusProvider.notifier).markWiped();
      if (context.mounted) {
        context.go('/');
      }
    } catch (e) {
      YHaptics.warn();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Could not fully wipe the wallet. Please try again.')));
      }
    }
  }
}

class _AboutTile extends StatelessWidget {
  const _AboutTile();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<PackageInfo>(
      future: PackageInfo.fromPlatform(),
      builder: (context, snapshot) {
        final version = snapshot.data?.version ?? '—';
        return MergeSemantics(
          child: ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('Version'),
            trailing: Text(version, style: const TextStyle(color: YColors.textSecondary)),
          ),
        );
      },
    );
  }
}

/// 'Immediately' / '10 seconds' / '1 minute' / '3 minutes', for the
/// auto-lock options (which are 0, or whole seconds under a minute, or
/// whole minutes).
String _autoLockLabel(int seconds) {
  if (seconds == 0) return 'Immediately';
  if (seconds < 60) return '$seconds seconds';
  final minutes = seconds ~/ 60;
  return minutes == 1 ? '1 minute' : '$minutes minutes';
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);

  @override
  Widget build(BuildContext context) {
    return Semantics(
      header: true,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(YSpacing.lg, YSpacing.lg, YSpacing.lg, YSpacing.sm),
        child: Text(
          title.toUpperCase(),
          style: const TextStyle(
            color: YColors.textMuted,
            fontSize: 12,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.8,
          ),
        ),
      ),
    );
  }
}
