import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../core/providers.dart';
import '../../core/models/ycash_config.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

/// Lets the user pick a date (down to the fork launch) and rescan the
/// wallet from the block height closest to it, instead of always
/// rescanning from Sapling activation.
///
/// This is the main lever for "I wiped/reinstalled the app and want my
/// balance back faster": if you know roughly when you first got Ycash, a
/// rescan from that date skips years of blocks you can prove you weren't
/// using yet, instead of walking the entire chain.
class RescanScreen extends ConsumerStatefulWidget {
  const RescanScreen({super.key});

  @override
  ConsumerState<RescanScreen> createState() => _RescanScreenState();
}

class _RescanScreenState extends ConsumerState<RescanScreen> {
  DateTime _selectedDate = YcashConfig.forkDate;
  bool _isEstimating = false;
  bool _isRescanning = false;

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate.isBefore(now) ? _selectedDate : now,
      // Nothing Ycash-specific happened before the fork, so there's no
      // point letting someone pick an earlier date — it would just waste
      // scan time re-deriving the same "found nothing" result.
      firstDate: YcashConfig.forkDate,
      lastDate: now,
      helpText: 'Rescan from date',
    );
    if (picked != null) setState(() => _selectedDate = picked);
  }

  Future<void> _startRescan({required int height, required String reason}) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rescan wallet?'),
        content: Text(
          "This clears your locally cached transaction history and rebuilds it by scanning the chain again, starting $reason (block $height). "
          "Your funds aren't affected — only how long recovery takes. "
          'This can take a while depending on how far back it starts.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Rescan')),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _isRescanning = true);
    try {
      await ref.read(engineProvider).rescanFromHeight(height);
      ref.invalidate(syncStatusProvider);
      ref.invalidate(balancesProvider);
      ref.invalidate(transactionHistoryProvider);
      if (mounted) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Rescan started — check Network & sync for progress.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not start rescan: $e')));
      }
    } finally {
      if (mounted) setState(() => _isRescanning = false);
    }
  }

  Future<void> _rescanFromSelectedDate() async {
    setState(() => _isEstimating = true);
    int height;
    try {
      height = await ref.read(engineProvider).estimateHeightForDate(_selectedDate);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not estimate a block height: $e')));
      }
      return;
    } finally {
      if (mounted) setState(() => _isEstimating = false);
    }
    if (!mounted) return;
    await _startRescan(
      height: height,
      reason: 'around ${DateFormat.yMMMd().format(_selectedDate)}',
    );
  }

  Future<void> _rescanFromFork() => _startRescan(
        height: YcashConfig.forkHeight,
        reason: 'from the Ycash fork launch',
      );

  @override
  Widget build(BuildContext context) {
    final busy = _isEstimating || _isRescanning;
    return Scaffold(
      appBar: AppBar(title: const Text('Rescan wallet')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(YSpacing.md),
          children: [
            const Text(
              "If you restored this wallet after a wipe or reinstall, "
              'rescanning from around when you first got Ycash is usually '
              'much faster than a full rescan — it skips the years of '
              "blocks before you had any funds. If you're not sure, pick a "
              'date a bit earlier than you think — an early guess only '
              'costs extra scan time, never missed funds.',
              style: TextStyle(color: YColors.textSecondary),
            ),
            const SizedBox(height: YSpacing.lg),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(YSpacing.md),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Rescan from a date', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  const SizedBox(height: YSpacing.sm),
                  MergeSemantics(
                    child: ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.event_outlined),
                      title: Text(DateFormat.yMMMd().format(_selectedDate)),
                      subtitle: const Text('We estimate the matching block height on the network'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: busy ? null : _pickDate,
                    ),
                  ),
                  const SizedBox(height: YSpacing.sm),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: busy ? null : _rescanFromSelectedDate,
                      child: _isEstimating
                          ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Text('Rescan from this date'),
                    ),
                  ),
                ]),
              ),
            ),
            const SizedBox(height: YSpacing.md),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(YSpacing.md),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Rescan everything', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  const SizedBox(height: YSpacing.xs),
                  Text(
                    'Scans from the Ycash fork launch (${DateFormat.yMMMd().format(YcashConfig.forkDate)}, block ${YcashConfig.forkHeight}) — the earliest anything Ycash-specific could exist. '
                    'Slower, but guaranteed complete if a date guess feels risky.',
                    style: const TextStyle(color: YColors.textSecondary),
                  ),
                  const SizedBox(height: YSpacing.sm),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: busy ? null : _rescanFromFork,
                      child: const Text('Rescan from the fork launch'),
                    ),
                  ),
                ]),
              ),
            ),
            if (_isRescanning) ...[
              const SizedBox(height: YSpacing.lg),
              const Center(child: YBusyState(label: 'Starting rescan')),
            ],
          ],
        ),
      ),
    );
  }
}
