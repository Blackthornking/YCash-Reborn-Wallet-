import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/providers.dart';
import '../../core/settings_store/currencies.dart';
import '../../design/tokens.dart';

class CurrencySettingsScreen extends ConsumerStatefulWidget {
  const CurrencySettingsScreen({super.key});
  @override
  ConsumerState<CurrencySettingsScreen> createState() => _CurrencySettingsScreenState();
}

class _CurrencySettingsScreenState extends ConsumerState<CurrencySettingsScreen> {
  final _search = TextEditingController();
  String _query = '';
  @override
  void dispose() { _search.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final current = ref.watch(localCurrencyProvider).value?.code ?? 'USD';
    final apiKey = ref.watch(cmcApiKeyProvider).valueOrNull;
    final q = _query.toLowerCase();
    final choices = globalCurrencies.where((c) => q.isEmpty || c.code.toLowerCase().contains(q) || c.name.toLowerCase().contains(q)).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Display currency')),
      body: Column(children: [
        MergeSemantics(
          child: ListTile(
            leading: const Icon(Icons.price_change_outlined),
            title: const Text('Price source (CoinMarketCap)'),
            subtitle: Text(apiKey == null || apiKey.isEmpty
                ? 'Not set — balances show in YEC only'
                : 'API key saved — showing an estimated local value'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _editApiKey(context, ref, apiKey),
          ),
        ),
        const Divider(height: 1),
        Padding(padding: const EdgeInsets.all(YSpacing.md), child: TextField(
          controller: _search, onChanged: (v) => setState(() => _query = v),
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search currency or country'),
        )),
        Padding(padding: const EdgeInsets.symmetric(horizontal: YSpacing.lg), child: Text('Choose the currency used for local-value display. Your wallet balances always remain denominated in YEC.', style: TextStyle(color: YColors.textMuted.withValues(alpha: .95), fontSize: 12))),
        const SizedBox(height: 8),
        Expanded(child: ListView.builder(itemCount: choices.length, itemBuilder: (context, index) {
          final c = choices[index];
          final selected = c.code == current;
          return ListTile(
            title: Text(c.code, style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(c.name),
            trailing: selected ? const Icon(Icons.check_circle, color: YColors.shieldedPrimary) : null,
            onTap: () async {
              await ref.read(settingsStoreProvider).setLocalCurrency(c.code);
              ref.invalidate(localCurrencyProvider);
              if (context.mounted) Navigator.of(context).pop();
            },
          );
        })),
      ]),
    );
  }

  Future<void> _editApiKey(BuildContext context, WidgetRef ref, String? current) async {
    final controller = TextEditingController(text: current ?? '');
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('CoinMarketCap API key'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text(
            "Paste your own CoinMarketCap API key to show an estimated local-currency "
            'value next to your YEC balance. Your wallet balances themselves are always '
            'stored and shown in YEC — this only adds an estimate line.',
            style: TextStyle(fontSize: 12),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: controller,
            autofocus: true,
            obscureText: true,
            decoration: const InputDecoration(labelText: 'API key', hintText: 'Paste key here'),
          ),
          const SizedBox(height: 8),
          InkWell(
            onTap: () => launchUrl(Uri.parse('https://pro.coinmarketcap.com/signup'), mode: LaunchMode.externalApplication),
            child: const Text('Get a free API key at coinmarketcap.com →', style: TextStyle(color: YColors.shieldedPrimary, fontSize: 12, fontWeight: FontWeight.w700)),
          ),
        ]),
        actions: [
          if (current != null && current.isNotEmpty)
            TextButton(onPressed: () => Navigator.pop(ctx, ''), child: const Text('Remove', style: TextStyle(color: YColors.danger))),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, controller.text), child: const Text('Save')),
        ],
      ),
    );
    if (result == null) return;
    await ref.read(cmcApiKeyProvider.notifier).setKey(result.isEmpty ? null : result);
  }
}
