import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/providers.dart';
import '../../core/settings_store/currencies.dart';
import '../../design/tokens.dart';

class CurrencySettingsScreen extends ConsumerStatefulWidget {
  const CurrencySettingsScreen({super.key});
  @override
  ConsumerState<CurrencySettingsScreen> createState() => _CurrencySettingsScreenState();
}

class _CurrencySettingsScreenState extends ConsumerState<CurrencySettingsScreen> {
  final _search = TextEditingController();
  String _query = '';
  @override
  void dispose() { _search.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final current = ref.watch(localCurrencyProvider).value?.code ?? 'USD';
    final q = _query.toLowerCase();
    final choices = globalCurrencies.where((c) => q.isEmpty || c.code.toLowerCase().contains(q) || c.name.toLowerCase().contains(q)).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Display currency')),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(YSpacing.md), child: TextField(
          controller: _search, onChanged: (v) => setState(() => _query = v),
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search currency or country'),
        )),
        Padding(padding: const EdgeInsets.symmetric(horizontal: YSpacing.lg), child: Text('Choose the currency used for local-value display. Your wallet balances always remain denominated in YEC.', style: TextStyle(color: YColors.textMuted.withValues(alpha: .95), fontSize: 12))),
        const SizedBox(height: 8),
        Expanded(child: ListView.builder(itemCount: choices.length, itemBuilder: (context, index) {
          final c = choices[index];
          final selected = c.code == current;
          return ListTile(
            title: Text(c.code, style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(c.name),
            trailing: selected ? const Icon(Icons.check_circle, color: YColors.shieldedPrimary) : null,
            onTap: () async {
              await ref.read(settingsStoreProvider).setLocalCurrency(c.code);
              ref.invalidate(localCurrencyProvider);
              if (context.mounted) Navigator.of(context).pop();
            },
          );
        })),
      ]),
    );
  }
}
