import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/providers.dart';
import '../../core/models/ycash_config.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

class ServerSettingsScreen extends ConsumerStatefulWidget {
  const ServerSettingsScreen({super.key});

  @override
  ConsumerState<ServerSettingsScreen> createState() =>
      _ServerSettingsScreenState();
}

class _ServerSettingsScreenState extends ConsumerState<ServerSettingsScreen> {
  final _controller = TextEditingController();
  bool _loaded = false;
  bool _saving = false;
  // Previously this screen had no way to represent "the stored server URL
  // failed to load" — it just sat on a spinner forever. Now a load
  // failure is a real, retryable state like everywhere else.
  String? _loadError;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loaded = false;
      _loadError = null;
    });
    try {
      final url = await ref.read(settingsStoreProvider).getServerUrl();
      if (!mounted) return;
      setState(() {
        _controller.text = url;
        _loaded = true;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loaded = true;
        _loadError = 'Could not load your saved server.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sync server')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(YSpacing.lg),
          child: !_loaded
              ? const Center(child: YBusyState(label: 'Loading server settings'))
              : _loadError != null
                  ? Center(
                      child: YErrorState(
                        message: _loadError!,
                        onRetry: _load,
                      ),
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Lightwalletd-compatible server used to sync your '
                          'wallet. Changing this only affects how you see the '
                          'chain — it never touches your keys.',
                          style: TextStyle(color: YColors.textSecondary),
                        ),
                        const SizedBox(height: YSpacing.lg),
                        TextField(
                          controller: _controller,
                          keyboardType: TextInputType.url,
                          decoration: const InputDecoration(labelText: 'Server URL'),
                        ),
                        const SizedBox(height: YSpacing.md),
                        Row(
                          children: [
                            Expanded(
                              child: ElevatedButton(
                                onPressed: _saving ? null : _save,
                                child: _saving
                                    ? const SizedBox(
                                        height: 20,
                                        width: 20,
                                        child: CircularProgressIndicator(
                                            strokeWidth: 2))
                                    : const Text('Save'),
                              ),
                            ),
                            const SizedBox(width: YSpacing.md),
                            Expanded(
                              child: OutlinedButton(
                                onPressed: _saving ? null : _resetToDefault,
                                child: const Text('Use default'),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
        ),
      ),
    );
  }

  Future<void> _save() async {
    final value = _controller.text.trim();
    final uri = Uri.tryParse(value);
    // Previously any string — including an empty one — was written
    // straight to storage with no check, so a typo silently broke sync
    // with no explanation the next time the app tried to connect.
    if (value.isEmpty || uri == null || !uri.hasScheme || !uri.hasAuthority) {
      YHaptics.warn();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Enter a full server URL, e.g. https://host:port')));
      return;
    }

    setState(() => _saving = true);
    try {
      await ref.read(settingsStoreProvider).setServerUrl(value);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Server updated — restart sync to apply')));
      }
    } catch (e) {
      YHaptics.warn();
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Could not save server')));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _resetToDefault() async {
    setState(() => _saving = true);
    try {
      await ref.read(settingsStoreProvider).resetServerUrl();
      if (mounted) setState(() => _controller.text = YcashConfig.defaultLightwalletd);
    } catch (e) {
      YHaptics.warn();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Could not reset to default')));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }
}
