import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../app/router.dart';
import '../../core/crypto_bridge/ycash_engine.dart';
import '../../core/providers.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';
import '../shield/shield_flow.dart';

/// Modern wallet dashboard. Pull down anywhere to refresh balances and history.
class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final balances = ref.watch(balancesProvider);
    final currency = ref.watch(localCurrencyProvider).valueOrNull?.code ?? 'USD';
    final sync = ref.watch(syncStatusProvider);
    final autoShield = ref.watch(autoShieldProvider).valueOrNull ?? false;
    final hideBalance = ref.watch(hideBalanceProvider).valueOrNull ?? false;
    final history = ref.watch(transactionHistoryProvider).valueOrNull ?? const <TxRecord>[];
    final cs = Theme.of(context).colorScheme;

    Future<void> refresh() async {
      ref.invalidate(balancesProvider);
      ref.invalidate(transactionHistoryProvider);
      await Future<void>.delayed(const Duration(milliseconds: 450));
    }

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        leading: Padding(
          padding: const EdgeInsets.all(10),
          child: Image.asset('assets/branding/ycash_logo.png', filterQuality: FilterQuality.high),
        ),
        title: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Ycash', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: .3)),
          Text('PRIVATE MONEY', style: TextStyle(fontSize: 9, letterSpacing: 1.8, color: Theme.of(context).hintColor)),
        ]),
        actions: [
          IconButton(tooltip: 'Wallet alerts', icon: const Icon(Icons.notifications_none_rounded), onPressed: context.pushAlerts),
          IconButton(tooltip: 'Settings', icon: const Icon(Icons.settings_outlined), onPressed: context.pushSettings),
        ],
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: refresh,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
            children: [
              _SyncStrip(sync: sync),
              const SizedBox(height: 16),
              balances.when(
                data: (b) => _MainBalanceCard(balances: b, currency: currency, hidden: hideBalance),
                loading: () => const SizedBox(height: 250, child: Center(child: YBusyState(label: 'Loading wallet'))),
                error: (_, __) => YErrorState(message: 'Could not refresh your balance.', onRetry: () => ref.invalidate(balancesProvider)),
              ),
              const SizedBox(height: 16),
              if (balances.valueOrNull != null && autoShield && balances.value!.hasUnshielded)
                _AutoShieldCard(onTap: () => runShieldFlow(context, ref, direction: ShieldDirection.shield)),
              const SizedBox(height: 18),
              Text('Quick actions', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: _QuickAction(icon: Icons.arrow_upward_rounded, label: 'Send', onTap: context.pushSend)),
                const SizedBox(width: 8),
                Expanded(child: _QuickAction(icon: Icons.qr_code_rounded, label: 'Receive', onTap: context.pushReceive)),
                const SizedBox(width: 8),
                Expanded(child: _QuickAction(icon: Icons.shield_outlined, label: 'Shield', onTap: () => runShieldFlow(context, ref, direction: ShieldDirection.shield))),
                const SizedBox(width: 8),
                Expanded(child: _QuickAction(icon: Icons.lock_open_outlined, label: 'Unshield', onTap: () => runShieldFlow(context, ref, direction: ShieldDirection.unshield))),
              ]),
              const SizedBox(height: 22),
              _SecurityStatus(autoShield: autoShield, color: cs.primary),
              const SizedBox(height: 18),
              Row(children:[Text('Recent activity', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),const Spacer(),TextButton(onPressed:context.pushActivity,child:const Text('View all'))]),
              if (history.isEmpty) const Padding(padding: EdgeInsets.symmetric(vertical:16), child: Text('No recent activity yet.', textAlign: TextAlign.center)) else ...history.take(3).map((tx)=>_RecentTx(tx:tx)),
              const SizedBox(height: 8),
              OutlinedButton.icon(onPressed: context.pushNetwork, icon: const Icon(Icons.cloud_outlined), label: const Text('Network & sync status')),
            ],
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        onDestinationSelected: (i) {
          if (i == 1) context.pushActivity();
          if (i == 2) _showActions(context, ref);
          if (i == 3) context.pushContacts();
          if (i == 4) context.pushSettings();
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'Wallet'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'History'),
          NavigationDestination(icon: Icon(Icons.add_circle_outline), selectedIcon: Icon(Icons.add_circle), label: 'Actions'),
          NavigationDestination(icon: Icon(Icons.contacts_outlined), selectedIcon: Icon(Icons.contacts), label: 'Contacts'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}

class _SyncStrip extends StatelessWidget {
  final AsyncValue<SyncStatus> sync;
  const _SyncStrip({required this.sync});
  @override
  Widget build(BuildContext context) {
    final s = sync.valueOrNull;
    final syncing = s?.isSyncing ?? false;
    final color = syncing ? YColors.shieldedPrimary : YColors.success;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(color: color.withValues(alpha: .10), borderRadius: BorderRadius.circular(16)),
      child: Row(children: [
        Icon(syncing ? Icons.sync_rounded : Icons.verified_user_rounded, color: color, size: 19),
        const SizedBox(width: 9),
        Expanded(child: Text(syncing ? 'Syncing your wallet securely…' : 'Wallet synced and protected', style: const TextStyle(fontWeight: FontWeight.w700))),
        if (syncing && s != null) Text('${(s.progress * 100).clamp(0, 100).toStringAsFixed(0)}%', style: TextStyle(color: color, fontWeight: FontWeight.w800)),
      ]),
    );
  }
}

class _MainBalanceCard extends ConsumerWidget {
  final Balances balances;
  final String currency;
  final bool hidden;
  const _MainBalanceCard({required this.balances, required this.currency, required this.hidden});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final total = balances.totalZatoshi / 1e8;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final card = dark ? const Color(0xFF12110F) : Colors.white;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Theme.of(context).dividerColor),
        boxShadow: dark ? null : [BoxShadow(color: Colors.black.withValues(alpha: .05), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('MAIN BALANCE', style: TextStyle(fontSize: 11, letterSpacing: 1.7, color: Theme.of(context).hintColor, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text('$currency • GLOBAL DISPLAY', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
          ])),
          Row(mainAxisSize: MainAxisSize.min, children:[IconButton(tooltip: hidden ? 'Show balances' : 'Hide balances', icon: Icon(hidden ? Icons.visibility_off_outlined : Icons.visibility_outlined), onPressed:()=>ref.read(hideBalanceProvider.notifier).setHidden(!hidden)),Container(width: 46, height: 46, decoration: BoxDecoration(shape: BoxShape.circle, color: YColors.shieldedPrimary.withValues(alpha: .13)), child: const Icon(Icons.shield_rounded, color: YColors.shieldedPrimary))]),
        ]),
        const SizedBox(height: 24),
        Text(hidden ? '••••••••' : total.toStringAsFixed(8), style: const TextStyle(fontSize: 36, height: 1, fontWeight: FontWeight.w600, fontFeatures: [FontFeature.tabularFigures()])),
        const SizedBox(height: 8),
        const Text('YEC', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.5)),
        const SizedBox(height: 18),
        Row(children: [
          Expanded(child: _PoolPanel(shielded: true, amount: hidden ? 0 : balances.shieldedZatoshi, action: 'Unshield', icon: Icons.lock_open_outlined, onAction: () => runShieldFlow(context, ref, direction: ShieldDirection.unshield))),
          const SizedBox(width: 10),
          Expanded(child: _PoolPanel(shielded: false, amount: hidden ? 0 : balances.transparentZatoshi, action: 'Shield', icon: Icons.shield_outlined, onAction: () => runShieldFlow(context, ref, direction: ShieldDirection.shield))),
        ]),
      ]),
    );
  }
}

class _PoolPanel extends StatelessWidget {
  final bool shielded; final int amount; final String action; final IconData icon; final VoidCallback onAction;
  const _PoolPanel({required this.shielded, required this.amount, required this.action, required this.icon, required this.onAction});
  @override
  Widget build(BuildContext context) {
    final accent = shielded ? YColors.shieldedPrimary : YColors.transparentAccent;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: accent.withValues(alpha: .08), borderRadius: BorderRadius.circular(20), border: Border.all(color: accent.withValues(alpha: .20))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Icon(shielded ? Icons.shield_rounded : Icons.visibility_outlined, size: 18, color: accent), const SizedBox(width: 6), Expanded(child: Text(shielded ? 'SHIELDED' : 'TRANSPARENT', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1, color: accent)))]),
        const SizedBox(height: 13),
        Text((amount / 1e8).toStringAsFixed(8), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16, fontFeatures: [FontFeature.tabularFigures()])),
        const SizedBox(height: 10),
        TextButton.icon(onPressed: onAction, icon: Icon(icon, size: 16), label: Text(action), style: TextButton.styleFrom(foregroundColor: accent, padding: EdgeInsets.zero, minimumSize: const Size(0, 34))),
      ]),
    );
  }
}

class _AutoShieldCard extends StatelessWidget {
  final VoidCallback onTap; const _AutoShieldCard({required this.onTap});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: YColors.shieldedPrimary.withValues(alpha: .09), borderRadius: BorderRadius.circular(20), border: Border.all(color: YColors.shieldedPrimary.withValues(alpha: .22))),
    child: Row(children: [const Icon(Icons.auto_awesome, color: YColors.shieldedPrimary), const SizedBox(width: 12), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Automatic shielding enabled', style: TextStyle(fontWeight: FontWeight.w800)), SizedBox(height: 3), Text('Transparent funds are ready for your secure shield action.', style: TextStyle(fontSize: 12))])), TextButton(onPressed: onTap, child: const Text('Shield'))]),
  );
}

class _QuickAction extends StatelessWidget {
  final IconData icon; final String label; final VoidCallback onTap;
  const _QuickAction({required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => Material(
    color: Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(18), child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(18), child: Padding(padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 4), child: Column(children: [Icon(icon, size: 21), const SizedBox(height: 7), Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700))]))),
  );
}

class _SecurityStatus extends StatelessWidget {
  final bool autoShield; final Color color;
  const _SecurityStatus({required this.autoShield, required this.color});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16), decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: Theme.of(context).dividerColor)),
    child: Row(children: [Icon(Icons.security_rounded, color: color), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Privacy status', style: TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text(autoShield ? 'Automatic shielding preference is enabled' : 'Shield funds manually whenever you choose', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor))])), Icon(autoShield ? Icons.check_circle : Icons.tune, color: color)]),
  );
}

void _showActions(BuildContext context, WidgetRef ref) { showModalBottomSheet(context: context, showDragHandle: true, builder: (ctx)=>SafeArea(child:Padding(padding:const EdgeInsets.all(16),child:Column(mainAxisSize:MainAxisSize.min,children:[ListTile(leading:const Icon(Icons.arrow_upward),title:const Text('Send'),onTap:(){Navigator.pop(ctx);context.pushSend();}),ListTile(leading:const Icon(Icons.qr_code),title:const Text('Receive'),onTap:(){Navigator.pop(ctx);context.pushReceive();}),ListTile(leading:const Icon(Icons.shield_outlined),title:const Text('Shield transparent funds'),onTap:(){Navigator.pop(ctx);runShieldFlow(context,ref,direction:ShieldDirection.shield);}),ListTile(leading:const Icon(Icons.lock_open_outlined),title:const Text('Unshield funds'),onTap:(){Navigator.pop(ctx);runShieldFlow(context,ref,direction:ShieldDirection.unshield);})])))); }
class _RecentTx extends StatelessWidget { final TxRecord tx; const _RecentTx({required this.tx}); @override Widget build(BuildContext context){final plus=tx.amountZatoshi>=0;return Card(child:ListTile(leading:CircleAvatar(child:Icon(tx.isShielded?Icons.shield:Icons.visibility_outlined)),title:Text(tx.isShielded?'Shielded transaction':'Transparent transaction'),subtitle:Text(tx.txId.length>20?'${tx.txId.substring(0,12)}…${tx.txId.substring(tx.txId.length-6)}':tx.txId),trailing:Text('${plus?'+':'−'}${(tx.amountZatoshi.abs()/1e8).toStringAsFixed(8)} YEC',style:TextStyle(fontWeight:FontWeight.w800,color:plus?YColors.success:Theme.of(context).colorScheme.onSurface)));}}
