import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/providers.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

class ReceiveScreen extends ConsumerStatefulWidget {
  const ReceiveScreen({super.key});

  @override
  ConsumerState<ReceiveScreen> createState() => _ReceiveScreenState();
}

class _ReceiveScreenState extends ConsumerState<ReceiveScreen> {
  bool _shielded = true;
  String? _address;
  Object? _error;

  String get _poolLabel => _shielded ? 'shielded' : 'transparent';

  @override
  void initState() {
    super.initState();
    _loadAddress();
  }

  Future<void> _loadAddress() async {
    // Reset both before the await starts so a retry (or a pool switch)
    // clears any previous error instead of leaving it stale underneath
    // a new spinner.
    setState(() {
      _address = null;
      _error = null;
    });
    final engine = ref.read(engineProvider);
    try {
      final addr = _shielded
          ? await engine.getShieldedAddress()
          : await engine.getTransparentAddress();
      if (mounted) setState(() => _address = addr);
    } catch (e) {
      // Previously uncaught: a failed address load left _address null
      // forever with the CircularProgressIndicator below spinning with
      // no way out. Now it surfaces a retry-capable error instead.
      YHaptics.warn();
      if (mounted) setState(() => _error = e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Receive')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(YSpacing.lg),
          child: Column(
            children: [
              SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(
                      value: true,
                      label: Text('Shielded'),
                      icon: Icon(Icons.shield_outlined)),
                  ButtonSegment(
                      value: false,
                      label: Text('Transparent'),
                      icon: Icon(Icons.visibility_outlined)),
                ],
                selected: {_shielded},
                onSelectionChanged: (s) {
                  setState(() => _shielded = s.first);
                  _loadAddress();
                },
              ),
              const SizedBox(height: YSpacing.xl),
              if (_error != null)
                YErrorState(
                  message: 'Could not load your $_poolLabel address.',
                  onRetry: _loadAddress,
                )
              else if (_address == null)
                const YBusyState()
              else
                YEnter(
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(YSpacing.lg),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(YRadius.card),
                        ),
                        child: QrImageView(data: _address!, size: 220),
                      ),
                      const SizedBox(height: YSpacing.lg),
                      SelectableText(
                        _address!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            fontFamily: 'monospace',
                            color: YColors.textSecondary),
                      ),
                      const SizedBox(height: YSpacing.md),
                      Row(children:[Expanded(child:OutlinedButton.icon(onPressed:(){Clipboard.setData(ClipboardData(text:_address!));ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Address copied')));},icon:const Icon(Icons.copy_outlined),label:const Text('Copy'))),const SizedBox(width:8),Expanded(child:OutlinedButton.icon(onPressed:()=>Share.share(_address!),icon:const Icon(Icons.share_outlined),label:const Text('Share')))]),
                      const SizedBox(height:8),Text(_shielded?'Private shielded address • recommended for receiving':'Public transparent address • consider shielding received funds',textAlign:TextAlign.center,style:TextStyle(fontSize:12,color:Theme.of(context).hintColor)),
                    ],
                  ),
                ),
              if (!_shielded)
                const Padding(
                  padding: EdgeInsets.only(top: YSpacing.lg),
                  child: Text(
                    'Transparent addresses are visible on the public chain. '
                    'Funds received here can be shielded with one tap from '
                    'the home screen.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: YColors.textMuted, fontSize: 12),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
