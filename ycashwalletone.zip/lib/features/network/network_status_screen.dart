import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/providers.dart';
import '../../core/crypto_bridge/ycash_engine.dart';
import '../../design/widgets.dart';
class NetworkStatusScreen extends ConsumerWidget { const NetworkStatusScreen({super.key});
 Future<void> _rescan(WidgetRef ref) async {
   // Invalidating syncStatusProvider only re-reads the engine's last
   // cached status — it doesn't make the wallet look for new blocks. Call
   // syncNow() to actually kick off another native scan round, then let
   // the provider pick up the result.
   await ref.read(engineProvider).syncNow();
   ref.invalidate(syncStatusProvider);
   ref.invalidate(balancesProvider);
 }
 // (icon, label) for each phase, in one place so the header row and any
 // future consumer of phase text stay in sync with each other.
 static (IconData, String) _phaseDisplay(SyncPhase phase, BuildContext context) => switch (phase) {
   SyncPhase.idle => (Icons.cloud_done, 'Connected & synced'),
   SyncPhase.connecting => (Icons.sync, 'Connecting…'),
   SyncPhase.scanning => (Icons.sync, 'Downloading blocks…'),
   SyncPhase.fetchingMemos => (Icons.sync, 'Fetching transaction details…'),
   SyncPhase.error => (Icons.error_outline, 'Sync stopped'),
 };
 @override Widget build(BuildContext context,WidgetRef ref){final sync=ref.watch(syncStatusProvider);return Scaffold(appBar:AppBar(title:const Text('Network & sync')),body:RefreshIndicator(onRefresh:()=>_rescan(ref),child:ListView(physics:const AlwaysScrollableScrollPhysics(),padding:const EdgeInsets.all(16),children:[sync.when(data:(s){
   // chainTipHeight is only known once a sync round's first fetch_latest_block
   // call has returned (see ycash_core_ffi_engine.dart). Right after a fresh
   // app launch that hasn't happened yet even though syncedHeight is already
   // meaningful (seeded from the wallet's own persisted height) -- showing a
   // literal "0" / "0.0%" there would misleadingly look like sync had reset,
   // so show that specific case as "checking" instead of a number.
   final tipKnown = s.chainTipHeight > 0;
   final (icon, label) = _phaseDisplay(s.phase, context);
   final iconColor = s.phase == SyncPhase.error
       ? Theme.of(context).colorScheme.error
       : (s.isSyncing ? Theme.of(context).colorScheme.primary : Colors.green);
   return Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Icon(icon,color:iconColor),const SizedBox(width:10),Text(label,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:18))]),const SizedBox(height:20),LinearProgressIndicator(value:tipKnown?s.progress:null),const SizedBox(height:14),_row('Wallet height',s.syncedHeight.toString()),_row('Network height',tipKnown?s.chainTipHeight.toString():'Checking…'),_row('Progress',tipKnown?'${(s.progress*100).clamp(0,100).toStringAsFixed(1)}%':'—'),if(s.lastError!=null)...[const SizedBox(height:14),Row(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(Icons.error_outline,color:Theme.of(context).colorScheme.error,size:20),const SizedBox(width:8),Expanded(child:Text('Sync stopped: ${s.lastError}',style:TextStyle(color:Theme.of(context).colorScheme.error,fontWeight:FontWeight.w600)))])]])));
 },loading:()=>const YBusyState(label:'Checking network'),error:(_,__)=>YErrorState(message:'Could not read network status.',onRetry:()=>_rescan(ref))),const SizedBox(height:16),Card(child:ListTile(leading:const Icon(Icons.refresh),title:const Text('Refresh sync status'),subtitle:const Text('Pull down anywhere on this page to refresh.'),onTap:()=>_rescan(ref)))])));}
 Widget _row(String a,String b)=>Padding(padding:const EdgeInsets.symmetric(vertical:5),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(a),Text(b,style:const TextStyle(fontWeight:FontWeight.w800))]));}
