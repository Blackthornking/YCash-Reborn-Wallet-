import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/providers.dart';
import '../../design/widgets.dart';
class NetworkStatusScreen extends ConsumerWidget { const NetworkStatusScreen({super.key});
 Future<void> _rescan(WidgetRef ref) async {
   // Invalidating syncStatusProvider only re-reads the engine's last
   // cached status — it doesn't make the wallet look for new blocks. Call
   // syncNow() to actually kick off another native scan round, then let
   // the provider pick up the result.
   await ref.read(engineProvider).syncNow();
   ref.invalidate(syncStatusProvider);
   ref.invalidate(balancesProvider);
 }
 @override Widget build(BuildContext context,WidgetRef ref){final sync=ref.watch(syncStatusProvider);return Scaffold(appBar:AppBar(title:const Text('Network & sync')),body:RefreshIndicator(onRefresh:()=>_rescan(ref),child:ListView(physics:const AlwaysScrollableScrollPhysics(),padding:const EdgeInsets.all(16),children:[sync.when(data:(s)=>Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Icon(s.isSyncing?Icons.sync:Icons.cloud_done,color:s.isSyncing?Theme.of(context).colorScheme.primary:Colors.green),const SizedBox(width:10),Text(s.isSyncing?'Syncing securely':'Connected & synced',style:const TextStyle(fontWeight:FontWeight.w900,fontSize:18))]),const SizedBox(height:20),LinearProgressIndicator(value:s.progress.clamp(0.0,1.0)),const SizedBox(height:14),_row('Wallet height',s.syncedHeight.toString()),_row('Network height',s.chainTipHeight.toString()),_row('Progress','${(s.progress*100).clamp(0,100).toStringAsFixed(1)}%')]))),loading:()=>const YBusyState(label:'Checking network'),error:(_,__)=>YErrorState(message:'Could not read network status.',onRetry:()=>_rescan(ref))),const SizedBox(height:16),Card(child:ListTile(leading:const Icon(Icons.refresh),title:const Text('Refresh sync status'),subtitle:const Text('Pull down anywhere on this page to refresh.'),onTap:()=>_rescan(ref)))])));}
 Widget _row(String a,String b)=>Padding(padding:const EdgeInsets.symmetric(vertical:5),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(a),Text(b,style:const TextStyle(fontWeight:FontWeight.w800))]));}
