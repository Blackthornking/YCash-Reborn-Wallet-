# Home, Pools and History Update

- Home now presents Full Balance, Shielded Balance and Unshielded Balance together.
- Shielded balance opens the Shielded page with an Unshield Funds action.
- Transparent/Unshielded balance opens the Transparent page with a Shield Funds action.
- Quick Shield is available directly from the main page.
- Both pool pages show the relevant receiving address and QR code.
- History is simplified and sorted newest first. Each row shows only transaction number, amount, date/time, and Shielded or Unshielded status.
- Existing shield/unshield flow remains the transaction planner and biometric confirmation path; no cryptographic logic was replaced.
