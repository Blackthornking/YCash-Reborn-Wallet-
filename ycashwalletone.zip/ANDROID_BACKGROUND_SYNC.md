# Ycash Android background sync

Ycash now uses a hybrid background-sync design:

- **Background sync: On** — starts an Android `dataSync` foreground service after the wallet is unlocked. The service keeps the Flutter/Rust sync engine alive when the screen is locked and kicks `startSync()` every 30 seconds so newly mined blocks are picked up.
- **Wi-Fi only** — keeps the lower-frequency WorkManager path and requires an unmetered connection. It does not start a continuous mobile-data foreground service.
- **Off** — cancels both background mechanisms.
- WorkManager remains as a fallback for devices/OEMs that refuse a foreground-service start.

The foreground notification shows the current scan state and block progress.

## Android limits

On Android 15+ a `dataSync` foreground service is limited to six hours of runtime in a 24-hour period. Ycash deliberately stops its service after 5h30m and restarts it when the app returns to the foreground, which gives Android a fresh window. WorkManager remains available after the foreground-service window ends.

The service is **not** configured for automatic boot startup. A wallet must first be unlocked so its unattended background-sync seed cache exists. This avoids starting an unattended wallet sync before the user has ever initialized the wallet.

## Security

The foreground task does not store a new seed. If the Android service has to recover after the app process is recreated, it uses the existing `SeedVault` background-sync cache protected by the dedicated unattended Android Keystore key already present in this project.

## Testing

On an Android 13+ device:

1. Unlock the Ycash wallet with Background sync set to **On**.
2. Confirm the **Ycash background sync** notification appears.
3. Open Network & sync and note the wallet/network heights.
4. Lock the phone.
5. Wait at least 30–60 seconds and reopen Network & sync.
6. Confirm the sync height has continued moving or has caught up to the network tip.
7. If the service is allowed to run for several hours, verify it stops before the Android 15 six-hour `dataSync` limit.
8. Bring the app back to the foreground and confirm the service starts again.

Force-stopping the application from Android Settings is intentionally different: Android terminates the application's services and background jobs, and Ycash cannot bypass an explicit user force-stop.
