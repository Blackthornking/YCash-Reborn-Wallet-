# Phase 56 Status

## Source changes applied

- Flutter now consumes a dedicated native read-only capability manifest.
- Read-only activation requires explicit `ycash_verified=true` from native code.
- Shielded and transparent address APIs remain unavailable until a corresponding
  native ABI implementation exists and advertises verified capability.

## Not enabled

No real address, sync, balance, transaction history, send, sign, or broadcast
claim is made by this source tree. Enabling any of those without the compiled
Ycash backend and deterministic vectors would be misleading and unsafe.
