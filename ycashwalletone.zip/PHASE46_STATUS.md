# Phase 46 — Upstream NU61 Trial-Decryption Scanner

## Implemented
Phase 46 adds a feature-gated adapter that invokes the pinned Ycash NU61
`zcash_client_backend::scanning::scan_block` API. It accepts generated
CompactBlock protobufs, converts them via protobuf encode/decode into the exact
upstream generated type, and passes real `ScanningKeys`, `Nullifiers`, network
parameters, and prior block metadata to the upstream scanner.

## Safety
- No manual compact-block wire parsing.
- No synthetic decrypted notes.
- No viewing or spending keys cross the Flutter FFI boundary.
- Scan results remain upstream `ScannedBlock` values until a later explicit
  storage-mapping phase.

## Not yet proven
This environment has not compiled or run a regtest fixture. Mainnet spending
remains disabled. The next phase must feed a real key set and regtest compact
block through this adapter and map verified `ScannedBlock` outputs atomically
into Phase 42 storage.
