# Ycash Reborn Phase 20

Phase 20 is the first phase with exact Ycash Foundation upstream revisions recorded
in both the source lock and Rust integration configuration. Run:

```bash
./upstream/scripts/fetch-pinned-upstreams.sh
cd packages/ycash_core_ffi/rust
cargo check --features ycash-sapling
```

Do not enable production spending from this phase. The next phase is deterministic
vector validation against Ycash-compatible key/address and compact-block data.
