# Phase 37

This phase turns the previously informal proving boundary into a source-verified integration checklist against the vendored Ycash Sapling implementation.

It deliberately fails closed rather than claiming real spending support. The next implementation requires the exact Ycash-patched transaction layer (for transaction-wide signatures and serialization) plus the wallet key-vault format that resolves stored key handles.
