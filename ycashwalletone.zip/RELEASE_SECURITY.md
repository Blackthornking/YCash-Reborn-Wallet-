# Release Security Gate

`spending_enabled` MUST remain false until this checklist is signed off.

- [ ] Exact upstream Ycash revisions pinned and archived.
- [ ] Cargo.lock committed and reproducible builds documented.
- [ ] Real Sapling address derivation matches Ycash reference vectors.
- [ ] Viewing-key scanning matches known chain fixtures.
- [ ] Note/nullifier accounting matches reference wallet.
- [ ] Shield/send/unshield transaction bytes accepted by a Ycash test environment.
- [ ] Nullifier migration tested for fork-era Sapling funds.
- [ ] Android/iOS secure-storage and key-lifetime review completed.
- [ ] External security review completed.
