# Ycash Reborn Phase 24

Phase 24 adds the deterministic wallet-state layer needed after compact-block trial decryption:
notes, nullifiers, balances, history, and rewind handling.

The cryptographic scanner is deliberately not faked. The next phase must wire these structures to real Ycash-compatible compact-block fixtures and the pinned Sapling backend.
