# Phase 56 — Read-only activation implementation boundary

This package is an actual source-level update of Phase 55. It does **not** pretend
that Ycash addresses or balances are live.

The Flutter adapter now reads the native backend capability manifest and refuses
to expose receive/sync functionality unless the native library explicitly reports
`ycash_verified=true` and the required read-only capabilities.

A production build must replace the native stub manifest with output from a
compiled, pinned Ycash backend that has passed deterministic address vectors and
an end-to-end compact-block fixture.
