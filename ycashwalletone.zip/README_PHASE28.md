# Ycash Reborn Phase 28 — Fixture Verification

Phase 28 adds a reproducible fixture-verification harness for the read-only
Ycash pipeline.

## Included
- fixture provenance manifest
- SHA-256 verification utility
- explicit expected-result metadata
- scanner fixture runner boundary
- CI checks for fixture integrity
- protocol-aware address HRP documentation

## Important
No invented cryptographic fixtures are included. A fixture becomes a production
test only after its source, height/range, hash, and expected result have been
recorded from a reproducible Ycash-compatible backend.

Spending remains disabled.
