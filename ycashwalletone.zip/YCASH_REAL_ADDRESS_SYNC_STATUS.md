# Ycash real-address and sync configuration

This project now explicitly uses the Ycash Warp coin selector (`1`) and the upstream Ycash Lightwalletd endpoint:

`https://lite.ycash.xyz:9067`

Address generation is fail-closed:

- Sapling receive address must begin with `ys1`.
- Transparent receive address must begin with `s1`.

The wallet does not fabricate addresses in Dart. Both are derived by the native Warp/Ycash backend from the wallet mnemonic/account. Synchronization is performed through Warp against Ycash Lightwalletd.

## Required release validation

Before funds are used in production, build the Android native Warp library and run an on-device integration test that:

1. creates a wallet from a test mnemonic,
2. verifies deterministic restoration produces identical `ys1` and `s1` addresses,
3. calls `getLatestHeight`,
4. runs `warpSync`,
5. confirms the local database advances toward the server tip, and
6. tests known funded test addresses/accounts without exposing production seeds.

Sending remains intentionally disabled until the exact Ycash prover/transaction assets are built and end-to-end network acceptance tests pass.
