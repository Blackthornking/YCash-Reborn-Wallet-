# Phase 20 — Exact Ycash Upstream Pins

This phase replaces floating upstream placeholders with exact Git revisions:

- sapling-crypto-ycash: c5e596c239dbf9138a74246b843bcd01413f51c7
- librustzcash-nu61: 26de676f2c5c0e2d35e0b28b7bea704f4ff0411e
- zcash-sync: d91b60309b9b414ad5359ae3da4407b8abe234df

## Included

- Optional Cargo integration for the exact Ycash Sapling crate.
- Reproducible upstream fetch script that checks out detached exact revisions.
- Runtime/backend compile capability boundary.
- Updated provenance lock.

## Still intentionally blocked

- Real address ownership claims
- Spending-key transaction signing
- Proof generation for production transactions
- Broadcast of spend transactions

Those remain blocked until deterministic Ycash address/key vectors and compact-block
trial-decryption vectors are added and passed in CI.
