# Phase 23 Status — Backend Compile Gate

## Implemented
- Whole Phase 22 project carried forward.
- Added a minimal pinned-Sapling compile boundary.
- Added tests ensuring upstream revisions are explicit and not floating branches.
- Updated CI to compile the core separately from the optional pinned Sapling feature.
- Kept Orchard out of the production core boundary.
- Spending remains disabled.

## Not yet claimed
- Successful CI compilation has not been observed in this environment.
- No real wallet address derivation is enabled yet.
- No compact-block trial decryption is enabled yet.
- No transaction construction/signing is enabled.

## Required next evidence
1. Green `cargo test --no-default-features`.
2. Green `cargo check --no-default-features --features ycash-sapling`.
3. Review and fix any dependency/API errors from CI.
4. Add recorded deterministic Ycash fixtures before promoting read-only scanning.
