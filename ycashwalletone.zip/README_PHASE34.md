# Phase 34

Phase 34 introduces the missing authenticated spend inputs required for a real
Sapling transaction: selected notes, witnesses, anchors, network identity,
change address, opaque key handles, and proving parameters.
