# Ycash Reborn Phase 22

Phase 22 makes the validation path executable in CI instead of relying on an unavailable local Rust toolchain.

The workflow intentionally keeps spending disabled. It validates buildability and upstream integration first.
