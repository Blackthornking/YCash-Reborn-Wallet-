# YecShell / libyec integration

The wallet now routes its Ycash engine through the Ycash-specific `yecdev/yecshell`
light-client library and the matching `yecdev/libyec` source tree.

## Native path

Flutter -> `ycash_core` C ABI -> vendored `yecshell` -> vendored `libyec` ->
Ycash lightwalletd.

The previous `warp_api_ffi` / dual-coin `zcash-sync` backend is no longer built
or used by the Flutter engine.

## Implemented native operations

- wallet create/restore using the existing 24-word seed lifecycle
- encrypted yecshell wallet persistence on Android
- Ycash Sapling + transparent address derivation
- balances
- asynchronous lightwalletd sync + sync status
- transaction history
- send planning + biometric-gated broadcast path
- partial/full transparent -> shielded shielding
- shielded -> transparent unshielding
- Ycash address prefix checks (`ys...` and `s...`)

## Storage

The yecshell wallet is stored under the application's support directory as
`yecshell_wallet.dat`. The yecshell seed/key material is encrypted with a
key deterministically derived from the existing secret seed phrase; the seed
phrase remains under the app's existing secure seed/password lifecycle.

On Android, yecshell's upstream `do_save()` is intentionally a no-op, so this
integration serializes the wallet through `LightWallet::write()` and persists
that encrypted representation directly to the configured application directory.

## Build gate

This source archive has been ZIP-integrity tested. A local Cargo/Android build
still needs to run in CI because this execution environment does not provide
Cargo/Rust. The GitHub Actions build now checks `ycash_core_ffi/rust` instead of
the old `zcash-sync` dependency graph.

Spending should be considered release-ready only after the Android CI build and
Ycash testnet/mainnet acceptance tests pass, including address, sync, balance,
shield, send, transaction-broadcast, restart/reopen and wrong-seed rejection.
