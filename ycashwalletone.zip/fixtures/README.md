# Phase 24 fixtures

Only public, reproducible Ycash compact-block and transaction fixtures may be added here.
Do not fabricate cryptographic ciphertext, note commitments, nullifiers, addresses, or proofs.
Fixtures must record their source, block height, block hash, and upstream revision.
