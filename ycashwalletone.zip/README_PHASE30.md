# Ycash Reborn Phase 30 — Full Flutter Platform Project

This package carries forward the Phase 29 wallet source and adds a complete
multi-platform project layout for:

- Android
- iOS
- Web
- Linux
- macOS
- Windows

## Important

The platform trees are checked-in integration scaffolds because Flutter was not
installed in the packaging environment. Before release builds, regenerate the
standard platform templates using the Flutter SDK:

    flutter create --platforms=android,ios,web,linux,macos,windows .

Then review native files and preserve the Ycash-specific Rust/FFI integration.

Do not enable spending based only on successful Flutter platform generation.
The pinned Ycash cryptographic backend and real fixture gates must still pass.
