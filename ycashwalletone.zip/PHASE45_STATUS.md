# Phase 45 Status — Generated CompactBlock + Trial-Decryption Boundary

## Implemented
- Generated protobuf `CompactBlock` decoding using `prost::Message`.
- Envelope/protobuf height and 32-byte hash continuity validation.
- Real compact Sapling nullifier extraction.
- Explicit `SaplingTrialDecryptor` interface for upstream key-bearing scanning.
- Fail-closed behavior for malformed protobuf data and missing scanning keys.

## Not yet complete
This phase does not pretend that trial decryption is implemented merely because
protobuf decoding works. A concrete decryptor must be wired to the exact pinned
Ycash NU61 scanning API and real wallet viewing keys.

## Next
Phase 46: connect `zcash_client_backend` scanning keys / trial-decryption APIs to
`SaplingTrialDecryptor`, then run a regtest compact-block fixture through the
Phase 43 storage pipeline.
