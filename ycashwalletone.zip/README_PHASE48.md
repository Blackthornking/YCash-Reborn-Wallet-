# Phase 48
Run `scripts/phase48_regtest_e2e.sh` only in an environment containing a real Ycash `ycashd` binary and a compatible compact-block/lightwallet service. The script fails rather than fabricating evidence.
