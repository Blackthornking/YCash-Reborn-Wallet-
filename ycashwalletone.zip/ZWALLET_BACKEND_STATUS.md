# ZWallet/YWallet backend integration status

**Not part of the build.** Everything below describes the Dart-side integration boundary that has been written against the vendored `upstream/zwallet/` reference tree. That Rust workspace itself is not compiled by CI or Gradle today, and its `Cargo.lock` still resolves a yanked `aes 0.7.5` / old `fpe 0.5.1` — see `ZWALLET_BACKEND_INTEGRATION.md` for the reconciliation this needs before it's wired in.

Implemented at the Dart integration boundary:

- Ycash wallet database initialization through upstream Warp API
- deterministic account creation/import using the existing protected mnemonic
- shielded receiving address retrieval
- transparent address retrieval
- Warp sync entry point and lightwalletd URL configuration
- shielded and transparent balance retrieval
- sync-status polling
- transaction history retrieval

Still deliberately gated:

- transaction planning/signing/broadcasting
- shield/unshield spending flows

Those require native proving assets and Ycash transaction acceptance testing.
