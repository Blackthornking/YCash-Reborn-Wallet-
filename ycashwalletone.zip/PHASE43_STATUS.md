# Phase 43 — Compact Block Scanner Integration

## Implemented
- Compact-block envelope and chain continuity checks.
- Pinned-decoder boundary for real Ycash compact-block trial decryption.
- Atomic persistence through the Phase 42 authenticated-note ingestion path.
- Nullifier updates tied to the scanned block height.
- Fail-closed behavior: scanner failure, height gaps, and previous-hash mismatches do not advance the chain cursor.

## Not yet proven
- A concrete upstream Ycash `CompactBlockDecoder` adapter is not wired in this package.
- No live lightwallet endpoint has been scanned.
- No `ycashd` regtest acceptance has been demonstrated.

## Spending
Mainnet spending remains disabled.
