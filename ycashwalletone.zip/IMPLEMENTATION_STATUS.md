# Implementation Status

Current phase: 30
Engine target: 0.14.0-phase30

Phase 30 adds a complete multi-platform project layout around the existing
wallet source and Rust backend.

The authoritative Flutter platform templates should be regenerated with the
Flutter SDK before release:

    flutter create --platforms=android,ios,web,linux,macos,windows .

This package does not claim an APK or desktop binary has been compiled.

Spending remains disabled pending backend and cryptographic validation.


## Phase 37
Exact vendored Sapling API integration and fail-closed proving prerequisites added. Real proving/signing/serialization remains incomplete.
