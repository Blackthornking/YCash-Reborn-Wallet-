# Android Flutter embedding v2 repair

The Android host was updated from a plain `android.app.Activity` to Flutter's v2 embedding:

- `MainActivity` now extends `FlutterActivity`.
- AndroidManifest declares `${applicationName}` and `flutterEmbedding=2`.
- Modern Flutter Gradle plugin loader and `dev.flutter.flutter-gradle-plugin` are configured.
- Launch/normal theme resources were added.

This fixes the deleted Android v1 embedding configuration used by recent Flutter releases.
