# Phase 27 Status

## Implemented
- Sapling trial-decryption integration boundary
- Verified ownership contract
- Incoming viewing-key model
- Compact-output adapter
- Fixture provenance policy

## Not yet proven
- Pinned backend compilation in CI
- Real Ycash compact-block fixture decryption
- Real note discovery against public-chain data

## Spending
DISABLED
