# Phase 55 — Read-Only Activation Gate

This phase prepares the project to activate **real receive addresses and blockchain scanning only after reproducible compilation and Ycash compatibility validation**.

## What the gate verifies

1. Vendored upstream source layout matches `YCASH_UPSTREAM_LOCK.toml`.
2. The native crate's ordinary tests pass.
3. The pinned Ycash Sapling feature compiles.
4. The pinned Ycash compact-block scanner feature compiles.

## Still fail-closed

The Flutter application must continue to reject claims that balances, addresses, or transactions are live until:

- deterministic address vectors are supplied from an independent Ycash implementation;
- the exact `ys...` and `s1...` encodings match those vectors;
- a real lightwallet endpoint/regtest fixture is scanned end-to-end;
- discovered notes and balances are independently checked;
- Android ABI builds pass.

No spend, signing, proving, or broadcasting capability is enabled by this phase.
