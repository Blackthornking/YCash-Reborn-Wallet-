# Phase 34 — Authenticated Spend Context

## Implemented
- Typed authenticated-note model.
- Merkle witness and anchor requirements.
- Explicit Ycash network selection.
- Opaque spending-key handles at the transaction boundary.
- Proving-parameter path requirements.
- Backend API now requires both a transaction plan and authenticated spend context.

## Security state
Mainnet spending remains disabled. This phase prevents the backend from attempting
proving with only recipient/amount/memo data.

## Not yet complete
Concrete calls into the vendored Ycash Sapling API, parameter loading and hash
verification, transaction serialization, broadcast, and independent `ycashd`
acceptance tests remain required before real spending can be enabled.
