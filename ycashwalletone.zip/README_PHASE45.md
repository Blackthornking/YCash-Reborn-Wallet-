# Phase 45

Generated Ycash lightwallet protobufs are now decoded with the project's
`tonic`/`prost` generated types. Raw bytes are never hand-parsed.

Notes may enter authenticated storage only through a concrete cryptographic
trial-decryption backend with real scanning keys.
