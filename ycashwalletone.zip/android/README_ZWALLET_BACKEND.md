# Native backend status

The production Flutter app currently loads `libycash_core.so`, built from
`packages/ycash_core_ffi/rust`.

The vendored ZWallet/YWallet `warp_api_ffi` tree is reference material only in
this checkout. Its required native `zcash-sync` source is not present, so this
project must **not** declare or call `libwarp_api_ffi.so`.

Android builds package only `libycash_core.so` for supported ABIs. Wallet
creation/restore/export/wipe are native-backed. Address derivation, sync,
balances, history and spending remain fail-closed until a complete, pinned
Ycash-compatible backend is integrated and validated.
