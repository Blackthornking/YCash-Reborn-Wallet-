# ZWallet/YWallet native backend wiring

YcashWalletOne now calls the vendored upstream `warp_api_ffi` Dart API for wallet
initialisation, account creation, addresses, Warp sync, balances and history.

The Android app must package `libwarp_api_ffi.so` for each ABI before a release
build. Build it from the vendored upstream workspace with its submodules pinned
and then copy the resulting libraries to:

`android/app/src/main/jniLibs/<abi>/libwarp_api_ffi.so`

Do not enable spending merely because the library builds. Install the exact Ycash
proving assets required by the backend and pass address, sync, transaction,
consensus and broadcast acceptance tests on test infrastructure first.
