# Phase 39 — Transaction Builder Integration

## Implemented
- Phase 38 validation is retained as a hard precondition.
- The exact vendored `zcash_primitives::transaction::builder::Builder` type is linked behind `ycash-transaction`.
- The exact vendored `zcash_proofs::prover::LocalTxProver` type is linked behind the same feature.
- The integration is configured to use upstream `Builder::new`, `add_sapling_spend`, `add_sapling_output`, and `build` rather than manual transaction serialization.
- CI now checks both the default backend and the transaction-builder feature.

## Not yet proven
- Database bytes have not yet been decoded into upstream Sapling `Note`, `MerklePath`, `Anchor`, and key types.
- Wallet key handles have not yet been connected to a concrete Rust key vault.
- A real transaction has not yet been built because those decoded/key-vault inputs are required.
- No transaction has yet been accepted by `ycashd` regtest.

## Safety gate
Mainnet spending remains disabled until a generated transaction compiles, is constructed using the exact Ycash-compatible stack, and passes independent `ycashd` acceptance testing.
