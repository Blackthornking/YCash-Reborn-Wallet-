# Rust ↔ Flutter FFI implementation status

Implemented in this revision:

- Rust `cdylib` C ABI for wallet lifecycle.
- OS-random 24-word BIP-39 wallet creation in Rust.
- Mnemonic restore validation in Rust.
- Mnemonic export across the native boundary for the onboarding backup flow.
- Native string ownership/freeing API.
- Rust mnemonic state zeroized on wipe.
- Dart `dart:ffi` bindings.
- `YcashCoreFfiEngine` adapter implementing the Flutter `YcashEngine` contract.
- `engineProvider` is now overridden at app startup.
- Android Gradle builds `libycash_core.so` for arm64-v8a, armeabi-v7a and x86_64.
- GitHub Actions installs Rust Android targets, cargo-ndk and protoc.

Not implemented / deliberately fail-closed:

- Ycash address derivation
- Lightwallet synchronization
- Balance discovery
- Transaction construction
- Sapling spending proofs
- Transaction broadcast

These remain disabled because the current project itself marks exact Ycash
cryptographic dependencies and compatibility tests as prerequisites. A UI or
FFI bridge must not pretend these operations are working before that validation.
