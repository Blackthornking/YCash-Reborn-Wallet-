# Security upgrade

This build replaces PBKDF2 PIN verification with native Rust Argon2id (64 MiB, 3 iterations, 32-byte output) and a per-PIN 128-bit random salt. The serialized verifier is encrypted with a non-exportable AES-256-GCM key in Android Keystore before being stored through Flutter secure storage. Android FLAG_SECURE is enabled for the wallet activity, blocking screenshots, screen recording, and sensitive recents previews.

The Keystore implementation is device-backed when the platform provides a hardware-backed Android Keystore implementation; the app does not claim StrongBox availability universally.
