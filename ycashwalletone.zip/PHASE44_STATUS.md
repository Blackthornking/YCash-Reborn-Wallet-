# Phase 44 Status — Source-Verified Upstream Scanner Adapter

Phase 44 verifies the vendored NU61 scanning API and introduces the concrete adapter boundary between Phase 43 raw compact-block transport and the upstream scanner.

## Verified upstream
The vendored `zcash_client_backend` contains scanning types including `ScanningKey`, `ScanningKeys`, `Nullifiers`, and block scanning functions.

## Fail-closed status
The adapter does not hand-parse raw compact-block bytes. Generated lightwallet protobuf types and real wallet scanning keys are still required before `zcash_client_backend` can scan a block.

No unauthenticated note can enter authenticated storage.

## Next
Phase 45: integrate generated lightwallet protobuf `CompactBlock` types and scanning keys, then execute real upstream trial decryption against regtest compact blocks.
