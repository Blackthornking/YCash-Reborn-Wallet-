# Phase 53 — Android native backend integration

This phase wires the project for reproducible Android Rust builds and prepares the
Flutter/Rust boundary for a real Ycash light-wallet backend.

## What is wired

- Android Gradle invokes `cargo ndk` before `preBuild`.
- ABI outputs are expected under `android/app/src/main/jniLibs/<abi>/libycash_core.so`.
- The Dart host loads `libycash_core.so` through `dart:ffi`.
- The Rust crate pins vendored Ycash/librustzcash sources behind explicit features.
- A GitHub Actions workflow installs Rust Android targets, NDK tooling and runs the
  native build before the Flutter APK build.

## Security gate

`Send`, `Broadcast`, `Shield`, `Unshield`, and balance claims remain disabled until:

1. deterministic Ycash address vectors pass;
2. compact-block scanning is validated against a Ycash lightwalletd endpoint;
3. received-note and UTXO accounting matches an independent wallet;
4. transaction bytes are accepted by an independent Ycash node/lightwallet stack;
5. Sapling proofs/signatures pass independent verification;
6. Android ABI builds and end-to-end tests pass on arm64-v8a and armeabi-v7a.

A syntactically plausible `ys1…` address is **not** enough to promote address
ownership or spending functionality.

## Build locally

```bash
rustup target add aarch64-linux-android armv7-linux-androideabi x86_64-linux-android
cargo install cargo-ndk --locked
cd packages/ycash_core_ffi/rust
cargo ndk -t arm64-v8a -t armeabi-v7a -t x86_64 -o ../../../android/app/src/main/jniLibs build --release
flutter build apk --release
```

If the vendored Ycash dependency graph requires a specific Rust version, use the
version pinned by the vendored upstream `rust-toolchain.toml` rather than silently
upgrading cryptographic dependencies.
