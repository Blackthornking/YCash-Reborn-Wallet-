# Phase 22 — Installable Validation & CI

## Completed

- Fixed Phase 21 duplicate Rust test module.
- Replaced stale `PIN_BEFORE_PRODUCTION` integration records with the Phase 20 pinned revisions.
- Added a GitHub Actions Rust validation workflow.
- CI installs the stable Rust toolchain and `protobuf-compiler` before running tests.
- Added a fixture policy that prevents invented cryptographic test vectors.
- Engine version advanced to `0.7.0-phase22`.

## Local environment result

Rust installation was attempted in the packaging sandbox, but the sandbox cannot resolve `sh.rustup.rs`, so no Rust toolchain could be installed or tests executed locally. This is an environment limitation, not a passing test result.

## Next gate

Run CI on GitHub. If the pinned dependency revisions fetch and compile, record the exact build output and then add reproducible Ycash vectors before implementing wallet-owned Sapling addresses.
