# iOS Runner

This directory reserves the iOS host integration point.

Generate the official Flutter iOS Runner files from the project root:

    flutter create --platforms=ios .

Then configure the Rust XCFramework/native library bridge and iOS entitlements.
