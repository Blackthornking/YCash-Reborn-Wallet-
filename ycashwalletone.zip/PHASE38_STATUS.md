# Phase 38 — Ycash Transaction Stack Integration

## Completed source integration
- Vendored the uploaded `librustzcash-nu61` workspace under `upstream/vendor/librustzcash-ycash-nu61`.
- Added feature-gated path dependencies for `zcash_primitives`, `zcash_proofs`, and `zcash_keys`.
- Added a Rust-only `SpendingKeyResolver` boundary so secret keys are not passed through Flutter FFI.
- Added fail-closed transaction-stack validation.

## Not yet proven
- This environment has no `cargo`, so no Rust compilation was executed here.
- Exact wallet key-vault encoding is still required for concrete key reconstruction.
- Ycash consensus parameter mapping and transaction serialization must be validated against `ycashd`.
- Mainnet spending remains disabled.

## Phase 39 gate
Phase 39 may call the concrete upstream transaction builder only after the vendored workspace compiles in CI and the exact key/witness encodings are mapped.
