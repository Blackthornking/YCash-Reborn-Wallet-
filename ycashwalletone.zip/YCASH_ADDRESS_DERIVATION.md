# Ycash deterministic address derivation

Wallet creation and restoration use the same mnemonic as the only wallet-secret input to the vendored Ycash Warp backend:

`BIP39 mnemonic -> BIP39 seed (inside backend path) -> ZIP-32 Sapling account derivation -> diversifier/receiver -> Ycash ys1... address`

The Ycash upstream chain parameters specify SLIP-0044 coin type 347 and the mainnet Sapling payment-address HRP `ys`. ZIP-32 defines the hardened account path semantics `m_Sapling / 32' / coin_type' / account'`.

The Flutter layer does not implement Sapling key arithmetic. It only passes the mnemonic to the pinned backend and rejects any returned shielded address that does not begin with `ys1`.

## Required acceptance tests before real-fund release

1. Create wallet, record mnemonic and first `ys1...` address.
2. Delete only the wallet database/application state.
3. Restore the recorded mnemonic.
4. Verify the restored first `ys1...` address is byte-for-byte identical.
5. Verify the backend reports Ycash coin/network selection.
6. Sync against a Ycash lightwalletd and verify a funded test address is detected.
7. Run a send/receive transaction only after prover assets and Ycash network acceptance tests pass.

Do not enable spending merely because address derivation succeeds.
