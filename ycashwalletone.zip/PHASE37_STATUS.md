# Phase 37 Status — Source-Verified Transaction Integration

## Implemented
- Exact vendored `sapling-crypto-ycash` Builder API verified from source.
- Pre-builder validation requires a single common Sapling anchor.
- Transaction plans require a recipient, non-zero amount, and authenticated notes.
- Explicit boundary documented between Sapling bundle construction and transaction-wide signing/serialization.

## Not implemented / not claimed
- Opaque database byte decoding into `Note`, `MerklePath`, `Anchor`, or keys.
- Key-vault resolution to `ExtendedSpendingKey`.
- Concrete `SpendProver` / `OutputProver` parameter loading.
- Transaction-wide authorization/binding signatures and Ycash serialization.
- `ycashd` acceptance.
- Mainnet spending.

## Why
The Phase 36 project does not vendor the Ycash-patched transaction layer needed for the transaction-wide portions. Guessing encodings or hand-rolling consensus serialization would be unsafe.
