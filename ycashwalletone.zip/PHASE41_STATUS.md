# Phase 41 — Exact Sapling Scanner Material

## Implemented
- Stores note reconstruction material: diversifier, `pk_d`, and `rcm`.
- Stores all 32 Sapling authentication-path siblings **and direction bits**.
- Rejects partial/legacy 32-byte-only witness blobs for the Phase 41 path.
- Adds schema version 4 and a dedicated `sapling_note_material` table.
- Keeps key material behind the Rust-only vault boundary.

## Not yet claimed
This phase intentionally does not claim successful Groth16 proving, transaction signing,
or node acceptance. Phase 42 must connect scanner output to this exact format and then use
the vendored Ycash upstream APIs to reconstruct consensus types.
