# Phase 36 — Source-Verified Sapling Proving Adapter

## Completed
- Vendored the uploaded `sapling-crypto-ycash` source.
- Bound the exact `Builder`, `SpendProver`, and `OutputProver` API surface.
- Added fail-closed checks for notes, proving parameters, common anchors and key handles.
- Added a regtest-only `ycashd` acceptance harness.

## Not completed
The wallet database currently stores opaque note/key/witness bytes and does not yet reconstruct the exact Ycash `Note`, `MerklePath`, `Anchor`, `ExtendedSpendingKey`, and `PaymentAddress` objects required by the builder. Transaction-wide authorization, binding signatures, and exact Ycash transaction serialization also require integration with the matching Ycash/librustzcash transaction layer.

Therefore this phase does **not** enable real spending and does not claim Groth16 proofs or signatures are emitted.
