# Phase 36

This release replaces the guessed remote Sapling dependency with the uploaded, vendored Ycash Sapling source and adds source-verified API bindings plus a regtest acceptance harness.

The next implementation phase must perform exact byte-to-type reconstruction and integrate the matching Ycash transaction layer. Mainnet spending remains disabled.
