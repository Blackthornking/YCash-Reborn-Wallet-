# Startup Screen

The app startup screen now uses `assets/branding/startup_page.png` as the full-screen branded splash artwork.
The Android native launch background also uses the same artwork to avoid flashing the previous logo before Flutter renders.
