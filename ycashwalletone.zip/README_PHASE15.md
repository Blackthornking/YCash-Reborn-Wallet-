# Ycash Reborn Phase 15

This package advances the Rust architecture to the point where the real Ycash
Sapling backend can be plugged in without leaking cryptographic internals into
Flutter.

The remaining cryptographic integration must be pinned to exact Ycash-compatible
source revisions and tested before real funds are accepted.
