# Halo2 dependency recovery

Vendored the supplied Orchard and Halo2 source trees and redirected the active Cargo patch roots to local paths to avoid the yanked crates.io `halo2_gadgets 0.4.0` resolution.
