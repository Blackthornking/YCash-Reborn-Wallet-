import 'package:flutter/material.dart';

class ContactsScreen extends StatefulWidget {
  const ContactsScreen({super.key});
  @override State<ContactsScreen> createState() => _ContactsScreenState();
}
class _Contact { String name; String address; bool shielded; bool favorite; _Contact(this.name,this.address,this.shielded,{this.favorite=false}); }
class _ContactsScreenState extends State<ContactsScreen> {
  final List<_Contact> _contacts=[];
  String _query='';
  @override Widget build(BuildContext context) {
    final list=_contacts.where((c)=>c.name.toLowerCase().contains(_query.toLowerCase())||c.address.contains(_query)).toList()..sort((a,b)=>(b.favorite?1:0).compareTo(a.favorite?1:0));
    return Scaffold(appBar: AppBar(title: const Text('Contacts')), floatingActionButton: FloatingActionButton.extended(onPressed:_add,icon:const Icon(Icons.person_add_alt_1),label:const Text('Add contact')), body: Column(children:[
      Padding(padding:const EdgeInsets.fromLTRB(16,8,16,8),child:TextField(onChanged:(v)=>setState(()=>_query=v),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Search contacts or addresses'))),
      Expanded(child:list.isEmpty?const Center(child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(Icons.contacts_outlined,size:52),SizedBox(height:12),Text('No contacts yet',style:TextStyle(fontWeight:FontWeight.w800,fontSize:18)),SizedBox(height:6),Text('Save trusted addresses to make sending safer.')])):ListView.separated(padding:const EdgeInsets.all(16),itemCount:list.length,separatorBuilder:(_,__)=>const SizedBox(height:8),itemBuilder:(_,i){final c=list[i];return Card(child:ListTile(leading:CircleAvatar(child:Icon(c.shielded?Icons.shield:Icons.visibility_outlined)),title:Text(c.name),subtitle:Text('${c.shielded?'Shielded':'Transparent'} • ${_short(c.address)}'),trailing:IconButton(icon:Icon(c.favorite?Icons.star:Icons.star_border),onPressed:()=>setState(()=>c.favorite=!c.favorite)));})) )
    ]));
  }
  String _short(String a)=>a.length>24?'${a.substring(0,12)}…${a.substring(a.length-8)}':a;
  Future<void> _add() async { final name=TextEditingController();final address=TextEditingController();bool shielded=true;final result=await showDialog<_Contact>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setLocal)=>AlertDialog(title:const Text('Add contact'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Name')),TextField(controller:address,decoration:const InputDecoration(labelText:'Ycash address')),SwitchListTile(value:shielded,onChanged:(v)=>setLocal(()=>shielded=v),title:const Text('Shielded address'))]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(ctx,_Contact(name.text.trim(),address.text.trim(),shielded)),child:const Text('Save'))])));if(result!=null&&result.name.isNotEmpty&&result.address.isNotEmpty)setState(()=>_contacts.add(result)); }
}
