package com.ycashfoundation.ycashreborn

import io.flutter.embedding.android.FlutterFragmentActivity

/**
 * local_auth requires a FragmentActivity so Android biometric/device
 * authentication can attach its fragment correctly.
 */
class MainActivity : FlutterFragmentActivity()
