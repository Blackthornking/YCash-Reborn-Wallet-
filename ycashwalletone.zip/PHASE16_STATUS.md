# Phase 16 — Ycash Read-Only Integration

## Implemented in this package

- Strict Ycash Sapling Bech32 network validation using HRP `ys`.
- Read-only compact-block sync planning and progress accounting.
- TLS light-wallet transport boundary retained from Phase 14.
- Auditable source-snapshot identifiers for the supplied librustzcash and
  zcash-sync archives.
- Stable FFI engine capability reporting.
- Explicit separation between read-only sync and spending.

## Deliberately NOT enabled

- Sapling spending-key derivation from the new mnemonic format.
- Trial decryption against production compact blocks.
- Spend/output proof generation.
- Shield, send, unshield, or broadcast operations.

Those operations require exact Ycash-compatible Sapling transaction code,
branch/version rules, proving parameters, and end-to-end tests. A syntactic
`ys...` validator is not a wallet address generator.

## Production gate before real funds

1. Pin exact Ycash Foundation crate revisions (not floating branches).
2. Build reproducibly for Android and iOS.
3. Verify address/key test vectors against ycashd/Ycash reference software.
4. Scan known compact-block fixtures and compare notes/balances.
5. Validate transaction bytes and signatures against Ycash nodes.
6. Test reorg/rewind and nullifier-migration flows.
7. Obtain an independent security review before enabling spending.
