# Phase 15 — Ycash Sapling Integration Gate

## Added
- Sapling backend interface that keeps cryptography behind a narrow boundary.
- Address/key import capability model.
- Compact-block scanner progress model.
- Ycash-specific nullifier migration transaction policy boundary.

## Required before production spending is enabled
1. Pin exact reviewed commits of Ycash Foundation `sapling-crypto-ycash` and compatible `librustzcash-nu61`.
2. Compile against those exact revisions.
3. Validate `ys...` encoding against Ycash vectors and a Ycash node/lightwallet server.
4. Validate trial decryption, note commitments, witnesses, anchors and nullifiers.
5. Run restore tests against known Ycash wallets.
6. Run shielding, shielded transfer and unshielding tests on a controlled environment before mainnet release.

No fake address generation or transaction signing is enabled by this phase.
