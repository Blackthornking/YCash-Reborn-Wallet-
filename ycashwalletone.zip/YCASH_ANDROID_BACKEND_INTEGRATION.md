# Ycash Android backend integration status

This project now has a single runtime capability manifest between Flutter and
Rust. The UI must use this manifest to decide what can be advertised as live.

## Pinned sources

The project vendors Ycash-specific sources recorded in `YCASH_UPSTREAM_LOCK.toml`:

- `ycashfoundation/librustzcash-nu61`
- `ycashfoundation/sapling-crypto-ycash`
- `ycashfoundation/zcash-sync`

These are pinned rather than fetched from a floating branch.

## Current safety gate

The following are **not promoted to production** merely because source code is
present:

- Sapling address derivation
- light-wallet scanning
- note/UTXO ownership detection
- transaction construction
- proving/signing
- broadcast

Each requires deterministic Ycash vectors and a real acceptance test against a
controlled Ycash node/lightwallet environment.

## Required promotion sequence

1. Build the Rust cdylib for all Android ABIs.
2. Run the upstream lock verifier and source hashes.
3. Add known mnemonic -> `ys1...` and `s1...` address vectors from an
   independently generated Ycash wallet.
4. Add compact-block sync fixtures and balance/history assertions.
5. Construct transactions on a regtest/private controlled environment.
6. Verify serialization and txid independently.
7. Broadcast and confirm only after the above pass.
8. Only then set the corresponding backend capability to true.

## Security rule

A button may display wallet data only when the corresponding backend capability
is true. Spending and broadcast remain fail-closed until proving and transaction
acceptance tests pass.
