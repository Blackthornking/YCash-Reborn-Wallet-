# Phase 32 Status — Ycash Sapling Integration & Validation Harness

## Implemented in this package
- Pinned `sapling-crypto-ycash` dependency remains fixed to the recorded revision.
- `ycash-sapling` feature provides a compile-time integration boundary.
- Spending state remains fail-closed.
- Transaction plans are validated before backend invocation.
- `ProvenAndSigned` and `NodeAccepted` remain distinct states.
- CI checks both the default build and the Ycash Sapling feature build.

## NOT implemented / NOT claimed
- Production Sapling spend/output construction.
- Groth16 proof generation.
- Spend authorization signatures.
- Binding signatures.
- Final Ycash transaction serialization.
- Independent `ycashd` acceptance.
- Mainnet spending.

## MAINNET SPENDING: DISABLED

Mainnet spending may only be enabled after generated transactions are accepted by an
independent Ycash consensus node and deterministic compatibility tests pass.
