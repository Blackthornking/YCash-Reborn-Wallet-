# Test APK signing

The GitHub Actions workflow generates a temporary test keystore during each run, signs the release APK, verifies the APK with `apksigner`, and produces a SHA-256 integrity file.

Do not use the temporary signing key workflow for production releases. A production wallet release must use a permanent, securely backed-up signing key.
