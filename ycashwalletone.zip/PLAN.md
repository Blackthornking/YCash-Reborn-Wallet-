# Ycash Reborn — Project Plan

A ground-up, Ycash-only wallet rebuild: new codebase, new architecture, new
design, one-tap shield/unshield, biometric-gated everywhere it matters — built
on the existing, proven Sapling cryptography engine rather than a
reimplementation of it.

## 0. Why the crypto engine stays, everything else is new

Sapling's cryptography (note commitments, nullifiers, spend/output proofs,
key derivation) is the one part of this app where a subtle bug means lost or
stolen coins, not a crash. That code (`librustzcash`/`orchard` crates + the
`rust/` FFI glue in the original project) is reused, but **trimmed hard**:

- Remove Orchard entirely (Ycash never activated it).
- Remove Unified Addresses / UA logic (Ycash uses Sapling + transparent only).
- Remove Ledger hardware wallet support (Ycash coin config never enabled it).
- Remove all Zcash mainnet/testnet coin definitions — this app supports
  exactly one coin.
- Keep: Sapling shielded pool, transparent pool, shield/unshield transaction
  building, warp-sync against `lite.ycash.xyz:9067`.

Everything above the crypto boundary — app architecture, state management,
UI, theming, navigation, security UX, storage — is written new.

## 1. New architecture

```
lib/
  app/                 # app root, theme wiring, router
  core/
    crypto_bridge/      # thin typed wrapper over the trimmed Rust FFI
    biometrics/          # BiometricGate: single chokepoint for sensitive actions
    secure_storage/      # seed/keys via Keychain/Keystore, never shared_preferences
    models/              # Balance, Account, Tx, ShieldPlan, etc.
  design/                # design tokens: color, type, motion, the new logo
  features/
    onboarding/          # create/restore, seed backup, biometric enrollment
    home/                # balance dashboard (shielded vs transparent, one glance)
    send/                # send flow, biometric confirm before broadcast
    receive/             # QR + address, request-amount
    shield/              # the one-tap shield/unshield flow (see §4)
    transactions/        # history, filters, tx detail
    settings/            # node/server config, backup, security, about
rust/                    # trimmed backend (Sapling-only, Ycash-only)
```

### Dependency modernization (vs. the original app)

| Concern | Old | New |
|---|---|---|
| State management | Mobx + manual stores | Riverpod (compile-safe, testable, less boilerplate) |
| Routing | go_router 11 | go_router latest, typed routes |
| Secrets at rest | shared_preferences | flutter_secure_storage (Keychain/Keystore-backed) |
| Biometrics | local_auth (already good) | local_auth latest, wrapped in one `BiometricGate` |
| QR scanning | legacy scan plugin | mobile_scanner |
| Charts | graphic | fl_chart |
| Motion | none | flutter_animate for the futuristic feel (subtle, not gimmicky) |
| Forms | flutter_form_builder | reactive_forms or plain Form + validators (fewer deps) |

## 2. Security model (biometric gate)

One `BiometricGate` service is the single chokepoint. It is required before:

- revealing the seed phrase or any viewing/spending key,
- confirming a send (after review screen, before broadcast),
- confirming a shield or unshield action,
- changing security-relevant settings (server URL, wipe wallet, export keys).

If biometrics aren't enrolled on the device, it falls back to a PIN the app
manages itself — never silently skips the gate.

## 3. Design direction

- Single-coin app: no coin switcher, no Zcash branding, no Zcash asset files.
- New logo: a minimal "shielded Y" mark — a Y monogram enclosed in a
  hex/shield outline, on a deep space-blue gradient. Works as an adaptive
  icon and as a small in-app mark.
- Palette: deep indigo/space-blue background, electric cyan/violet accent
  for shielded actions, warm amber accent reserved for transparent
  (unshielded) balance — so "which pool is this?" is answerable at a glance.
- Typography: one modern geometric sans throughout; large tabular numerals
  for balances.

## 4. The headline feature: one-tap shield / unshield

Home dashboard shows two balances side by side (Shielded, Transparent) with
a single **"Shield all" / "Unshield all"** action button that appears
whenever the non-preferred pool has spendable funds — no separate menu, no
manual amount entry required for the common case (advanced/partial
amount available one tap deeper). Flow: tap → review (fee, resulting
balances) → biometric confirm → broadcast → progress → done.

## 5. Delivery phases

1. **Plan** — this document. ✅
2. Design system: theme tokens, logo, core reusable widgets.
3. App shell + trimmed Ycash-only coin config + Rust backend trim plan.
4. Onboarding: create/restore wallet, seed backup, biometric enrollment.
5. Home dashboard: shielded/transparent balances, sync status.
6. Send flow with biometric-gated confirmation.
7. Receive flow: QR + address, payment request/amount.
8. Shield/Unshield one-tap flow (the headline feature).
9. Transaction history + detail.
10. Settings: server/node config, backup, security, about.
11. Polish pass: motion, empty states, error states, accessibility.

Each phase lands as real, buildable Dart (and Rust-trim notes) files —
nothing here is a mockup-only exercise. Since this sandbox has no network
access, code is written and structured to build/run in your own Flutter +
Rust dev environment; I can't compile or launch it from here.

## 6. What I'm building next in this conversation

Phase 2 and the start of phase 3: the design tokens/theme, the new logo as
an SVG asset, the trimmed Ycash-only coin config, and the `BiometricGate`
service — the pieces every later screen depends on.
