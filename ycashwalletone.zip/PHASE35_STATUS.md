# Phase 35 — Sync/Database Spend Context Bridge

## Implemented
- Persistent authenticated-note table with commitment, position, anchor, witness, and opaque key handle.
- Fail-closed loader that converts only complete, unspent authenticated records into `SpendContext`.
- No witness, anchor, or spending key is fabricated by the transaction layer.
- Schema version advanced to 3.

## Not implemented
- Blockchain scanner generation of these authenticated records from live Ycash compact/full blocks.
- Real Sapling proving/signing and transaction serialization.
- Independent `ycashd` mempool/consensus acceptance.

## Security invariant
A missing or malformed authenticated record prevents spending; it never falls back to a synthetic witness.
