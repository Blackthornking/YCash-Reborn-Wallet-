# Phase 47 — Regtest CompactBlock Fixture → Scanner → Storage Bridge

## Implemented
- Typed fixture container for **real Ycash regtest** CompactBlock protobuf bytes.
- Fail-closed rejection of empty/fabricated fixture payloads.
- Height and block-hash binding before scanner output can enter the existing storage pipeline.
- No synthetic note ciphertext, decrypted notes, witnesses, or nullifiers are generated.

## Validation status
A real fixture must still be captured from a running Ycash regtest + compatible compact-block/lightwallet service and exercised by CI. This package therefore does **not** claim successful trial decryption or node-validated spending.

## Next gate
Run the fixture through the Phase 46 upstream scanner, persist the resulting authenticated state atomically, then validate commitment-tree/witness reconstruction against regtest.
