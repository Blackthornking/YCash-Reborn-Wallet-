# Modern Wallet UI Update

Implemented in this project:

- Modern main wallet dashboard with total balance and global display currency.
- Separate shielded and transparent balance panels.
- Quick Shield and Unshield actions directly from the main balance page.
- Send and Receive quick actions.
- Privacy/security status panel.
- Pull-to-refresh on the main wallet and transaction history.
- Persistent Light / Dark / System appearance setting.
- Persistent Automatic Shielding preference in Settings.
- Automatic-shield readiness banner when transparent funds are present.
- Modern bottom navigation for Wallet, History, Receive and Settings.
- Transaction history sorted newest-to-oldest and grouped by date.
- Every transaction row shows transaction ID, amount, shielded/unshielded state, date and time.

## Security note

The automatic-shield setting intentionally does not silently broadcast transactions without user authentication. The existing shield flow still requires the wallet's review/authentication protection before funds move. The preference surfaces shield-ready funds immediately on the dashboard.
