# YCash batch Sapling trial-decryption accelerator v2

This version uses the YCash-pinned `sapling-crypto-ycash` implementation as the
accelerated trial-decryption engine rather than maintaining a second hand-rolled
Jubjub implementation inside the legacy `libyec` crate.

## Hot path

1. Convert the wallet's legacy IVKs to canonical bytes.
2. Convert all valid compact outputs in a transaction to YCash Sapling compact
   output descriptions.
3. Use `zcash_note_encryption::batch::try_compact_note_decryption`.
4. `SaplingDomain` uses prepared Jubjub IVK/EPK representations.
5. EPK decoding is batched so field inversion is amortized.
6. `batch_ka_agree_dec` uses the same prepared IVK against the batch of prepared
   EPKs, avoiding repeated IVK fixed-window setup.
7. Batch KDF normalizes shared secrets together.
8. Only actual matches are passed through the existing legacy YCash note parser
   to produce the wallet's existing `Note` and `PaymentAddress` types.

## Why this is better than the previous implementation

The previous accelerator multiplied each EPK with a raw modern scalar and then
batch-normalized the results. The new path uses the YCash Sapling source's own
prepared scalar/base machinery and the upstream batch trial-decryption API.
That moves the optimization to the same abstraction boundary used by the modern
Sapling implementation instead of duplicating curve logic in `libyec`.

## Compatibility

No wallet serialization, transaction serialization, note serialization, KDF
parameters, ciphertext format, witness ordering, or database format is changed.
The legacy YCash parser remains the final authority for constructing wallet notes.
Malformed compact outputs continue to follow the old scanner path by being
excluded from the accelerated candidate set.

## Validation required before release

- `cargo fmt --check`
- `cargo check -p zecwalletlitelib`
- YCash Sapling note-decryption tests
- differential batch-vs-single decryption corpus
- complete historical scan comparison against the legacy scanner
- benchmarks with 1 / 10 / 50 IVKs and 10 / 100 / 1000 outputs
- full Android ARM64 release build
