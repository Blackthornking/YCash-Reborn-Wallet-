# YCash batch Sapling trial-decryption accelerator v2

This version uses the YCash-pinned `sapling-crypto-ycash` implementation as the
accelerated trial-decryption engine rather than maintaining a second hand-rolled
Jubjub implementation inside the legacy `libyec` crate.

## Hot path

1. Convert the wallet's legacy IVKs to canonical bytes and build a
   `PreparedBatchIvks` once per block (`scan_block_internal`), not once per
   transaction, so fixed-window scalar tables are reused across every
   transaction in the block.
2. Flatten every valid compact output from every transaction in the block
   (`scan_block_internal`'s `all_outputs`) into YCash Sapling compact output
   descriptions and convert them all in one call
   (`match_outputs_batch_internal`), rather than one batch call per
   transaction. Matching has no dependency on Merkle-tree/witness state, so
   it's safe to compute for the whole block up front.
3. Use `zcash_note_encryption::batch::try_compact_note_decryption`.
4. `SaplingDomain` uses prepared Jubjub IVK/EPK representations.
5. EPK decoding is batched so field inversion is amortized across every
   output in the block.
6. `batch_ka_agree_dec` uses the same prepared IVK against the batch of prepared
   EPKs, avoiding repeated IVK fixed-window setup.
7. Batch KDF normalizes shared secrets together, again across the whole
   block's outputs rather than one transaction's.
8. The per-block match results are sliced back out per transaction
   (`apply_batch_matches_internal`) so the existing sequential
   witness/commitment-tree bookkeeping still runs one output at a time, in
   the exact original per-transaction, per-output order -- only the
   candidate-matching step above is block-wide. Only actual matches are then
   passed through the existing legacy YCash note parser to produce the
   wallet's existing `Note` and `PaymentAddress` types.

## Why this is better than the previous implementation

The previous accelerator multiplied each EPK with a raw modern scalar and then
batch-normalized the results. The new path uses the YCash Sapling source's own
prepared scalar/base machinery and the upstream batch trial-decryption API.
That moves the optimization to the same abstraction boundary used by the modern
Sapling implementation instead of duplicating curve logic in `libyec`.

## Compatibility

No wallet serialization, transaction serialization, note serialization, KDF
parameters, ciphertext format, witness ordering, or database format is changed.
The legacy YCash parser remains the final authority for constructing wallet notes.
Malformed compact outputs continue to follow the old scanner path by being
excluded from the accelerated candidate set.

## Validation required before release

- `cargo fmt --check`
- `cargo check -p zecwalletlitelib`
- YCash Sapling note-decryption tests
- differential batch-vs-single decryption corpus
- complete historical scan comparison against the legacy scanner
- benchmarks with 1 / 10 / 50 IVKs and 10 / 100 / 1000 outputs
- full Android ARM64 release build
