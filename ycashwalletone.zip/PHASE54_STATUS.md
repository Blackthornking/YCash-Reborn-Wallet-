# Phase 54 status — verified address derivation + lightwallet sync integration

## Added now

- Reproducible Ycash-maintained upstream acquisition script.
- Explicit dependency boundary for the Ycash NU61 Rust stack and Sapling cryptography.
- CI gate that prevents release packaging unless upstream sources are present and the native crate passes a locked compile check.
- Phase 54 acceptance checklist for real addresses and read-only synchronization.

## Still intentionally disabled

- Mainnet spending
- Broadcast
- Shield/unshield transaction construction

Those operations must remain disabled until exact Ycash consensus compatibility is demonstrated.

## Acceptance target

The next build must produce a real `libycash_core.so`, derive addresses using the pinned Ycash backend, and scan compact blocks through a verified Ycash-compatible lightwallet service.
