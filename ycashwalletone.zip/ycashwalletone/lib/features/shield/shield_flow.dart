import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/providers.dart';
import '../../core/biometrics/biometric_gate.dart';
import '../../core/crypto_bridge/ycash_engine.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

/// Which direction the one-tap action moves funds.
enum ShieldDirection { shield, unshield }

/// Runs the full shield/unshield flow: plan -> review -> biometric confirm
/// -> broadcast -> result. Every step after "review" requires a successful
/// [BiometricGate] check; there is no path that broadcasts a shielding
/// transaction without it.
Future<void> runShieldFlow(
  BuildContext context,
  WidgetRef ref, {
  required ShieldDirection direction,
  int? amountZatoshi, // null = act on the whole spendable pool
}) async {
  final engine = ref.read(engineProvider);
  final gate = ref.read(biometricGateProvider);

  // Previously uncaught entirely: a failed planShield/planUnshield RPC
  // (e.g. the lightwalletd request times out) threw straight out of the
  // button's onPressed with no busy indication beforehand and no
  // feedback on failure — from the user's side, the button just did
  // nothing. This now shows a busy overlay while planning and, on
  // failure, a retry-capable error sheet.
  final plan = await _planWithRetry(context, engine, direction, amountZatoshi);
  if (plan == null) return;

  if (!context.mounted) return;
  final confirmed = await showModalBottomSheet<bool>(
    context: context,
    backgroundColor: YColors.spaceSurfaceRaised,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(YRadius.card)),
    ),
    builder: (ctx) => _ReviewSheet(direction: direction, plan: plan),
  );
  if (confirmed != true) return;

  final reason = direction == ShieldDirection.shield
      ? GateReason.confirmShield
      : GateReason.confirmUnshield;
  final auth = await gate.authenticate(reason);

  if (!auth.authenticated) {
    if (auth.error == 'no_biometrics_use_password') {
      if (!context.mounted) return;
      final passwordOk = await _showPinSheet(context, gate);
      if (!passwordOk) return;
    } else {
      // Previously silent on this branch — every other auth failure in
      // the app gets the same haptic warn, this one didn't.
      YHaptics.warn();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(auth.error ?? 'Authentication failed')),
        );
      }
      return;
    }
  }

  try {
    final txId = await engine.broadcastPlannedTx(plan);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            direction == ShieldDirection.shield
                ? 'Shielded — tx $txId'
                : 'Unshielded — tx $txId',
          ),
        ),
      );
    }
  } catch (e) {
    // Same haptic warn used for every other broadcast/send failure.
    YHaptics.warn();
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed: $e')),
      );
    }
  }
}

/// Fetches the shield/unshield plan behind a non-dismissible busy overlay,
/// looping through a retry-capable error sheet on failure instead of
/// letting the exception propagate uncaught. Returns null if the user
/// gives up (dismisses the error sheet) or navigates away mid-fetch.
Future<TxPlan?> _planWithRetry(
  BuildContext context,
  YcashEngine engine,
  ShieldDirection direction,
  int? amountZatoshi,
) async {
  while (true) {
    if (!context.mounted) return null;
    unawaited(showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: YBusyState(label: 'Preparing transaction…'),
      ),
    ));
    try {
      final plan = direction == ShieldDirection.shield
          ? await engine.planShield(amountZatoshi: amountZatoshi)
          : await engine.planUnshield(amountZatoshi: amountZatoshi);
      if (context.mounted) Navigator.of(context, rootNavigator: true).pop();
      return plan;
    } catch (e) {
      if (context.mounted) Navigator.of(context, rootNavigator: true).pop();
      YHaptics.warn();
      if (!context.mounted) return null;
      final verb = direction == ShieldDirection.shield ? 'shield' : 'unshield';
      final retry = await showModalBottomSheet<bool>(
        context: context,
        backgroundColor: YColors.spaceSurfaceRaised,
        shape: const RoundedRectangleBorder(
          borderRadius:
              BorderRadius.vertical(top: Radius.circular(YRadius.card)),
        ),
        builder: (ctx) => YErrorState(
          message: 'Could not prepare the $verb transaction. $e',
          retryLabel: 'Try again',
          onRetry: () => Navigator.of(ctx).pop(true),
        ),
      );
      if (retry != true) return null;
      // loop back around and retry the plan fetch
    }
  }
}

/// Shows a modal password-entry sheet and returns true only once the password
/// verifies. Previously a wrong password just popped `false` with no message
/// at all, indistinguishable from the user deliberately dismissing the
/// sheet — the whole shield/unshield attempt would silently vanish with
/// no explanation. Now a wrong password keeps the sheet open with an inline,
/// haptic-backed error so retrying is just typing again, and only an
/// explicit Cancel (or dismissing the sheet) exits without one.
Future<bool> _showPinSheet(BuildContext context, BiometricGate gate) async {
  final result = await showModalBottomSheet<bool>(
    context: context,
    backgroundColor: YColors.spaceSurfaceRaised,
    isScrollControlled: true,
    builder: (ctx) => _PinSheetContent(gate: gate),
  );
  return result ?? false;
}

class _PinSheetContent extends StatefulWidget {
  final BiometricGate gate;
  const _PinSheetContent({required this.gate});

  @override
  State<_PinSheetContent> createState() => _PinSheetContentState();
}

class _PinSheetContentState extends State<_PinSheetContent> {
  final _controller = TextEditingController();
  String? _error;
  bool _checking = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() {
      _checking = true;
      _error = null;
    });
    try {
      final ok = await widget.gate.verifyPassword(_controller.text);
      if (!mounted) return;
      if (ok) {
        Navigator.of(context).pop(true);
        return;
      }
      YHaptics.warn();
      setState(() {
        _checking = false;
        _error = 'Incorrect password';
      });
    } catch (e) {
      if (!mounted) return;
      YHaptics.warn();
      setState(() {
        _checking = false;
        _error = e.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: YSpacing.lg,
        right: YSpacing.lg,
        top: YSpacing.lg,
        bottom: MediaQuery.of(context).viewInsets.bottom + YSpacing.lg,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('Enter your password to confirm'),
          const SizedBox(height: YSpacing.md),
          TextField(
            controller: _controller,
            obscureText: true,
            keyboardType: TextInputType.visiblePassword,
            autofocus: true,
            onSubmitted: (_) => _checking ? null : _submit(),
          ),
          if (_error != null) ...[
            const SizedBox(height: YSpacing.sm),
            Semantics(
              liveRegion: true,
              child: Text(_error!,
                  style: const TextStyle(color: YColors.danger, fontSize: 12)),
            ),
          ],
          const SizedBox(height: YSpacing.md),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _checking ? null : _submit,
              child: _checking
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Confirm'),
            ),
          ),
        ],
      ),
    );
  }
}

class _ReviewSheet extends StatelessWidget {
  final ShieldDirection direction;
  final TxPlan plan;
  const _ReviewSheet({required this.direction, required this.plan});

  @override
  Widget build(BuildContext context) {
    final title = direction == ShieldDirection.shield
        ? 'Shield funds'
        : 'Unshield funds';
    return Padding(
      padding: const EdgeInsets.all(YSpacing.lg),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: YSpacing.md),
          // Staggered like the send-flow review sheet, instead of every
          // row snapping in at once on top of the sheet's own slide-up.
          YEnter(child: _row('Amount', '${plan.amountZatoshi / 1e8} YEC')),
          YEnter(
            delay: const Duration(milliseconds: 60),
            child: _row('Network fee', '${plan.feeZatoshi / 1e8} YEC'),
          ),
          const Divider(height: YSpacing.xl),
          YEnter(
            delay: const Duration(milliseconds: 100),
            child: _row('Shielded after',
                '${plan.resultingBalances.shieldedZatoshi / 1e8} YEC'),
          ),
          YEnter(
            delay: const Duration(milliseconds: 140),
            child: _row('Transparent after',
                '${plan.resultingBalances.transparentZatoshi / 1e8} YEC'),
          ),
          const SizedBox(height: YSpacing.lg),
          YEnter(
            delay: const Duration(milliseconds: 180),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: const Text('Continue'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _row(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: YSpacing.xs),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(color: YColors.textSecondary)),
            Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      );
}
