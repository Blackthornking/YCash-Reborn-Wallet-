import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/biometrics/biometric_gate.dart';
import '../../core/providers.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

/// Full-screen gate shown over the rest of the app whenever
/// [walletLockedProvider] is true (see app.dart, which arms it based on
/// the auto-lock timeout).
///
/// Deliberately password-only, with no biometric shortcut — the wallet
/// should *always* ask for the password to unlock, per how this was
/// specced. Every other biometric-gated action in the app (reveal seed,
/// send, change password, wipe) is a separate, unaffected flow that still
/// tries biometrics first.
class AppLockScreen extends ConsumerStatefulWidget {
  const AppLockScreen({super.key});

  @override
  ConsumerState<AppLockScreen> createState() => _AppLockScreenState();
}

class _AppLockScreenState extends ConsumerState<AppLockScreen> {
  final _controller = TextEditingController();
  bool _submitting = false;
  String? _error;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _unlock() async {
    final password = _controller.text;
    if (password.isEmpty) return;
    setState(() {
      _submitting = true;
      _error = null;
    });
    try {
      final gate = ref.read(biometricGateProvider);
      final ok = await gate.verifyPassword(password);
      if (!mounted) return;
      if (!ok) {
        YHaptics.warn();
        setState(() {
          _submitting = false;
          _error = 'Incorrect password';
        });
        return;
      }
      _controller.clear();
      // Flipping this to false is what removes this screen from the tree
      // — see app.dart's builder — so there's nothing further to
      // navigate here. Belt-and-suspenders reset of _submitting anyway,
      // in case this widget is ever kept mounted a moment longer than
      // expected: a lesson from an earlier bug where a success path that
      // never reset a "saving" flag left a button stuck forever.
      setState(() => _submitting = false);
      ref.read(walletLockedProvider.notifier).state = false;
    } catch (e) {
      YHaptics.warn();
      if (mounted) {
        setState(() {
          _submitting = false;
          _error = e is PasswordLockedOutException || e is PasswordRecordInvalidatedException
              ? e.toString()
              : 'Could not verify password. Please try again.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // canPop: false — this is an overlay, not a route, so there's nothing
    // for the system back gesture to legitimately pop to while locked.
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: YColors.spaceDeep,
        body: SafeArea(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => FocusScope.of(context).unfocus(),
            child: Padding(
              padding: const EdgeInsets.all(YSpacing.lg),
              child: Center(
                child: SingleChildScrollView(
                  child: YEnter(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Icon(Icons.lock_outline, size: 64, color: YColors.shieldedPrimary),
                        const SizedBox(height: YSpacing.lg),
                        Text(
                          'Enter your password',
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(color: YColors.textPrimary),
                        ),
                        const SizedBox(height: YSpacing.sm),
                        const Text(
                          'Ycash is locked. Enter your wallet password to continue.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: YColors.textSecondary),
                        ),
                        const SizedBox(height: YSpacing.lg),
                        TextField(
                          controller: _controller,
                          obscureText: true,
                          autofocus: true,
                          enabled: !_submitting,
                          keyboardType: TextInputType.visiblePassword,
                          decoration: const InputDecoration(labelText: 'Wallet password'),
                          onSubmitted: (_) {
                            if (!_submitting) _unlock();
                          },
                        ),
                        if (_error != null) ...[
                          const SizedBox(height: YSpacing.sm),
                          Semantics(
                            liveRegion: true,
                            child: Text(_error!, style: const TextStyle(color: YColors.danger)),
                          ),
                        ],
                        const SizedBox(height: YSpacing.lg),
                        ElevatedButton(
                          onPressed: _submitting ? null : _unlock,
                          child: Text(_submitting ? 'Please wait…' : 'Unlock'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
