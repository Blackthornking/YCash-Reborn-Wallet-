import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/biometrics/biometric_gate.dart';
import '../../core/providers.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

/// Full-screen gate shown over the rest of the app whenever
/// [walletLockedProvider] is true (see app.dart, which arms it based on
/// the auto-lock timeout).
///
/// Deliberately password-only, with no biometric shortcut — the wallet
/// should *always* ask for the password to unlock, per how this was
/// specced. Every other biometric-gated action in the app (reveal seed,
/// send, change password, wipe) is a separate, unaffected flow that still
/// tries biometrics first.
///
/// The native engine's wallet session lives entirely in this process and
/// is never reopened automatically — [YcashCoreFfiEngine.openOrCreateWallet]
/// is only ever called during onboarding (create or restore). On every
/// fresh app process that starts already-onboarded (the normal case after
/// an auto-lock or app relaunch), this screen is therefore the one place
/// that re-derives the seed from [SeedVault] and reopens the native
/// session — via the same `restoreSeedPhrase` path onboarding's restore
/// flow uses — before letting the rest of the app back in. Simply
/// flipping [walletLockedProvider] to false without doing this leaves the
/// native engine believing no wallet is open, so every call that requires
/// an open session (balances, addresses, sync status, ...) throws.
class AppLockScreen extends ConsumerStatefulWidget {
  const AppLockScreen({super.key});

  @override
  ConsumerState<AppLockScreen> createState() => _AppLockScreenState();
}

class _AppLockScreenState extends ConsumerState<AppLockScreen> {
  final _controller = TextEditingController();
  bool _submitting = false;
  String? _error;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _unlock() async {
    final password = _controller.text;
    if (password.isEmpty) return;
    setState(() {
      _submitting = true;
      _error = null;
    });
    try {
      // SeedVault.readWithPassword checks the password against the same
      // throttled record gate.verifyPassword uses internally, so a wrong
      // guess here still counts toward the lockout — there's no need to
      // call gate.verifyPassword separately first. The auth argument only
      // asserts "some authentication already happened"; this screen's
      // whole purpose *is* that authentication, so it's synthesized here
      // rather than obtained from a separate biometric prompt.
      final vault = ref.read(seedVaultProvider);
      final seed = await vault.readWithPassword(const BiometricAuthResult(true), password);

      // Password was correct. Re-derive the native wallet session from the
      // seed we just decrypted — this is the step that was previously
      // missing, which is what left getBalances()/getShieldedAddress()/
      // watchSyncStatus() throwing "Wallet is not open" after unlock on a
      // fresh app process. A failure past this point (e.g. no network to
      // reach lightwalletd) is a different problem from a wrong password,
      // so it's reported separately below rather than as "Incorrect
      // password" — the password was fine.
      try {
        final engine = ref.read(engineProvider);
        await engine.openOrCreateWallet(restoreSeedPhrase: seed);
      } catch (e) {
        YHaptics.warn();
        if (mounted) {
          setState(() {
            _submitting = false;
            _error = 'Password correct, but the wallet could not be reopened: $e';
          });
        }
        return;
      }

      if (!mounted) return;
      _controller.clear();
      // Flipping this to false is what removes this screen from the tree
      // — see app.dart's builder — so there's nothing further to
      // navigate here. Belt-and-suspenders reset of _submitting anyway,
      // in case this widget is ever kept mounted a moment longer than
      // expected: a lesson from an earlier bug where a success path that
      // never reset a "saving" flag left a button stuck forever.
      setState(() => _submitting = false);
      ref.read(walletLockedProvider.notifier).state = false;
    } catch (e) {
      YHaptics.warn();
      if (mounted) {
        setState(() {
          _submitting = false;
          if (e is PasswordLockedOutException || e is PasswordRecordInvalidatedException) {
            _error = e.toString();
          } else if (e is StateError && e.message == 'Incorrect password') {
            _error = 'Incorrect password';
          } else {
            _error = 'Could not verify password. Please try again.';
          }
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // canPop: false — this is an overlay, not a route, so there's nothing
    // for the system back gesture to legitimately pop to while locked.
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: YColors.spaceDeep,
        body: SafeArea(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => FocusScope.of(context).unfocus(),
            child: Padding(
              padding: const EdgeInsets.all(YSpacing.lg),
              child: Center(
                child: SingleChildScrollView(
                  child: YEnter(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Icon(Icons.lock_outline, size: 64, color: YColors.shieldedPrimary),
                        const SizedBox(height: YSpacing.lg),
                        Text(
                          'Enter your password',
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(color: YColors.textPrimary),
                        ),
                        const SizedBox(height: YSpacing.sm),
                        const Text(
                          'Ycash is locked. Enter your wallet password to continue.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: YColors.textSecondary),
                        ),
                        const SizedBox(height: YSpacing.lg),
                        TextField(
                          controller: _controller,
                          obscureText: true,
                          autofocus: true,
                          enabled: !_submitting,
                          keyboardType: TextInputType.visiblePassword,
                          decoration: const InputDecoration(labelText: 'Wallet password'),
                          onSubmitted: (_) {
                            if (!_submitting) _unlock();
                          },
                        ),
                        if (_error != null) ...[
                          const SizedBox(height: YSpacing.sm),
                          Semantics(
                            liveRegion: true,
                            child: Text(_error!, style: const TextStyle(color: YColors.danger)),
                          ),
                        ],
                        const SizedBox(height: YSpacing.lg),
                        ElevatedButton(
                          onPressed: _submitting ? null : _unlock,
                          child: Text(_submitting ? 'Please wait…' : 'Unlock'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
