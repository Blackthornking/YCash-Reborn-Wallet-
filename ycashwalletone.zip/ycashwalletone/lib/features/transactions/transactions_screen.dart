import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../core/crypto_bridge/ycash_engine.dart';
import '../../core/providers.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

enum _Filter { all, sent, received, shielded, transparent }

class TransactionsScreen extends ConsumerStatefulWidget {
  const TransactionsScreen({super.key});

  @override
  ConsumerState<TransactionsScreen> createState() =>
      _TransactionsScreenState();
}

class _TransactionsScreenState extends ConsumerState<TransactionsScreen> {
  _Filter _filter = _Filter.all;
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final history = ref.watch(transactionHistoryProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Activity')),
      body: history.when(
        data: (txs) {
          var ordered = [...txs]
            ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
          ordered = ordered.where(_matches).toList();

          final groups = <String, List<TxRecord>>{};
          for (final tx in ordered) {
            final key =
                DateFormat('yyyy-MM-dd').format(tx.timestamp.toLocal());
            groups.putIfAbsent(key, () => <TxRecord>[]).add(tx);
          }

          final keys = groups.keys.toList();

          return RefreshIndicator(
            onRefresh: () async {
              ref.invalidate(transactionHistoryProvider);
              await Future<void>.delayed(
                const Duration(milliseconds: 350),
              );
            },
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              children: [
                TextField(
                  onChanged: (value) => setState(() => _query = value),
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    hintText: 'Search transaction ID or memo',
                  ),
                ),
                const SizedBox(height: 12),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: _Filter.values
                        .map(
                          (filter) => Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: ChoiceChip(
                              label: Text(_label(filter)),
                              selected: _filter == filter,
                              onSelected: (_) =>
                                  setState(() => _filter = filter),
                            ),
                          ),
                        )
                        .toList(),
                  ),
                ),
                const SizedBox(height: 8),
                if (keys.isEmpty)
                  const Padding(
                    padding: EdgeInsets.only(top: 60),
                    child: YEmptyState(
                      icon: Icons.receipt_long_outlined,
                      title: 'No matching transactions',
                      subtitle:
                          'Try another filter or pull down to refresh.',
                    ),
                  ),
                ...keys.expand(
                  (key) => <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(
                        top: 14,
                        bottom: 8,
                      ),
                      child: Text(
                        _dayLabel(groups[key]!.first.timestamp),
                        style: TextStyle(
                          color: Theme.of(context).hintColor,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ),
                    ...groups[key]!.map(
                      (tx) => Padding(
                        padding: const EdgeInsets.only(bottom: 9),
                        child: _HistoryCard(tx: tx),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
        loading: () => const Center(
          child: YBusyState(label: 'Loading activity'),
        ),
        error: (_, __) => Center(
          child: YErrorState(
            message: 'Could not load transaction history.',
            onRetry: () => ref.invalidate(transactionHistoryProvider),
          ),
        ),
      ),
    );
  }

  bool _matches(TxRecord tx) {
    final query = _query.toLowerCase();

    if (query.isNotEmpty &&
        !tx.txId.toLowerCase().contains(query) &&
        !(tx.memo ?? '').toLowerCase().contains(query)) {
      return false;
    }

    return switch (_filter) {
      _Filter.all => true,
      _Filter.sent => tx.amountZatoshi < 0,
      _Filter.received => tx.amountZatoshi >= 0,
      _Filter.shielded => tx.isShielded,
      _Filter.transparent => !tx.isShielded,
    };
  }

  String _label(_Filter filter) {
    return switch (filter) {
      _Filter.all => 'All',
      _Filter.sent => 'Sent',
      _Filter.received => 'Received',
      _Filter.shielded => 'Shielded',
      _Filter.transparent => 'Transparent',
    };
  }

  String _dayLabel(DateTime value) {
    final day = value.toLocal();
    final now = DateTime.now();
    final yesterday = now.subtract(const Duration(days: 1));

    if (day.year == now.year &&
        day.month == now.month &&
        day.day == now.day) {
      return 'TODAY';
    }

    if (day.year == yesterday.year &&
        day.month == yesterday.month &&
        day.day == yesterday.day) {
      return 'YESTERDAY';
    }

    return DateFormat('EEEE, d MMMM yyyy')
        .format(day)
        .toUpperCase();
  }
}

class _HistoryCard extends StatelessWidget {
  const _HistoryCard({required this.tx});

  final TxRecord tx;

  @override
  Widget build(BuildContext context) {
    final outgoing = tx.amountZatoshi < 0;
    final amount = (tx.amountZatoshi.abs() / 1e8).toStringAsFixed(8);
    final accent =
        tx.isShielded ? YColors.shieldedPrimary : YColors.transparentAccent;
    final pool = tx.isShielded ? 'SHIELDED' : 'TRANSPARENT';
    final status = outgoing ? 'Sent' : 'Received';
    final txNo = tx.txId.length > 18
        ? '${tx.txId.substring(0, 10)}…'
            '${tx.txId.substring(tx.txId.length - 6)}'
        : tx.txId;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: accent.withValues(alpha: .12),
              child: Icon(
                outgoing ? Icons.north_east : Icons.south_west,
                color: accent,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          status,
                          style: const TextStyle(
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: accent.withValues(alpha: .12),
                          borderRadius: BorderRadius.circular(99),
                        ),
                        child: Text(
                          pool,
                          style: TextStyle(
                            color: accent,
                            fontSize: 9,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'TX $txNo',
                    style: TextStyle(
                      color: Theme.of(context).hintColor,
                      fontFamily: 'monospace',
                    ),
                  ),
                  Text(
                    DateFormat('d MMM yyyy • HH:mm')
                        .format(tx.timestamp.toLocal()),
                    style: TextStyle(
                      fontSize: 11,
                      color: Theme.of(context).hintColor,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Text(
              '${outgoing ? '−' : '+'}$amount\nYEC',
              textAlign: TextAlign.end,
              style: TextStyle(
                fontWeight: FontWeight.w900,
                color: outgoing
                    ? Theme.of(context).colorScheme.onSurface
                    : YColors.success,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
