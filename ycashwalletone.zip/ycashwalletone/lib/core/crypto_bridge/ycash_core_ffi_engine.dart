import 'dart:async';
import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:warp_api/warp_api.dart';
import 'package:ycash_core/ycash_core.dart';

import 'ycash_engine.dart';

/// Ycash adapter backed by the upstream ZWallet/YWallet Warp API.
///
/// This deliberately keeps the app's seed vault/authentication boundary
/// separate from the wallet database. The native Warp library owns consensus,
/// scanning and wallet-state operations; Dart never implements Sapling crypto.
class YcashCoreFfiEngine implements YcashEngine {
  YcashCoreFfiEngine({YcashCoreNative? native})
      : _native = native ?? YcashCoreNative.instance;

  // Upstream Warp uses a numeric coin selector. Ycash is selector 1 in the
  // vendored YWallet/ZWallet backend.
  static const int _ycashCoin = 1;
  // Upstream YWallet's Ycash defaults use UA type 2, but Ycash does not
  // currently use Zcash Unified Addresses in the same way. Keep the receiver
  // selection aligned with the vendored Ycash configuration so this resolves
  // to a real Sapling Ycash address.
  static const int _shieldedUa = 2;
  static const String _defaultYcashLwd = 'https://lite.ycash.xyz:9067';

  final YcashCoreNative _native;
  bool _opened = false;
  int _account = 0; // Warp account id; 0 means no active account.
  Timer? _syncPoll;
  final StreamController<SyncStatus> _sync =
      StreamController<SyncStatus>.broadcast();

  Future<String> _dbPath() async {
    final dir = await getApplicationSupportDirectory();
    final walletDir = Directory('${dir.path}/ycash-wallet');
    if (!await walletDir.exists()) await walletDir.create(recursive: true);
    return '${walletDir.path}/wallet.db';
  }

  @override
  Future<void> openOrCreateWallet({String? restoreSeedPhrase}) async {
    // Keep the existing secure seed lifecycle as the source of truth.
    final seed = restoreSeedPhrase?.trim();
    if (seed == null || seed.isEmpty) {
      _native.createWallet();
    } else {
      _native.restoreWallet(seed);
    }
    final mnemonic = _native.exportMnemonic();
    final path = await _dbPath();
    WarpApi.initWallet(_ycashCoin, path);
    // Explicitly pin the upstream Ycash Lightwalletd endpoint. This avoids
    // accidentally inheriting a Zcash endpoint from another Warp instance.
    WarpApi.updateLWD(_ycashCoin, _defaultYcashLwd);

    // Account creation is delegated to the vendored Ycash Warp backend. The
    // mnemonic is therefore the sole deterministic input: restoring the same
    // mnemonic must select the same account and derive the same receivers.
    final first = WarpApi.getFirstAccount(_ycashCoin);
    if (first > 0) {
      _account = first;
    } else {
      _account = await WarpApi.newAccount(
        _ycashCoin,
        'YcashWalletOne',
        mnemonic,
        0,
      );
    }
    if (_account <= 0) {
      throw StateError('Ycash Warp backend failed to create or restore account 0');
    }

    // Fail closed immediately if the backend/network configuration does not
    // derive a Ycash mainnet Sapling receiver. This prevents the UI from ever
    // treating a Zcash `zs...` receiver as a Ycash address.
    final sapling = WarpApi.getAddress(_ycashCoin, _account, _shieldedUa);
    if (!sapling.startsWith('ys1')) {
      throw StateError('Ycash account derivation returned a non-Ycash Sapling address: $sapling');
    }
    _opened = true;
  }

  void _requireOpen() {
    if (!_opened || _account == 0) throw StateError('Wallet is not open');
  }

  @override
  Future<String> exportSeedPhrase() async {
    _requireOpen();
    return _native.exportMnemonic();
  }

  @override
  Future<void> wipeWallet() async {
    _syncPoll?.cancel();
    await _sync.close();
    _native.wipeWallet();
    _opened = false;
    _account = 0;
  }

  @override
  Future<Balances> getBalances() async {
    _requireOpen();
    final height = WarpApi.getDbHeight(_ycashCoin).height;
    final shielded = WarpApi.getBalance(_ycashCoin, _account, height).shielded;
    final transparent = await WarpApi.getTBalance(_ycashCoin, _account);
    return Balances(
      shieldedZatoshi: shielded,
      transparentZatoshi: transparent,
    );
  }

  @override
  Stream<SyncStatus> watchSyncStatus() {
    _requireOpen();
    _syncPoll ??= Timer.periodic(const Duration(seconds: 3), (_) async {
      try {
        final db = WarpApi.getDbHeight(_ycashCoin).height;
        final tip = await WarpApi.getLatestHeight(_ycashCoin);
        _sync.add(SyncStatus(
          syncedHeight: db,
          chainTipHeight: tip,
          isSyncing: db < tip,
        ));
      } catch (_) {
        // Keep the stream alive across temporary network/server failures.
      }
    });
    return _sync.stream;
  }

  /// Starts a real upstream Warp sync. The UI can call this through a
  /// controller/provider without exposing raw FFI elsewhere in the app.
  Future<void> syncNow({String? lightwalletdUrl}) async {
    _requireOpen();
    final endpoint = lightwalletdUrl?.trim();
    WarpApi.updateLWD(
      _ycashCoin,
      endpoint == null || endpoint.isEmpty ? _defaultYcashLwd : endpoint,
    );
    await WarpApi.warpSync(_ycashCoin, _account, true, 10, 0, 0);
    final db = WarpApi.getDbHeight(_ycashCoin).height;
    final tip = await WarpApi.getLatestHeight(_ycashCoin);
    _sync.add(SyncStatus(
      syncedHeight: db,
      chainTipHeight: tip,
      isSyncing: db < tip,
    ));
  }

  @override
  Future<String> getShieldedAddress() async {
    _requireOpen();
    final address = WarpApi.getAddress(_ycashCoin, _account, _shieldedUa);
    // Mainnet Sapling Ycash payment addresses use the ys1 Bech32 prefix.
    // Fail closed instead of displaying an address from the wrong network.
    if (!address.startsWith('ys1')) {
      throw StateError('Warp backend returned a non-Ycash Sapling address: $address');
    }
    return address;
  }

  @override
  Future<String> getTransparentAddress() async {
    _requireOpen();
    final address = WarpApi.getTAddr(_ycashCoin, _account);
    // Ycash transparent mainnet addresses use the s1 prefix.
    if (!address.startsWith('s1')) {
      throw StateError('Warp backend returned a non-Ycash transparent address: $address');
    }
    return address;
  }

  Never _notReady(String operation) => throw UnsupportedError(
        '$operation requires the exact Ycash transaction/prover assets and '
        'network acceptance tests to be installed and passed before enabling spending.',
      );

  @override
  Future<TxPlan> planSend({
    required String toAddress,
    required int amountZatoshi,
    String? memo,
    required String feeTier,
  }) async =>
      _notReady('Sending');

  @override
  Future<String> broadcastPlannedTx(TxPlan plan) async =>
      _notReady('Broadcasting transactions');

  @override
  Future<TxPlan> planShield({int? amountZatoshi}) async =>
      _notReady('Shielding');

  @override
  Future<TxPlan> planUnshield({int? amountZatoshi}) async =>
      _notReady('Unshielding');

  @override
  Future<List<TxRecord>> getTransactionHistory() async {
    _requireOpen();
    final txs = await WarpApi.getTxs(_ycashCoin, _account);
    return txs
        .map((tx) => TxRecord(
              txId: tx.txId ?? tx.shortTxId ?? 'unknown',
              timestamp: DateTime.fromMillisecondsSinceEpoch(tx.timestamp * 1000,
                  isUtc: true),
              amountZatoshi: tx.value,
              isShielded: true,
              memo: tx.memo,
            ))
        .toList(growable: false);
  }
}
