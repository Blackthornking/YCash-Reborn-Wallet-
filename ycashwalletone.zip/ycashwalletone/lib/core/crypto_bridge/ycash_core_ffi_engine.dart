import 'dart:async';
import 'dart:convert';

import 'package:ycash_core/ycash_core.dart';

import 'ycash_engine.dart';

/// Production adapter between the Flutter domain interface and the Rust ABI.
///
/// Only operations backed by verified native functionality are enabled.
/// Android Rust ABI build wiring is present; address derivation, sync and spending
/// deliberately remain fail-closed until exact Ycash compatibility tests pass.
class YcashCoreFfiEngine implements YcashEngine {
  YcashCoreFfiEngine({YcashCoreNative? native})
      : _native = native ?? YcashCoreNative.instance;

  final YcashCoreNative _native;
  bool _opened = false;

  @override
  Future<void> openOrCreateWallet({String? restoreSeedPhrase}) async {
    if (restoreSeedPhrase == null || restoreSeedPhrase.trim().isEmpty) {
      _native.createWallet();
    } else {
      _native.restoreWallet(restoreSeedPhrase.trim());
    }
    _opened = true;
  }

  @override
  Future<String> exportSeedPhrase() async {
    if (!_opened) {
      throw StateError('Wallet is not open');
    }
    return _native.exportMnemonic();
  }

  @override
  Future<void> wipeWallet() async {
    _native.wipeWallet();
    _opened = false;
  }

  Map<String, dynamic>? _readOnlyCapabilities() {
    try {
      final decoded = jsonDecode(_native.readOnlyCapabilitiesJson());
      return decoded is Map<String, dynamic> ? decoded : null;
    } catch (_) {
      return null;
    }
  }

  bool _capabilityEnabled(String capability) {
    final caps = _readOnlyCapabilities();
    return caps?['ycash_verified'] == true && caps?[capability] == true;
  }

  Never _notReady(String operation) {
    throw UnsupportedError(
      '$operation is disabled until exact YCash cryptographic compatibility '
      'and consensus tests pass.',
    );
  }

  @override
  Future<Balances> getBalances() async => const Balances(
        shieldedZatoshi: 0,
        transparentZatoshi: 0,
      );

  @override
  Stream<SyncStatus> watchSyncStatus() =>
      Stream.value(const SyncStatus(
        syncedHeight: 0,
        chainTipHeight: 0,
        isSyncing: false,
      ));

  @override
  Future<String> getShieldedAddress() async {
    if (!_capabilityEnabled('shielded_address')) _notReady('Shielded addresses');
    return _notReady('Shielded addresses'); // native ABI not yet implemented
  }

  @override
  Future<String> getTransparentAddress() async {
    if (!_capabilityEnabled('transparent_address')) _notReady('Transparent addresses');
    return _notReady('Transparent addresses'); // native ABI not yet implemented
  }

  @override
  Future<TxPlan> planSend({
    required String toAddress,
    required int amountZatoshi,
    String? memo,
    required String feeTier,
  }) async =>
      _notReady('Sending');

  @override
  Future<String> broadcastPlannedTx(TxPlan plan) async =>
      _notReady('Broadcasting transactions');

  @override
  Future<TxPlan> planShield({int? amountZatoshi}) async =>
      _notReady('Shielding');

  @override
  Future<TxPlan> planUnshield({int? amountZatoshi}) async =>
      _notReady('Unshielding');

  @override
  Future<List<TxRecord>> getTransactionHistory() async => const [];
}
