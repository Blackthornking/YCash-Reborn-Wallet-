import 'dart:convert';
import 'dart:math';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../biometrics/biometric_gate.dart';

/// Recovery seed storage uses two independent envelopes:
///   seed -> AES-256-GCM(password-derived Argon2id key) -> AES-256-GCM(Android Keystore)
/// The outer key requests StrongBox and falls back to hardware-backed TEE.
class SeedVault {
  SeedVault({FlutterSecureStorage? storage, BiometricGate? gate})
      : _storage = storage ?? const FlutterSecureStorage(),
        _gate = gate ?? BiometricGate();

  final FlutterSecureStorage _storage;
  final BiometricGate _gate;
  static const _seedKey = 'ycash.wallet.seed_phrase.v3';
  static const _legacySeedKey = 'ycash.wallet.seed_phrase.v2';
  static const _backupConfirmedKey = 'ycash.wallet.backup_confirmed';
  // Only for the password-wrap/unwrap AES-GCM calls, which are not
  // Keystore-backed. The Keystore envelope itself goes through
  // [BiometricGate.protect]/[BiometricGate.unprotect] (see below) so it
  // gets the same AUTH_REQUIRED-retry and KEY_INVALIDATED handling as the
  // rest of the app's Keystore-protected records, instead of surfacing a
  // raw PlatformException whenever the Keystore key's unlock window has
  // simply lapsed while wrapping or reading the seed.
  static const _channel = MethodChannel('com.ycashfoundation.ycash/security');

  Future<void> writeWrapped(String seedPhrase, String password) async {
    final salt = List<int>.generate(16, (_) => Random.secure().nextInt(256));
    final saltB64 = base64UrlEncode(salt).replaceAll('=', '');
    // Pin the KDF parameters used for *this* record so it stays decryptable
    // even if BiometricGate's defaults are tuned later.
    final memoryKiB = _gate.currentArgon2MemoryKiB;
    final iterations = _gate.currentArgon2Iterations;
    final parallelism = _gate.currentArgon2Parallelism;
    final key = _gate.derivePasswordKeyWithParams(
      password, saltB64,
      memoryKiB: memoryKiB, iterations: iterations, parallelism: parallelism,
    );
    try {
      final inner = await _channel.invokeMethod<String>('passwordWrap', {
        'plaintext': seedPhrase, 'key': key,
      });
      if (inner == null) throw StateError('Password seed wrapping failed');
      final outer = await _gate.protect(inner);
      final record = jsonEncode({
        'v': 3, 'kdf': 'Argon2id', 'm': memoryKiB, 't': iterations,
        'p': parallelism, 's': saltB64, 'c': outer,
      });
      await _storage.write(key: _seedKey, value: record);
      await _storage.delete(key: _legacySeedKey);
    } finally {
      // Dart strings cannot be reliably zeroized, but do not persist the key.
    }
  }

  Future<String> readWithPassword(BiometricAuthResult auth, String password) async {
    if (!auth.authenticated) throw StateError('SeedVault.read called without authentication');
    // Gate every seed decryption through the same throttled password check
    // used everywhere else, directly here — not just in whichever screen
    // happens to call this. Without this, a caller that skipped its own
    // gate.verifyPassword() check (today's callers don't, but a future one
    // could forget) would let anyone who already has an authenticated
    // session brute-force the wallet password straight against the seed
    // ciphertext, with no exponential lockout at all.
    if (!await _gate.verifyPassword(password)) {
      throw StateError('Incorrect password');
    }
    var key = _seedKey;
    var raw = await _storage.read(key: key);
    if (raw == null) {
      // Fall back to a pre-existing legacy record so upgrading the app
      // doesn't strand a seed that was written before 'm'/'t'/'p' were
      // pinned per-record. It's rewritten in the current format the next
      // time writeWrapped runs (e.g. a password change).
      key = _legacySeedKey;
      raw = await _storage.read(key: key);
    }
    if (raw == null) throw StateError('No seed phrase stored');
    final r = jsonDecode(raw) as Map<String, dynamic>;
    if (r['kdf'] != 'Argon2id') throw StateError('Unsupported seed vault format');
    final String derivedKey;
    if (r['v'] == 3) {
      derivedKey = _gate.derivePasswordKeyWithParams(
        password, r['s'] as String,
        memoryKiB: r['m'] as int, iterations: r['t'] as int, parallelism: r['p'] as int,
      );
    } else if (r['v'] == 2) {
      // Legacy record: no KDF params were stored, so it can only be
      // re-derived correctly as long as BiometricGate's current defaults
      // still match what it was originally written with.
      derivedKey = _gate.derivePasswordKey(password, r['s'] as String);
    } else {
      throw StateError('Unsupported seed vault format');
    }
    final inner = await _gate.unprotect(r['c'] as String);
    final seed = await _channel.invokeMethod<String>('passwordUnwrap', {'ciphertext': inner, 'key': derivedKey});
    if (seed == null) throw StateError('Incorrect password or corrupted seed');
    return seed;
  }

  Future<void> markBackupConfirmed() => _storage.write(key: _backupConfirmedKey, value: 'true');
  Future<bool> get isBackupConfirmed async => (await _storage.read(key: _backupConfirmedKey)) == 'true';
  Future<void> wipe() async {
    await _storage.delete(key: _seedKey);
    await _storage.delete(key: _legacySeedKey);
    await _storage.delete(key: _backupConfirmedKey);
  }
}
