import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'crypto_bridge/ycash_engine.dart';
import 'biometrics/biometric_gate.dart';
import 'pricing/coinmarketcap_service.dart';
import 'pricing/free_price_service.dart';
import 'secure_storage/seed_vault.dart';
import 'secure_storage/price_api_key_vault.dart';
import 'settings_store/settings_store.dart';
import 'settings_store/currencies.dart';

final engineProvider = Provider<YcashEngine>((ref) {
  throw UnimplementedError('engineProvider must be overridden with the real ycash_core_ffi engine at startup');
});
final biometricGateProvider = Provider<BiometricGate>((ref) => BiometricGate());
final seedVaultProvider = Provider<SeedVault>((ref) => SeedVault());
final settingsStoreProvider = Provider<SettingsStore>((ref) => SettingsStore());
final priceApiKeyVaultProvider = Provider<PriceApiKeyVault>((ref) => PriceApiKeyVault());
final coinMarketCapServiceProvider = Provider<CoinMarketCapService>((ref) {
  final service = CoinMarketCapService();
  ref.onDispose(service.dispose);
  return service;
});
final freePriceServiceProvider = Provider<FreePriceService>((ref) {
  final service = FreePriceService();
  ref.onDispose(service.dispose);
  return service;
});

final themeModeProvider = AsyncNotifierProvider<ThemeModeController, ThemeMode>(ThemeModeController.new);
class ThemeModeController extends AsyncNotifier<ThemeMode> {
  @override
  Future<ThemeMode> build() => ref.read(settingsStoreProvider).getThemeMode();
  Future<void> setMode(ThemeMode mode) async {
    state = AsyncData(mode);
    await ref.read(settingsStoreProvider).setThemeMode(mode);
  }
}

/// Whether onboarding (wallet created/restored, backup confirmed, and a
/// security method set up) is complete — backed by
/// [SeedVault.isBackupConfirmed]. This drives [buildRouter]'s
/// `hasCompletedOnboarding` check in app.dart.
///
/// Unlike a plain field read once at app boot, this is a provider
/// specifically so the two places that change what the *right* answer is —
/// finishing onboarding, and wiping the wallet — can update it immediately
/// via [refresh]/[markWiped] and have the router's redirect pick that up
/// on the very next navigation, instead of only at the next cold start.
final onboardingStatusProvider =
    AsyncNotifierProvider<OnboardingStatusController, bool>(OnboardingStatusController.new);

class OnboardingStatusController extends AsyncNotifier<bool> {
  @override
  Future<bool> build() => ref.read(seedVaultProvider).isBackupConfirmed;

  /// Re-reads persisted state from the vault. Call right after onboarding
  /// completes (before navigating home), so `hasCompletedOnboarding()`
  /// returns true the moment the router's redirect next runs rather than
  /// bouncing back to /onboarding on the stale pre-onboarding value.
  Future<void> refresh() async {
    state = await AsyncValue.guard(() => ref.read(seedVaultProvider).isBackupConfirmed);
  }

  /// Sets state to "not onboarded" directly, without a storage round-trip.
  /// Call right after a successful wipe — the vault has just been cleared,
  /// so there's nothing to re-read; this just needs to be false before the
  /// post-wipe navigation happens so the redirect sends the user to
  /// /onboarding instead of back to a wallet-less Home.
  void markWiped() {
    state = const AsyncData(false);
  }
}

final autoShieldProvider = AsyncNotifierProvider<AutoShieldController, bool>(AutoShieldController.new);
class AutoShieldController extends AsyncNotifier<bool> {
  @override
  Future<bool> build() => ref.read(settingsStoreProvider).getAutoShield();
  Future<void> setEnabled(bool enabled) async {
    state = AsyncData(enabled);
    await ref.read(settingsStoreProvider).setAutoShield(enabled);
  }
}

final transactionHistoryProvider = FutureProvider<List<TxRecord>>((ref) => ref.watch(engineProvider).getTransactionHistory());
final balancesProvider = StreamProvider<Balances>((ref) async* {
  final engine = ref.watch(engineProvider);
  while (true) {
    try { yield await engine.getBalances(); }
    catch (e, st) { yield* Stream<Balances>.error(e, st); }
    await Future.delayed(const Duration(seconds: 5));
  }
});
final syncStatusProvider = StreamProvider<SyncStatus>((ref) => ref.watch(engineProvider).watchSyncStatus());
final localCurrencyProvider = FutureProvider<CurrencyChoice>((ref) async {
  final code = await ref.watch(settingsStoreProvider).getLocalCurrency();
  return currencyByCode(code);
});

/// The user's own CoinMarketCap API key (Settings > Local currency > Price
/// source). Null means no key has been saved, in which case the fiat
/// estimate is simply not shown — see [fiatRateProvider].
final cmcApiKeyProvider = AsyncNotifierProvider<CmcApiKeyController, String?>(CmcApiKeyController.new);
class CmcApiKeyController extends AsyncNotifier<String?> {
  @override
  Future<String?> build() {
    final key = ref.read(priceApiKeyVaultProvider).readCoinMarketCapKey();
    return key;
  }

  Future<void> setKey(String? key) async {
    final vault = ref.read(priceApiKeyVaultProvider);
    if (key == null || key.trim().isEmpty) {
      await vault.clearCoinMarketCapKey();
      state = const AsyncData(null);
    } else {
      await vault.writeCoinMarketCapKey(key.trim());
      state = AsyncData(key.trim());
    }
  }
}

/// Local-currency value of 1 YEC, for the "≈ X.XX CCY" line under the main
/// balance, converted to whatever currency is picked in Settings > Local
/// currency.
///
/// Works out of the box with nothing to configure: by default this uses
/// [FreePriceService] (CoinGecko for the USD price, a free FX endpoint to
/// convert to the selected currency) — no API key required. If the user
/// has saved their own CoinMarketCap key, that's used instead (a single,
/// more frequently-refreshed request); if a call on that path ever fails
/// (bad key, quota, unsupported currency), this falls back to the free
/// source for that cycle rather than hiding the estimate. Only genuine
/// failures on *both* sources yield null, hiding the estimate rather than
/// showing a misleading 0.00.
final fiatRateProvider = StreamProvider<double?>((ref) async* {
  final apiKey = ref.watch(cmcApiKeyProvider).valueOrNull;
  final currency = ref.watch(localCurrencyProvider).valueOrNull;
  if (currency == null) {
    yield null;
    return;
  }

  final useCmc = apiKey != null && apiKey.isNotEmpty;
  final cmcService = useCmc ? ref.watch(coinMarketCapServiceProvider) : null;
  final freeService = ref.watch(freePriceServiceProvider);
  // The free path chains two public services with modest shared rate
  // limits (CoinGecko's public tier, and an FX endpoint that only updates
  // once a day anyway), so it polls less often than the CMC key path.
  final pollInterval = useCmc ? const Duration(seconds: 90) : const Duration(minutes: 5);

  while (true) {
    if (useCmc) {
      try {
        yield await cmcService!.getYecPrice(apiKey: apiKey, fiatCurrencyCode: currency.code);
      } catch (_) {
        try {
          yield await freeService.getYecPrice(fiatCurrencyCode: currency.code);
        } catch (_) {
          yield null;
        }
      }
    } else {
      try {
        yield await freeService.getYecPrice(fiatCurrencyCode: currency.code);
      } catch (_) {
        yield null;
      }
    }
    await Future.delayed(pollInterval);
  }
});

final hideBalanceProvider = AsyncNotifierProvider<HideBalanceController, bool>(HideBalanceController.new);
class HideBalanceController extends AsyncNotifier<bool> { @override Future<bool> build()=>ref.read(settingsStoreProvider).getHideBalance(); Future<void> setHidden(bool value) async { state=AsyncData(value); await ref.read(settingsStoreProvider).setHideBalance(value); } }
final autoShieldMinimumProvider = AsyncNotifierProvider<AutoShieldMinimumController, double>(AutoShieldMinimumController.new);
class AutoShieldMinimumController extends AsyncNotifier<double> { @override Future<double> build()=>ref.read(settingsStoreProvider).getAutoShieldMinimum(); Future<void> setMinimum(double value) async { state=AsyncData(value); await ref.read(settingsStoreProvider).setAutoShieldMinimum(value); } }

/// The auto-lock timeouts offered in Settings, in seconds: immediately,
/// 10s, 15s, 20s, 25s, 30s, 1m, 2m, 3m. [SettingsStore.getAutoLockSeconds]
/// defaults to the 15s entry.
const List<int> autoLockSecondsOptions = [0, 10, 15, 20, 25, 30, 60, 120, 180];

final autoLockSecondsProvider = AsyncNotifierProvider<AutoLockSecondsController, int>(AutoLockSecondsController.new);
class AutoLockSecondsController extends AsyncNotifier<int> {
  @override
  Future<int> build() => ref.read(settingsStoreProvider).getAutoLockSeconds();
  Future<void> setSeconds(int seconds) async {
    state = AsyncData(seconds);
    await ref.read(settingsStoreProvider).setAutoLockSeconds(seconds);
  }
}

/// Whether the app is currently showing the password-only lock screen
/// (see AppLockScreen). Starts locked — a cold start with an existing
/// wallet should always ask for the password, same as coming back after
/// the configured timeout — and from there is driven by app.dart (which
/// arms it on backgrounding past the timeout) and by whatever unlocks it
/// (AppLockScreen on a correct password, or onboarding finishing for a
/// brand-new wallet, which has no reason to immediately re-challenge a
/// password the user just set).
final walletLockedProvider = StateProvider<bool>((ref) => true);
