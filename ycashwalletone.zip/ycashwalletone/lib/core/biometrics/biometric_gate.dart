import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:ffi';
import 'dart:io';

import 'package:ffi/ffi.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';

enum GateReason { revealSeedOrKeys, confirmSend, confirmShield, confirmUnshield, changeSecuritySettings, wipeWallet, enableBiometrics }

class BiometricAuthResult {
  final bool authenticated;
  final String? error;
  const BiometricAuthResult(this.authenticated, [this.error]);
}

/// Thrown by [BiometricGate.verifyPassword] when too many recent password attempts
/// have failed. Callers should surface [remaining] to the user rather than
/// retrying immediately.
class PasswordLockedOutException implements Exception {
  final Duration remaining;
  const PasswordLockedOutException(this.remaining);

  @override
  String toString() {
    final total = remaining.inSeconds.clamp(0, 1 << 30);
    final m = total ~/ 60;
    final s = total % 60;
    return m > 0
        ? 'Too many incorrect attempts. Try again in ${m}m ${s}s.'
        : 'Too many incorrect attempts. Try again in ${s}s.';
  }
}

/// Thrown when the Android Keystore key protecting the password record was
/// permanently invalidated (e.g. the device's screen lock was removed or
/// reset at the OS level). The old encrypted record can never be decrypted
/// again — the user must set a new password.
class PasswordRecordInvalidatedException implements Exception {
  const PasswordRecordInvalidatedException();

  @override
  String toString() =>
      'Your device security settings changed, so the saved password could not be '
      'recovered. Please set a new password.';
}

/// password verification uses Argon2id in the Rust native layer. The encrypted
/// record is additionally protected by a non-exportable Android Keystore key.
class BiometricGate {
  BiometricGate({LocalAuthentication? localAuth, FlutterSecureStorage? storage})
      : _localAuth = localAuth ?? LocalAuthentication(),
        _storage = storage ?? const FlutterSecureStorage();

  final LocalAuthentication _localAuth;
  final FlutterSecureStorage _storage;

  static const _passwordRecordKey = 'ycash.security.password_record.v4';
  static const _legacyPinRecordKey = 'ycash.security.password_record.v2';
  static const _legacyPinHashKey = 'ycash.security.password_hash';
  static const _passwordAttemptsKey = 'ycash.security.password_attempts';
  static const _passwordLockedUntilKey = 'ycash.security.password_locked_until';
  static const _channel = MethodChannel('com.ycashfoundation.ycash/security');

  // Exponential-ish backoff after repeated wrong passwords, keyed by the total
  // number of consecutive failures. Slows scripted/automated brute forcing
  // without ever destroying wallet data.
  static Duration _lockoutFor(int attempts) {
    if (attempts < 3) return Duration.zero;
    if (attempts < 5) return const Duration(seconds: 30);
    if (attempts < 7) return const Duration(minutes: 2);
    if (attempts < 10) return const Duration(minutes: 10);
    return const Duration(minutes: 30);
  }

  // OWASP-style interactive baseline. Kept explicit in the stored record for
  // future parameter upgrades.
  static const _memoryKiB = 65536;
  static const _iterations = 3;
  static const _parallelism = 1;
  static const _saltBytes = 16;

  Future<bool> get canUseBiometrics async {
    try {
      return await _localAuth.isDeviceSupported() && await _localAuth.canCheckBiometrics;
    } catch (_) {
      return false;
    }
  }

  /// Whether the device can run *any* local authentication check —
  /// biometric or device credential (PIN/pattern/password). Unlike
  /// [canUseBiometrics], this doesn't require an enrolled biometric: a
  /// device with only a screen-lock PIN set still counts. [authenticate]
  /// uses this (rather than [canUseBiometrics]) to decide whether it's
  /// even worth asking the OS to try, so "fall back to the device PIN
  /// when biometrics fail or aren't enrolled" actually reaches the OS
  /// prompt instead of short-circuiting straight to the wallet password.
  Future<bool> get _canAttemptDeviceAuth async {
    try {
      return await _localAuth.isDeviceSupported();
    } catch (_) {
      return false;
    }
  }

  Future<bool> get hasPasswordFallback async =>
      (await _storage.read(key: _passwordRecordKey)) != null ||
      (await _storage.read(key: _legacyPinRecordKey)) != null ||
      (await _storage.read(key: _legacyPinHashKey)) != null;

  String _reasonText(GateReason reason) => switch (reason) {
    GateReason.revealSeedOrKeys => 'Authenticate to view your recovery phrase',
    GateReason.confirmSend => 'Authenticate to send funds',
    GateReason.confirmShield => 'Authenticate to shield funds',
    GateReason.confirmUnshield => 'Authenticate to unshield funds',
    GateReason.changeSecuritySettings => 'Authenticate to change security settings',
    GateReason.wipeWallet => 'Authenticate to erase this wallet',
    GateReason.enableBiometrics => 'Authenticate to enable biometric protection',
  };

  Future<BiometricAuthResult> authenticateBiometricsOnly(GateReason reason) async {
    if (!await canUseBiometrics) return const BiometricAuthResult(false, 'no_biometrics_use_password');
    try {
      final ok = await _localAuth.authenticate(localizedReason: _reasonText(reason), options: const AuthenticationOptions(stickyAuth: true, biometricOnly: true));
      return ok ? const BiometricAuthResult(true) : const BiometricAuthResult(false, 'Authentication failed');
    } catch (e) { return BiometricAuthResult(false, e.toString()); }
  }

  /// Authenticates with a biometric if one's enrolled, otherwise falls
  /// back to the device's own PIN/pattern/password (handled by the OS
  /// prompt itself, since `biometricOnly: false`). Only returns
  /// 'no_biometrics_use_password' when the device has no local
  /// authentication method at all — no biometric *and* no screen lock —
  /// in which case the wallet password is the only thing left to check.
  Future<BiometricAuthResult> authenticate(GateReason reason) async {
    if (!await _canAttemptDeviceAuth) return const BiometricAuthResult(false, 'no_biometrics_use_password');
    try {
      final ok = await _localAuth.authenticate(localizedReason: _reasonText(reason), options: const AuthenticationOptions(stickyAuth: true, biometricOnly: false));
      return ok ? const BiometricAuthResult(true) : const BiometricAuthResult(false, 'Authentication failed');
    } catch (e) { return BiometricAuthResult(false, e.toString()); }
  }

  bool _isStrongPassword(String value) => passwordPolicyError(value) == null;

  /// Human-readable statement of the password policy, shown wherever the
  /// user is asked to set or change their password so the requirement is
  /// never a surprise after they've typed something and hit submit.
  static const String passwordPolicyDescription =
      'At least 8 characters, with a capital letter, a lowercase letter, a '
      'number, and a symbol (like ! ? # or %).';

  /// Returns a short description of the first unmet policy rule, or null
  /// if [value] satisfies the policy. Shared by every screen that sets or
  /// changes the password so the rule can never drift between them.
  static String? passwordPolicyError(String value) {
    if (value.length < 8) return 'Must be at least 8 characters.';
    if (!RegExp(r'[A-Z]').hasMatch(value)) return 'Add a capital letter.';
    if (!RegExp(r'[a-z]').hasMatch(value)) return 'Add a lowercase letter.';
    if (!RegExp(r'[0-9]').hasMatch(value)) return 'Add a number.';
    if (!RegExp(r'[^A-Za-z0-9]').hasMatch(value)) return 'Add a symbol (e.g. ! ? # %).';
    return null;
  }

  Future<void> setPassword(String password) async {
    if (!_isStrongPassword(password)) { throw ArgumentError('Password must be at least 8 characters and include a lowercase letter, an uppercase letter, a number, and a symbol.'); }
    final salt = List<int>.generate(_saltBytes, (_) => Random.secure().nextInt(256));
    final saltB64 = base64UrlEncode(salt).replaceAll('=', '');
    final derived = _argon2id(password, saltB64, _memoryKiB, _iterations, _parallelism);
    final record = jsonEncode({
      'v': 3, 'kdf': 'Argon2id', 'm': _memoryKiB, 't': _iterations,
      'p': _parallelism, 's': saltB64, 'd': derived,
    });
    final protected = await _protect(record);
    await _storage.write(key: _passwordRecordKey, value: protected);
    await _storage.delete(key: _legacyPinRecordKey);
    await _storage.delete(key: _legacyPinHashKey);
    // A fresh password clears any prior lockout — the old failure count no
    // longer applies to a password the user hasn't tried yet.
    await _clearLockout();
  }

  /// The Argon2id parameters new records should be created with. Exposed so
  /// callers (e.g. [SeedVault]) can persist them alongside the salt, the
  /// same way the password record itself does — see [setPassword].
  int get currentArgon2MemoryKiB => _memoryKiB;
  int get currentArgon2Iterations => _iterations;
  int get currentArgon2Parallelism => _parallelism;

  /// Derives a 256-bit key for password-wrapping sensitive wallet material,
  /// using the *current* Argon2id parameters. Salt is stored with the
  /// ciphertext; the password itself is never stored.
  ///
  /// Only safe to use when creating a brand-new record. To re-derive a key
  /// for an *existing* record, use [derivePasswordKeyWithParams] with the
  /// m/t/p that were stored alongside that record's salt — otherwise a
  /// future tuning of [_memoryKiB]/[_iterations]/[_parallelism] would make
  /// every previously-written record permanently undecryptable.
  String derivePasswordKey(String password, String salt) => derivePasswordKeyWithParams(
        password,
        salt,
        memoryKiB: _memoryKiB,
        iterations: _iterations,
        parallelism: _parallelism,
      );

  /// Derives a 256-bit key using explicit Argon2id parameters, e.g. ones
  /// read back from a stored record's 'm'/'t'/'p' fields. This is what
  /// makes it safe to tune [_memoryKiB]/[_iterations]/[_parallelism] later:
  /// old records keep re-deriving with whatever parameters they were
  /// created under, instead of silently being re-derived with today's
  /// (different) hardcoded constants and failing to match.
  ///
  /// Returned as standard (non-URL-safe), padded base64 — NOT the
  /// URL-safe/unpadded form the native Argon2id call itself produces.
  /// This value is handed to the native `passwordWrap`/`passwordUnwrap`
  /// channel calls as a raw AES key, and those decode it with Android's
  /// default (non-URL-safe) Base64 alphabet. A 32-byte key that stayed in
  /// URL-safe form would contain '-' or '_' roughly three times out of
  /// four, which the standard decoder rejects — so re-encoding here (once,
  /// at the source) is what makes password-wrapped writes/reads actually
  /// succeed instead of failing for most passwords.
  String derivePasswordKeyWithParams(
    String password,
    String salt, {
    required int memoryKiB,
    required int iterations,
    required int parallelism,
  }) {
    if (!_isStrongPassword(password)) throw ArgumentError('Password does not meet the required policy');
    final urlSafeNoPad = _argon2id(password, salt, memoryKiB, iterations, parallelism);
    final keyBytes = base64Url.decode(_pad(urlSafeNoPad));
    return base64Encode(keyBytes);
  }


  /// Verifies [password] against the stored record.
  ///
  /// Throws [PasswordLockedOutException] if too many recent attempts have
  /// failed, and [PasswordRecordInvalidatedException] if the OS invalidated the
  /// Keystore key backing the record (the record is unrecoverable and the
  /// user must set a new password).
  Future<bool> verifyPassword(String password) async {
    final lockedUntil = await _lockedUntil();
    if (lockedUntil != null) {
      final remaining = lockedUntil.difference(DateTime.now());
      if (remaining > Duration.zero) throw PasswordLockedOutException(remaining);
    }

    final protected = await _storage.read(key: _passwordRecordKey);
    if (protected == null) return false;

    // Decrypting the stored record is separate from checking the password
    // against it: a reauth prompt being dismissed or a Keystore error here
    // isn't evidence of a wrong password guess, so it must not feed the lockout
    // counter (that would let flaky auth prompts lock a legitimate user
    // out just as effectively as wrong guesses would).
    final String encoded;
    try {
      encoded = await _unprotect(protected);
    } on PasswordRecordInvalidatedException {
      rethrow;
    }

    try {
      final r = jsonDecode(encoded) as Map<String, dynamic>;
      if (r['v'] != 3 || r['kdf'] != 'Argon2id') {
        await _recordFailure();
        return false;
      }
      final actual = _argon2id(password, r['s'] as String, r['m'] as int, r['t'] as int, r['p'] as int);
      final match = _constantTimeEquals(
        base64Url.decode(_pad(actual)),
        base64Url.decode(_pad(r['d'] as String)),
      );
      if (match) {
        await _clearLockout();
        return true;
      }
      await _recordFailure();
      return false;
    } catch (_) {
      await _recordFailure();
      return false;
    }
  }

  /// How much longer password entry is locked out, or null if it's open now.
  Future<Duration?> get passwordLockoutRemaining async {
    final lockedUntil = await _lockedUntil();
    if (lockedUntil == null) return null;
    final remaining = lockedUntil.difference(DateTime.now());
    return remaining > Duration.zero ? remaining : null;
  }

  Future<DateTime?> _lockedUntil() async {
    final raw = await _storage.read(key: _passwordLockedUntilKey);
    final ms = raw == null ? null : int.tryParse(raw);
    return ms == null ? null : DateTime.fromMillisecondsSinceEpoch(ms);
  }

  Future<void> _recordFailure() async {
    final raw = await _storage.read(key: _passwordAttemptsKey);
    final attempts = (int.tryParse(raw ?? '0') ?? 0) + 1;
    await _storage.write(key: _passwordAttemptsKey, value: attempts.toString());
    final lockout = _lockoutFor(attempts);
    if (lockout > Duration.zero) {
      final until = DateTime.now().add(lockout);
      await _storage.write(key: _passwordLockedUntilKey, value: until.millisecondsSinceEpoch.toString());
    }
  }

  Future<void> _clearLockout() async {
    await _storage.delete(key: _passwordAttemptsKey);
    await _storage.delete(key: _passwordLockedUntilKey);
  }

  /// Removes every password-related record this class owns: the current
  /// verification record, legacy PIN-era records, and any active lockout
  /// state. Callers wiping the wallet must call this alongside
  /// [SeedVault.wipe] — otherwise a stale verification record, or worse an
  /// active lockout counter, survives into whatever wallet gets set up
  /// next on this device, even though the seed itself is gone.
  Future<void> wipePasswordRecords() async {
    await _storage.delete(key: _passwordRecordKey);
    await _storage.delete(key: _legacyPinRecordKey);
    await _storage.delete(key: _legacyPinHashKey);
    await _clearLockout();
  }

  /// Destroys the native (Android Keystore) AES key that every
  /// protect/unprotect call — and so every password record and wrapped
  /// seed — is encrypted under, and that biometric/device-credential
  /// authentication unlocks access to.
  ///
  /// [wipePasswordRecords] and [SeedVault.wipe] delete the encrypted
  /// *ciphertext* records; on their own they leave this underlying key
  /// alive in the device's Keystore. That's the biometric/password setup
  /// itself, not just its output — left in place, the next wallet created
  /// on this device would silently inherit the previous wallet's
  /// hardware-backed key rather than starting from a clean one. Callers
  /// wiping the wallet should call this alongside those two.
  ///
  /// Best-effort: there's nothing platform-specific to fail meaningfully
  /// against on non-Android targets, so an unimplemented channel is
  /// swallowed here rather than surfaced — the caller's own error handling
  /// around the whole wipe already covers genuine failures.
  Future<void> wipeNativeKey() async {
    try {
      await _channel.invokeMethod<void>('deleteKey');
    } on PlatformException {
      // Nothing left for us to clean up.
    } on MissingPluginException {
      // Platform doesn't implement this channel (e.g. not Android).
    }
  }

  /// Invokes the platform security channel, transparently handling the two
  /// recoverable native error codes:
  ///  - `AUTH_REQUIRED`: the Keystore key's recent-unlock window lapsed.
  ///    Prompt the user to authenticate, then retry once.
  ///  - `KEY_INVALIDATED`: the key can never be used again. Drop the local
  ///    record and surface [PasswordRecordInvalidatedException].
  // Native calls and the reauth prompt they can trigger must never hang the
  // UI indefinitely: if the system auth activity is torn down mid-prompt
  // (e.g. a config change) the result can be lost and the Future would
  // otherwise never complete, leaving the caller stuck on "Please wait".
  static const _secureCallTimeout = Duration(seconds: 30);

  Future<String> _invokeSecure(String method, Map<String, dynamic> args, {bool retried = false}) async {
    try {
      final result = await _channel
          .invokeMethod<String>(method, args)
          .timeout(_secureCallTimeout);
      if (result == null) throw StateError('$method returned no result');
      return result;
    } on TimeoutException {
      throw StateError(
        'Security check timed out. Please try again.',
      );
    } on PlatformException catch (e) {
      if (e.code == 'AUTH_REQUIRED' && !retried) {
        final reauthed = await _localAuth
            .authenticate(
              localizedReason: 'Confirm your device unlock to continue',
              options: const AuthenticationOptions(stickyAuth: true, biometricOnly: false),
            )
            .timeout(_secureCallTimeout, onTimeout: () => false);
        if (!reauthed) throw StateError('Authentication required to continue');
        return _invokeSecure(method, args, retried: true);
      }
      if (e.code == 'KEY_INVALIDATED') {
        await _storage.delete(key: _passwordRecordKey);
        throw const PasswordRecordInvalidatedException();
      }
      if (e.code == 'NO_DEVICE_CREDENTIAL') {
        throw StateError(
          'Your device has no screen lock (password, pattern, password, or '
          'fingerprint) set up. Please set one in your device settings, '
          'then try again.',
        );
      }
      rethrow;
    }
  }

  Future<String> _protect(String plaintext) => _invokeSecure('protect', {'plaintext': plaintext});
  Future<String> _unprotect(String ciphertext) => _invokeSecure('unprotect', {'ciphertext': ciphertext});

  /// Public entry points for other secure-storage classes (e.g. [SeedVault])
  /// that need the same hardware-backed Keystore envelope. These must be
  /// used instead of opening a second raw channel to 'protect'/'unprotect',
  /// so every caller gets the same 30s-reauth-and-retry handling for
  /// `AUTH_REQUIRED` and the same record-invalidation handling for
  /// `KEY_INVALIDATED` — rather than a bare [PlatformException] when the
  /// Keystore key's unlock window has simply lapsed.
  Future<String> protect(String plaintext) => _protect(plaintext);
  Future<String> unprotect(String ciphertext) => _unprotect(ciphertext);

  String _argon2id(String password, String salt, int memoryKiB, int iterations, int parallelism) {
    if (!Platform.isAndroid && !Platform.isLinux && !Platform.isMacOS && !Platform.isWindows) throw UnsupportedError('Native Argon2id is unavailable');
    final lib = Platform.isAndroid || Platform.isLinux
        ? DynamicLibrary.open('libycash_core.so')
        : Platform.isMacOS ? DynamicLibrary.open('libycash_core.dylib') : DynamicLibrary.open('ycash_core.dll');
    final fn = lib.lookupFunction<Pointer<Utf8> Function(Pointer<Utf8>, Pointer<Utf8>, Uint32, Uint32, Uint32, Pointer<Pointer<Utf8>>), Pointer<Utf8> Function(Pointer<Utf8>, Pointer<Utf8>, int, int, int, Pointer<Pointer<Utf8>>) >('ycash_password_argon2id');
    final free = lib.lookupFunction<Void Function(Pointer<Utf8>), void Function(Pointer<Utf8>)>('ycash_string_free');
    final p = password.toNativeUtf8(); final s = salt.toNativeUtf8(); final err = calloc<Pointer<Utf8>>();
    try {
      final out = fn(p, s, memoryKiB, iterations, parallelism, err);
      if (out == nullptr) { final msg = err.value == nullptr ? 'Argon2id failed' : err.value.toDartString(); if (err.value != nullptr) free(err.value); throw StateError(msg); }
      try { return out.toDartString(); } finally { free(out); }
    } finally { calloc.free(p); calloc.free(s); calloc.free(err); }
  }

  String _pad(String s) => s.padRight(s.length + ((4 - s.length % 4) % 4), '=');
  bool _constantTimeEquals(List<int> a, List<int> b) { if (a.length != b.length) return false; var d=0; for (var i=0;i<a.length;i++) d |= a[i]^b[i]; return d==0; }
}
