import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../design/tokens.dart';
import '../design/widgets.dart';
import '../core/providers.dart';
import '../features/lock/app_lock_screen.dart';
import 'router.dart';

/// Root widget. Onboarding completion is derived from whether a seed and a
/// security method (biometrics-capable device, or an app password) are
/// already in place, via [onboardingStatusProvider] — there's no separate
/// "onboarding done" flag to drift out of sync with the actual wallet
/// state.
///
/// The router itself (`_router`) is built exactly once — lazily, on first
/// use, via `late final` — and its
/// `hasCompletedOnboarding` closure always does a live `ref.read` of
/// [onboardingStatusProvider] rather than capturing a value computed at
/// boot. That matters because go_router only re-runs `redirect` when a
/// navigation happens — it doesn't poll — so the two places that change
/// the right answer (finishing onboarding, wiping the wallet) explicitly
/// update the provider *before* they navigate, and the redirect that fires
/// from that navigation call sees the fresh value immediately, instead of
/// only after the next cold start re-reads storage.
///
/// This widget also owns the app-wide auto-lock: it watches
/// [AppLifecycleState] directly (rather than each screen tracking its own
/// idle timer) and, once the app has been backgrounded for longer than
/// [autoLockSecondsProvider]'s current value, arms [walletLockedProvider]
/// so [AppLockScreen] covers everything the next time the app is in the
/// foreground — including right at a cold start, since that provider
/// starts locked.
class YcashRebornApp extends ConsumerStatefulWidget {
  const YcashRebornApp({super.key});

  @override
  ConsumerState<YcashRebornApp> createState() => _YcashRebornAppState();
}

class _YcashRebornAppState extends ConsumerState<YcashRebornApp> with WidgetsBindingObserver {
  late final GoRouter _router = buildRouter(
    hasCompletedOnboarding: () => ref.read(onboardingStatusProvider).valueOrNull ?? false,
  );

  // Not persisted — only needs to survive within the running process. If
  // the process itself is killed while backgrounded, the app cold-starts
  // next time, and walletLockedProvider already starts locked regardless.
  //
  // Deliberately a Stopwatch (monotonic) rather than two DateTime.now()
  // reads diffed against each other. DateTime.now() is wall-clock time —
  // someone with the device unlocked could wind the system clock backward
  // while this app is backgrounded and the elapsed-time check would come
  // out small (or negative), silently defeating the auto-lock. Stopwatch
  // is backed by the monotonic clock, which only moves forward and is
  // unaffected by the user (or anything else) changing the date/time.
  Stopwatch? _backgroundedStopwatch;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final onboarded = ref.read(onboardingStatusProvider).valueOrNull ?? false;
    // Nothing to lock yet if there's no wallet/password set up — this
    // would otherwise misfire mid-onboarding (e.g. while the OS biometric
    // prompt itself briefly backgrounds the app).
    if (!onboarded) return;

    if (state == AppLifecycleState.paused || state == AppLifecycleState.hidden) {
      _backgroundedStopwatch ??= Stopwatch()..start();
      return;
    }
    if (state != AppLifecycleState.resumed) return;

    final stopwatch = _backgroundedStopwatch;
    _backgroundedStopwatch = null;
    if (stopwatch == null) return;

    final timeoutSeconds = ref.read(autoLockSecondsProvider).valueOrNull ?? 15;
    if (stopwatch.elapsed >= Duration(seconds: timeoutSeconds)) {
      ref.read(walletLockedProvider.notifier).state = true;
    }
  }

  @override
  Widget build(BuildContext context) {
    final status = ref.watch(onboardingStatusProvider);

    // Only gate on the *initial* load/failure (no value yet at all) — once
    // we have a value, later refreshes/errors on this provider shouldn't
    // yank the user back to a bare spinner or error screen out from under
    // whatever they're doing.
    if (!status.hasValue) {
      if (status.hasError) {
        // Previously unguarded: a secure-storage read failure at boot left
        // every single launch stuck on a bare spinner forever, since the
        // router never got built and nothing else in the tree could ever
        // run. This is the one spot where that would hit every user, every
        // cold start — now it's a retryable error like everywhere else.
        YHaptics.warn();
        return MaterialApp(
          theme: buildYcashLightTheme(),
          darkTheme: buildYcashTheme(),
          themeMode: ref.watch(themeModeProvider).valueOrNull ?? ThemeMode.dark,
          home: Scaffold(
            body: Center(
              child: YErrorState(
                message: 'Could not start Ycash.',
                onRetry: () => ref.invalidate(onboardingStatusProvider),
              ),
            ),
          ),
        );
      }
      return MaterialApp(
        theme: buildYcashLightTheme(),
        darkTheme: buildYcashTheme(),
        themeMode: ref.watch(themeModeProvider).valueOrNull ?? ThemeMode.dark,
        home: const _YCashStartupScreen(),
      );
    }

    final onboarded = status.valueOrNull ?? false;

    return MaterialApp.router(
      title: 'Ycash',
      theme: buildYcashLightTheme(),
      darkTheme: buildYcashTheme(),
      themeMode: ref.watch(themeModeProvider).valueOrNull ?? ThemeMode.dark,
      routerConfig: _router,
      // The lock screen is layered over the router's content rather than
      // being a route of its own, so the underlying navigation stack (and
      // whatever screen the user was on) survives being locked and
      // unlocked intact.
      builder: (context, child) {
        final locked = ref.watch(walletLockedProvider);
        return Stack(
          children: [
            if (child != null) child,
            if (onboarded && locked) const AppLockScreen(),
          ],
        );
      },
    );
  }
}


class _YCashStartupScreen extends StatelessWidget {
  const _YCashStartupScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Semantics(
        label: 'Ycash wallet starting securely',
        child: SizedBox.expand(
          child: Image.asset(
            'assets/branding/startup_page.png',
            fit: BoxFit.cover,
            filterQuality: FilterQuality.high,
            excludeFromSemantics: true,
          ),
        ),
      ),
    );
  }
}
