import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../features/onboarding/onboarding_flow.dart';
import '../features/home/home_screen.dart';
import '../features/send/send_screen.dart';
import '../features/receive/receive_screen.dart';
import '../features/transactions/transactions_screen.dart';
import '../features/settings/settings_screen.dart';
import '../features/pools/pool_screen.dart';
import '../features/contacts/contacts_screen.dart';
import '../features/network/network_status_screen.dart';
import '../features/notifications/notifications_screen.dart';

/// [hasCompletedOnboarding] gates every route except onboarding itself,
/// via [GoRouter.redirect] — this is what prevents someone from deep
/// linking into `/send` before a wallet exists or a security method is set.
GoRouter buildRouter({required bool Function() hasCompletedOnboarding}) {
  return GoRouter(
    initialLocation: '/',
    redirect: (context, state) {
      final done = hasCompletedOnboarding();
      final onOnboarding = state.matchedLocation == '/onboarding';
      if (!done && !onOnboarding) return '/onboarding';
      if (done && onOnboarding) return '/';
      return null;
    },
    routes: [
      GoRoute(
        path: '/onboarding',
        builder: (context, state) => OnboardingFlow(
          onFinished: () => context.go('/'),
        ),
      ),
      GoRoute(
        path: '/',
        builder: (context, state) => const HomeScreen(),
        routes: [
          GoRoute(
            path: 'send',
            builder: (context, state) => const SendScreen(),
          ),
          GoRoute(
            path: 'receive',
            builder: (context, state) => const ReceiveScreen(),
          ),
          GoRoute(
            path: 'activity',
            builder: (context, state) => const TransactionsScreen(),
          ),
          GoRoute(
            path: 'shielded',
            builder: (context, state) => const PoolScreen(shielded: true),
          ),
          GoRoute(
            path: 'transparent',
            builder: (context, state) => const PoolScreen(shielded: false),
          ),
          GoRoute(path: 'settings', builder: (context, state) => const SettingsScreen()),
          GoRoute(path: 'contacts', builder: (context, state) => const ContactsScreen()),
          GoRoute(path: 'network', builder: (context, state) => const NetworkStatusScreen()),
          GoRoute(path: 'alerts', builder: (context, state) => const NotificationsScreen()),
        ],
      ),
    ],
  );
}

/// Thin navigation helpers so feature screens don't hardcode path strings.
extension YRouterContext on BuildContext {
  void pushSend() => push('/send');
  void pushReceive() => push('/receive');
  void pushActivity() => push('/activity');
  void pushSettings() => push('/settings');
  void pushShielded() => push('/shielded');
  void pushTransparent() => push('/transparent');
  void pushContacts() => push('/contacts');
  void pushNetwork() => push('/network');
  void pushAlerts() => push('/alerts');
}
