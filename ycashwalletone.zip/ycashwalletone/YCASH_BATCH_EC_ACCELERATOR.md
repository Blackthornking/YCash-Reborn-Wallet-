# YCash batch Sapling trial-decryption accelerator v3

The scanner now uses the pinned Ycash Sapling implementation for the expensive
candidate-matching operation and keeps the EC workload bounded.

## Hot path

1. Wallet IVKs are converted once into prepared Ycash Sapling IVKs for the block.
2. Compact outputs are flattened only for the current block's scan decision.
3. The batch engine processes outputs in **256-output chunks**, never an
   unbounded block-wide EC allocation.
4. Prepared IVK state is reused between chunks.
5. The existing sequential commitment-tree and witness bookkeeping remains in
   exact output order.
6. A batch result is mapped back to the wallet account index without changing
   addresses, notes, transaction encoding or serialization.

## Why this is safer

The former design tried to amortize everything across an entire block. That can
be fast on a desktop but is a poor mobile failure mode because one unusually
large block can create a large native allocation and a long GC/CPU stall.

The new design keeps the cryptographic optimisation while imposing a hard
memory/work bound.

## Sync architecture

The scanner is paired with Sync Engine v2:

- Ycash mainnet parameters are explicit.
- 64–512 block sync ranges, 256 default.
- One persistent lightwalletd connection.
- No speculative prefetch.
- Exact range validation before wallet mutation.
- Reorgs rebuild from the new wallet height.

## Compatibility

The wallet-file, address, transaction and signature formats are unchanged.
The existing wallet note representation remains the persistence boundary in this
release so existing wallets can open without migration.

## Release validation

- `cargo fmt --check`
- `cargo check -p zecwalletlitelib`
- Ycash Sapling note-decryption tests
- differential batch-vs-single decryption corpus
- historical scan comparison
- Android ARM64 release build
- restore/sync/rescan/reorg regression tests
