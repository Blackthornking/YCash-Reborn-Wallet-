#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ZW="$ROOT/upstream/zwallet"
[ -f "$ZW/Cargo.toml" ] || { echo "ZWallet backend missing"; exit 1; }
[ -f "$ZW/packages/warp_api_ffi/pubspec.yaml" ] || { echo "warp_api_ffi missing"; exit 1; }
echo "ZWallet/YWallet backend source is present."
echo "Next: perform dependency/API reconciliation before enabling mainnet spending."
