# YcashWalletOne batch scanner v2

The scanner now uses bounded Ycash-native Sapling EC batches.

## Defaults

- Compact-block sync range: **256 blocks**
- Allowed sync range: **64–512 blocks**
- Automatic CPU workers: **2–8**
- One persistent lightwalletd connection per sync round
- No speculative prefetch
- Wallet commit order: strictly increasing block height
- EC output batch: **256 compact outputs**
- Ycash mainnet only: Sapling, no Orchard

## Why this replaces the previous design

The previous 2,000-block/worker-prefetch design coupled transport memory,
scanner memory and cryptographic parallelism. On Android that could make a
large restore look stalled or terminate the process.

The new design separates the concerns:

1. network range is bounded;
2. the complete range is validated;
3. blocks are scanned sequentially;
4. the expensive EC operation is batched in bounded output chunks;
5. wallet state is committed immediately and in order.

This gives up some theoretical throughput in exchange for deterministic memory
usage and much stronger failure/reorg behaviour.

## Public API

The existing FFI entry point remains compatible:

`startBatchSync(batchSize: 256, workers: 0)`

Explicit batch sizes outside 64–512 are rejected. `workers: 0` selects the
mobile-safe automatic worker count.

No address, transaction, wallet-file or signature format is changed.
