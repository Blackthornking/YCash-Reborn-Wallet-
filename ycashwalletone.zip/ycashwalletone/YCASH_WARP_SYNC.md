# Ycash Sync v2

The previous Warp-style speculative prefetch pipeline has been retired from the
default sync path.

The new architecture is intentionally conservative:

`lightwalletd -> persistent connection -> bounded range -> validation -> scan -> commit`

There is no speculative range queue. This is important because a range fetched
before a reorg can become stale, and because retaining multiple large compact
block ranges increases Android native-memory pressure.

Performance is moved to the correct layer: Ycash-native Sapling trial
decryption uses prepared IVKs and bounded EC output batches. Transport is kept
simple and deterministic.

Ycash mainnet parameters are explicit:

- fork height 570,000
- Sapling activation 419,200
- coin type 347
- Sapling only
- 100-block wallet reorg window
