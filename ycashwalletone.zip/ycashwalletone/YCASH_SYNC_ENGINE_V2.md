# YcashWalletOne — Modern Ycash Sync Engine v2

This revision replaces the unstable high-throughput Warp-style scheduling experiment
with a bounded, Ycash-specific synchronization pipeline.

## Network model

The engine is explicitly Ycash mainnet:

- BIP-44 coin type: 347
- Sapling activation: 419,200
- Ycash fork: 570,000
- Sapling only; no Orchard and no Unified Address scanning
- Maximum wallet reorg window: 100 blocks
- Default lightwalletd: `https://lite.ycash.xyz:9067`

These values are treated as protocol parameters, not inferred from generic Zcash
configuration.

## Sync architecture

`lightwalletd -> one persistent gRPC connection -> exact bounded range -> validate -> scan -> ordered wallet commit`

The engine intentionally does **not**:

- prefetch a second compact-block range;
- keep speculative post-reorg data in memory;
- spawn a new network thread for every range;
- scan blocks out of height order;
- use a 2,000/10,000-block memory-heavy batch;
- change wallet key, address, transaction, or signature serialization.

## Range policy

- Minimum: 64 blocks
- Default: 256 blocks
- Maximum: 512 blocks
- Automatic CPU workers: 2–8
- Exactly one range is resident during a scan.
- Every server response must have the exact requested first height, last height,
  and number of blocks before wallet state is touched.

## Cryptographic scanner

The Sapling trial-decryption accelerator is Ycash-specific and uses the pinned
Ycash Sapling implementation. Prepared IVKs are retained and compact outputs are
processed in bounded EC batches of 256 outputs.

The wallet's existing note/witness/commitment-tree update code remains the
serialization boundary for now. This preserves existing wallet files and spend
behavior while the new transport and scan scheduler are isolated from the old
Zcash-oriented synchronization policy.

## Reorg behaviour

If a continuity check fails:

1. stop scanning the current range;
2. invalidate only the detected reorg region;
3. discard the current range;
4. rebuild the next range from the new wallet height;
5. never consume a stale speculative range.

## Failure behaviour

After retry exhaustion, native sync status is explicitly moved to `Error` and
the error text is retained. A failed sync therefore cannot leave the UI in a
permanent `is_syncing=true` state.

## Compatibility

No changes are made to:

- existing wallet-file serialization;
- Ycash addresses;
- transaction encoding;
- signing;
- verification;
- the 1,140-byte signature invariant in the cryptographic project.

The redesign is deliberately a sync/scanning architecture change, not a protocol
fork.
