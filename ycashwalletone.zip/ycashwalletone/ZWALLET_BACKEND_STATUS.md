# ZWallet/YWallet backend integration status

Implemented at the Dart integration boundary:

- Ycash wallet database initialization through upstream Warp API
- deterministic account creation/import using the existing protected mnemonic
- shielded receiving address retrieval
- transparent address retrieval
- Warp sync entry point and lightwalletd URL configuration
- shielded and transparent balance retrieval
- sync-status polling
- transaction history retrieval

Still deliberately gated:

- transaction planning/signing/broadcasting
- shield/unshield spending flows

Those require native proving assets and Ycash transaction acceptance testing.
