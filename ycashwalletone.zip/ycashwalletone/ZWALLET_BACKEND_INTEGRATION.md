# ZWallet/YWallet Backend Integration Baseline

This package preserves YcashWalletOne as the application/security shell and vendors the supplied ZWallet/YWallet source tree as the backend reference implementation.

## Intended architecture

Flutter UI + Android security shell
  -> adapter layer
  -> ZWallet warp API / native Rust backend
  -> Ycash-compatible lightwalletd

## Integration rule

Do not route Ycash funds through Zcash-only network parameters. The adapter must explicitly select Ycash mode and Ycash-compatible server/consensus configuration.

## Current status

The complete ZWallet source is vendored under `upstream/zwallet/` so its Rust backend, `warp_api_ffi`, Android configuration, protobuf definitions and sync engine can be integrated without reimplementing cryptography.

The existing YcashWalletOne UI remains intact. This baseline intentionally does not claim that spend/sign/broadcast is production-ready until the native dependency graph builds and real Ycash transaction vectors pass.

## Next build steps

1. Reconcile Flutter dependencies between root `pubspec.yaml` and `upstream/zwallet/pubspec.yaml`.
2. Replace the current read-only native adapter with an adapter over `warp_api_ffi`.
3. Configure explicit Ycash network selection and Ycash lightwalletd endpoints.
4. Migrate wallet-state calls: create/import account, sync, balances, history, receive addresses.
5. Enable transaction preparation, signing and broadcast only after Ycash consensus tests pass.
6. Run Android build and integration tests on a machine with Flutter, Android SDK/NDK and Rust installed.
