# Ycash sync crash fix — 2026-09-11

## Observed failure

The Android sync screen reported:

`Sync stopped: called Option::unwrap() on a None value`

with the wallet at approximately height 570000 and the network around 3027931.

## Changes

The vendored YecShell sync scanner was hardened at the wallet/block state boundary:

- Empty block history can no longer panic while handling a reorg/invalidation.
- The unconfirmed-spent rollback path now reads `unconfirmed_spent` rather than an unrelated `spent` field.
- Shielded-spend worker channel closure is returned as a sync error rather than panicking.
- Shielded nullifier/note lookups in block commit now return a contextual sync error instead of `Option::unwrap()` panics.
- The wallet transaction entry lookup now returns a contextual sync error instead of unwrapping.
- `scan_block_internal` propagates those errors to the block scanner, which reports the failing height and enters the existing retry/error path.

The existing Ycash batch trial-decryption implementation, wallet serialization, signature/transaction formats, and block ordering are not intentionally changed by this fix.

## Validation limitation

This environment does not contain `cargo`, `rustc`, Flutter, or Dart, so a native Android build/test could not be executed here. The source was edited in the supplied project tree and should be compiled with the project's normal Android build environment before installing.
