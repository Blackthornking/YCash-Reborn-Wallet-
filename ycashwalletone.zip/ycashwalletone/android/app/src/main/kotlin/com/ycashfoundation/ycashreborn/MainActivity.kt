package com.ycashfoundation.ycashreborn

import android.os.Build
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import android.security.keystore.KeyInfo
import android.content.Context
import android.security.keystore.UserNotAuthenticatedException
import android.util.Base64
import android.view.WindowManager
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Wallet security host: biometric FragmentActivity, non-exportable Android
 * Keystore AES key, and screenshot/screen-recording protection.
 *
 * The Keystore key backing the PIN record is bound to a recent device
 * unlock (`setUserAuthenticationRequired`). That means the key can only be
 * used to encrypt/decrypt within [AUTH_VALIDITY_SECONDS] of the user having
 * unlocked the device with their biometric, PIN, pattern, or password — so
 * code running in the app process cannot silently use the key without the
 * device actually being authenticated to. When that window has lapsed, the
 * cipher throws [UserNotAuthenticatedException] and we surface an
 * "AUTH_REQUIRED" error code so the Dart side can prompt re-authentication
 * and retry, rather than failing outright.
 */
class MainActivity : FlutterFragmentActivity() {
    private val channel = "com.ycashfoundation.ycash/security"
    private val alias = "ycash.wallet.password.record.v2"

    companion object {
        // How long after a device unlock the Keystore key stays usable
        // without requiring a fresh authentication.
        private const val AUTH_VALIDITY_SECONDS = 30
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Recovery phrases and private-key material must never appear in
        // screenshots, recordings, or the Android recents thumbnail.
        // TEMP: disabled for local debugging — re-enable before any build
        // that leaves your machine (release, TestFlight/Play internal
        // testing, or a device someone else will use).
        // window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channel).setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "protect" -> result.success(protect(call.argument<String>("plaintext") ?: ""))
                    "unprotect" -> result.success(unprotect(call.argument<String>("ciphertext") ?: ""))
                    "keystoreInfo" -> result.success(keystoreInfo())
                    "passwordWrap" -> result.success(passwordWrap(call.argument<String>("plaintext") ?: "", call.argument<String>("key") ?: ""))
                    "passwordUnwrap" -> result.success(passwordUnwrap(call.argument<String>("ciphertext") ?: "", call.argument<String>("key") ?: ""))
                    "deleteKey" -> { deleteKey(); result.success(null) }
                    else -> result.notImplemented()
                }
            } catch (e: UserNotAuthenticatedException) {
                // Key exists but the recent-unlock window has expired. The
                // Dart layer should trigger a device authentication prompt
                // and retry the same call once.
                result.error("AUTH_REQUIRED", "Re-authentication required", null)
            } catch (e: java.security.InvalidAlgorithmParameterException) {
                // Thrown by KeyGenParameterSpec.Builder when the device has
                // no secure lock screen (no PIN/pattern/password/biometric)
                // set up at all — an auth-bound key can't be created, so
                // this isn't recoverable by retrying or reauthenticating.
                result.error("NO_DEVICE_CREDENTIAL", e.message, null)
            } catch (e: KeyPermanentlyInvalidatedException) {
                // The key was invalidated (e.g. all biometrics/device
                // credential were removed on the device). It can never be
                // used again — the old encrypted record is unrecoverable.
                // Drop the dead key so a fresh one is generated next time,
                // and tell the Dart layer the stored PIN record is gone.
                deleteKey()
                result.error("KEY_INVALIDATED", "Security key invalidated; PIN must be reset", null)
            } catch (e: Exception) {
                result.error("KEYSTORE", e.message, null)
            }
        }
    }

    /**
     * Deletes the Keystore entry backing every protect/unprotect call.
     * Called internally when the OS reports the key as permanently
     * invalidated (see [KeyPermanentlyInvalidatedException] above), and
     * also reachable directly from Dart via the "deleteKey" channel call
     * — [BiometricGate.wipeNativeKey] uses that during wallet wipe, so the
     * hardware-backed key doesn't outlive the wallet it was protecting.
     */
    private fun deleteKey() {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (ks.containsAlias(alias)) ks.deleteEntry(alias)
    }

    /**
     * Builds the KeyGenParameterSpec used to generate the Keystore key.
     * [strongBox] controls whether StrongBox is requested — callers retry
     * with `false` if a StrongBox-backed attempt fails (see [key]).
     */
    private fun buildKeySpec(strongBox: Boolean): KeyGenParameterSpec {
        val builder = KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)
            .setUserAuthenticationRequired(true)
        if (strongBox && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            builder.setIsStrongBoxBacked(true)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // API 30+: the key becomes usable for AUTH_VALIDITY_SECONDS
            // after the user unlocks the device with a strong biometric or
            // their device credential (PIN/pattern/password). Including
            // AUTH_BIOMETRIC_STRONG means adding/removing an enrolled
            // biometric permanently invalidates this key by OS design
            // (a change in enrolled biometrics could mean an attacker
            // added their own) — that's intentional defense-in-depth, and
            // we handle it via KEY_INVALIDATED below rather than avoiding
            // it, since silently excluding biometric re-enrollment from
            // invalidation would defeat the point of binding to it at all.
            builder.setUserAuthenticationParameters(
                AUTH_VALIDITY_SECONDS,
                KeyProperties.AUTH_DEVICE_CREDENTIAL or KeyProperties.AUTH_BIOMETRIC_STRONG
            )
        } else {
            @Suppress("DEPRECATION")
            builder.setUserAuthenticationValidityDurationSeconds(AUTH_VALIDITY_SECONDS)
            // Pre-API 30 can't scope the authenticator type, so explicitly
            // opt out of biometric-enrollment invalidation to avoid bricking
            // the record when the user changes their fingerprint/face setup.
            builder.setInvalidatedByBiometricEnrollment(false)
        }
        return builder.build()
    }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")

        // Requesting StrongBox on the spec Builder rarely throws by itself —
        // the actual android.security.keystore.StrongBoxUnavailableException
        // (a device may advertise the feature-flag but still fail to
        // provision a StrongBox-backed key) surfaces from generateKey(), so
        // that's the call we need to guard, not the Builder configuration.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                generator.init(buildKeySpec(strongBox = true))
                return generator.generateKey()
            } catch (_: android.security.keystore.StrongBoxUnavailableException) {
                // StrongBox was requested but generation actually failed.
                // Clear any partial/aborted entry before falling back so it
                // can't shadow the TEE-backed key we're about to create.
                deleteKey()
            }
        }
        generator.init(buildKeySpec(strongBox = false))
        return generator.generateKey()
    }

    private fun keystoreInfo(): Map<String, Any> {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val secret = (ks.getKey(alias, null) as? SecretKey)
        if (secret == null) return mapOf("alias" to alias, "hardwareBacked" to false, "strongBox" to false, "attestation" to "key_not_created")
        // AndroidKeyStore only exposes a KeySpec for SecretKeys through
        // SecretKeyFactory — java.security.KeyFactory is for asymmetric
        // KeyPairs and throws NoSuchAlgorithmException here.
        val factory = javax.crypto.SecretKeyFactory.getInstance(secret.algorithm, "AndroidKeyStore")
        val info = factory.getKeySpec(secret, KeyInfo::class.java) as KeyInfo
        val secure = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) info.securityLevel != android.security.keystore.KeyProperties.SECURITY_LEVEL_SOFTWARE else info.isInsideSecureHardware
        // Note: KeyInfo (unlike KeyGenParameterSpec.Builder) never exposed an
        // isStrongBoxBacked() getter. StrongBox status can only be read back
        // via KeyInfo.securityLevel, added in API 31.
        val strong = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) info.securityLevel == android.security.keystore.KeyProperties.SECURITY_LEVEL_STRONGBOX else false
        return mapOf("alias" to alias, "hardwareBacked" to secure, "strongBox" to strong, "attestation" to "hardware-backed key verified")
    }


    // Inner envelope: AES-256-GCM using a key derived from the wallet password
    // with Argon2id. The resulting ciphertext is then stored inside the
    // non-exportable StrongBox/TEE Keystore envelope on the Dart side.
    private fun passwordWrap(plaintext: String, keyB64: String): String {
        val raw = Base64.decode(keyB64, Base64.NO_WRAP)
        require(raw.size == 32) { "Password wrapping key must be 256 bits" }
        val key = javax.crypto.spec.SecretKeySpec(raw, "AES")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val iv = cipher.iv
        val encrypted = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(iv, Base64.NO_WRAP) + "." + Base64.encodeToString(encrypted, Base64.NO_WRAP)
    }

    private fun passwordUnwrap(value: String, keyB64: String): String {
        val raw = Base64.decode(keyB64, Base64.NO_WRAP)
        require(raw.size == 32) { "Password wrapping key must be 256 bits" }
        val parts = value.split('.', limit = 2)
        require(parts.size == 2) { "Invalid password-wrapped record" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, javax.crypto.spec.SecretKeySpec(raw, "AES"), GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)))
        return String(cipher.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)), Charsets.UTF_8)
    }

    private fun protect(plaintext: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(iv, Base64.NO_WRAP) + "." + Base64.encodeToString(encrypted, Base64.NO_WRAP)
    }

    private fun unprotect(value: String): String {
        val parts = value.split('.', limit = 2)
        require(parts.size == 2) { "Invalid protected record" }
        val iv = Base64.decode(parts[0], Base64.NO_WRAP)
        val data = Base64.decode(parts[1], Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(data), Charsets.UTF_8)
    }
}
