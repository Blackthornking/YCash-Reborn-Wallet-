library ycash_core;

import 'dart:ffi';
import 'dart:io';

import 'package:ffi/ffi.dart';

class YcashCoreException implements Exception {
  final String message;
  const YcashCoreException(this.message);
  @override
  String toString() => 'YcashCoreException: $message';
}

class YcashCoreNative {
  YcashCoreNative._(this._lib);

  final DynamicLibrary _lib;

  static final YcashCoreNative instance =
      YcashCoreNative._(_openLibrary());

  static DynamicLibrary _openLibrary() {
    if (Platform.isAndroid) return DynamicLibrary.open('libycash_core.so');
    if (Platform.isLinux) return DynamicLibrary.open('libycash_core.so');
    if (Platform.isMacOS) return DynamicLibrary.open('libycash_core.dylib');
    if (Platform.isWindows) return DynamicLibrary.open('ycash_core.dll');
    throw UnsupportedError('Ycash native engine is not available on this platform');
  }


  late final _saplingBackendAvailable = _lib.lookupFunction<
      Uint8 Function(Pointer<Pointer<Utf8>>),
      int Function(Pointer<Pointer<Utf8>>)>(
    'ycash_sapling_backend_available',
  );

  bool saplingBackendAvailable() {
    final error = calloc<Pointer<Utf8>>();
    try {
      final ok = _saplingBackendAvailable(error) != 0;
      if (!ok && error.value != nullptr) {
        _throwNative(error, 'YCash Sapling backend unavailable');
      }
      return ok;
    } finally {
      calloc.free(error);
    }
  }

  late final _backendStatus = _lib.lookupFunction<
      Pointer<Utf8> Function(),
      Pointer<Utf8> Function()>(
    'ycash_backend_status_json',
  );

  /// Native capability manifest for diagnostics and release gating.
  String backendStatusJson() => _take(_backendStatus());

  late final _readOnlyCapabilities = _lib.lookupFunction<
      Pointer<Utf8> Function(),
      Pointer<Utf8> Function()>(
    'ycash_readonly_capabilities_json',
  );

  /// Machine-readable read-only capability manifest supplied by the native backend.
  String readOnlyCapabilitiesJson() => _take(_readOnlyCapabilities());

  late final _create = _lib.lookupFunction<
      Uint8 Function(Pointer<Pointer<Utf8>>),
      int Function(Pointer<Pointer<Utf8>>)>(
    'ycash_wallet_create',
  );

  late final _restore = _lib.lookupFunction<
      Uint8 Function(Pointer<Utf8>, Pointer<Pointer<Utf8>>),
      int Function(Pointer<Utf8>, Pointer<Pointer<Utf8>>)>(
    'ycash_wallet_restore',
  );

  late final _export = _lib.lookupFunction<
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>),
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>)>(
    'ycash_wallet_export_mnemonic',
  );

  late final _wipe = _lib.lookupFunction<Void Function(), void Function()>(
    'ycash_wallet_wipe',
  );

  late final _free = _lib.lookupFunction<
      Void Function(Pointer<Utf8>),
      void Function(Pointer<Utf8>)>(
    'ycash_string_free',
  );

  String _take(Pointer<Utf8> pointer) {
    try {
      return pointer.toDartString();
    } finally {
      _free(pointer);
    }
  }

  String? _takeNullable(Pointer<Utf8> pointer) {
    if (pointer == nullptr) return null;
    return _take(pointer);
  }

  Never _throwNative(Pointer<Pointer<Utf8>> error, String fallback) {
    final value = _takeNullable(error.value);
    throw YcashCoreException(value ?? fallback);
  }

  void createWallet() {
    final error = calloc<Pointer<Utf8>>();
    try {
      if (_create(error) == 0) _throwNative(error, 'wallet creation failed');
    } finally {
      calloc.free(error);
    }
  }

  void restoreWallet(String phrase) {
    final error = calloc<Pointer<Utf8>>();
    final nativePhrase = phrase.toNativeUtf8();
    try {
      if (_restore(nativePhrase, error) == 0) {
        _throwNative(error, 'wallet restore failed');
      }
    } finally {
      calloc.free(nativePhrase);
      calloc.free(error);
    }
  }

  String exportMnemonic() {
    final error = calloc<Pointer<Utf8>>();
    try {
      final result = _export(error);
      if (result == nullptr) _throwNative(error, 'mnemonic export failed');
      return _take(result);
    } finally {
      calloc.free(error);
    }
  }

  void wipeWallet() => _wipe();
}
