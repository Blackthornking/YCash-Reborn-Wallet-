# Ycash Cryptographic Dependency Status

The Android APK build is now gated on a reproducible Ycash upstream integrity policy.

## Pinned production sources

- `sapling-crypto-ycash` is pinned to commit `c5e596c239dbf9138a74246b843bcd01413f51c7`.
- `librustzcash-nu61` is pinned to commit `26de676f2c5c0e2d35e0b28b7bea704f4ff0411e`.
- The exact vendored source trees are protected by SHA-256 tree hashes in `YCASH_UPSTREAM_LOCK.toml`.
- The production Rust manifest uses local path dependencies into those pinned vendor trees rather than floating Git branches.

## Validation gates

1. `scripts/verify_ycash_lock.py` verifies immutable 40-character commit IDs, expected repositories, expected vendor paths, and exact tree hashes.
2. The Android APK workflow runs the integrity verifier before dependency resolution and APK compilation.
3. `ycash-crypto-integrity.yml` separately compiles the safe backend, Ycash Sapling feature, and Ycash transaction feature.

## Important boundary

A successful APK build and dependency-integrity check do **not** by themselves prove mainnet consensus compatibility or prove that spending is safe. Mainnet transaction generation must remain gated on Ycash consensus and test-vector validation.
