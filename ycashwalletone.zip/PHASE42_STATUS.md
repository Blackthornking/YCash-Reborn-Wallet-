# Phase 42 — Scanner → Exact Sapling Storage

## Implemented
- Atomic ingestion boundary for scanner-authenticated Sapling notes.
- Strict Phase 41 witness-v2 validation (32 siblings plus direction bits).
- Persistence of note plaintext reconstruction material, position, commitment and anchor.
- Scan-height advancement is committed atomically with note/nullifier updates.
- No synthetic witness generation.

## Not yet proven
- Compact-block trial decryption is still delegated to the pinned upstream Ycash scanner implementation.
- Nullifier ownership-to-note mapping requires the wallet's real nullifier derivation/key context.
- Transaction proving/signing and ycashd acceptance remain disabled.
