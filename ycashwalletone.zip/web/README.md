# Web

Generate/update the official Flutter web bootstrap files with:

    flutter create --platforms=web .

Web must remain read-only until the security model for browser key storage and
native Ycash cryptography is separately approved.
