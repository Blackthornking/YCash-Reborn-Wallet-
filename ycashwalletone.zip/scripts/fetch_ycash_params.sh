#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PARAM_DIR="$ROOT/packages/ycash_core_ffi/rust/vendor/yecshell-lib/zcash-params"
mkdir -p "$PARAM_DIR"

# Large Sapling proving parameters intentionally live outside the Git repository.
# The build downloads them and yecshell-lib embeds them into the native library.
# These IDs correspond to the two externally hosted Google Drive files supplied
# for YWallet/Ycash. Do not commit the parameter blobs themselves.
SPEND_ID="1OfbiqE2uzdJqxFfC8s8h0l_s4KT8_Io6"
OUTPUT_ID="1T02YAgRo3Rx6ksXphGuDKadkV5K49RW2"

command -v python3 >/dev/null || { echo "python3 is required" >&2; exit 1; }
python3 -m pip install --disable-pip-version-check --quiet gdown==5.2.0

download_one() {
  local id="$1" name="$2" expected_size="$3"
  local dst="$PARAM_DIR/$name"
  local tmp="$dst.part"

  echo "Downloading $name from external parameter storage..."
  rm -f "$tmp"
  python3 -m gdown --id "$id" --output "$tmp" --fuzzy

  if [ ! -s "$tmp" ]; then
    echo "ERROR: downloaded $name is empty" >&2
    exit 1
  fi

  # Reject HTML/error pages accidentally saved as parameter files.
  if file "$tmp" | grep -qiE 'HTML|text'; then
    echo "ERROR: $name download does not look like a binary parameter file" >&2
    file "$tmp" >&2 || true
    exit 1
  fi

  mv "$tmp" "$dst"
  echo "$(sha256sum "$dst")"
  echo "$(du -h "$dst" | cut -f1)  $name"
}

download_one "$SPEND_ID" "sapling-spend.params" ""
download_one "$OUTPUT_ID" "sapling-output.params" ""

# yecshell-lib uses RustEmbed with this directory at compile time.
test -s "$PARAM_DIR/sapling-spend.params"
test -s "$PARAM_DIR/sapling-output.params"

echo "Ycash Sapling parameters ready for yecshell-lib embedding."
