#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo '[1/5] checking immutable upstream lock'
grep -q 'revision = "[0-9a-f]\{40\}"' YCASH_UPSTREAM_LOCK.toml

echo '[2/5] checking vendor directories'
test -d upstream/vendor/librustzcash-ycash-nu61
test -d upstream/vendor/sapling-crypto-ycash

echo '[3/5] compiling default native ABI'
cd packages/ycash_core_ffi/rust
cargo check

echo '[4/5] compiling pinned read-only scanner feature'
cargo check --features ycash-scanner

echo '[5/5] address activation is blocked until deterministic vectors are supplied'
echo 'PASS: build gate reached; activation remains false by design.'
