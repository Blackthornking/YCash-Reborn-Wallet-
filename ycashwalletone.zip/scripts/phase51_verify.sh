#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../packages/ycash_core_ffi/rust"
cargo test --lib tx::phase51
