#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VENDOR="$ROOT/upstream/vendor"
mkdir -p "$VENDOR"

clone_pinned() {
  local name="$1" url="$2" ref="$3"
  if [ -d "$VENDOR/$name/.git" ]; then
    git -C "$VENDOR/$name" fetch --depth 1 origin "$ref"
    git -C "$VENDOR/$name" checkout --detach FETCH_HEAD
  else
    git clone --depth 1 --branch "$ref" "$url" "$VENDOR/$name"
  fi
}

# Repositories are intentionally fetched from Ycash-maintained upstreams.
# Review and replace refs with audited commit SHAs before production release.
clone_pinned librustzcash-ycash-nu61 https://github.com/ycashfoundation/librustzcash-nu61.git main
clone_pinned sapling-crypto-ycash https://github.com/ycashfoundation/sapling-crypto-ycash.git main

echo "Upstreams fetched into $VENDOR"
echo "IMPORTANT: record immutable commit SHAs in YCASH_UPSTREAM_LOCK.toml before enabling spending."
