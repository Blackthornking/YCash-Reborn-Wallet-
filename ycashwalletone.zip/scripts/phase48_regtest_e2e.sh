#!/usr/bin/env bash
set -euo pipefail
: "${YCASHD:=ycashd}"
DATADIR="${YCASH_REGTEST_DATADIR:-$(mktemp -d)}"
OUT="${PHASE48_OUT:-artifacts/phase48}"
mkdir -p "$OUT"
if ! command -v "$YCASHD" >/dev/null 2>&1; then
  echo 'ycashd not found; refusing to fabricate a regtest result.' >&2; exit 2
fi
"$YCASHD" --version | tee "$OUT/ycashd-version.txt"
# Harness intentionally stops unless a compatible compact-block/lightwallet service is supplied.
# This prevents synthetic protobuf fixtures from being labelled as real-chain evidence.
echo 'Phase 48 harness initialized. Capture CompactBlock bytes from a real compatible regtest lightwallet service.' >&2
exit 3
