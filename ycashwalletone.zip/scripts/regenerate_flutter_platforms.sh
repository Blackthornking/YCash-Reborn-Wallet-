#!/usr/bin/env bash
set -euo pipefail

echo "Regenerating official Flutter platform templates."
flutter create --platforms=android,ios,web,linux,macos,windows .

echo "Review native files and reapply only documented Ycash Reborn integrations."
