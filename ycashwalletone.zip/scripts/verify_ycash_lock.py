#!/usr/bin/env python3
"""Verify pinned Ycash cryptographic upstream provenance and vendor integrity."""
from pathlib import Path
import hashlib
import re
import sys
import tomllib

ROOT = Path(__file__).resolve().parents[1]
LOCK = ROOT / "YCASH_UPSTREAM_LOCK.toml"


def tree_sha256(root: Path) -> str:
    h = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if not path.is_file() or ".git" in path.parts:
            continue
        rel = path.relative_to(root).as_posix().encode()
        digest = hashlib.sha256(path.read_bytes()).hexdigest().encode()
        h.update(b"F\0" + rel + b"\0" + digest + b"\n")
    return h.hexdigest()


def fail(message: str) -> None:
    print(f"ERROR: {message}")
    sys.exit(1)

if not LOCK.exists():
    fail("YCASH_UPSTREAM_LOCK.toml not found")

raw = LOCK.read_text()
if re.search(r'(?:branch|rev)\s*=\s*"(?:main|master)"', raw):
    fail("floating upstream references detected")

try:
    records = tomllib.loads(raw).get("upstream", [])
except tomllib.TOMLDecodeError as exc:
    fail(f"invalid upstream lock: {exc}")

required = {
    "sapling-crypto-ycash": "https://github.com/ycashfoundation/sapling-crypto-ycash",
    "librustzcash-nu61": "https://github.com/ycashfoundation/librustzcash-nu61",
    "zcash-sync": "https://github.com/ycashfoundation/zcash-sync",
}
by_name = {r.get("name"): r for r in records}
for name, repository in required.items():
    record = by_name.get(name)
    if not record:
        fail(f"missing upstream record: {name}")
    if record.get("repository") != repository:
        fail(f"unexpected repository for {name}")
    revision = record.get("revision", "")
    if not re.fullmatch(r"[0-9a-f]{40}", revision):
        fail(f"{name} does not use an immutable 40-character commit id")

# These two trees are the cryptographic/protocol code linked through path deps.
for name in ("sapling-crypto-ycash", "librustzcash-nu61"):
    record = by_name[name]
    rel = record.get("vendor_path")
    expected = record.get("tree_sha256")
    if not rel or not re.fullmatch(r"[0-9a-f]{64}", expected or ""):
        fail(f"{name} is missing a pinned vendor tree hash")
    root = ROOT / rel
    if not root.is_dir():
        fail(f"vendored source missing: {rel}")
    actual = tree_sha256(root)
    if actual != expected:
        fail(f"vendored {name} hash mismatch\nexpected {expected}\nactual   {actual}")

# Ensure production Cargo.toml points only at the pinned local trees.
cargo = ROOT / "packages/ycash_core_ffi/rust/Cargo.toml"
text = cargo.read_text()
for rel in (
    "../../../upstream/vendor/sapling-crypto-ycash",
    "../../../upstream/vendor/librustzcash-ycash-nu61/zcash_primitives",
    "../../../upstream/vendor/librustzcash-ycash-nu61/zcash_proofs",
    "../../../upstream/vendor/librustzcash-ycash-nu61/zcash_keys",
):
    if rel not in text:
        fail(f"production manifest is not pinned to expected vendor path: {rel}")

print("Ycash cryptographic upstream lock and vendor integrity checks passed")
