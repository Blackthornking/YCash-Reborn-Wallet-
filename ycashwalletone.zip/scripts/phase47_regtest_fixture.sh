#!/usr/bin/env bash
set -euo pipefail
: "${YCASH_REGTEST_FIXTURE:?Set YCASH_REGTEST_FIXTURE to a real captured CompactBlock protobuf fixture}"
test -s "$YCASH_REGTEST_FIXTURE"
echo "Phase 47 fixture present: $YCASH_REGTEST_FIXTURE"
