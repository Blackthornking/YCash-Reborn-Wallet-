#!/usr/bin/env bash
set -euo pipefail
# Phase 36 acceptance harness. Never run against mainnet.
: "${YCASHD:=ycashd}"
: "${YCASH_CLI:=ycash-cli}"
DATADIR="${YCASH_REGTEST_DATADIR:-$PWD/.phase36-ycash-regtest}"
mkdir -p "$DATADIR"
"$YCASHD" -regtest -daemon -datadir="$DATADIR"
trap '"$YCASH_CLI" -regtest -datadir="$DATADIR" stop || true' EXIT
# A Phase 37 concrete transaction emitter must write PHASE36_RAW_TX_HEX only
# after proving/signing and exact Ycash serialization are implemented.
if [[ -z "${PHASE36_RAW_TX_HEX:-}" ]]; then
  echo "No raw transaction supplied; proving/signing emitter is not yet complete." >&2
  exit 2
fi
"$YCASH_CLI" -regtest -datadir="$DATADIR" decoderawtransaction "$PHASE36_RAW_TX_HEX" >/dev/null
"$YCASH_CLI" -regtest -datadir="$DATADIR" sendrawtransaction "$PHASE36_RAW_TX_HEX"
