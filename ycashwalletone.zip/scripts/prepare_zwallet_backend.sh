#!/usr/bin/env bash
# NOT part of the CI/Gradle build. This is a manual sanity check for the
# upstream/zwallet reference tree only -- it is not invoked by
# .github/workflows/build-android.yml or any Gradle task, and
# packages/ycash_core_ffi/rust (the crate that actually ships in the APK)
# has no path dependency on upstream/zwallet. Do not assume running this
# script, or upstream/zwallet building, has any effect on the release build.
#
# upstream/zwallet/Cargo.lock currently resolves orchard + zcash_primitives
# via a yanked `aes 0.7.5` / old `fpe 0.5.1`. That must be reconciled before
# this backend is ever wired into the real build (see
# ZWALLET_BACKEND_INTEGRATION.md, "Next build steps").
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ZW="$ROOT/upstream/zwallet"
[ -f "$ZW/Cargo.toml" ] || { echo "ZWallet backend missing"; exit 1; }
[ -f "$ZW/packages/warp_api_ffi/pubspec.yaml" ] || { echo "warp_api_ffi missing"; exit 1; }
echo "ZWallet/YWallet backend source is present."
echo "Next: perform dependency/API reconciliation before enabling mainnet spending."
