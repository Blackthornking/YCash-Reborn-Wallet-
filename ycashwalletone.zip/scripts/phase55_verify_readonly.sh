#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LOCK="$ROOT/YCASH_UPSTREAM_LOCK.toml"
RUST="$ROOT/packages/ycash_core_ffi/rust"

need(){ command -v "$1" >/dev/null || { echo "missing tool: $1" >&2; exit 1; }; }
need git; need cargo; need python3
python3 - "$LOCK" "$ROOT" <<'PY'
import pathlib,re,subprocess,sys
lock=pathlib.Path(sys.argv[1]).read_text(); root=pathlib.Path(sys.argv[2])
for name, repo, rev, rel in re.findall(r'name = "([^"]+)"\nrepository = "([^"]+)"\nrevision = "([0-9a-f]+)"[\s\S]*?vendor_path = "([^"]+)"', lock):
    dst=root/rel
    if not dst.exists():
        print(f"Missing vendored {name}: {dst}", file=sys.stderr); sys.exit(2)
    got=subprocess.check_output(['git','-C',str(dst),'rev-parse','HEAD'],text=True).strip() if (dst/'.git').exists() else None
    if got and got != rev:
        print(f"{name}: expected {rev}, got {got}",file=sys.stderr);sys.exit(3)
print('Pinned Ycash vendor layout present')
PY
cd "$RUST"
cargo test --locked
cargo check --locked --features ycash-sapling
cargo check --locked --features ycash-scanner
printf '\nREAD-ONLY GATE: compilation passed. This does NOT enable spending.\n'
