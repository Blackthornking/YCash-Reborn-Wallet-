# Ycash Reborn — Phase 17

Phase 17 moves the project from placeholder integration boundaries to a reproducible upstream-lock workflow.

The next engineering operation is mechanical and test-driven:

1. choose exact immutable Ycash Foundation commits;
2. record them in `YCASH_UPSTREAM_LOCK.toml`;
3. wire those commits into Cargo;
4. compile on a controlled Rust toolchain;
5. add Ycash address/key vectors;
6. validate sync against `lite.ycash.xyz:9067` or another trusted compatible server;
7. only then enable wallet-owned Sapling addresses and read-only scanning.

Do not use floating `main` or `master` dependencies for a wallet that can spend funds.
