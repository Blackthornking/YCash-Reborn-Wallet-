# Ycash Reborn — Phase 26: Lightwallet Transport

Phase 26 adds the production-shaped boundary for fetching Ycash compact blocks
from a TLS lightwallet endpoint and feeding them into the wallet scanner.

## Security rule
Transported blocks are **untrusted network input**. A block/output becomes a
wallet note only after the Ycash-compatible Sapling backend proves ownership.

## Included
- HTTPS-only production endpoint validation
- compact-block source abstraction
- deterministic sync-progress model
- generated-protobuf boundary retained in the Rust crate
- CI-ready tests for transport invariants

## Not enabled
- spending
- fake address generation
- treating compact blocks as owned funds without trial decryption

The default endpoint is intentionally configuration-driven. Production releases
must pin and verify the service configuration independently of wallet keys.
