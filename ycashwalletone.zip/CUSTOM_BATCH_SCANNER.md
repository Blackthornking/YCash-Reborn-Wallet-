# YcashWalletOne custom batch scanner

The wallet now uses a native custom batch scanner by default.

## Defaults
- Compact-block batch: **2,000 blocks**
- CPU workers: **automatic, 2–12 workers**
- One persistent gRPC/TLS stream per batch
- CPU-bound Sapling trial decryption remains parallel
- Wallet state is committed in chain order
- Existing reorg detection and retry handling are preserved
- No transaction format, address format, or cryptographic verification behavior is changed

## API

The existing `startSync()` entry point now starts the custom scanner with the
2,000-block default.

For tuning from Dart:

`startBatchSync(batchSize: 2000, workers: 0)`

`workers: 0` selects the native automatic CPU count. Valid batch sizes are
100–10,000 and valid explicit worker counts are 1–32.

The native status/result also reports `scan_batch_size` and `scan_workers`.

## Why this is safe

Parallelism is used for CPU-heavy scanning only. Blocks are still streamed in
height order, reorg detection remains serialized, and wallet progress only
advances after the current batch has been successfully scanned. This avoids
introducing out-of-order wallet state while reducing per-batch network and
allocation overhead.
