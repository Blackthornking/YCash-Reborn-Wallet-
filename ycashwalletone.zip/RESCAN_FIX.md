# Rescan-from-date fix

The date-based rescan could sit on the loading spinner because the block-height
estimator created a fresh Tokio runtime and TLS/gRPC connection for every binary
search probe. On mobile this can take long enough to hit the Flutter timeout.

The native estimator now:
- creates one Tokio runtime;
- creates one lightwalletd gRPC/TLS client;
- reuses that connection for all `GetBlock` probes;
- keeps the existing 200-block safety margin;
- leaves the rescan height/serialization and wallet scanning behavior unchanged.

The Flutter UI/API remains compatible: `estimateHeightForDate()` and
`rescanFromHeight()` have the same signatures.
