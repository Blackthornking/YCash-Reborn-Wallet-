# Background sync implementation

Implemented in this build:

- Added `flutter_foreground_task: ^8.17.0`.
- Added Android foreground-service, notification, and `dataSync` permissions.
- Added the foreground service declaration to the app manifest.
- Reworked `lib/core/background_sync/background_sync.dart` to:
  - initialize the foreground service;
  - start it for Background sync = On;
  - run the existing Ycash native sync engine every 30 seconds while locked;
  - update a low-priority progress notification;
  - recover the native wallet from the existing unattended seed cache if Android recreates the service;
  - stop before Android 15's six-hour `dataSync` limit;
  - retain WorkManager as fallback;
  - stop the foreground service when Background sync is turned Off.
- Updated app lifecycle handling so returning to the foreground restarts the service after its Android time window has expired.
- Wallet wipe already disables Background sync; it now also stops the foreground service through the existing scheduler path.

No Rust, transaction serialization, key serialization, or signature-format code was changed.
