# Modern Home & Global Currency Update

This update refreshes the wallet home screen with:

- Shielded wallet protection status
- Total portfolio balance
- Separate Shielded (Sapling) and Transparent connection cards
- Pool-specific balances and direct receive access
- Send, Receive and Shield quick actions
- Wallet sync, backup and device-protection health indicators
- Pull-to-refresh balance refresh
- Global local-currency selector in Settings
- Searchable ISO-style list of major active global currencies
- Honest fiat quote handling: no fabricated exchange rate is shown when a verified Ycash market quote is unavailable

The update does not change wallet cryptography, key derivation, transaction formats, address derivation, or signing behaviour.
