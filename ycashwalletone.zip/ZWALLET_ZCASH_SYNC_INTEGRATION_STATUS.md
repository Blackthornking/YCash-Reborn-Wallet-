# ZWallet / zcash-sync integration

This package stages the complete uploaded `zcash-sync` source under
`packages/warp_api_ffi/native/zcash-sync` and wires the existing ZWallet Dart
FFI bindings into the Ycash app.

The Android build now produces both:

- `libycash_core.so` for the existing seed lifecycle.
- `libwarp_api_ffi.so` for wallet database, Ycash account/address derivation,
  lightwalletd sync, balances and transaction history.

The Warp crate is built with `--features dart_ffi` and `crate-type = ["cdylib",
"rlib"]`.

## Security gate

Transaction creation and broadcasting remain fail-closed. They are not enabled
until an Android build succeeds and Ycash network acceptance tests verify the
exact prover parameters, transaction format, address prefixes and broadcast
behaviour.

## Important build limitation

This integration was assembled from the uploaded source archives, but this
execution environment does not contain the Rust `cargo` toolchain, so the native
Android build could not be compiled here. The GitHub Actions workflow must be
used as the next build gate; a successful APK build is required before calling
this backend production-ready.
