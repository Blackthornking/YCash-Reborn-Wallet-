# Phase 43

Phase 43 connects a real compact-block scanner abstraction to the authenticated
storage path. The decoder must be implemented by the pinned Ycash-compatible
scanner and must return only trial-decrypted, commitment-tree-authenticated data.
