# Phase 40

Phase 40 replaces unconstrained opaque wallet bytes with a strict storage-boundary decoder and a Rust-only secret-vault interface. This is deliberately fail-closed: bytes with the wrong lengths or malformed witness chunking are rejected before any transaction builder is invoked.

The next phase must use the scanner's exact witness/path-direction encoding and note plaintext encoding to reconstruct the upstream Sapling types; those encodings must not be guessed.
