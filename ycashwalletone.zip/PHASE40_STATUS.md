# Phase 40 — Wallet Data Decoding & Rust-Only Key Vault

Implemented:
- strict persisted authenticated-note decoding with fixed-size commitment/anchor checks;
- witness chunk validation;
- explicit rejection of empty key handles;
- Rust-only key-vault abstraction with a zeroizing in-process test adapter;
- no private key serialization or Flutter/FFI exposure.

Not yet complete:
- exact scanner-produced note plaintext decoding into upstream `sapling::Note`;
- exact Merkle-path reconstruction (path direction bits must come from the scanner format);
- production platform-keystore adapter;
- transaction build/prove/sign and `ycashd` acceptance.

Mainnet spending remains disabled.
