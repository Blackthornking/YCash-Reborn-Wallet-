# macOS Runner

Generate the official Flutter macOS host:

    flutter create --platforms=macos .

Then add the macOS Rust dynamic-library bridge and review sandbox entitlements.
