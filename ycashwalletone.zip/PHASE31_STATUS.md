# Phase 31 — Real Sapling Spending Integration Status

## What this phase adds
- A strict production spending interface (`YcashSaplingSpender`).
- A typed boundary between transaction planning and cryptographic transaction bytes.
- A safe disabled implementation that cannot fabricate a successful spend.
- Root Git hygiene for Flutter, Rust, Android, IDE artifacts and secrets.

## What is still required before mainnet spending can be enabled
1. Link a reviewed Ycash-compatible Sapling transaction builder/prover.
2. Supply the correct Sapling Groth16 proving parameters and verify their hashes.
3. Construct spends and outputs from wallet notes and witnesses.
4. Generate spend proofs and output proofs.
5. Generate spend authorization signatures and the binding signature.
6. Compute the exact Ycash transaction digest and serialize with Ycash consensus parameters.
7. Submit generated transactions to a Ycash consensus node and require acceptance.
8. Add deterministic known-answer vectors and integration tests against a controlled Ycash node.

## Production status
**MAINNET SPENDING: DISABLED.**

This is intentional. The project now has the correct integration boundary, but it
must not claim to perform Sapling proving/signing until the concrete backend and
consensus-node acceptance tests exist and pass.
