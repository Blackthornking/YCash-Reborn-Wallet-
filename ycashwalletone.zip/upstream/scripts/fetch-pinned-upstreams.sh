#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
DEST="$ROOT/upstream/pinned"
mkdir -p "$DEST"
fetch() {
  local name="$1" url="$2" rev="$3"
  if [ ! -d "$DEST/$name/.git" ]; then
    git clone --filter=blob:none "$url" "$DEST/$name"
  fi
  git -C "$DEST/$name" fetch --depth 1 origin "$rev"
  git -C "$DEST/$name" checkout --detach "$rev"
  test "$(git -C "$DEST/$name" rev-parse HEAD)" = "$rev"
}
fetch sapling-crypto-ycash https://github.com/ycashfoundation/sapling-crypto-ycash.git c5e596c239dbf9138a74246b843bcd01413f51c7
fetch librustzcash-nu61 https://github.com/ycashfoundation/librustzcash-nu61.git 26de676f2c5c0e2d35e0b28b7bea704f4ff0411e
fetch zcash-sync https://github.com/ycashfoundation/zcash-sync.git d91b60309b9b414ad5359ae3da4407b8abe234df
