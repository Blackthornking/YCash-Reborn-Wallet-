# Phase 54 — Ycash upstream integration

This phase adds a reproducible upstream acquisition boundary for the Android native wallet.

## Included targets

- `ycashfoundation/librustzcash-nu61`
- `ycashfoundation/sapling-crypto-ycash`
- Ycash light-client protocol compatibility work remains behind the existing read-only gate.

## Security rule

The fetch script is **not** permission to enable spending. Before a release:

1. Replace branch names in the lock file with immutable reviewed commit SHAs.
2. Record SHA-256/source provenance.
3. Compile Android ABIs in CI.
4. Pass Ycash shielded and transparent address vectors.
5. Sync against a Ycash-compatible lightwalletd endpoint.
6. Verify balances/history against an independent wallet.
7. Construct and locally verify transactions.
8. Broadcast on a non-production test environment first.
9. Only then enable mainnet spend/broadcast gates.

Until those checks pass, the app remains fail-closed for address claims, spending and broadcasting.
