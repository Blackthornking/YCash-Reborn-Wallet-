# Phase 24 — Scan State, Balances & History

## Implemented in this phase
- Deterministic wallet scan-state model.
- Owned-note accounting.
- Observed-nullifier tracking boundary.
- Confirmed balance calculation.
- Chain rewind/reorg handling.
- Transaction history model with reorg status.
- SQLite schema extended for scan state, nullifiers, and transaction history.
- Fixture policy requiring real public Ycash source data.

## Not yet implemented
- Real Sapling trial decryption.
- Compact-block decoding against the pinned backend.
- Witness construction.
- Real wallet-owned note discovery.
- Spending, shielding, sending, or unshielding.

## Safety
Spending remains disabled until real backend compilation and Ycash cryptographic vectors pass.
