# Ycash Reborn

New Flutter codebase for a futuristic, Ycash-only shielded wallet. See
`PLAN.md` for the full project plan and phasing.

## What's in this drop (Phase 2 + start of Phase 3)

- `PLAN.md` — full project plan.
- `pubspec.yaml` — modernized dependency set (Riverpod, go_router 14,
  flutter_secure_storage, mobile_scanner, fl_chart, flutter_animate, no
  Zcash-only packages).
- `assets/branding/logo.svg` — new "shielded Y" logo, no Zcash branding.
- `lib/design/tokens.dart` — color/type/spacing/motion design system.
- `lib/core/models/ycash_config.dart` — single-coin config replacing the
  old multi-coin `CoinBase`/`coins.dart` abstraction.
- `lib/core/crypto_bridge/ycash_engine.dart` — the typed contract the app
  talks to. **No cryptography lives here or anywhere in `lib/`.**
- `lib/core/biometrics/biometric_gate.dart` — the single chokepoint every
  sensitive action (send, shield, unshield, reveal seed, wipe wallet) must
  pass through, with a PIN fallback if biometrics aren't enrolled.
- `lib/features/shield/shield_flow.dart` + `lib/features/home/home_screen.dart`
  — the headline one-tap shield/unshield UX, biometric-gated end to end.

## The Rust backend: trim, don't rewrite

`packages/ycash_core_ffi` (referenced by `pubspec.yaml`, not included in
this drop) should start as a copy of the original project's `rust/` +
`librustzcash` + relevant crates, then have the following removed:

1. All `orchard` crate usage and any code path gated on it — Ycash never
   activated Orchard.
2. Unified Address encoding/decoding and any "UA type" branching.
3. Ledger hardware wallet transport and signing code.
4. Zcash mainnet and testnet network parameters, activation heights, and
   the `ZcashCoin`/`ZcashTestCoin` equivalents — one network only
   (Ycash mainnet, lightwalletd at `lite.ycash.xyz:9067`).
5. Any multi-coin dispatch table — replace with direct calls, since there's
   only one coin.

Keep, verbatim, everything implementing: Sapling note commitments,
nullifiers, spend/output proving and verification, the warp-sync algorithm,
and transparent-pool handling. Do not hand-modify the proving/verifying key
material or the note commitment tree logic — that's the part where a typo
costs someone their funds.

## Phase 4 additions (onboarding + send/receive)

- `lib/core/secure_storage/seed_vault.dart` — encrypted-at-rest seed
  storage; `read()` requires proof of a passed [`BiometricGate`] auth, so
  there's no code path that returns the seed without it.
- `lib/features/onboarding/` — welcome → create-or-restore → seed backup
  (reveal gated by biometrics, plus a pick-the-word verification quiz
  before continuing) → biometric enrollment (falls back to an app PIN if
  the device has none). Onboarding is considered complete once backup is
  confirmed — no separate flag to drift out of sync.
- `lib/features/send/send_screen.dart` — address (with QR scan via
  `mobile_scanner`), amount, optional memo, fee-tier chips, review sheet,
  then a biometric-gated confirm before broadcast.
- `lib/features/receive/receive_screen.dart` — toggle between shielded and
  transparent addresses, QR + share, with a note that transparent funds
  are one tap from being shielded on the home screen.
- `lib/app/router.dart` + `lib/app/app.dart` — go_router wiring; the
  redirect logic sends anyone without a confirmed backup straight to
  onboarding, so `/send` etc. can't be deep-linked into prematurely.
- `lib/main.dart` — entry point; wire the real engine implementation here
  once `packages/ycash_core_ffi` exists (see the trim plan above).

## Phase 9-10 additions (activity + settings)

- `lib/features/transactions/transactions_screen.dart` — history list with
  All/Shielded/Transparent filter chips, grouped visually by direction.
- `lib/features/transactions/tx_detail_screen.dart` — amount, date, copyable
  txid, memo (if present), and a link out to the configured block explorer.
- `lib/features/settings/settings_screen.dart` — Security (view recovery
  phrase, change PIN), Network (sync server), About (version, block
  explorer link), and a Danger Zone (wipe wallet) — every sensitive action
  routes through [`BiometricGate`] first.
- `lib/features/settings/seed_reveal_screen.dart` — read-only phrase reveal
  for people who already backed up during onboarding; still gated.
- `lib/features/settings/server_settings_screen.dart` — lets the sync
  server URL be changed or reset to the shipped default; explicitly framed
  as "only affects how you see the chain, never your keys."
- `lib/core/settings_store/settings_store.dart` — a small, deliberately
  separate store (backed by `shared_preferences`) for non-secret settings
  like the server URL, kept apart from `SeedVault` so nothing sensitive
  can accidentally end up in plain preferences.

## Phase 11 — polish pass (complete)

Auditing every screen for three things bare early drafts tended to skip:
a retry-capable error state instead of dead-end text, a screen-reader-
friendly combined semantics label instead of several disconnected text
nodes, and a subtle entrance motion that still respects the OS
"reduce motion" setting. `lib/design/widgets.dart` (`YErrorState`,
`YEmptyState`, `YBusyState`, `YEnter`, `YHaptics`) is the shared toolkit
this pass reaches for instead of each screen hand-rolling its own.

Audited:

- `lib/features/transactions/transactions_screen.dart` — retry wired via
  `YErrorState` + `ref.invalidate(transactionHistoryProvider)`, empty
  state now distinguishes "no transactions ever" from "none matching this
  filter," tx tiles merged into one semantics node per row, list entries
  fade/slide in staggered by index.
- `lib/features/transactions/tx_detail_screen.dart` — summary header and
  each detail row merged into one semantics node apiece, copy button has
  an accessible tooltip, content sections have a light staggered entrance,
  explorer-launch failure gets the same haptic warn used elsewhere.
- `lib/design/tokens.dart` — added a shared `inputDecorationTheme` (filled
  space-surface background, subtle rest border, shielded-accent focus
  ring) so every `TextField` in the app inherits one look instead of each
  screen hand-rolling `OutlineInputBorder()`.
- `lib/features/send/send_screen.dart` — text fields now use the shared
  input theme; the QR scanner has a viewfinder frame, on-screen guidance
  text, and a retry-capable camera-error state instead of a bare preview;
  the review bottom sheet's rows stagger in with `YEnter` instead of
  snapping in all at once.
- `lib/features/settings/settings_screen.dart` — change-PIN is now its own
  dialog with a confirm field and inline validation (previously a PIN
  under 4 digits, or a typo in a confirm field that didn't exist, failed
  silently); wipe-wallet's storage/engine calls are wrapped so a failure
  mid-wipe surfaces an error instead of leaving the user unsure whether
  anything happened; every row uses `MergeSemantics` so leading icon,
  title, and trailing chevron read as one item; section headers are
  marked as accessibility headers; auth failures and errors get the same
  haptic warn used elsewhere.
- `lib/features/settings/server_settings_screen.dart` — a failed load of
  the saved server now shows a retryable `YErrorState` instead of an
  infinite spinner; saving validates the URL has a scheme and host
  instead of writing anything (including empty strings) straight to
  storage; save/reset failures surface an error instead of failing
  silently.
- `lib/features/onboarding/welcome_screen.dart` — the logo/heading/tagline
  entrance now runs through `YEnter` instead of raw `.animate()` calls, so
  it actually respects "reduce motion" like the rest of the app; the logo
  is marked decorative (`excludeFromSemantics`) and the heading + tagline
  are merged into one semantics node instead of two separate stops; the
  two buttons stagger in after.
- `lib/features/onboarding/biometric_enroll_screen.dart` — the device
  check's bare `CircularProgressIndicator` is now a `YBusyState`; the
  fingerprint icon and its explanation are merged into one semantics
  node; both branches' content staggers in with `YEnter`; PIN validation
  errors get the same haptic warn used everywhere else and are announced
  via a `liveRegion`; saving the PIN is now wrapped in a try/catch so a
  storage failure surfaces a retryable error instead of leaving "Set PIN"
  looking like it silently did nothing.
- `lib/features/onboarding/seed_backup_screen.dart` — the word grid
  staggers in with `YEnter.staggered` and each tile gets a proper "Word
  N: word" semantics label instead of the raw "1.  word" text; a failed
  auth on reveal now gets the same haptic warn used elsewhere; a wrong
  quiz answer also buzzes; confirming the backup (the storage write) is
  now wrapped in a try/catch — previously a failure there left "Continue"
  looking like a dead tap with no way to tell whether the backup was
  actually confirmed, now it surfaces an error and the retry is just
  pressing Continue again.

(`lib/features/onboarding/restore_wallet_screen.dart` was reviewed and
confirmed solid — no changes needed there.)

Every screen on the original checklist has now been through this pass.

### Two more found outside the original checklist

Going back over the rest of the app for the same three things turned up
two spots that predate this pass and were never on its list, both worth
closing out for the pass to actually mean what it says:

- `lib/app/app.dart` — the onboarding-status check that gates the very
  first frame of the app was unguarded: a secure-storage read failure at
  boot left every cold start on a bare spinner forever, since `_router`
  never got built and nothing else could run. This is the one dead-end
  spinner that would have hit every user rather than just one screen.
  Now wrapped in a try/catch with a retryable `YErrorState`.
- `lib/features/home/home_screen.dart` — the sync banner and the two
  balance cards animated in with raw `.animate()` calls that don't check
  "reduce motion"; switched to `YEnter`. The loading skeleton's shimmer
  is a *looping* animation rather than a one-off entrance, so it's now
  gated separately: reduce-motion renders a plain static block instead
  of suppressing just the fade-in.
- `lib/features/shield/shield_flow.dart` — a wrong PIN on the
  shield/unshield confirm sheet used to pop the sheet with `false` and no
  message at all, indistinguishable from a deliberate cancel — the whole
  attempt just vanished. The sheet is now a small stateful widget that
  shows an inline "Incorrect PIN" and lets you try again in place;
  the auth-failure branch and the broadcast-failure branch each pick up
  the same haptic warn used everywhere else (both were silent); the
  review sheet's rows now stagger in with `YEnter` like the send flow's
  equivalent sheet already did.
- `lib/features/settings/seed_reveal_screen.dart` — the word grid tiles
  now get the same "Word N: word" semantics label as the onboarding
  backup screen's grid, instead of the raw "1.  word" text. Everything
  else here (retry-capable error handling, busy/entrance states) was
  already solid.

## Building

This was written outside a build environment (the assistant sandbox has no
network access), so it hasn't been `flutter pub get` / `cargo build`
verified. Steps in your own environment:

```
flutter pub get
# once packages/ycash_core_ffi exists per the trim plan above:
cd packages/ycash_core_ffi && cargo build --release
cd ../..
flutter run
```

## Phase 14 safety gate
The project now contains the real light-wallet gRPC transport boundary, but real-fund Sapling operations remain disabled until Ycash-specific upstream revisions are pinned and validated. Do not use placeholder cryptography for addresses or transactions.

## Phase 16 — read-only Ycash integration

This package now contains strict `ys...` Sapling network validation and a
read-only sync plan. It still does **not** enable spending. The next milestone
must integrate exact Ycash-compatible Sapling key derivation and compact-block
trial decryption, then prove results against Ycash reference fixtures before
any real-money transaction code is enabled.

## Phase 21

Deterministic read-only validation harness added; spending remains disabled.

## Phase 34
Authenticated Sapling spend-context boundary added; real proving remains disabled pending concrete API integration and node acceptance tests.

## Phase 38
The project vendors the Ycash NU61 Rust transaction workspace behind a feature gate. CI must compile `ycash-transaction` before any cryptographic spending path is enabled.
