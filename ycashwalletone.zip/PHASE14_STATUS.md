# Ycash Reborn Phase 14 — Network Integration Gate

Implemented:
- Modern tonic/prost gRPC light-wallet transport boundary.
- Ycash-compatible lightwallet protocol protobufs vendored from the supplied sync source for reproducible builds.
- TLS-only production endpoint parser.
- Explicit upstream dependency manifest for Ycash, sapling-crypto-ycash, librustzcash-nu61 and lightwallet protocol.
- Sync state/progress API.
- No Orchard or Halo2 dependency is enabled.

Not yet enabled:
- Real Sapling key derivation/address generation.
- Compact-block decryption/scanning.
- Witness/nullifier tracking.
- Transaction proving/signing.
- Shield/unshield/broadcast.

These are blocked on pinning the exact Ycash-maintained Sapling/librustzcash revisions and passing compatibility tests against Ycash before any real-fund operations are exposed.
