use rusqlite::{Connection, OptionalExtension};

pub fn set_db_passwd(connection: &Connection, passwd: &str) -> anyhow::Result<()> {
    // The wallet never actually calls set_coin_passwd from Dart, so passwd
    // is always "" in practice. If this build has the optional `sqlcipher`
    // feature enabled, "PRAGMA key = ''" still runs a full PBKDF2 key
    // derivation over an empty passphrase - not a no-op - and this
    // constructor runs once per block-chunk during sync, so that cost was
    // being paid repeatedly for a key nobody set. Skip the pragma entirely
    // when there's no real passphrase; a later real set_coin_passwd call
    // will still go through set_db_passwd with a non-empty value.
    if passwd.is_empty() {
        return Ok(());
    }
    connection
        .query_row(&format!("PRAGMA key = '{}'", passwd), [], |_| Ok(()))
        .optional()?;
    Ok(())
}

pub fn check_passwd(connection: &Connection, passwd: &str) -> anyhow::Result<bool> {
    set_db_passwd(connection, passwd)?;
    let c = connection.query_row("SELECT COUNT(*) FROM sqlite_master", [], |row| {
        let c: u32 = row.get(0)?;
        Ok(c)
    });
    Ok(c.is_ok())
}

pub fn clone_db_with_passwd(src: &Connection, new_path: &str, passwd: &str) -> anyhow::Result<()> {
    src.execute(
        &format!(
            "ATTACH DATABASE '{}' AS encrypted KEY '{}'",
            new_path, passwd
        ),
        [],
    )?;
    src.query_row("SELECT sqlcipher_export('encrypted')", [], |_row| Ok(()))?;
    src.execute("DETACH DATABASE encrypted", [])?;
    Ok(())
}
