#!/usr/bin/env bash
set -euo pipefail
cargo metadata --format-version=1 --no-deps >/dev/null
cargo tree -i halo2_gadgets 2>/dev/null || true
