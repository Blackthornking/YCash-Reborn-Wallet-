//! Read-only Ycash sync orchestration.
//!
//! Network transport is separated from wallet scanning so that compact-block
//! fetching can be tested without exposing spending keys.
use crate::sync::scanner::{ScanProgress, ScanRange};

#[derive(Debug, Clone)]
pub struct ReadOnlySyncPlan {
    pub birthday_height: u32,
    pub batch_size: u32,
}

impl Default for ReadOnlySyncPlan {
    fn default() -> Self { Self { birthday_height: 570_000, batch_size: 1_000 } }
}

impl ReadOnlySyncPlan {
    pub fn next_range(&self, current: u32, tip: u32) -> Option<ScanRange> {
        if current >= tip { return None; }
        let start = current.saturating_add(1);
        let end = start.saturating_add(self.batch_size.saturating_sub(1)).min(tip);
        Some(ScanRange { start, end })
    }

    pub fn progress(&self, current: u32, tip: u32, notes: u64, spends: u64) -> ScanProgress {
        ScanProgress { height: current, target_height: tip, discovered_notes: notes, discovered_spends: spends }
    }
}
