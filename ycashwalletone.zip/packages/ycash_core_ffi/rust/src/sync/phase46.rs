//! Phase 46: real upstream compact-block scanning adapter.
//!
//! This module invokes the pinned Ycash NU61 `scan_block` implementation. Compact
//! blocks are decoded using generated protobuf types and then re-encoded into the
//! upstream generated CompactBlock type; no hand-written wire parsing is used.
//!
//! The adapter deliberately returns the upstream `ScannedBlock` unchanged. Mapping
//! it into the wallet's storage schema is a separate step so that cryptographic
//! scan results cannot be silently reinterpreted or fabricated.

#![cfg(feature = "ycash-scanner")]

use prost::Message;
use subtle::ConditionallySelectable;
use std::hash::Hash;

use crate::lightclient::proto::CompactBlock as TransportCompactBlock;

use zcash_client_backend_ycash::{
    data_api::{BlockMetadata, Nullifiers, ScannedBlock},
    proto::compact_formats::CompactBlock as UpstreamCompactBlock,
    scanning::{scan_block, ScanningKeys},
};
use zcash_protocol_ycash::consensus;

/// Errors from the source-verified upstream scanner adapter.
#[derive(Debug, thiserror::Error)]
pub enum Phase46Error {
    #[error("transport CompactBlock cannot be encoded: {0}")]
    Encode(#[from] prost::EncodeError),
    #[error("upstream CompactBlock cannot be decoded: {0}")]
    Decode(#[from] prost::DecodeError),
    #[error("upstream compact-block scan failed: {0}")]
    Scan(String),
}

/// A key-bearing scanner that performs real Sapling compact-note trial
/// decryption through the pinned NU61 upstream implementation.
pub struct YcashNu61TrialDecryptScanner<AccountId, IvkTag> {
    scanning_keys: ScanningKeys<AccountId, IvkTag>,
    nullifiers: Nullifiers<AccountId>,
}

impl<AccountId, IvkTag> YcashNu61TrialDecryptScanner<AccountId, IvkTag> {
    pub fn new(
        scanning_keys: ScanningKeys<AccountId, IvkTag>,
        nullifiers: Nullifiers<AccountId>,
    ) -> Self {
        Self { scanning_keys, nullifiers }
    }

    /// Converts generated transport protobufs into the exact generated protobuf
    /// type expected by the pinned upstream scanner.
    fn to_upstream(
        &self,
        block: &TransportCompactBlock,
    ) -> Result<UpstreamCompactBlock, Phase46Error> {
        let bytes = block.encode_to_vec();
        Ok(UpstreamCompactBlock::decode(bytes.as_slice())?)
    }

    /// Runs the real upstream batch trial-decryption scanner.
    pub fn scan<P>(
        &self,
        params: &P,
        block: &TransportCompactBlock,
        prior: Option<&BlockMetadata>,
    ) -> Result<ScannedBlock<AccountId>, Phase46Error>
    where
        P: consensus::Parameters + Send + 'static,
        AccountId: Default + Eq + Hash + ConditionallySelectable + Send + 'static,
        IvkTag: Copy + Eq + Hash + Send + 'static,
    {
        let upstream_block = self.to_upstream(block)?;
        scan_block(
            params,
            upstream_block,
            &self.scanning_keys,
            &self.nullifiers,
            prior,
        ).map_err(|e| Phase46Error::Scan(e.to_string()))
    }
}
