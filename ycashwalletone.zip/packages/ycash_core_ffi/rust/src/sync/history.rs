use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum TransactionStatus { Pending, Confirmed, Reorged }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WalletTransaction {
    pub txid: String,
    pub height: Option<u32>,
    pub value_delta: i64,
    pub status: TransactionStatus,
}

#[derive(Debug, Default)]
pub struct TransactionHistory { entries: Vec<WalletTransaction> }

impl TransactionHistory {
    pub fn upsert(&mut self, tx: WalletTransaction) {
        if let Some(existing) = self.entries.iter_mut().find(|e| e.txid == tx.txid) { *existing = tx; }
        else { self.entries.push(tx); }
        self.entries.sort_by_key(|e| e.height.unwrap_or(u32::MAX));
    }
    pub fn entries(&self) -> &[WalletTransaction] { &self.entries }
    pub fn rewind_to(&mut self, height: u32) {
        for tx in &mut self.entries {
            if tx.height.is_some_and(|h| h > height) { tx.status = TransactionStatus::Reorged; tx.height = None; }
        }
    }
}
