use crate::network::NetworkConfig;
use crate::keys::{SeedMaterial, WalletMnemonic};
use crate::sync::SyncEndpoint;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum WalletError {
    #[error("invalid configuration: {0}")] InvalidConfiguration(String),
    #[error("invalid mnemonic: {0}")] InvalidMnemonic(String),
    #[error("cryptographic operation failed: {0}")] Crypto(String),
    #[error("storage error: {0}")] Storage(String),
    #[error("feature is not enabled until Ycash compatibility tests pass")] FeatureNotReady,
}

pub struct WalletEngine { network: NetworkConfig, endpoint: Option<SyncEndpoint> }

impl WalletEngine {
    pub fn new(network: NetworkConfig) -> Self { Self { network, endpoint: None } }
    pub fn network(&self) -> &NetworkConfig { &self.network }
    pub fn set_endpoint(&mut self, endpoint: &str) -> Result<(), WalletError> {
        self.endpoint = Some(
            SyncEndpoint::parse(endpoint)
                .map_err(|error| WalletError::InvalidConfiguration(error.to_string()))?,
        );
        Ok(())
    }
    pub fn create_wallet(&self) -> Result<(WalletMnemonic, SeedMaterial), WalletError> { WalletMnemonic::generate_24() }
    pub fn restore_wallet(&self, phrase: &str, passphrase: &str) -> Result<(WalletMnemonic, SeedMaterial), WalletError> { WalletMnemonic::restore(phrase, passphrase) }
    pub fn endpoint(&self) -> Option<&SyncEndpoint> { self.endpoint.as_ref() }
    pub fn signing_enabled(&self) -> bool { false }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::network::YcashMainnet;
    #[test]
    fn creates_24_word_wallet() {
        let e = WalletEngine::new(YcashMainnet::config());
        let (m, s) = e.create_wallet().unwrap();
        assert_eq!(m.expose_for_backup().split_whitespace().count(), 24);
        assert_eq!(s.0.len(), 64);
    }
}
