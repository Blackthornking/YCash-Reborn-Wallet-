//! Deterministic wallet derivation boundaries for Ycash.
//!
//! This module deliberately keeps standard mnemonic/seed handling separate from
//! the Ycash-specific Sapling backend. A wallet cannot claim an address is owned
//! until the pinned backend derives it and the resulting output passes vectors.

use crate::keys::SeedMaterial;
use zeroize::Zeroizing;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DerivationMode {
    /// Standard wallet derivation used by normal Ycash software.
    Standard,
    /// Ycash Ledger recovery path. This is intentionally separate because the
    /// Ledger implementation uses a non-standard Sapling seed transform.
    LedgerCompatibility,
}

#[derive(Clone)]
pub struct AccountSeed {
    pub account: u32,
    pub material: Zeroizing<Vec<u8>>,
}

impl AccountSeed {
    pub fn from_wallet_seed(seed: &SeedMaterial, account: u32) -> Self {
        // This is a deterministic account-domain boundary, not a replacement for
        // ZIP-32. Real Sapling derivation is delegated to the pinned backend.
        let mut material = Vec::with_capacity(seed.0.len() + 4);
        material.extend_from_slice(&seed.0);
        material.extend_from_slice(&account.to_le_bytes());
        Self { account, material: Zeroizing::new(material) }
    }
}
