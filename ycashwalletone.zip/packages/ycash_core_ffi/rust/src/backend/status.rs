//! Runtime capability manifest exposed to the Flutter host.
//!
//! This deliberately distinguishes "source is vendored" from "safe to use for
//! mainnet spending". A capability can only be promoted after deterministic
//! Ycash vectors and an independent transaction acceptance test pass.

use serde::Serialize;

#[derive(Debug, Serialize)]
pub struct BackendStatus {
    pub engine_version: &'static str,
    pub network: &'static str,
    pub upstream_pinned: bool,
    pub sapling_source_present: bool,
    pub address_derivation_verified: bool,
    pub scanner_verified: bool,
    pub transaction_builder_verified: bool,
    pub proving_verified: bool,
    pub broadcast_enabled: bool,
}

pub fn current() -> BackendStatus {
    BackendStatus {
        engine_version: crate::ENGINE_VERSION,
        network: "ycash-mainnet",
        upstream_pinned: true,
        sapling_source_present: cfg!(feature = "ycash-sapling"),
        address_derivation_verified: false,
        scanner_verified: false,
        transaction_builder_verified: false,
        proving_verified: false,
        broadcast_enabled: false,
    }
}
