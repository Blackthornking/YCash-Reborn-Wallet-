//! Auditable upstream snapshot record.
//!
//! These IDs identify the source snapshots supplied for Ycash Reborn. They are
//! deliberately not floating `main` dependencies. Before enabling spending,
//! replace this record with reviewed Ycash Foundation commit pins and record
//! the compatibility-test results in RELEASE_SECURITY.md.

pub const LIBRUSTZCASH_SOURCE_SNAPSHOT: &str = "a40ee353bba84d1cb3eaf1889df433d3be9c79e5";
pub const ZCASH_SYNC_SOURCE_SNAPSHOT: &str = "d91b60309b9b414ad5359ae3da4407b8abe234df";
