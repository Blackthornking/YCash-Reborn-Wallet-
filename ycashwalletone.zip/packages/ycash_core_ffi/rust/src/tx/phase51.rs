//! Phase 51: production transaction-builder boundary.
//!
//! This module makes the remaining consensus-critical inputs explicit and refuses
//! to downgrade them to opaque bytes. It is intentionally separated from network
//! broadcast: a transaction is broadcast only after cryptographic construction and
//! local verification have succeeded.

use super::{AuthenticatedNote, ProvingParameters, SaplingNoteMaterial, MerkleWitnessStep, TransactionPlan, YcashNetwork};

pub const SAPLING_TREE_DEPTH: usize = 32;

#[derive(Debug, thiserror::Error)]
pub enum BuildInputError {
    #[error("recipient is empty")]
    EmptyRecipient,
    #[error("amount must be non-zero")]
    ZeroAmount,
    #[error("no authenticated notes selected")]
    NoInputs,
    #[error("note {index} has an incomplete witness: expected {SAPLING_TREE_DEPTH}, got {got}")]
    BadWitnessDepth { index: usize, got: usize },
    #[error("note material is missing for selected note {0}")]
    MissingMaterial(usize),
    #[error("proving parameter path is empty")]
    MissingProvingParameters,
    #[error("selected notes have inconsistent Sapling anchors")]
    InconsistentAnchor,
}

/// Exact material required to reconstruct a Sapling `Note` and its witness.
#[derive(Debug, Clone)]
pub struct BuilderSpendInput {
    pub authenticated: AuthenticatedNote,
    pub material: SaplingNoteMaterial,
    pub witness: Vec<MerkleWitnessStep>,
}

/// Complete backend-owned request. Spending keys remain referenced by opaque
/// handles and must be resolved inside Rust's key vault.
#[derive(Debug, Clone)]
pub struct ProductionBuildRequest {
    pub network: YcashNetwork,
    pub target_height: u32,
    pub plan: TransactionPlan,
    pub spends: Vec<BuilderSpendInput>,
    pub change_address: String,
    pub proving_params: ProvingParameters,
}

impl ProductionBuildRequest {
    pub fn validate(&self) -> Result<(), BuildInputError> {
        if self.plan.recipient.trim().is_empty() { return Err(BuildInputError::EmptyRecipient); }
        if self.plan.amount == 0 { return Err(BuildInputError::ZeroAmount); }
        if self.spends.is_empty() { return Err(BuildInputError::NoInputs); }
        if self.proving_params.spend_params_path.trim().is_empty() || self.proving_params.output_params_path.trim().is_empty() {
            return Err(BuildInputError::MissingProvingParameters);
        }
        let first_anchor = self.spends[0].authenticated.anchor;
        for (i, spend) in self.spends.iter().enumerate() {
            if spend.witness.len() != SAPLING_TREE_DEPTH {
                return Err(BuildInputError::BadWitnessDepth { index: i, got: spend.witness.len() });
            }
            if spend.authenticated.anchor != first_anchor { return Err(BuildInputError::InconsistentAnchor); }
        }
        Ok(())
    }
}

/// Result before network broadcast. `raw` is consensus serialization; `txid_hex`
/// must be derived from that exact serialization by the upstream transaction code.
#[derive(Debug, Clone)]
pub struct LocallyVerifiedTransaction {
    pub raw: Vec<u8>,
    pub txid_hex: String,
}

/// Cryptographic backend contract. Implementations must use the pinned YCash
/// upstream types; mock provers are forbidden in production builds.
pub trait ProductionTransactionBuilder: Send + Sync {
    fn build_and_verify(&self, request: &ProductionBuildRequest) -> Result<LocallyVerifiedTransaction, String>;
}

/// Fails closed until the exact vendored upstream API is compiled into this target.
pub struct UnlinkedProductionBuilder;
impl ProductionTransactionBuilder for UnlinkedProductionBuilder {
    fn build_and_verify(&self, request: &ProductionBuildRequest) -> Result<LocallyVerifiedTransaction, String> {
        request.validate().map_err(|e| e.to_string())?;
        Err("YCash production transaction builder is not linked in this build".into())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::tx::{MerkleWitness, ProvingParameters};

    fn request() -> ProductionBuildRequest {
        let anchor=[9u8;32];
        let steps=(0..32).map(|i| MerkleWitnessStep{sibling:[i as u8;32],is_right:i%2==1}).collect();
        ProductionBuildRequest {
            network:YcashNetwork::Testnet, target_height:1,
            plan:TransactionPlan{recipient:"ys1test".into(),amount:1,memo:None},
            spends:vec![BuilderSpendInput{
                authenticated:AuthenticatedNote{note_commitment:[1;32],value:2,position:0,anchor,witness:MerkleWitness{auth_path:vec![[0;32];32]},spending_key_handle:"k".into()},
                material:SaplingNoteMaterial{diversifier:[0;11],pk_d:[0;32],rcm:[0;32]},
                witness:steps,
            }],
            change_address:"ys1change".into(),
            proving_params:ProvingParameters{spend_params_path:"spend.params".into(),output_params_path:"output.params".into()},
        }
    }
    #[test] fn validates_complete_inputs() { assert!(request().validate().is_ok()); }
    #[test] fn rejects_incomplete_witness() { let mut r=request(); r.spends[0].witness.pop(); assert!(matches!(r.validate(),Err(BuildInputError::BadWitnessDepth{..}))); }
}
