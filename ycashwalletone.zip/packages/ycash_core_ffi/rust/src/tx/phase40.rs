//! Phase 40: concrete wallet-record decoding and Rust-only key-vault boundary.
//!
//! This module removes the previous "anything goes" opaque-byte boundary. It
//! validates the persisted record format and provides a vault interface whose
//! implementations never expose spending keys through the Flutter FFI.
//!
//! It intentionally does NOT claim that decoded records are already consensus
//! objects; conversion into exact upstream Sapling types is a separate,
//! compile-verified step because note plaintext/nullifier/key encodings must
//! match the scanner that produced them.

use std::collections::HashMap;
use zeroize::Zeroizing;

use super::{AuthenticatedNote, MerkleWitness};

#[derive(Debug, thiserror::Error)]
pub enum Phase40Error {
    #[error("note commitment must be exactly 32 bytes, got {0}")]
    BadCommitment(usize),
    #[error("anchor must be exactly 32 bytes, got {0}")]
    BadAnchor(usize),
    #[error("witness encoding must be a multiple of 32 bytes, got {0}")]
    BadWitness(usize),
    #[error("empty spending-key handle")]
    EmptyHandle,
    #[error("unknown spending-key handle: {0}")]
    UnknownHandle(String),
}

/// Strict database representation used at the storage boundary.
#[derive(Debug, Clone)]
pub struct StoredAuthenticatedNote {
    pub value: u64,
    pub position: u64,
    pub note_commitment: Vec<u8>,
    pub anchor: Vec<u8>,
    pub witness: Vec<u8>,
    pub spending_key_handle: String,
}

impl TryFrom<StoredAuthenticatedNote> for AuthenticatedNote {
    type Error = Phase40Error;
    fn try_from(v: StoredAuthenticatedNote) -> Result<Self, Self::Error> {
        if v.note_commitment.len() != 32 { return Err(Phase40Error::BadCommitment(v.note_commitment.len())); }
        if v.anchor.len() != 32 { return Err(Phase40Error::BadAnchor(v.anchor.len())); }
        if v.witness.len() % 32 != 0 { return Err(Phase40Error::BadWitness(v.witness.len())); }
        if v.spending_key_handle.trim().is_empty() { return Err(Phase40Error::EmptyHandle); }
        let mut cm = [0u8; 32]; cm.copy_from_slice(&v.note_commitment);
        let mut anchor = [0u8; 32]; anchor.copy_from_slice(&v.anchor);
        let auth_path = v.witness.chunks_exact(32).map(|c| { let mut a=[0u8;32]; a.copy_from_slice(c); a }).collect();
        Ok(AuthenticatedNote { note_commitment: cm, value: v.value, position: v.position, anchor, witness: MerkleWitness { auth_path }, spending_key_handle: v.spending_key_handle })
    }
}

/// Rust-only secret vault. The returned secret type is intentionally generic so
/// callers cannot require a Dart/FFI representation of a spending key.
pub trait SpendingKeyVault: Send + Sync {
    type Secret;
    fn resolve(&self, handle: &str) -> Result<Self::Secret, Phase40Error>;
}

/// Minimal in-process vault for tests and future platform-keystore adapters.
/// Secrets are zeroized when removed/dropped and are never serializable.
pub struct MemoryKeyVault {
    entries: HashMap<String, Zeroizing<Vec<u8>>>,
}

impl MemoryKeyVault {
    pub fn new() -> Self { Self { entries: HashMap::new() } }
    pub fn insert(&mut self, handle: impl Into<String>, secret: Vec<u8>) {
        self.entries.insert(handle.into(), Zeroizing::new(secret));
    }
}

impl SpendingKeyVault for MemoryKeyVault {
    type Secret = Zeroizing<Vec<u8>>;
    fn resolve(&self, handle: &str) -> Result<Self::Secret, Phase40Error> {
        if handle.trim().is_empty() { return Err(Phase40Error::EmptyHandle); }
        self.entries.get(handle).cloned().ok_or_else(|| Phase40Error::UnknownHandle(handle.to_owned()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rejects_bad_lengths() {
        let r = StoredAuthenticatedNote { value:1, position:0, note_commitment:vec![0;31], anchor:vec![0;32], witness:vec![], spending_key_handle:"k".into() };
        assert!(matches!(AuthenticatedNote::try_from(r), Err(Phase40Error::BadCommitment(31))));
    }
    #[test]
    fn vault_never_serializes_secret() {
        let mut v=MemoryKeyVault::new(); v.insert("k", vec![7;32]);
        assert_eq!(&*v.resolve("k").unwrap(), &[7;32]);
    }
}
