//! Phase 38: Ycash transaction-stack integration boundary.
//!
//! Private key material remains behind a Rust-only resolver. This module does
//! not expose seed phrases or spending keys to Flutter/FFI callers.

use super::{SpendContext, TransactionPlan};

#[derive(Debug, thiserror::Error)]
pub enum Phase38Error {
    #[error("Phase 37 input validation failed: {0}")]
    Phase37(#[from] super::phase37::Phase37Error),
    #[error("no Rust key resolver is configured for handle {0}")]
    MissingKeyResolver(String),
    #[error("transaction-layer feature is not enabled")]
    TransactionFeatureDisabled,
}

/// Rust-only boundary for resolving an opaque wallet key handle.
/// Implementations must keep secret material out of Dart/Flutter memory.
pub trait SpendingKeyResolver: Send + Sync {
    type Key;
    fn resolve(&self, handle: &str) -> Result<Self::Key, Phase38Error>;
}

/// Validates the complete Phase 38 hand-off before cryptographic construction.
pub fn validate_for_transaction_layer(
    plan: &TransactionPlan,
    context: &SpendContext,
) -> Result<(), Phase38Error> {
    super::phase37::validate_source_verified_inputs(plan, context)?;
    Ok(())
}

/// Compile-time marker proving that the vendored transaction stack is selected.
#[cfg(feature = "ycash-transaction")]
pub const YCAST_TRANSACTION_STACK_SELECTED: bool = true;
#[cfg(not(feature = "ycash-transaction"))]
pub const YCAST_TRANSACTION_STACK_SELECTED: bool = false;

/// Production transaction construction is intentionally unavailable unless the
/// feature is compiled and a concrete key-vault implementation is supplied.
pub fn require_transaction_stack() -> Result<(), Phase38Error> {
    if YCAST_TRANSACTION_STACK_SELECTED { Ok(()) }
    else { Err(Phase38Error::TransactionFeatureDisabled) }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn transaction_feature_is_fail_closed_by_default() {
        #[cfg(not(feature = "ycash-transaction"))]
        assert!(matches!(require_transaction_stack(), Err(Phase38Error::TransactionFeatureDisabled)));
    }
}
