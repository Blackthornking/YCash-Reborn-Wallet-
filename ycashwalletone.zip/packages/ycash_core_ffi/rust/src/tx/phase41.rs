//! Phase 41: exact scanner/storage representation for future Sapling reconstruction.
//!
//! A Sapling witness is not just 32-byte siblings: the position/direction bits are
//! consensus-critical. Likewise a note commitment alone cannot reconstruct a Note.
//! This module persists the scanner-provided note plaintext components plus the full
//! authenticated path and rejects malformed or incomplete records.

use super::{MerkleWitnessStep, SaplingNoteMaterial};

pub const SAPLING_TREE_DEPTH: usize = 32;

#[derive(Debug, Clone)]
pub struct StoredSaplingSpendRecord {
    pub diversifier: Vec<u8>,
    pub pk_d: Vec<u8>,
    pub rcm: Vec<u8>,
    pub witness_steps: Vec<MerkleWitnessStep>,
}

#[derive(Debug, thiserror::Error)]
pub enum Phase41Error {
    #[error("diversifier must be 11 bytes, got {0}")]
    Diversifier(usize),
    #[error("pk_d must be 32 bytes, got {0}")]
    Pkd(usize),
    #[error("rcm must be 32 bytes, got {0}")]
    Rcm(usize),
    #[error("Merkle path must contain exactly {SAPLING_TREE_DEPTH} steps, got {0}")]
    WitnessDepth(usize),
}

#[derive(Debug, Clone)]
pub struct DecodedSaplingSpendRecord {
    pub note: SaplingNoteMaterial,
    pub witness: Vec<MerkleWitnessStep>,
}

impl TryFrom<StoredSaplingSpendRecord> for DecodedSaplingSpendRecord {
    type Error = Phase41Error;
    fn try_from(v: StoredSaplingSpendRecord) -> Result<Self, Self::Error> {
        if v.diversifier.len() != 11 { return Err(Phase41Error::Diversifier(v.diversifier.len())); }
        if v.pk_d.len() != 32 { return Err(Phase41Error::Pkd(v.pk_d.len())); }
        if v.rcm.len() != 32 { return Err(Phase41Error::Rcm(v.rcm.len())); }
        if v.witness_steps.len() != SAPLING_TREE_DEPTH { return Err(Phase41Error::WitnessDepth(v.witness_steps.len())); }
        let mut diversifier=[0u8;11]; diversifier.copy_from_slice(&v.diversifier);
        let mut pk_d=[0u8;32]; pk_d.copy_from_slice(&v.pk_d);
        let mut rcm=[0u8;32]; rcm.copy_from_slice(&v.rcm);
        Ok(Self { note: SaplingNoteMaterial { diversifier, pk_d, rcm }, witness: v.witness_steps })
    }
}

/// Stable binary encoding for DB blobs: 32 repetitions of sibling(32) + direction(1).
pub fn encode_witness(steps: &[MerkleWitnessStep]) -> Result<Vec<u8>, Phase41Error> {
    if steps.len() != SAPLING_TREE_DEPTH { return Err(Phase41Error::WitnessDepth(steps.len())); }
    let mut out=Vec::with_capacity(SAPLING_TREE_DEPTH*33);
    for step in steps { out.extend_from_slice(&step.sibling); out.push(u8::from(step.is_right)); }
    Ok(out)
}

pub fn decode_witness(bytes: &[u8]) -> Result<Vec<MerkleWitnessStep>, Phase41Error> {
    if bytes.len() != SAPLING_TREE_DEPTH*33 { return Err(Phase41Error::WitnessDepth(bytes.len()/33)); }
    Ok(bytes.chunks_exact(33).map(|c| { let mut sibling=[0u8;32]; sibling.copy_from_slice(&c[..32]); MerkleWitnessStep { sibling, is_right: c[32] != 0 } }).collect())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn rejects_missing_direction_data() { assert!(decode_witness(&vec![0; 32*32]).is_err()); }
    #[test] fn round_trip_full_witness() {
        let steps=(0..32).map(|i| MerkleWitnessStep{sibling:[i as u8;32],is_right:i%2==1}).collect::<Vec<_>>();
        let decoded=decode_witness(&encode_witness(&steps).unwrap()).unwrap();
        assert_eq!(decoded.len(),32); assert!(decoded[1].is_right);
    }
}
