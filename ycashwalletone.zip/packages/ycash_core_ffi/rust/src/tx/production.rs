//! Phase 32 Ycash Sapling spending integration boundary.
//!
//! This module is deliberately split into:
//! 1. transaction planning,
//! 2. a concrete backend adapter,
//! 3. independent node acceptance.
//!
//! `NodeAccepted` must never be returned merely because proving/signing succeeded.

use super::{TransactionPlan, SpendContext};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SpendingState {
    Disabled,
    PlannedOnly,
    ProvenAndSigned,
    NodeAccepted,
}

#[derive(Debug, thiserror::Error)]
pub enum SpendError {
    #[error("ycash Sapling backend is not compiled into this build")]
    BackendUnavailable,
    #[error("transaction was not independently accepted by a Ycash consensus node")]
    ConsensusNotConfirmed,
    #[error("invalid transaction plan: {0}")]
    InvalidPlan(String),
    #[error("backend error: {0}")]
    Backend(String),
}

#[derive(Debug, Clone)]
pub struct BuiltTransaction {
    pub raw: Vec<u8>,
    pub txid_hex: String,
}

/// Result from a cryptographic backend before node acceptance.
#[derive(Debug, Clone)]
pub struct ProvenTransaction {
    pub raw: Vec<u8>,
    pub txid_hex: String,
}

/// Backend contract for the actual cryptographic path.
///
/// A production implementation must:
/// - construct Sapling spends and outputs;
/// - generate Groth16 proofs using Ycash-compatible parameters;
/// - generate spend authorization and binding signatures;
/// - serialize with exact Ycash consensus/network rules.
///
/// This interface intentionally does not expose a method that marks a transaction
/// as node-accepted. Acceptance is a separate external operation.
pub trait YcashSaplingSpender: Send + Sync {
    fn build_prove_sign(&self, plan: &TransactionPlan, context: &SpendContext) -> Result<ProvenTransaction, SpendError>;
}

pub struct DisabledSpender;

impl YcashSaplingSpender for DisabledSpender {
    fn build_prove_sign(&self, _plan: &TransactionPlan, _context: &SpendContext) -> Result<ProvenTransaction, SpendError> {
        Err(SpendError::BackendUnavailable)
    }
}

#[cfg(feature = "ycash-sapling")]
pub mod ycash_backend {
    //! Compile-time integration point for the pinned Ycash Sapling crate.
    //!
    //! The dependency is intentionally referenced here so CI verifies that the
    //! exact pinned fork resolves. The cryptographic transaction API is not
    //! guessed: concrete proving code must be wired to the audited API surface
    //! of this exact revision before mainnet spending can be enabled.

    use super::*;

    /// Confirms the pinned dependency is linked by the feature build.
    pub fn dependency_linked() -> &'static str {
        "sapling-crypto-ycash pinned dependency linked"
    }

    /// Concrete backend placeholder that still fails closed until audited
    /// transaction-construction calls are implemented for this exact revision.
    pub struct YcashSaplingBackend;

    impl YcashSaplingSpender for YcashSaplingBackend {
        fn build_prove_sign(&self, plan: &TransactionPlan, context: &SpendContext) -> Result<ProvenTransaction, SpendError> {
            if context.selected_notes.is_empty() {
                return Err(SpendError::InvalidPlan("no authenticated Sapling notes selected".into()));
            }
            if context.proving_params.spend_params_path.trim().is_empty() || context.proving_params.output_params_path.trim().is_empty() {
                return Err(SpendError::InvalidPlan("proving parameter paths are missing".into()));
            }
            if plan.recipient.trim().is_empty() {
                return Err(SpendError::InvalidPlan("recipient is empty".into()));
            }
            if plan.amount == 0 {
                return Err(SpendError::InvalidPlan("amount must be non-zero".into()));
            }
            Err(SpendError::Backend(
                "Phase 32 dependency integration is compiled, but audited Ycash proving/signing calls are not yet implemented".into(),
            ))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::tx::{AuthenticatedNote, MerkleWitness, ProvingParameters, YcashNetwork};

    #[test]
    fn context_can_represent_authenticated_spend_inputs() {
        let ctx = SpendContext {
            network: YcashNetwork::Testnet,
            selected_notes: vec![AuthenticatedNote {
                note_commitment: [0; 32], value: 1, position: 0, anchor: [0; 32],
                witness: MerkleWitness { auth_path: vec![] },
                spending_key_handle: "opaque-key-handle".into(),
            }],
            change_address: "ytestsapling1change".into(),
            proving_params: ProvingParameters { spend_params_path: "spend.params".into(), output_params_path: "output.params".into() },
        };
        assert_eq!(ctx.selected_notes.len(), 1);
    }
}
