//! Ycash-specific light-client adapter built on yecdev/yecshell + libyec.
//!
//! This module is deliberately behind the existing C ABI. The Flutter layer
//! never sees the old Zcash/Orchard dependency graph; it talks only to these
//! small Ycash operations.

use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::ffi::{CStr, CString};
use std::fs;
use std::os::raw::c_char;
use std::path::Path;
use std::sync::{Arc, Mutex, OnceLock};
use yecshell::lightclient::{LightClient, LightClientConfig};
use yecshell::lightwallet::fee;

const DEFAULT_SERVER: &str = "https://lightwalletd2.ycash.xyz:1443";
const DEFAULT_BIRTHDAY: u64 = 0;
const WALLET_FILENAME: &str = "yecshell_wallet.dat";

struct EngineState {
    client: Option<Arc<LightClient>>,
    server: String,
    data_dir: String,
}

static STATE: OnceLock<Mutex<EngineState>> = OnceLock::new();

fn state() -> &'static Mutex<EngineState> {
    STATE.get_or_init(|| Mutex::new(EngineState {
        client: None,
        server: DEFAULT_SERVER.to_string(),
        data_dir: String::new(),
    }))
}

fn c_string(value: impl AsRef<str>) -> *mut c_char {
    CString::new(value.as_ref())
        .unwrap_or_else(|_| CString::new("internal string error").unwrap())
        .into_raw()
}

fn error_out(error: *mut *mut c_char, message: impl AsRef<str>) {
    if !error.is_null() {
        unsafe { *error = c_string(message); }
    }
}

fn arg(ptr: *const c_char, name: &str) -> Result<String, String> {
    if ptr.is_null() { return Err(format!("{} was null", name)); }
    unsafe { CStr::from_ptr(ptr) }
        .to_str()
        .map(|s| s.to_owned())
        .map_err(|_| format!("{} was not valid UTF-8", name))
}

fn storage_password(seed_phrase: &str) -> String {
    // yecshell itself hashes the supplied password again with SHA256(SHA256).
    // The input here is derived from the already-secret seed phrase, so the
    // on-disk yecshell wallet remains encrypted without introducing another
    // plaintext password into the native layer.
    let mut h = Sha256::new();
    h.update(seed_phrase.as_bytes());
    hex::encode(h.finalize())
}

fn parse_server(server: &str) -> Result<http::Uri, String> {
    server.parse::<http::Uri>().map_err(|e| format!("invalid lightwalletd URL: {}", e))
}

fn build_config(server: &str, data_dir: &str) -> Result<(LightClientConfig, u64), String> {
    let server_uri = parse_server(server)?;
    fs::create_dir_all(data_dir).map_err(|e| format!("cannot create wallet directory: {}", e))?;
    LightClientConfig::create(
        server_uri,
        Some(data_dir.to_string()),
        Some("YcashWalletOne".to_string()),
        Some(WALLET_FILENAME.to_string()),
        Some("yecshell_debug.log".to_string()),
    ).map_err(|e| format!("lightwalletd initialization failed: {}", e))
}

fn persist_yec_wallet(client: &LightClient) -> Result<(), String> {
    let mut bytes = Vec::new();
    {
        let wallet = client.wallet.read().map_err(|_| "wallet lock failed".to_string())?;
        wallet.write(&mut bytes).map_err(|e| format!("wallet serialization failed: {}", e))?;
    }
    let path = client.config.get_wallet_path();
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|e| format!("cannot create wallet directory: {}", e))?;
    }
    fs::write(&path, bytes).map_err(|e| format!("wallet persistence failed: {}", e))
}

fn with_client<F, T>(f: F) -> Result<T, String>
where
    F: FnOnce(&Arc<LightClient>) -> Result<T, String>,
{
    let guard = state().lock().map_err(|_| "wallet state lock failed".to_string())?;
    let client = guard.client.as_ref().ok_or_else(|| "wallet is not open".to_string())?;
    f(client)
}

fn json_ptr(v: Value) -> *mut c_char { c_string(v.to_string()) }

/// Configure the Ycash lightwalletd endpoint and persistent data directory.
#[no_mangle]
pub extern "C" fn ycash_yecshell_configure(
    server: *const c_char,
    data_dir: *const c_char,
    error: *mut *mut c_char,
) -> u8 {
    let server = match arg(server, "server") { Ok(v) => v, Err(e) => { error_out(error, e); return 0; } };
    let data_dir = match arg(data_dir, "data_dir") { Ok(v) => v, Err(e) => { error_out(error, e); return 0; } };
    if let Err(e) = fs::create_dir_all(&data_dir) { error_out(error, format!("cannot create wallet directory: {}", e)); return 0; }
    match state().lock() {
        Ok(mut s) => { s.server = server; s.data_dir = data_dir; 1 }
        Err(_) => { error_out(error, "wallet state lock failed"); 0 }
    }
}

/// Create or restore the Ycash light-client wallet from the seed phrase.
/// Existing yecshell wallet files are opened and authenticated by deriving
/// the same storage key from the seed phrase.
#[no_mangle]
pub extern "C" fn ycash_yecshell_open(
    seed_phrase: *const c_char,
    birthday: u64,
    error: *mut *mut c_char,
) -> u8 {
    let seed = match arg(seed_phrase, "seed phrase") { Ok(v) => v, Err(e) => { error_out(error, e); return 0; } };
    let (server, data_dir) = match state().lock() {
        Ok(s) => (s.server.clone(), s.data_dir.clone()),
        Err(_) => { error_out(error, "wallet state lock failed"); return 0; }
    };
    if data_dir.is_empty() { error_out(error, "Ycash engine has not been configured"); return 0; }

    let (config, latest) = match build_config(&server, &data_dir) {
        Ok(v) => v,
        Err(e) => { error_out(error, e); return 0; }
    };
    let birthday = if birthday == 0 { DEFAULT_BIRTHDAY } else { birthday };
    let wallet_path = config.get_wallet_path();
    let password = storage_password(&seed);

    let client = if wallet_path.exists() {
        match LightClient::read_from_disk(&config) {
            Ok(c) => c,
            Err(e) => { error_out(error, format!("could not read Ycash wallet: {}", e)); return 0; }
        }
    } else {
        match LightClient::new_from_phrase(seed.clone(), &config, birthday.min(latest), false) {
            Ok(c) => c,
            Err(e) => { error_out(error, format!("could not create Ycash wallet: {}", e)); return 0; }
        }
    };

    // Ensure the persistent file is encrypted. On an existing encrypted wallet
    // this also verifies that the supplied seed matches the stored key material.
    {
        let mut wallet = match client.wallet.write() {
            Ok(w) => w,
            Err(_) => { error_out(error, "wallet lock failed"); return 0; }
        };
        if wallet.is_encrypted() {
            if !wallet.is_unlocked_for_spending() {
                if let Err(e) = wallet.unlock(password.clone()) {
                    error_out(error, format!("seed does not unlock the existing Ycash wallet: {}", e));
                    return 0;
                }
            }
        } else {
            let existing_seed = wallet.get_seed_phrase();
            if existing_seed != seed {
                error_out(error, "the supplied seed does not match the existing Ycash wallet");
                return 0;
            }
            if let Err(e) = wallet.encrypt(password.clone()) {
                error_out(error, format!("could not encrypt Ycash wallet: {}", e));
                return 0;
            }
        }
    }
    if let Err(e) = persist_yec_wallet(&client) { error_out(error, format!("could not save Ycash wallet: {}", e)); return 0; }

    match state().lock() {
        Ok(mut s) => { s.client = Some(Arc::new(client)); 1 }
        Err(_) => { error_out(error, "wallet state lock failed"); 0 }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_addresses(error: *mut *mut c_char) -> *mut c_char {
    match with_client(|c| Ok(c.do_address().to_string())) {
        Ok(v) => c_string(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_balances(error: *mut *mut c_char) -> *mut c_char {
    match with_client(|c| Ok(c.do_balance().to_string())) {
        Ok(v) => c_string(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_history(error: *mut *mut c_char) -> *mut c_char {
    match with_client(|c| Ok(c.do_list_transactions(false).to_string())) {
        Ok(v) => c_string(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_sync_start(error: *mut *mut c_char) -> u8 {
    let client = match state().lock() {
        Ok(s) => match &s.client { Some(c) => Arc::clone(c), None => { error_out(error, "wallet is not open"); return 0; } },
        Err(_) => { error_out(error, "wallet state lock failed"); return 0; }
    };
    std::thread::Builder::new().name("ycash-yecshell-sync".to_string()).spawn(move || {
        let _ = client.do_sync(false);
        let _ = persist_yec_wallet(&client);
    }).map(|_| 1).unwrap_or_else(|e| { error_out(error, format!("could not start sync: {}", e)); 0 })
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_sync_status(error: *mut *mut c_char) -> *mut c_char {
    match with_client(|c| {
        let s = c.do_scan_status();
        Ok(json!({"is_syncing": s.is_syncing, "total_blocks": s.total_blocks, "synced_blocks": s.synced_blocks}).to_string())
    }) {
        Ok(v) => c_string(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_seed(error: *mut *mut c_char) -> *mut c_char {
    match with_client(|c| c.do_seed_phrase().map(|v| v.to_string()).map_err(|e| e.to_string())) {
        Ok(v) => c_string(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

fn current_balances(c: &LightClient) -> Result<(u64, u64), String> {
    let raw = c.do_balance().to_string();
    let v: Value = serde_json::from_str(&raw).map_err(|e| format!("balance serialization failed: {}", e))?;
    let z = v["verified_zbalance"].as_u64().unwrap_or(0);
    let t = v["tbalance"].as_u64().unwrap_or(0);
    Ok((z, t))
}

fn make_plan(c: &LightClient, amount: u64, kind: &str, to: Option<&str>, memo: Option<&str>) -> Result<Value, String> {
    if amount == 0 { return Err("amount must be greater than zero".to_string()); }
    let (z, t) = current_balances(c)?;
    let fee = fee::get_default_fee(c.last_scanned_height() as i32);
    let available = match kind { "shield" => t, "unshield" | "send" => z.saturating_add(t), _ => 0 };
    let needed = amount.saturating_add(fee);
    if available < needed { return Err(format!("insufficient spendable balance: have {}, need {}", available, needed)); }
    if let Some(addr) = to {
        if !(addr.starts_with("ys1") || addr.starts_with("s1")) { return Err("recipient is not a Ycash mainnet address".to_string()); }
    }
    Ok(json!({
        "kind": kind,
        "amount": amount,
        "fee": fee,
        "to": to,
        "memo": memo,
        "shielded_after": if kind == "shield" { z + amount } else { z.saturating_sub(amount + fee) },
        "transparent_after": if kind == "shield" { t.saturating_sub(amount + fee) } else { t },
    }))
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_plan_send(
    to: *const c_char, amount: u64, memo: *const c_char, error: *mut *mut c_char
) -> *mut c_char {
    let to = match arg(to, "recipient") { Ok(v) => v, Err(e) => { error_out(error, e); return std::ptr::null_mut(); } };
    let memo = if memo.is_null() { None } else { match arg(memo, "memo") { Ok(v) => Some(v), Err(e) => { error_out(error, e); return std::ptr::null_mut(); } } };
    match with_client(|c| make_plan(c, amount, "send", Some(&to), memo.as_deref())) {
        Ok(v) => json_ptr(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_plan_shield(amount: u64, error: *mut *mut c_char) -> *mut c_char {
    match with_client(|c| {
        let raw = c.do_balance().to_string();
        let bal: Value = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
        let t = bal["tbalance"].as_u64().unwrap_or(0);
        let fee = fee::get_default_fee(c.last_scanned_height() as i32);
        let actual = if amount == 0 { t.saturating_sub(fee) } else { amount };
        make_plan(c, actual, "shield", None, None)
    }) {
        Ok(v) => json_ptr(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_plan_unshield(amount: u64, error: *mut *mut c_char) -> *mut c_char {
    match with_client(|c| {
        let addresses: Value = serde_json::from_str(&c.do_address().to_string()).map_err(|e| e.to_string())?;
        let taddr = addresses["t_addresses"].as_array().and_then(|a| a.first()).and_then(|v| v.as_str()).ok_or_else(|| "no transparent Ycash address available".to_string())?.to_string();
        let raw = c.do_balance().to_string();
        let bal: Value = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
        let z = bal["spendable_zbalance"].as_u64().unwrap_or(0);
        let fee = fee::get_default_fee(c.last_scanned_height() as i32);
        let actual = if amount == 0 { z.saturating_sub(fee) } else { amount };
        make_plan(c, actual, "unshield", Some(&taddr), None)
    }) {
        Ok(v) => json_ptr(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_broadcast_plan(plan_json: *const c_char, error: *mut *mut c_char) -> *mut c_char {
    let text = match arg(plan_json, "plan") { Ok(v) => v, Err(e) => { error_out(error, e); return std::ptr::null_mut(); } };
    let plan: Value = match serde_json::from_str(&text) { Ok(v) => v, Err(e) => { error_out(error, format!("invalid plan: {}", e)); return std::ptr::null_mut(); } };
    let kind = plan["kind"].as_str().unwrap_or("");
    let amount = plan["amount"].as_u64().unwrap_or(0);
    let to = plan["to"].as_str().map(str::to_owned);
    let memo = plan["memo"].as_str().map(str::to_owned);
    match with_client(|c| {
        let txid = match kind {
            "shield" => c.do_shield_amount(amount, None)?,
            "unshield" | "send" => {
                let addr = to.as_deref().ok_or_else(|| "plan has no recipient".to_string())?;
                c.do_send(vec![(addr, amount, memo.as_deref())])?
            }
            _ => return Err("unsupported transaction plan".to_string()),
        };
        persist_yec_wallet(c)?;
        Ok(txid)
    }) {
        Ok(v) => c_string(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_wipe() -> u8 {
    if let Ok(mut s) = state().lock() {
        s.client = None;
        if !s.data_dir.is_empty() {
            let _ = fs::remove_file(Path::new(&s.data_dir).join(WALLET_FILENAME));
        }
        1
    } else { 0 }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_string_free(value: *mut c_char) {
    if !value.is_null() { unsafe { drop(CString::from_raw(value)); } }
}
