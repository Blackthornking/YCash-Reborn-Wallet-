//! Phase 26 Lightwallet transport boundary.
//!
//! This module deliberately does not mark network data as wallet-owned. It
//! transports compact blocks into the scanner, where ownership must be proven
//! by the Sapling backend.

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LightwalletEndpoint {
    pub uri: String,
}

impl LightwalletEndpoint {
    pub fn new(uri: impl Into<String>) -> Result<Self, &'static str> {
        let uri = uri.into();
        if !uri.starts_with("https://") {
            return Err("production lightwallet endpoints must use HTTPS");
        }
        Ok(Self { uri })
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SyncProgress {
    pub start_height: u64,
    pub current_height: u64,
    pub target_height: u64,
}

impl SyncProgress {
    pub fn fraction(&self) -> f64 {
        if self.target_height <= self.start_height { return 1.0; }
        let done = self.current_height.saturating_sub(self.start_height);
        let total = self.target_height - self.start_height;
        (done as f64 / total as f64).clamp(0.0, 1.0)
    }
}

/// Transport abstraction. The generated protobuf client is plugged in behind
/// this trait so tests can use deterministic block streams.
pub trait CompactBlockSource {
    type Error;
    fn latest_height(&mut self) -> Result<u64, Self::Error>;
    fn compact_blocks(&mut self, start: u64, end: u64) -> Result<Vec<Vec<u8>>, Self::Error>;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn production_endpoint_requires_https() {
        assert!(LightwalletEndpoint::new("https://example.invalid:9067").is_ok());
        assert!(LightwalletEndpoint::new("http://example.invalid:9067").is_err());
    }

    #[test]
    fn progress_is_bounded() {
        let p = SyncProgress { start_height: 100, current_height: 150, target_height: 200 };
        assert_eq!(p.fraction(), 0.5);
    }
}
