//! Ycash address parsing and network validation.
//!
//! This module intentionally validates only network encodings. It does not
//! claim that a syntactically-valid address belongs to the wallet; ownership
//! requires Sapling key derivation and trial decryption.
use bech32::{decode, Hrp};
use thiserror::Error;

#[derive(Debug, Error)]
pub enum AddressError {
    #[error("invalid bech32 address: {0}")]
    Bech32(#[from] bech32::DecodeError),
    #[error("address belongs to a different network or pool: expected HRP {expected}, got {actual}")]
    WrongHrp { expected: &'static str, actual: String },
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SaplingAddress(String);

impl SaplingAddress {
    pub const HRP: &'static str = "ys";

    pub fn parse(value: impl Into<String>) -> Result<Self, AddressError> {
        let value = value.into();
        let (hrp, _data) = decode(&value)?;
        if hrp != Hrp::parse(Self::HRP).expect("constant HRP") {
            return Err(AddressError::WrongHrp {
                expected: Self::HRP,
                actual: hrp.to_string(),
            });
        }
        Ok(Self(value))
    }

    pub fn as_str(&self) -> &str { &self.0 }
}

pub fn is_valid_ycash_sapling_address(value: &str) -> bool {
    SaplingAddress::parse(value).is_ok()
}

pub mod ownership;
pub use ownership::{AddressOwnership, DerivedAddress};
