# Yanked Orchard/core2 dependency recovery

This project vendors a `librustzcash` snapshot whose dependency graph requires
`orchard` 0.12.x. `orchard` 0.12.0 is now yanked, and its historical metadata
also resolves the yanked `core2` crate.

The root `Cargo.toml` therefore contains two explicit root-level Cargo patches:

- `orchard` is pinned to the official `zcash/orchard` 0.12.0 release commit
  (`648ef342`). This preserves the 0.12 API expected by the vendored
  `librustzcash` crates.
- `core2` is supplied by `vendor/core2-shim`, a local package named `core2`
  with a compatible 0.3.x version and feature surface. The implementation
  re-exports `corez` 0.1.1, the maintained successor used by current Zcash
  upstream code.

This avoids asking Cargo to freshly select a yanked crates.io package while
keeping the vendored YCash/Sapling dependency graph unchanged.

## CI checks

The native workflow should use the production feature set:

```sh
cargo check --features ycash-sapling
cargo test --features ycash-sapling
```

For future full-feature checks, the same root patches also cover the Orchard
resolution path.
