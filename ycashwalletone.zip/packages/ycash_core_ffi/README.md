# ycash_core FFI — Phase 16

Phase 16 provides a stable Rust boundary for **Ycash mainnet read-only work**.
It validates Ycash Sapling Bech32 network encoding (`ys...`) and contains sync
orchestration boundaries, but it does not claim to generate wallet-owned
addresses or spend funds yet.

Secrets and Sapling spending operations remain Rust-side and disabled until
exact Ycash-compatible cryptographic dependencies are pinned and validated.
