# Ycash Reborn Phase 23

Phase 23 is the compile-and-integration phase. It turns the Phase 22 CI plan into a clearer two-stage build gate: core first, then the pinned Ycash Sapling dependency.

This package intentionally does not pretend that compilation equals cryptographic compatibility. Spending remains disabled until deterministic Ycash fixtures and transaction compatibility tests pass.
