# Phase 41

Phase 41 fixes the data-loss problem discovered in Phase 40: an authentication path requires
both sibling nodes and position/direction bits, and a note commitment cannot reconstruct a
Sapling note by itself. The new format is fail-closed and preserves the scanner material needed
for a source-verified upstream adapter.
