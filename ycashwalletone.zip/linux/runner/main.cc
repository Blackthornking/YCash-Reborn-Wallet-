#include <iostream>
int main() {
  std::cout << "YCash Linux host scaffold. Regenerate with Flutter before release.\n";
  return 0;
}
