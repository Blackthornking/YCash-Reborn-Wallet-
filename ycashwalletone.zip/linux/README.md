# Linux

Regenerate the official Flutter Linux runner:

    flutter create --platforms=linux .

Then integrate the Rust shared library and package dependencies.
