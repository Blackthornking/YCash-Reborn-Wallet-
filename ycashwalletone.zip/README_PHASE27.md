# Ycash Reborn Phase 27 — Sapling Trial Decryption Integration

This phase adds the production integration boundary for real Ycash Sapling trial decryption.

## Included
- Incoming viewing-key backend interface
- Compact-output trial-decryption adapter
- Verified ownership result model
- Nullifier matching interface
- Scanner integration contract
- Fixture provenance manifest
- CI gates for real backend compilation and fixture execution

## Safety
This phase does not claim that trial decryption has passed. Real wallet ownership is accepted only when the pinned Ycash-compatible backend returns a verified ownership result.

Spending remains disabled.
