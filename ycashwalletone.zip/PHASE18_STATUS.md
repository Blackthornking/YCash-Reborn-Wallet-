# Phase 18 — Vendored Upstream Integration Boundary

## Completed
- Locked SHA-256 provenance for the exact supplied `librustzcash` and `zcash-sync` archives.
- Added a Rust backend capability interface.
- Added a hard Ycash-verification gate.
- Added separate read-only and spending gates.
- Preserved the Ycash-only architecture and kept Orchard/Halo2 out of the wallet engine.

## Not yet enabled
- Production Sapling key derivation.
- Production `ys...` address ownership/generation.
- Trial decryption against live Ycash compact blocks.
- Transaction proving/signing.

Those features remain disabled because the supplied upstream snapshots are generic/reference snapshots and cannot safely be treated as Ycash consensus-compatible merely by changing address prefixes.

## Required Phase 19 evidence
1. Exact Ycash-patched crate revisions or vendored patches.
2. Deterministic key/address test vectors.
3. Compact-block trial-decryption vectors.
4. Ycash node/lightwallet acceptance tests.
5. Spend serialization and consensus tests before enabling funds movement.
