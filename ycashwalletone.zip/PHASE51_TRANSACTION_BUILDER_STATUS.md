# Phase 51 — Production Transaction Builder Boundary

This phase adds the complete typed request boundary required before real Sapling
construction can occur: note plaintext material, full 32-level witnesses with
direction bits, anchors, target height, proving parameters, change address and
opaque spending-key handles.

## Safety status

**Mainnet spending remains disabled.** The vendored YCash upstream transaction
APIs still need to be compiled and exercised end-to-end for this Android target.
This package deliberately does not substitute a mock prover or fabricated
serialization.

## Required release gate

Before enabling real spending, CI must demonstrate:

1. pinned YCash consensus parameters are selected;
2. production Groth16 parameters load successfully;
3. spend proofs and output proofs verify;
4. spend authorization and binding signatures verify;
5. the exact serialized transaction round-trips through the YCash parser;
6. an independent YCash node accepts the transaction on testnet/regtest;
7. only then, a separately reviewed mainnet release enables spending.
