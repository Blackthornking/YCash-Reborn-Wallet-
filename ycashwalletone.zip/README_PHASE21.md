# Ycash Reborn Phase 21 — Deterministic Validation Harness

This phase turns the Phase 20 pinned-upstream foundation into a testable validation
harness for the read-only wallet path.

## Added

- standard vs Ledger-compatible derivation boundary
- deterministic vector contract registry
- address ownership model
- compact-block validation gates
- explicit read-only readiness report
- hard guarantee that this phase cannot authorize spending
- Rust integration tests for upstream pin identity and gate behavior

## What remains intentionally blocked

Real wallet-owned `ys...` address generation, trial decryption, note detection,
and balance accounting still require recorded Ycash fixtures generated from the
pinned backend. This phase provides the exact harness where those fixtures belong.

## Build

```bash
./upstream/scripts/fetch-pinned-upstreams.sh
cd packages/ycash_core_ffi/rust
cargo test --features ycash-sapling
```

No Rust toolchain was available in the packaging environment, so compilation was
not claimed here.
