# Production Readiness Gate

Do NOT enable spending until all items below are independently passing:

- [ ] Exact Ycash upstream revisions are recorded and auditable.
- [ ] CI fetches the exact revisions reproducibly.
- [ ] Rust backend compiles without dependency substitution.
- [ ] Ycash Sapling address vectors pass.
- [ ] Viewing/spending key import vectors pass.
- [ ] Genuine compact-block trial decryption passes.
- [ ] Owned-note and nullifier tests pass.
- [ ] Balance/history and rewind tests pass.
- [ ] Nullifier migration workflow is tested.
- [ ] Transaction bytes are accepted by Ycash infrastructure.
- [ ] Security review is completed.

Until then: SPENDING DISABLED.
