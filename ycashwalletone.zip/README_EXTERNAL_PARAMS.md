# External Ycash Sapling parameters

The large Sapling proving parameter files are intentionally not stored in this
Git repository. `scripts/fetch_ycash_params.sh` downloads the two externally
hosted files into:

`packages/ycash_core_ffi/rust/vendor/yecshell-lib/zcash-params/`

The vendored `yecshell-lib` crate uses RustEmbed on that directory, so the files
are present when the native Rust library is compiled and are embedded into the
resulting native library/APK. The parameter blobs therefore do not need to be
committed to GitHub.

Files:

- `sapling-spend.params`
- `sapling-output.params`

The build fails if either download is missing or empty, and prints SHA-256
hashes for the downloaded files in the GitHub Actions log.

For a local build, run:

```bash
./scripts/fetch_ycash_params.sh
flutter pub get
flutter build apk --debug
```
