//! YCash Sapling proving/signing integration boundary.
//!
//! This module intentionally calls the YCash upstream proving ABI rather than
//! reimplementing Groth16, RedJubjub, or transaction consensus serialization.

use libc::{c_uchar, c_void};

#[repr(C)]
pub struct SaplingProvingContext {
    _private: [u8; 0],
}

#[repr(C)]
pub struct SaplingVerificationContext {
    _private: [u8; 0],
}

extern "C" {
    pub fn librustzcash_sapling_proving_ctx_init() -> *mut SaplingProvingContext;
    pub fn librustzcash_sapling_proving_ctx_free(ctx: *mut SaplingProvingContext);

    // YCash upstream Sapling primitives. The exact argument layouts are kept
    // at this boundary so Flutter never handles proving keys or secret scalars.
    pub fn librustzcash_sapling_spend_proof(
        ctx: *mut SaplingProvingContext,
        ak: *const c_uchar,
        nsk: *const c_uchar,
        d: *const c_uchar,
        rcm: *const c_uchar,
        ar: *const c_uchar,
        value: u64,
        anchor: *const c_uchar,
        merkle_path: *const c_void,
        cv: *mut c_uchar,
        rk: *mut c_uchar,
        zkproof: *mut c_uchar,
    ) -> bool;

    pub fn librustzcash_sapling_output_proof(
        ctx: *mut SaplingProvingContext,
        esk: *const c_uchar,
        payment_address: *const c_uchar,
        rcm: *const c_uchar,
        value: u64,
        cv: *mut c_uchar,
        zkproof: *mut c_uchar,
    ) -> bool;

    pub fn librustzcash_sapling_spend_sig(
        ask: *const c_uchar,
        ar: *const c_uchar,
        sighash: *const c_uchar,
        result: *mut c_uchar,
    ) -> bool;

    pub fn librustzcash_sapling_binding_sig(
        ctx: *mut SaplingProvingContext,
        value_balance: i64,
        sighash: *const c_uchar,
        result: *mut c_uchar,
    ) -> bool;
}

/// Opaque owner of a YCash upstream proving context.
pub struct ProvingContext {
    raw: *mut SaplingProvingContext,
}

impl ProvingContext {
    pub unsafe fn new() -> Result<Self, &'static str> {
        let raw = unsafe { librustzcash_sapling_proving_ctx_init() };
        if raw.is_null() {
            Err("YCash Sapling proving context initialization failed")
        } else {
            Ok(Self { raw })
        }
    }

    pub fn as_ptr(&mut self) -> *mut SaplingProvingContext { self.raw }
}

impl Drop for ProvingContext {
    fn drop(&mut self) {
        unsafe {
            if !self.raw.is_null() {
                librustzcash_sapling_proving_ctx_free(self.raw);
            }
        }
    }
}
