# Ycash Reborn — Phase 18

This release replaces floating-upstream assumptions with an auditable source boundary. The supplied archives are fingerprinted and recorded, but are **not automatically trusted as Ycash backends**.

The Rust engine now requires an explicit backend identity and `ycash_verified = true` before exposing cryptographic capabilities. Read-only features and spending have separate gates.

This is intentional: a wallet can lose funds if Zcash transaction rules, network constants, branch IDs, key derivation, or Sapling encodings are mixed with Ycash rules.
