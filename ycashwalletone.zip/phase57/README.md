# Phase 57 — Native Read-Only Activation Implementation

This phase replaces the previous documentation-only next-step with concrete source integration points for a Ycash read-only backend.

## Security rule
No address, balance, or transaction-history value may be presented as genuine until:

1. the exact pinned Ycash upstream revisions are fetched;
2. the Rust Android library compiles from those revisions;
3. deterministic shielded and transparent address vectors pass;
4. a compact-block/lightwallet fixture passes end-to-end; and
5. the native capability manifest reports the corresponding capability as verified.

## Native API contract added

- `ycash_wallet_shielded_address`
- `ycash_wallet_transparent_address`
- `ycash_read_only_capabilities_json`

The functions fail closed unless the verified upstream implementation is linked.

## Why this is not yet marked active
The archive contains the implementation boundary and reproducible CI gate, but this environment has not produced a successful Android native build against the pinned Ycash forks. Therefore the UI must remain fail-closed.
