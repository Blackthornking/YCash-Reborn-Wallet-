# Ycash Reborn Phase 29 — Real Backend CI

Phase 29 stops treating the backend as a completed implementation and adds a
reproducible CI gate intended to prove the actual pinned Ycash-compatible Rust
dependencies can be fetched and compiled.

## CI goals
1. Verify lockfile provenance.
2. Reject floating branches in production dependency definitions.
3. Install stable Rust.
4. Run Cargo metadata and compilation checks where manifests are present.
5. Emit dependency diagnostics.
6. Keep spending disabled unless cryptographic fixture gates pass.

No claim of successful backend compilation is made by this package until CI
produces a passing result.
