Phase 32 adds pinned Ycash Sapling dependency compilation and a fail-closed validation boundary. It does not claim production proving/signing.
