class YcashConfig {
  static const ticker = 'YEC';
  static const coinType = 347;
  static const forkHeight = 570000;
  static const saplingActivationHeight = 419200;

  /// Canonical Ycash lightwalletd endpoint. All wallet sync/open paths use
  /// this endpoint so endpoint selection cannot silently drift between Dart
  /// and native code.
  static const lightwalletdServers = <String>[
    'https://lite.ycash.xyz:9067',
  ];

  /// Canonical endpoint for callers that just want "the" server.
  static const lightwalletd = 'https://lite.ycash.xyz:9067';

  /// Key under which the last endpoint that successfully opened the wallet is
  /// remembered.
  static const lastGoodServerKey = 'ycash.simple.lastServer';

  /// Raised from 512. Each batch costs a GetBlockRange round trip plus one
  /// GetTaddressTxids call per transparent address, and those fixed costs are
  /// paid once per batch regardless of size -- so on a multi-million-block
  /// catch-up a small batch multiplies connection overhead for no benefit.
  /// 2000 compact blocks is a few MB, well within a phone's budget.
  static const modernBatchSize = 2000;
  static const modernWorkers = 8;

  /// How often the UI re-reads native sync state. The native call takes the
  /// engine's global state lock, which the scanning thread also wants, so
  /// polling several times a second actively slows scanning down on a phone.
  static const statusPoll = Duration(seconds: 1);

  /// How often to kick off another sync round. The native engine returns as
  /// soon as it reaches the chain tip, so without this the wallet would sync
  /// once at open and then never see another block.
  static const resyncInterval = Duration(seconds: 30);

  /// Attempts (per server) when opening the wallet, with a short backoff.
  /// Opening does a live getinfo call, so a phone that has just come back
  /// onto a network can legitimately fail the first try.
  static const openAttempts = 2;
  static const openRetryDelay = Duration(seconds: 3);
}
