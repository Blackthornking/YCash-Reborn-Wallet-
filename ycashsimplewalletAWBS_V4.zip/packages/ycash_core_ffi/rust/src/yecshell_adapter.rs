//! Ycash-specific light-client adapter built on yecdev/yecshell + libyec.
//!
//! This module is deliberately behind the existing C ABI. The Flutter layer
//! never sees the old Zcash/Orchard dependency graph; it talks only to these
//! small Ycash operations.

use serde_json::{json, Value};
use bip39::Mnemonic;
use rand::RngCore;
use sha2::{Digest, Sha256};
use std::ffi::{CStr, CString};
use std::fs;
use std::os::raw::c_char;
use std::path::Path;
use std::sync::{atomic::{AtomicBool, Ordering}, Arc, Mutex, OnceLock};
use std::time::Duration;
use yecshell::lightclient::{last_initial_state_note, LightClient, LightClientConfig};
use yecshell::lightwallet::fee;

const DEFAULT_SERVER: &str = "https://lite.ycash.xyz:9067";
/// Fallback birthday when the caller doesn't supply one and this isn't a
/// brand-new wallet (see YcashCoreNative.newWalletBirthday on the Dart
/// side): the Ycash fork height (block 570,000, July 2019). Ycash forked
/// from Zcash there and never adopted any pre-fork Zcash history, so
/// nothing before it is worth scanning for a restore of unknown age.
/// Deliberately *not* 0 -- 0 falls through to yecshell-lib's own fallback,
/// config.sapling_activation_height (419,200), which is Zcash's own
/// Sapling activation inherited pre-fork and ~150,800 blocks earlier than
/// anything Ycash-specific could exist.
const DEFAULT_BIRTHDAY: u64 = 570_000;
const WALLET_FILENAME: &str = "yecshell_wallet.dat";

struct EngineState {
    client: Option<Arc<LightClient>>,
    server: String,
    data_dir: String,
    // Cached storage password (derived from the seed phrase, never the raw
    // seed itself) so we can re-lock/re-unlock the wallet around saves
    // without needing the user to re-enter anything mid-session.
    storage_password: Option<String>,
}

static STATE: OnceLock<Mutex<EngineState>> = OnceLock::new();

// Only one native sync worker may run at a time. The LightClient has an
// internal sync mutex for correctness, but spawning another OS thread for
// every UI refresh still creates a queue of blocked workers and, on Android,
// unnecessary thread stacks and memory pressure. Treat sync start as a
// single-flight operation instead.
static SYNC_RUNNING: AtomicBool = AtomicBool::new(false);

/// Serializes every wallet write to disk.
///
/// Scan progress is now checkpointed *during* a long sync (see the saver
/// thread in `ycash_yecshell_sync_start_batch`), not only once at the very
/// end, so two saves can now genuinely be in flight at the same time -- the
/// periodic one and the final one, or a save racing a `do_send`. Saving
/// involves temporarily locking and re-unlocking the in-memory wallet (see
/// `persist_yec_wallet`), which must never interleave with another save.
static SAVE_LOCK: OnceLock<Mutex<()>> = OnceLock::new();

fn save_lock() -> &'static Mutex<()> {
    SAVE_LOCK.get_or_init(|| Mutex::new(()))
}

/// The most recent wallet-save failure, if any.
///
/// Every save site discarded its Result (`let _ = persist_yec_wallet(..)`),
/// so a wallet that could not be written to disk looked exactly like one that
/// could -- the scan simply restarted from the same height on every launch
/// with nothing to explain why. Recorded here and reported through
/// `ycash_yecshell_sync_status`.
static LAST_SAVE_ERROR: OnceLock<Mutex<Option<String>>> = OnceLock::new();

fn last_save_error_cell() -> &'static Mutex<Option<String>> {
    LAST_SAVE_ERROR.get_or_init(|| Mutex::new(None))
}

fn record_save_result(result: Result<(), String>) {
    if let Ok(mut slot) = last_save_error_cell().lock() {
        *slot = result.err();
    }
}

fn last_save_error() -> Option<String> {
    last_save_error_cell().lock().ok().and_then(|s| s.clone())
}

/// How often to checkpoint scan progress to disk during a long sync.
///
/// Without this, a first sync from the bundled checkpoint (block 960,000) to
/// a chain tip past 3,000,000 wrote *nothing* to disk until the entire run
/// finished -- hours of scanning on a phone. Any interruption (Android
/// reclaiming the process, the battery dying, the user swiping the app away)
/// discarded all of it and the next launch restarted from 960,000 again, so
/// the initial sync could never actually complete. The wallet's block list is
/// capped at MAX_REORG entries, so a save is small and cheap regardless of
/// how far the scan has got.
const SYNC_SAVE_INTERVAL_SECS: u64 = 30;

fn state() -> &'static Mutex<EngineState> {
    STATE.get_or_init(|| Mutex::new(EngineState {
        client: None,
        server: DEFAULT_SERVER.to_string(),
        data_dir: String::new(),
        storage_password: None,
    }))
}

/// Fetch the cached storage password for the currently open wallet. Uses a
/// short-lived lock that is released before returning, so it is always safe
/// to call this immediately before `with_client` (never from inside it).
fn cached_storage_password() -> Result<String, String> {
    let guard = state().lock().map_err(|_| "wallet state lock failed".to_string())?;
    guard.storage_password.clone().ok_or_else(|| "wallet is not open".to_string())
}

fn c_string(value: impl AsRef<str>) -> *mut c_char {
    CString::new(value.as_ref())
        .unwrap_or_else(|_| CString::new("internal string error").unwrap())
        .into_raw()
}

fn error_out(error: *mut *mut c_char, message: impl AsRef<str>) {
    if !error.is_null() {
        unsafe { *error = c_string(message); }
    }
}

fn arg(ptr: *const c_char, name: &str) -> Result<String, String> {
    if ptr.is_null() { return Err(format!("{} was null", name)); }
    unsafe { CStr::from_ptr(ptr) }
        .to_str()
        .map(|s| s.to_owned())
        .map_err(|_| format!("{} was not valid UTF-8", name))
}

fn storage_password(seed_phrase: &str) -> String {
    // yecshell itself hashes the supplied password again with SHA256(SHA256).
    // The input here is derived from the already-secret seed phrase, so the
    // on-disk yecshell wallet remains encrypted without introducing another
    // plaintext password into the native layer.
    let mut h = Sha256::new();
    h.update(seed_phrase.as_bytes());
    hex::encode(h.finalize())
}

fn parse_server(server: &str) -> Result<http02::Uri, String> {
    // yecshell-lib's LightClientConfig::create() expects an http 0.2 Uri, not
    // the http 1.x Uri used elsewhere in this crate (e.g. by tonic).
    server.parse::<http02::Uri>().map_err(|e| format!("invalid lightwalletd URL: {}", e))
}

fn build_config(server: &str, data_dir: &str) -> Result<(LightClientConfig, u64), String> {
    let server_uri = parse_server(server)?;
    fs::create_dir_all(data_dir).map_err(|e| format!("cannot create wallet directory: {}", e))?;
    LightClientConfig::create(
        server_uri,
        Some(data_dir.to_string()),
        Some("YcashWalletOne".to_string()),
        Some(WALLET_FILENAME.to_string()),
        Some("yecshell_debug.log".to_string()),
    ).map_err(|e| format!("lightwalletd initialization failed: {}", e))
}

/// Write the wallet to disk.
///
/// `LightWallet::write()` refuses to serialize while the wallet is encrypted
/// *and* unlocked, because in that state the in-memory seed is plaintext and
/// writing it out would defeat the encryption. Since this app keeps the
/// wallet unlocked in memory for the whole session (so spending/sync
/// operations don't need the password every time), we have to temporarily
/// lock the wallet for the write and then unlock it again afterwards using
/// the cached storage password, mirroring what `LightClient::do_save()` does
/// on desktop.
fn persist_yec_wallet(client: &LightClient, storage_password: &str) -> Result<(), String> {
    let _guard = save_lock().lock().map_err(|_| "wallet save lock failed".to_string())?;
    let mut needs_reunlock = false;
    {
        let mut wallet = client.wallet.write().map_err(|_| "wallet lock failed".to_string())?;
        if wallet.is_encrypted() && wallet.is_unlocked_for_spending() {
            wallet.lock().map_err(|e| format!("could not lock wallet before saving: {}", e))?;
            needs_reunlock = true;
        }
    }

    let write_result = (|| -> Result<(), String> {
        let mut bytes = Vec::new();
        {
            let wallet = client.wallet.read().map_err(|_| "wallet lock failed".to_string())?;
            wallet.write(&mut bytes).map_err(|e| format!("wallet serialization failed: {}", e))?;
        }
        let path = client.config.get_wallet_path();
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).map_err(|e| format!("cannot create wallet directory: {}", e))?;
        }
        fs::write(&path, bytes).map_err(|e| format!("wallet persistence failed: {}", e))
    })();

    if needs_reunlock {
        let mut wallet = client.wallet.write().map_err(|_| "wallet lock failed".to_string())?;
        if let Err(e) = wallet.unlock(storage_password.to_string()) {
            // The save itself may have succeeded; still surface the
            // re-unlock failure, since the caller needs a working, spendable
            // wallet in memory to continue this session.
            write_result?;
            return Err(format!("wallet saved but could not be re-unlocked: {}", e));
        }
    }

    write_result
}

fn with_client<F, T>(f: F) -> Result<T, String>
where
    F: FnOnce(&Arc<LightClient>) -> Result<T, String>,
{
    let guard = state().lock().map_err(|_| "wallet state lock failed".to_string())?;
    let client = guard.client.as_ref().ok_or_else(|| "wallet is not open".to_string())?;
    // A panic unwinding across this `extern "C"` boundary (every FFI
    // function below routes through here) is not just an ordinary crash --
    // Rust aborts the whole process immediately (SIGABRT) rather than
    // unwinding through the FFI edge, so it produces *no* Dart-visible
    // exception, no Flutter error screen, nothing for `adb logcat` to
    // attribute to Dart at all. From the app's side that's indistinguishable
    // from "doesn't open." catch_unwind turns it into an ordinary `Err`
    // instead, which flows back through error_out exactly like any other
    // failure and can actually be seen and acted on.
    match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| f(client))) {
        Ok(result) => result,
        Err(payload) => Err(format!("internal error (panic): {}", panic_message(&payload))),
    }
}

/// Best-effort extraction of a panic's message. `std::panic::catch_unwind`
/// gives back `Box<dyn Any + Send>`, which is almost always either a `&str`
/// (a string-literal panic like `.unwrap()`'s default message) or a
/// `String` (a `panic!("{}", ...)` with formatting) -- anything else falls
/// back to a generic message rather than failing to report the panic at all.
fn panic_message(payload: &Box<dyn std::any::Any + Send>) -> String {
    if let Some(s) = payload.downcast_ref::<&str>() {
        s.to_string()
    } else if let Some(s) = payload.downcast_ref::<String>() {
        s.clone()
    } else {
        "unknown panic payload".to_string()
    }
}

fn json_ptr(v: Value) -> *mut c_char { c_string(v.to_string()) }

/// Configure the Ycash lightwalletd endpoint and persistent data directory.


/// Generate fresh 256-bit BIP39 entropy and encode it as the 24-word
/// English mnemonic used by the Ycash light wallet. This endpoint only
/// generates key material; it never creates or touches a wallet file.
#[no_mangle]
pub extern "C" fn ycash_yecshell_generate_mnemonic(error: *mut *mut c_char) -> *mut c_char {
    let mut entropy = [0u8; 32];
    rand::rngs::OsRng.fill_bytes(&mut entropy);
    match Mnemonic::from_entropy(&entropy) {
        Ok(m) => c_string(m.to_string()),
        Err(e) => {
            error_out(error, format!("could not generate wallet mnemonic: {}", e));
            std::ptr::null_mut()
        }
    }
}
#[no_mangle]
pub extern "C" fn ycash_yecshell_configure(
    server: *const c_char,
    data_dir: *const c_char,
    error: *mut *mut c_char,
) -> u8 {
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
    let server = match arg(server, "server") { Ok(v) => v, Err(e) => { error_out(error, e); return 0; } };
    let data_dir = match arg(data_dir, "data_dir") { Ok(v) => v, Err(e) => { error_out(error, e); return 0; } };
    if let Err(e) = fs::create_dir_all(&data_dir) { error_out(error, format!("cannot create wallet directory: {}", e)); return 0; }
    match state().lock() {
        Ok(mut s) => { s.server = server; s.data_dir = data_dir; 1 }
        Err(_) => { error_out(error, "wallet state lock failed"); 0 }
    }
    }));

    match result {
        Ok(v) => v,
        Err(payload) => {
            error_out(error, format!("internal error configuring wallet (panic): {}", panic_message(&payload)));
            0
        }
    }
}

/// Create or restore the Ycash light-client wallet from the seed phrase.
/// Existing yecshell wallet files are opened and authenticated by deriving
/// the same storage key from the seed phrase.
#[no_mangle]
pub extern "C" fn ycash_yecshell_open(
    seed_phrase: *const c_char,
    birthday: u64,
    error: *mut *mut c_char,
) -> u8 {
    // Wraps the whole existing body unchanged -- every `return 0;` inside
    // returns from this closure, not the outer function, so nothing about
    // the control flow below needed to change. See with_client's comment
    // for why catching the panic here (rather than letting it unwind) is
    // what makes a failure here show up as a normal, visible error instead
    // of the whole process aborting silently -- this is exactly the
    // function the app calls at startup to open the wallet, so a panic
    // anywhere in this call graph would otherwise look indistinguishable
    // from "the app doesn't open."
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
    let seed = match arg(seed_phrase, "seed phrase") { Ok(v) => v, Err(e) => { error_out(error, e); return 0; } };
    let (server, data_dir) = match state().lock() {
        Ok(s) => (s.server.clone(), s.data_dir.clone()),
        Err(_) => { error_out(error, "wallet state lock failed"); return 0; }
    };
    if data_dir.is_empty() { error_out(error, "Ycash engine has not been configured"); return 0; }

    let (config, latest) = match build_config(&server, &data_dir) {
        Ok(v) => v,
        Err(e) => { error_out(error, e); return 0; }
    };
    let birthday = if birthday == 0 { DEFAULT_BIRTHDAY } else { birthday };
    let wallet_path = config.get_wallet_path();
    let password = storage_password(&seed);

    let client = if wallet_path.exists() {
        match LightClient::read_from_disk(&config) {
            Ok(c) => c,
            Err(e) => { error_out(error, format!("could not read Ycash wallet: {}", e)); return 0; }
        }
    } else {
        match LightClient::new_from_phrase(seed.clone(), &config, birthday.min(latest), false) {
            // `.min(latest)` also naturally resolves a brand-new wallet's
            // sentinel birthday (u64::MAX, from YcashCoreNative.newWalletBirthday
            // on the Dart side) down to the current chain tip at creation
            // time -- a wallet that didn't exist before `latest` couldn't
            // have received funds before it, so there's nothing earlier
            // worth scanning.
            Ok(c) => c,
            Err(e) => { error_out(error, format!("could not create Ycash wallet: {}", e)); return 0; }
        }
    };

    // Ensure the persistent file is encrypted. On an existing encrypted wallet
    // this also verifies that the supplied seed matches the stored key material.
    {
        let mut wallet = match client.wallet.write() {
            Ok(w) => w,
            Err(_) => { error_out(error, "wallet lock failed"); return 0; }
        };
        if wallet.is_encrypted() {
            if !wallet.is_unlocked_for_spending() {
                if let Err(e) = wallet.unlock(password.clone()) {
                    error_out(error, format!("seed does not unlock the existing Ycash wallet: {}", e));
                    return 0;
                }
            }
        } else {
            let existing_seed = wallet.get_seed_phrase();
            if existing_seed != seed {
                error_out(error, "the supplied seed does not match the existing Ycash wallet");
                return 0;
            }
            if let Err(e) = wallet.encrypt(password.clone()) {
                error_out(error, format!("could not encrypt Ycash wallet: {}", e));
                return 0;
            }
        }
    }
    if let Err(e) = persist_yec_wallet(&client, &password) { error_out(error, format!("could not save Ycash wallet: {}", e)); return 0; }

    match state().lock() {
        Ok(mut s) => { s.client = Some(Arc::new(client)); s.storage_password = Some(password); 1 }
        Err(_) => { error_out(error, "wallet state lock failed"); 0 }
    }
    }));

    match result {
        Ok(v) => v,
        Err(payload) => {
            error_out(error, format!("internal error opening wallet (panic): {}", panic_message(&payload)));
            0
        }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_addresses(error: *mut *mut c_char) -> *mut c_char {
    match with_client(|c| Ok(c.do_address().to_string())) {
        Ok(v) => c_string(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_balances(error: *mut *mut c_char) -> *mut c_char {
    match with_client(|c| Ok(c.do_balance().to_string())) {
        Ok(v) => c_string(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_history(error: *mut *mut c_char) -> *mut c_char {
    match with_client(|c| Ok(c.do_list_transactions(false).to_string())) {
        Ok(v) => c_string(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_sync_start(error: *mut *mut c_char) -> u8 {
    // V4 starts with a larger bounded batch and parallel CPU/fetch workers; AWBS grows it automatically when
    // measured throughput is healthy. The explicit entry point can still be
    // used by benchmarks to choose a different starting point.
    ycash_yecshell_sync_start_batch(4000, 8, error)
}

/// Starts the custom batch scanner.
///
/// `batch_size` is the number of compact blocks requested per streaming batch.
/// `workers == 0` selects an automatic CPU count (2..12). The native scanner
/// keeps network/commit ordering intact while parallelizing CPU-bound trial
/// decryption inside each batch.
#[no_mangle]
pub extern "C" fn ycash_yecshell_sync_start_batch(
    batch_size: u64,
    workers: u32,
    error: *mut *mut c_char,
) -> u8 {
    if !(100..=10_000).contains(&batch_size) {
        error_out(error, "batch size must be between 100 and 10000 blocks");
        return 0;
    }
    if workers > 32 {
        error_out(error, "worker count must be between 0 and 32");
        return 0;
    }

    // Do not queue another native sync if one is already running. The old
    // behaviour spawned a fresh thread for every refresh; the LightClient
    // then serialized them behind its internal mutex. On Android this could
    // accumulate blocked threads and large scan buffers, making the app look
    // frozen and eventually causing the process to be killed.
    if SYNC_RUNNING.swap(true, Ordering::AcqRel) {
        return 1;
    }

    let (client, password) = match state().lock() {
        Ok(s) => {
            let client = match &s.client { Some(c) => Arc::clone(c), None => { SYNC_RUNNING.store(false, Ordering::Release); error_out(error, "wallet is not open"); return 0; } };
            let password = match &s.storage_password { Some(p) => p.clone(), None => { SYNC_RUNNING.store(false, Ordering::Release); error_out(error, "wallet is not open"); return 0; } };
            (client, password)
        }
        Err(_) => { SYNC_RUNNING.store(false, Ordering::Release); error_out(error, "wallet state lock failed"); return 0; }
    };
    let thread_name = format!("ycash-batch-scanner-{}x{}", batch_size, workers);

    // Checkpoint scan progress to disk while the scan below is still
    // running. See SYNC_SAVE_INTERVAL_SECS: previously the only save was the
    // one after do_sync_with_options returned, so an initial sync of two
    // million blocks persisted nothing at all until it was completely
    // finished, and any interruption threw the whole thing away.
    //
    // This thread exits on its own as soon as SYNC_RUNNING clears, which the
    // scanner thread below always does (including on panic), so it can never
    // outlive the sync it belongs to.
    let saver_client = Arc::clone(&client);
    let saver_password = password.clone();
    let _ = std::thread::Builder::new()
        .name("ycash-sync-saver".to_string())
        .spawn(move || {
            loop {
                // Wake once a second so shutdown is prompt, rather than
                // sleeping the whole interval and delaying thread exit.
                let mut waited = 0;
                while waited < SYNC_SAVE_INTERVAL_SECS && SYNC_RUNNING.load(Ordering::Acquire) {
                    std::thread::sleep(Duration::from_secs(1));
                    waited += 1;
                }
                if !SYNC_RUNNING.load(Ordering::Acquire) {
                    break;
                }
                // A failed checkpoint is not fatal and must not disturb the
                // scan's own status -- the scan keeps going and the next
                // attempt (or the final save) can still succeed.
                record_save_result(persist_yec_wallet(&saver_client, &saver_password));
            }
        });

    std::thread::Builder::new().name(thread_name).spawn(move || {
        // Never allow an unexpected Rust panic in the worker to unwind into
        // the Android/native boundary. Record it as a normal sync error and
        // always release the single-flight guard so a later refresh can try
        // again.
        let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            let sync_result = client.do_sync_with_options(false, batch_size, workers as usize);
            let save_result = persist_yec_wallet(&client, &password);
            record_save_result(save_result.clone());
            (sync_result, save_result)
        }));

        if let Err(panic_payload) = result {
            let message = if let Some(s) = panic_payload.downcast_ref::<&str>() {
                (*s).to_string()
            } else if let Some(s) = panic_payload.downcast_ref::<String>() {
                s.clone()
            } else {
                "native sync worker panicked".to_string()
            };
            client.set_sync_error(message);
        }

        SYNC_RUNNING.store(false, Ordering::Release);
    }).map(|_| 1).unwrap_or_else(|e| {
        SYNC_RUNNING.store(false, Ordering::Release);
        error_out(error, format!("could not start sync: {}", e));
        0
    })
}

/// Estimate the block height for a Unix timestamp (seconds), by asking the
/// connected lightwalletd server directly. Runs synchronously — it's a
/// handful of round trips (binary search), not a full scan — so the caller
/// can show the resulting height to the user and get confirmation before
/// actually starting a rescan with `ycash_yecshell_rescan_from_height`.
#[no_mangle]
pub extern "C" fn ycash_yecshell_height_for_timestamp(timestamp: u64, error: *mut *mut c_char) -> u64 {
    match with_client(|c| c.height_for_timestamp(timestamp)) {
        Ok(h) => h,
        Err(e) => { error_out(error, e); 0 }
    }
}

/// Kicks off a rescan starting from `height` on a background thread (same
/// pattern as `ycash_yecshell_sync_start`), discarding and rebuilding
/// wallet transaction data from that point forward. Used by the Settings >
/// Rescan wallet flow after the user has confirmed a height (usually via
/// `ycash_yecshell_height_for_timestamp`).
#[no_mangle]
pub extern "C" fn ycash_yecshell_rescan_from_height(height: u64, error: *mut *mut c_char) -> u8 {
    let (client, password) = match state().lock() {
        Ok(s) => {
            let client = match &s.client { Some(c) => Arc::clone(c), None => { error_out(error, "wallet is not open"); return 0; } };
            let password = match &s.storage_password { Some(p) => p.clone(), None => { error_out(error, "wallet is not open"); return 0; } };
            (client, password)
        }
        Err(_) => { error_out(error, "wallet state lock failed"); return 0; }
    };
    std::thread::Builder::new().name("ycash-yecshell-rescan".to_string()).spawn(move || {
        let _ = client.do_rescan_from_height(height);
        let _ = persist_yec_wallet(&client, &password);
    }).map(|_| 1).unwrap_or_else(|e| { error_out(error, format!("could not start rescan: {}", e)); 0 })
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_sync_status(error: *mut *mut c_char) -> *mut c_char {
    match with_client(|c| {
        let s = c.do_scan_status();
        Ok(json!({
            "is_syncing": s.is_syncing,
            "phase": s.phase.as_str(),
            "total_blocks": s.total_blocks,
            "synced_blocks": s.synced_blocks,
            "birthday": s.birthday,
            // How this wallet's scan start was established -- server tree
            // state, a bundled checkpoint, or nothing at all. Surfaced so a
            // wallet that is scanning from the wrong place (or from the right
            // place with the wrong commitment tree) is visible on the device
            // instead of only in a log file.
            "initial_state": last_initial_state_note(),
            "save_error": last_save_error(),
            "last_error": s.last_error
        }).to_string())
    }) {
        Ok(v) => c_string(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

/// Write the wallet to disk right now.
///
/// The Dart layer calls this when the app is backgrounded. Android freezes and
/// then reclaims the process at will, and this wallet has no foreground
/// service, so scanning effectively only runs while the app is on screen --
/// anything since the last periodic checkpoint was lost every time the user
/// switched away. Saving on the way out makes that window zero.
#[no_mangle]
pub extern "C" fn ycash_yecshell_save(error: *mut *mut c_char) -> u8 {
    let password = match cached_storage_password() {
        Ok(p) => p,
        Err(e) => { error_out(error, e); return 0; }
    };
    let result = with_client(|c| persist_yec_wallet(c, &password));
    record_save_result(result.clone());
    match result {
        Ok(_) => 1,
        Err(e) => { error_out(error, e); 0 }
    }
}

/// Binary-search the *configured* server for the height at a Unix timestamp,
/// without needing an open wallet.
///
/// `ycash_yecshell_height_for_timestamp` goes through `with_client`, so it
/// can only be used once a wallet is already open -- too late to choose that
/// wallet's birthday. This variant only needs the endpoint from
/// `ycash_yecshell_configure`, so a restore can resolve "I first used this
/// wallet in March 2024" to a height and open directly at it.
#[no_mangle]
pub extern "C" fn ycash_yecshell_server_height_for_timestamp(timestamp: u64, error: *mut *mut c_char) -> u64 {
    let server = match state().lock() {
        Ok(s) => s.server.clone(),
        Err(_) => { error_out(error, "wallet state lock failed"); return 0; }
    };
    let uri = match parse_server(&server) {
        Ok(u) => u,
        Err(e) => { error_out(error, e); return 0; }
    };
    match yecshell::grpcconnector::find_height_for_timestamp(&uri, DEFAULT_BIRTHDAY, timestamp) {
        Ok(h) => h,
        Err(e) => { error_out(error, e); 0 }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_seed(error: *mut *mut c_char) -> *mut c_char {
    match with_client(|c| c.do_seed_phrase().map(|v| v.to_string()).map_err(|e| e.to_string())) {
        Ok(v) => c_string(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

fn current_balances(c: &LightClient) -> Result<(u64, u64), String> {
    let raw = c.do_balance().to_string();
    let v: Value = serde_json::from_str(&raw).map_err(|e| format!("balance serialization failed: {}", e))?;
    let z = v["verified_zbalance"].as_u64().unwrap_or(0);
    let t = v["tbalance"].as_u64().unwrap_or(0);
    Ok((z, t))
}

fn make_plan(c: &LightClient, amount: u64, kind: &str, to: Option<&str>, memo: Option<&str>) -> Result<Value, String> {
    if amount == 0 { return Err("amount must be greater than zero".to_string()); }
    let (z, t) = current_balances(c)?;
    let fee = fee::get_default_fee(c.last_scanned_height() as i32);
    let available = match kind { "shield" => t, "unshield" | "send" => z.saturating_add(t), _ => 0 };
    let needed = amount.saturating_add(fee);
    if available < needed { return Err(format!("insufficient spendable balance: have {}, need {}", available, needed)); }
    if let Some(addr) = to {
        if !(addr.starts_with("ys1") || addr.starts_with("s1")) { return Err("recipient is not a Ycash mainnet address".to_string()); }
    }
    Ok(json!({
        "kind": kind,
        "amount": amount,
        "fee": fee,
        "to": to,
        "memo": memo,
        "shielded_after": if kind == "shield" { z + amount } else { z.saturating_sub(amount + fee) },
        "transparent_after": if kind == "shield" { t.saturating_sub(amount + fee) } else { t },
    }))
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_plan_send(
    to: *const c_char, amount: u64, memo: *const c_char, error: *mut *mut c_char
) -> *mut c_char {
    let to = match arg(to, "recipient") { Ok(v) => v, Err(e) => { error_out(error, e); return std::ptr::null_mut(); } };
    let memo = if memo.is_null() { None } else { match arg(memo, "memo") { Ok(v) => Some(v), Err(e) => { error_out(error, e); return std::ptr::null_mut(); } } };
    match with_client(|c| make_plan(c, amount, "send", Some(&to), memo.as_deref())) {
        Ok(v) => json_ptr(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_plan_shield(amount: u64, error: *mut *mut c_char) -> *mut c_char {
    match with_client(|c| {
        let raw = c.do_balance().to_string();
        let bal: Value = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
        let t = bal["tbalance"].as_u64().unwrap_or(0);
        let fee = fee::get_default_fee(c.last_scanned_height() as i32);
        let actual = if amount == 0 { t.saturating_sub(fee) } else { amount };
        make_plan(c, actual, "shield", None, None)
    }) {
        Ok(v) => json_ptr(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_plan_unshield(amount: u64, error: *mut *mut c_char) -> *mut c_char {
    match with_client(|c| {
        let addresses: Value = serde_json::from_str(&c.do_address().to_string()).map_err(|e| e.to_string())?;
        let taddr = addresses["t_addresses"].as_array().and_then(|a| a.first()).and_then(|v| v.as_str()).ok_or_else(|| "no transparent Ycash address available".to_string())?.to_string();
        let raw = c.do_balance().to_string();
        let bal: Value = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
        let z = bal["spendable_zbalance"].as_u64().unwrap_or(0);
        let fee = fee::get_default_fee(c.last_scanned_height() as i32);
        let actual = if amount == 0 { z.saturating_sub(fee) } else { amount };
        make_plan(c, actual, "unshield", Some(&taddr), None)
    }) {
        Ok(v) => json_ptr(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_broadcast_plan(plan_json: *const c_char, error: *mut *mut c_char) -> *mut c_char {
    let text = match arg(plan_json, "plan") { Ok(v) => v, Err(e) => { error_out(error, e); return std::ptr::null_mut(); } };
    let plan: Value = match serde_json::from_str(&text) { Ok(v) => v, Err(e) => { error_out(error, format!("invalid plan: {}", e)); return std::ptr::null_mut(); } };
    let kind = plan["kind"].as_str().unwrap_or("");
    let amount = plan["amount"].as_u64().unwrap_or(0);
    let to = plan["to"].as_str().map(str::to_owned);
    let memo = plan["memo"].as_str().map(str::to_owned);
    let password = match cached_storage_password() { Ok(p) => p, Err(e) => { error_out(error, e); return std::ptr::null_mut(); } };
    match with_client(|c| {
        // Syncing never needs the Sapling proving parameters, but signing
        // does. They are ~51 MB and are not committed to this repository, so
        // a build without them can still create a wallet, connect, sync and
        // show balances -- it just cannot spend. Say so plainly here rather
        // than letting LocalTxProver::from_bytes fail on empty input.
        if !c.has_sapling_params() {
            return Err("Sapling proving parameters are not available in this build, so transactions cannot be signed. \
                        Place sapling-spend.params and sapling-output.params in the wallet data directory's \
                        zcash-params folder (or bundle them under vendor/yecshell-lib/zcash-params/ before building) \
                        and reopen the wallet.".to_string());
        }
        let txid = match kind {
            "shield" => c.do_shield_amount(amount, None)?,
            "unshield" | "send" => {
                let addr = to.as_deref().ok_or_else(|| "plan has no recipient".to_string())?;
                c.do_send(vec![(addr, amount, memo)])?
            }
            _ => return Err("unsupported transaction plan".to_string()),
        };
        persist_yec_wallet(c, &password)?;
        Ok(txid)
    }) {
        Ok(v) => c_string(v), Err(e) => { error_out(error, e); std::ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_wipe() -> u8 {
    if let Ok(mut s) = state().lock() {
        s.client = None;
        s.storage_password = None;
        if !s.data_dir.is_empty() {
            let _ = fs::remove_file(Path::new(&s.data_dir).join(WALLET_FILENAME));
        }
        1
    } else { 0 }
}

#[no_mangle]
pub extern "C" fn ycash_yecshell_string_free(value: *mut c_char) {
    if !value.is_null() { unsafe { drop(CString::from_raw(value)); } }
}
