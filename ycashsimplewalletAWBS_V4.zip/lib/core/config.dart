class YcashConfig {
  static const ticker = 'YEC';
  static const coinType = 347;
  static const forkHeight = 570000;
  static const saplingActivationHeight = 419200;

  /// Ycash lightwalletd endpoints, tried in order at wallet-open time until
  /// one answers. A single hardcoded endpoint meant any outage, DNS change or
  /// blocked port looked identical to "the wallet is broken" -- and the three
  /// Ycash projects this wallet is derived from each shipped a *different*
  /// default, so there was no way to tell which one was actually current.
  ///
  ///  - lightwalletd.ycash.xyz:443   -- this project's previous default
  ///  - lite.ycash.xyz:9067          -- zwallet's Ycash coin definition
  ///  - lightwalletd2.ycash.xyz:1443 -- upstream yecshell's DEFAULT_SERVER
  ///
  /// A port must always be present: LightClientConfig::create resolves
  /// `host:port` directly and does not infer 443 from the https scheme.
  /// lite.ycash.xyz:9067 is first because it is the one confirmed reachable
  /// from a real device. The previous order put lightwalletd.ycash.xyz:443
  /// first, and every launch paid its full connect timeout before falling
  /// through to the working endpoint -- which is exactly the long
  /// "Connecting to the Ycash network..." wait at startup. The last endpoint
  /// that actually worked is also remembered (see SimpleWallet) and tried
  /// ahead of this list, so a launch after the first one goes straight to it.
  static const lightwalletdServers = <String>[
    'https://lite.ycash.xyz:9067',
    'https://lightwalletd.ycash.xyz:443',
    'https://lightwalletd2.ycash.xyz:1443',
  ];

  /// Kept for anything that just wants "the" server; the open path uses the
  /// full list above.
  static const lightwalletd = 'https://lite.ycash.xyz:9067';

  /// Key under which the last endpoint that successfully opened the wallet is
  /// remembered.
  static const lastGoodServerKey = 'ycash.simple.lastServer';

  /// Raised from 512. Each batch costs a GetBlockRange round trip plus one
  /// GetTaddressTxids call per transparent address, and those fixed costs are
  /// paid once per batch regardless of size -- so on a multi-million-block
  /// catch-up a small batch multiplies connection overhead for no benefit.
  /// 2000 compact blocks is a few MB, well within a phone's budget.
  static const modernBatchSize = 2000;
  static const modernWorkers = 4;

  /// How often the UI re-reads native sync state. The native call takes the
  /// engine's global state lock, which the scanning thread also wants, so
  /// polling several times a second actively slows scanning down on a phone.
  static const statusPoll = Duration(seconds: 1);

  /// How often to kick off another sync round. The native engine returns as
  /// soon as it reaches the chain tip, so without this the wallet would sync
  /// once at open and then never see another block.
  static const resyncInterval = Duration(seconds: 30);

  /// Attempts (per server) when opening the wallet, with a short backoff.
  /// Opening does a live getinfo call, so a phone that has just come back
  /// onto a network can legitimately fail the first try.
  static const openAttempts = 2;
  static const openRetryDelay = Duration(seconds: 3);
}
