Phase 53 adds a real GitHub native Rust compile/test gate.
Upload/extract the repository contents, then run Actions -> Build Native YCash Core.
Do not enable mainnet spending until that workflow is green and transaction acceptance tests are implemented.
