# Phase 52 — Vendored YCash transaction wiring

This package now vendors the supplied `librustzcash-nu61` and
`sapling-crypto-ycash` source trees under `phase48/ycash_core/vendor/` and makes
`ycash_core` depend on them by local Cargo paths.

## Security boundary

Flutter supplies only a validated transaction request. Authenticated notes,
Merkle witnesses, anchors and spending keys remain in native wallet storage.
Sapling proofs, spend-authorization signatures, binding signatures and
transaction serialization are delegated to the vendored upstream implementation.

## Release gate

Mainnet Send/Broadcast MUST remain disabled until all of these pass against the
exact pinned vendor revision:

1. `cargo test` for the native core and upstream dependency graph.
2. Valid Sapling proof verification and invalid-proof rejection.
3. Spend authorization and binding signature verification.
4. Serialization round-trip and txid consistency tests.
5. Wrong-network and mutated-transaction rejection.
6. Independent YCash node acceptance on a disposable test transaction.
7. Android ABI build/load tests for every shipped ABI.

This package intentionally does not claim those tests have already passed.
