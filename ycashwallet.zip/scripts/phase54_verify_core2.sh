#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-phase48/ycash_core}"
ACTIVE="$ROOT/vendor/librustzcash-nu61/Cargo.toml"
test -f "$ACTIVE"
grep -Eq 'core2 = \{ version = "0\.4"' "$ACTIVE"
if grep -R --include='Cargo.toml' -nE 'core2 = \{ version = "0\.3"|core2 = "0\.3' "$ROOT/vendor/librustzcash-nu61"; then
  echo "ERROR: yanked core2 0.3 dependency remains"
  exit 1
fi
echo "core2 dependency check passed"
