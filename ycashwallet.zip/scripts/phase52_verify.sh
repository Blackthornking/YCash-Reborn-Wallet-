#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../phase48/ycash_core"
test -f vendor/librustzcash-nu61/Cargo.toml
test -f vendor/sapling-crypto-ycash/Cargo.toml
cargo test --locked
