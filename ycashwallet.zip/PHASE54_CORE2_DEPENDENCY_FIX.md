# Phase 54 — core2 Dependency Resolution Fix

This phase updates the vendored YCash-compatible librustzcash workspaces from the
fully-yanked `core2 = "0.3"` dependency range to `core2 = "0.4"`.

Updated workspaces:
- phase48/ycash_core/vendor/librustzcash-nu61
- phase48/upstream/vendor/librustzcash-ycash-nu61
- phase48/upstream/vendor/librustzcash-reference

The native GitHub workflow should now proceed past dependency selection and expose
the next genuine Rust API or build error, if one remains.

This change does not claim mainnet transaction spending is validated.
