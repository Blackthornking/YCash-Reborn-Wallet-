# Android CI Gradle fix

The GitHub Actions workflow regenerates the Android host using the installed Flutter SDK and then explicitly updates the Gradle wrapper distribution to Gradle 8.14.

This addresses the failure:

`Your project's Gradle version (8.9.0) is lower than Flutter's minimum supported version of 8.14.0`.

The workflow also runs `flutter analyze` before APK builds so Dart analysis errors stop the build earlier.
