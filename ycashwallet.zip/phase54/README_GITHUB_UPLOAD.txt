YCASH WALLET - GITHUB READY PACKAGE

IMPORTANT:
GitHub does not automatically extract a ZIP uploaded as a normal repository file.

1. Extract YCash-Wallet-GitHub-Ready.zip on your device.
2. Upload the CONTENTS of the extracted folder to the root of your GitHub repository.
3. The repository root must contain:
   .github/workflows/build-android.yml
   phase48/pubspec.yaml
   phase48/lib/
   phase48/packages/
4. Commit to main.
5. Open GitHub Actions and run "Build Android APK".
6. Download the APK from the workflow Artifacts section after a successful build.
