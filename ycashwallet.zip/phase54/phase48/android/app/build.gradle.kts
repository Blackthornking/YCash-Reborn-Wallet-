plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.ycashfoundation.ycashreborn"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    defaultConfig {
        applicationId = "com.ycashfoundation.ycashreborn"
        minSdk = 26
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }
}

flutter {
    source = "../.."
}


val rustDir = rootProject.file("../../packages/ycash_core_ffi/rust")
val rustJniDir = project.file("src/main/jniLibs")

val buildRustNative by tasks.registering(Exec::class) {
    group = "build"
    description = "Builds the Ycash Rust cdylib for Android ABIs."
    workingDir = rustDir
    doFirst { rustJniDir.mkdirs() }
    commandLine(
        "bash", "-lc",
        "cargo ndk -t arm64-v8a -t armeabi-v7a -t x86_64 -o " +
            rustJniDir.absolutePath + " build --release"
    )
}

tasks.matching { it.name == "preBuild" }.configureEach {
    dependsOn(buildRustNative)
}
