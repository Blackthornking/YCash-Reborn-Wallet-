import 'package:flutter/material.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

class WelcomeScreen extends StatelessWidget {
  final VoidCallback onCreateNew;
  final VoidCallback onRestore;
  const WelcomeScreen({super.key, required this.onCreateNew, required this.onRestore});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [YColors.spaceDeep, Color(0xFF0B0905)],
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(YSpacing.xl),
            child: Column(
              children: [
                const Spacer(),
                YEnter(
                  child: Image.asset(
                    'assets/branding/ycash_logo.png',
                    width: 300,
                    fit: BoxFit.contain,
                    excludeFromSemantics: true,
                  ),
                ),
                const SizedBox(height: YSpacing.xl),
                YEnter(
                  delay: const Duration(milliseconds: 100),
                  child: Semantics(
                    label: 'YCash. Private by default. Shielded funds, one tap away.',
                    child: Text(
                      'Private by default. Shielded funds, one tap away.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: YColors.textSecondary),
                    ),
                  ),
                ),
                const Spacer(),
                YEnter(
                  delay: const Duration(milliseconds: 220),
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: onCreateNew,
                      child: const Text('Create a new wallet'),
                    ),
                  ),
                ),
                const SizedBox(height: YSpacing.md),
                YEnter(
                  delay: const Duration(milliseconds: 280),
                  child: SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: onRestore,
                      child: const Text('Restore from recovery phrase'),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
