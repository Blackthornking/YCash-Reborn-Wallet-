#!/usr/bin/env sh
set -eu

grep -q 'zcash/orchard.git' Cargo.toml
grep -q '648ef342' Cargo.toml
grep -q 'core2 = { path = "vendor/core2-shim" }' Cargo.toml
test -f vendor/core2-shim/Cargo.toml
test -f vendor/core2-shim/src/lib.rs
grep -q '^name = "core2"' vendor/core2-shim/Cargo.toml
grep -q '^version = "0.3.3"' vendor/core2-shim/Cargo.toml
grep -q 'pub use corez::\*;' vendor/core2-shim/src/lib.rs

echo 'Yanked Orchard/core2 recovery configuration: OK'
