# Phase 54: core2 dependency resolution fix

## Problem

The native YCash core build depended on `core2 = "0.4"`. As of 2026, all
published `core2` releases have been yanked from crates.io, so a fresh Cargo
resolution fails before compilation.

## Fix

The active vendored `librustzcash-nu61` workspace now declares:

```toml
core2 = { package = "no_std_io2", version = "0.9.4", default-features = false, features = ["alloc"] }
```

The dependency key remains `core2`, so existing upstream imports such as
`core2::io::Read` continue to compile without source rewrites. Cargo resolves
the maintained `no_std_io2` package instead of the yanked `core2` package.

## CI verification

`scripts/phase54_verify_core2.sh` checks that the active workspace uses the
`no_std_io2` alias and rejects a direct crates.io `core2` dependency.
