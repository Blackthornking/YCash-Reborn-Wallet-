#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-phase48/ycash_core}"
ACTIVE="$ROOT/vendor/librustzcash-nu61/Cargo.toml"
test -f "$ACTIVE"

# crates.io yanked every core2 release. The vendored librustzcash workspace
# keeps the dependency key `core2` so existing source imports remain unchanged,
# but aliases that key to the maintained no_std_io2 fork.
grep -Eq 'core2 = \{ package = "no_std_io2", version = "0\.9\.4"' "$ACTIVE"

if grep -R --include='Cargo.toml' -nE '(^|[[:space:]])core2[[:space:]]*=[[:space:]]*\{[[:space:]]*version[[:space:]]*=' "$ROOT/vendor/librustzcash-nu61"; then
  echo "ERROR: direct crates.io core2 dependency remains"
  exit 1
fi

echo "core2 replacement check passed (no_std_io2 alias)"
