# Android CI: migrated to AGP 9's new DSL + built-in Kotlin

**Status: migration complete.** The app no longer opts out of AGP 9's new
DSL or built-in Kotlin. This supersedes the previous temporary shim
described below (kept for history).

## What changed

- `android/app/build.gradle.kts`
  - Removed the `id("org.jetbrains.kotlin.android")` plugin application.
    AGP 9's built-in Kotlin compiles the app's Kotlin sources
    (`MainActivity.kt`) without a separate Kotlin Gradle Plugin (KGP).
  - Removed the legacy `kotlinOptions { jvmTarget = ... }` block (AGP 9's
    new DSL no longer reads it) and replaced it with the new
    `kotlin { compilerOptions { jvmTarget = ... } }` DSL, per
    <https://developer.android.com/build/migrate-to-built-in-kotlin>.
- `android/settings.gradle.kts`
  - Removed the `org.jetbrains.kotlin.android` plugin declaration entirely
    (no longer applied anywhere, so it doesn't need to be pinned).
  - Bumped `com.android.application` from `8.7.3` to `9.1.0` - the AGP
    version Flutter 3.47 verifies against for built-in Kotlin.
- `android/gradle.properties`
  - Removed `android.newDsl=false` and `android.builtInKotlin=false`. Both
    are Flutter-provided *temporary* opt-outs
    (see <https://docs.flutter.dev/release/breaking-changes/migrate-to-built-in-kotlin/>);
    leaving them set would keep building against the legacy DSL/KGP path,
    which AGP 10.0 removes entirely.
- `.github/workflows/build-android.yml`
  - The "Pin Android Gradle Plugin and Gradle wrapper" step now pins AGP
    `9.1.0` and Gradle `9.3.1` (the minimum Gradle version AGP 9.1.0
    requires), instead of AGP `8.7.3` / Kotlin `2.1.0` / Gradle `8.14`.

## Why AGP 9.1.0 / Gradle 9.3.1 specifically

Flutter's own "What's new in Flutter 3.47" post states the release is
verified against AGP 9.1.0 (newest compatible with KGP 2.4.0) and Gradle
9.3.1 (the minimum Gradle 9.1.0 requires). Since this app no longer applies
KGP at all, the KGP version doesn't matter here, but pinning the same AGP/
Gradle pair Flutter itself tests against is the safest choice. A newer AGP
9.x (9.2, 9.3, 9.4, ...) will likely also work, but hasn't been verified
against this project's Flutter version.

## Remaining risk: third-party plugin compatibility

Built-in Kotlin requires every Flutter plugin used by the app - not just
the app itself - to have dropped the legacy `org.jetbrains.kotlin.android`
plugin from its own Android build files. Several plugins in `pubspec.yaml`
were pinned with caret constraints that capped them well below their
current releases - old enough to predate every AGP 9 fix on pub.dev:

| Plugin | Was | Now | Why |
|---|---|---|---|
| `flutter_secure_storage` | `^9.2.2` (<10.0.0) | `^10.3.1` | latest 10.x; 11.0.0 exists but needs Dart >=3.8.0, a separate bump |
| `mobile_scanner` | `^5.1.1` (<6.0.0) | `^7.3.0` | latest; changelog documents AGP 9 groundwork |
| `share_plus` | `^9.0.0` (<10.0.0) | `^13.2.1` | latest; changelog documents "Add support of built-in Kotlin" |
| `package_info_plus` | `^8.0.0` (<9.0.0) | `>=9.1.0 <12.0.0` | changelog documents "Add support of built-in Kotlin"; exact version it landed in wasn't confirmed, hence the range instead of a single floor |

For each, the app's actual usage (`Share.share()`, `MobileScannerController`
+ `onDetect`, `PackageInfo.fromPlatform()`, `FlutterSecureStorage`) is a
long-stable API that hasn't changed across these major version bumps, so
this is a version-constraint fix, not a code migration. `local_auth`,
`url_launcher`, and `shared_preferences` were left as-is: they're
Flutter-maintained federated plugins already migrated as part of Flutter's
own AGP 9 push, and their existing caret ranges can already reach a fixed
version.

This was checked against each package's published changelog and version
history (pub.dev), not by actually running `flutter pub get` - there's no
network access in this environment to do that. Run `flutter pub outdated`
or `flutter pub upgrade` locally to confirm the resolved versions, and
`flutter pub deps` if a conflict comes up between these new floors and
other dependencies. The [flutter_compat](https://pub.dev/packages/flutter_compat)
CLI (`dart pub global activate flutter_compat`, then `flutter_compat doctor`)
is also built specifically to scan a project for exactly this class of
AGP/Kotlin/Gradle/plugin mismatch.

If `flutter build apk` still fails during Gradle configuration with an
error like:

```
Failed to apply plugin 'org.jetbrains.kotlin.android'.
> Cannot add extension with name 'kotlin', as there is an extension already registered with that name.
```

that means a specific plugin dependency hasn't migrated yet. Options, in
order of preference:

1. Run `flutter pub upgrade` to pick up a migrated version of the
   offending plugin, if one has since been released.
2. Report the incompatibility to the plugin's maintainers using the
   template in Flutter's
   [built-in Kotlin migration guide](https://docs.flutter.dev/release/breaking-changes/migrate-to-built-in-kotlin/for-app-developers#report-incompatible-kotlin-gradle-plugin-usage-to-plugin-authors).
3. As a last resort, re-add `android.newDsl=false` and
   `android.builtInKotlin=false` to `android/gradle.properties` and
   restore `id("org.jetbrains.kotlin.android")` in
   `android/settings.gradle.kts` / `android/app/build.gradle.kts` until the
   dependency is migrated. Treat this as temporary: AGP 10.0 (expected
   later in 2026) removes both opt-outs entirely.

## Original problem (historical, now resolved)

The `Build debug APK` step of the Android workflow started failing with:

```
[!] Starting AGP 9+, only the new DSL interface will be read.
This results in a build failure when applying the Flutter Gradle plugin at
android/app/build.gradle.kts.
To resolve this update flutter or opt out of `android.newDsl`.
```

The workflow pinned AGP to 8.7.3 in `android/settings.gradle.kts`, but the
installed (unpinned, `channel: stable`) Flutter SDK still resolved/
configured the project assuming AGP 9's new DSL types by default, and
`android/app/build.gradle.kts` used the legacy `kotlinOptions {}` block,
which AGP 9's new DSL doesn't read - so the build failed regardless of the
pinned AGP version. The original fix was the temporary opt-out documented
above; this file now documents the follow-up full migration instead.
