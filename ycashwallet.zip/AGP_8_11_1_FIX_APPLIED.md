# AGP 8.11.1 Fix Applied

- Android Gradle Plugin is pinned to **8.11.1** in `phase48/android/settings.gradle.kts`.
- Kotlin is pinned to **2.2.20**.
- Gradle wrapper is pinned to **8.14.3**.
- Java 17 remains the CI JDK.
- No AGP 9 migration or `android.newDsl` workaround is required.

This configuration addresses Flutter's reported minimum Android Gradle Plugin requirement while avoiding AGP 9 DSL incompatibilities.
