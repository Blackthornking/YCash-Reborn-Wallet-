# AGP 8.11.1 Fix Applied

- Android Gradle Plugin upgraded from **8.7.3** to **8.11.1** in `phase48/android/settings.gradle.kts`.
- Gradle wrapper remains **8.14.3**.
- Removed the GitHub Actions AGP 9 compatibility workaround that added `android.newDsl=false` and `android.builtInKotlin=false`.

This addresses Flutter's reported minimum Android Gradle Plugin requirement.
