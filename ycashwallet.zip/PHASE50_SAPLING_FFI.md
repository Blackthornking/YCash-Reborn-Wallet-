YCash Sapling FFI integration added. Mainnet spending remains gated until full transaction-builder and node-acceptance validation is completed.
