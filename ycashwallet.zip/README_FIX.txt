GitHub Actions fix
==================

Replace the repository file:
.github/workflows/build-ycash-wallet.yml

with the build-ycash-wallet.yml included in this package.

Why the old workflow failed:
It had a default working directory of phase48 before phase48 existed. The
'extract' command therefore looked for phase48/ycashwallet.zip instead of the
repository-root ycashwallet.zip.

This replacement extracts ycashwallet.zip from the repository root first, then
uses phase48 for all Flutter commands.
