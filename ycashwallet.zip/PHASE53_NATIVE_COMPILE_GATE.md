# Phase 53 — Native compile gate

This phase fixes the feature mismatch in the prior package and adds a GitHub
Actions job that performs a real Rust `cargo check --all-features` and
`cargo test --all-features` against the vendored YCash-compatible sources.

## Important release gate

A green Flutter build alone is not sufficient to enable spending. Mainnet
spending remains blocked until this native job is green and the concrete
transaction path is implemented using the APIs exposed by the exact vendored
revision.

The CI job is intentionally authoritative because this packaging environment
does not contain the Rust toolchain, so no claim is made that the native crate
was compiled locally here.
