#include <windows.h>
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
  MessageBoxA(nullptr, "YCash Windows host scaffold. Regenerate with Flutter before release.", "YCash", MB_OK);
  return 0;
}
