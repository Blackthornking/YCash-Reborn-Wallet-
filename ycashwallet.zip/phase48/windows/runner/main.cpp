#include <windows.h>
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
  MessageBoxA(nullptr, "Ycash Reborn Windows host scaffold. Regenerate with Flutter before release.", "Ycash Reborn", MB_OK);
  return 0;
}
