# Windows

Regenerate the official Flutter Windows runner:

    flutter create --platforms=windows .

Then integrate the Rust DLL build and Windows secure-storage implementation.
