# Ycash Reborn — Phase 19

Phase 19 converts the previous architecture into an auditable upstream integration workspace.

The supplied generic sources are preserved as **reference snapshots only**. Production code must use exact Ycash-compatible revisions and pass deterministic compatibility vectors before spending is enabled.

This is deliberate: a wallet must never silently promote a syntactically compiling backend into a real-money backend.
