# Production build scope

The Android wallet workflow validates only the Flutter application and the
`packages/ycash_core_ffi/rust` production Rust crate.

`upstream/vendor/zcash-sync-reference` and other upstream snapshots are
reference/vendor source trees. They are not Android wallet build targets and
must not be compiled by the production APK workflow. Some historical upstream
manifests intentionally retain dependencies whose old crates.io versions are
yanked, so recursively running `cargo check` over every vendored `Cargo.toml`
creates a false CI failure unrelated to the wallet binary.
