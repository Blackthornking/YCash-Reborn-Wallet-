import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/providers.dart';
import '../../core/biometrics/biometric_gate.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

/// Read-only recovery phrase reveal for Settings -> Backup. Unlike the
/// onboarding [SeedBackupScreen], there's no verification quiz here — the
/// user already passed that once; this is just "let me see it again",
/// still gated by biometrics since it's the same secret.
class SeedRevealScreen extends ConsumerStatefulWidget {
  const SeedRevealScreen({super.key});

  @override
  ConsumerState<SeedRevealScreen> createState() => _SeedRevealScreenState();
}

class _SeedRevealScreenState extends ConsumerState<SeedRevealScreen> {
  String? _seed;
  String? _error;

  @override
  void initState() {
    super.initState();
    _reveal();
  }

  Future<void> _reveal() async {
    // Previously: an auth failure set _error with no way to retry short of
    // leaving the screen, and vault.read() had no error handling at all —
    // if it threw after a successful auth, _seed stayed null forever with
    // the spinner below running indefinitely. Both paths now flow through
    // one try/catch so any failure lands on a retry-capable error.
    setState(() => _error = null);
    final gate = ref.read(biometricGateProvider);
    try {
      final auth = await gate.authenticate(GateReason.revealSeedOrKeys);
      if (!auth.authenticated) {
        if (auth.error == 'no_biometrics_use_pin') {
          // Same PIN-entry pattern used elsewhere; kept inline here since
          // this screen has no other content competing for space.
          final pin = await _promptPin();
          if (pin == null) {
            // User cancelled the PIN prompt — that's a deliberate exit,
            // not a failure, so just back out instead of showing an error.
            if (mounted) Navigator.of(context).maybePop();
            return;
          }
          if (!await gate.verifyPin(pin)) {
            throw StateError('Incorrect PIN');
          }
        } else {
          throw StateError(auth.error ?? 'Authentication required');
        }
      }
      final vault = ref.read(seedVaultProvider);
      final seed = await vault.read(const BiometricAuthResult(true));
      if (mounted) setState(() => _seed = seed);
    } catch (e) {
      YHaptics.warn();
      if (mounted) {
        setState(() =>
            _error = e is StateError ? e.message : 'Could not reveal your recovery phrase: $e');
      }
    }
  }

  Future<String?> _promptPin() async {
    final controller = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Enter PIN'),
        content: TextField(
          controller: controller,
          obscureText: true,
          keyboardType: TextInputType.number,
          autofocus: true,
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('Cancel')),
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(controller.text),
              child: const Text('Confirm')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Recovery phrase')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(YSpacing.lg),
          child: _error != null
              ? Center(
                  child: YErrorState(
                    message: _error!,
                    onRetry: _reveal,
                  ),
                )
              : _seed == null
                  ? const Center(child: YBusyState(label: 'Authenticating…'))
                  : YEnter(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Never share these words. Anyone with them can '
                            'spend your Ycash.',
                            style: TextStyle(color: YColors.danger),
                          ),
                          const SizedBox(height: YSpacing.lg),
                          Expanded(
                            child: GridView.builder(
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                mainAxisSpacing: YSpacing.sm,
                                crossAxisSpacing: YSpacing.sm,
                                childAspectRatio: 3.4,
                              ),
                              itemCount: _seed!.split(' ').length,
                              itemBuilder: (context, i) {
                                final word = _seed!.split(' ')[i];
                                return Semantics(
                                  label: 'Word ${i + 1}: $word',
                                  excludeSemantics: true,
                                  child: Container(
                                    alignment: Alignment.centerLeft,
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: YSpacing.md),
                                    decoration: BoxDecoration(
                                      color: YColors.spaceSurface,
                                      borderRadius:
                                          BorderRadius.circular(YRadius.button),
                                    ),
                                    child: Text('${i + 1}.  $word'),
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
        ),
      ),
    );
  }
}
