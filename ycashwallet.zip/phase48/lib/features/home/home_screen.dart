import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/providers.dart';
import '../../core/crypto_bridge/ycash_engine.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';
import '../../app/router.dart';
import '../shield/shield_flow.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final balancesAsync = ref.watch(balancesProvider);
    final syncAsync = ref.watch(syncStatusProvider);

    // The poll loop now self-heals on the next tick either way (see
    // providers.dart), but a haptic buzz on the *first* failed poll still
    // tells the user something went wrong without waiting on them to
    // notice a stale number.
    ref.listen<AsyncValue<Balances>>(balancesProvider, (previous, next) {
      if (next.hasError && !(previous?.hasError ?? false)) {
        YHaptics.warn();
      }
    });

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ycash'),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            onPressed: () => context.pushActivity(),
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => context.pushSettings(),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(YSpacing.lg),
          children: [
            _SyncBanner(syncAsync: syncAsync),
            const SizedBox(height: YSpacing.md),
            balancesAsync.when(
              data: (b) => _BalanceStack(balances: b),
              loading: () => const _BalanceStackSkeleton(),
              // Previously bare `Text('Could not load balances: $e')` with
              // no way to retry short of leaving and returning to the
              // screen. Now offers an immediate retry alongside the
              // automatic one that already happens on the next poll.
              error: (e, _) => YErrorState(
                message: 'Could not load balances.',
                onRetry: () => ref.invalidate(balancesProvider),
              ),
            ),
            const SizedBox(height: YSpacing.xl),
            _QuickActions(balances: balancesAsync.value),
          ],
        ),
      ),
    );
  }
}

class _SyncBanner extends StatelessWidget {
  final AsyncValue<SyncStatus> syncAsync;
  const _SyncBanner({required this.syncAsync});

  @override
  Widget build(BuildContext context) {
    return syncAsync.when(
      data: (s) {
        if (!s.isSyncing) return const SizedBox.shrink();
        // YEnter instead of a raw .animate() call so this respects
        // "reduce motion" like the rest of the app.
        return YEnter(
          child: LinearProgressIndicator(
            value: s.progress,
            backgroundColor: YColors.spaceSurface,
            color: YColors.shieldedPrimary,
          ),
        );
      },
      loading: () => const SizedBox.shrink(),
      error: (_, __) => const SizedBox.shrink(),
    );
  }
}

class _BalanceStack extends StatelessWidget {
  final Balances balances;
  const _BalanceStack({required this.balances});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        YEnter(
          child: _BalanceCard(
            label: 'Shielded',
            zatoshi: balances.shieldedZatoshi,
            gradient: YColors.shieldedGradient,
            icon: Icons.shield_outlined,
          ),
        ),
        const SizedBox(height: YSpacing.md),
        YEnter(
          delay: const Duration(milliseconds: 80),
          child: _BalanceCard(
            label: 'Transparent',
            zatoshi: balances.transparentZatoshi,
            gradient: const LinearGradient(
                colors: [YColors.transparentAccent, Color(0xFFF57B5B)]),
            icon: Icons.visibility_outlined,
          ),
        ),
      ],
    );
  }
}

class _BalanceCard extends StatelessWidget {
  final String label;
  final int zatoshi;
  final Gradient gradient;
  final IconData icon;
  const _BalanceCard({
    required this.label,
    required this.zatoshi,
    required this.gradient,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final amount = (zatoshi / 1e8).toStringAsFixed(4);
    return Container(
      padding: const EdgeInsets.all(YSpacing.lg),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(YRadius.card),
        gradient: LinearGradient(
          colors: [
            YColors.spaceSurface,
            YColors.spaceSurfaceRaised,
          ],
        ),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(YSpacing.sm),
            decoration: BoxDecoration(gradient: gradient, shape: BoxShape.circle),
            child: Icon(icon, color: Colors.white, size: 22),
          ),
          const SizedBox(width: YSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(color: YColors.textSecondary)),
                Text('$amount YEC',
                    style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w700,
                        fontFeatures: [FontFeature.tabularFigures()])),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _BalanceStackSkeleton extends StatelessWidget {
  const _BalanceStackSkeleton();
  @override
  Widget build(BuildContext context) {
    // A continuously-looping shimmer is exactly the kind of motion
    // "reduce motion" exists to suppress — unlike a one-off entrance
    // fade, this repeats for as long as the screen is loading. Under
    // that setting this renders as a plain static block instead.
    final reduceMotion = MediaQuery.of(context).disableAnimations;
    return Column(
      children: List.generate(2, (i) {
        final block = Container(
          height: 84,
          margin: const EdgeInsets.only(bottom: YSpacing.md),
          decoration: BoxDecoration(
            color: YColors.spaceSurface,
            borderRadius: BorderRadius.circular(YRadius.card),
          ),
        );
        return reduceMotion
            ? block
            : block.animate(onPlay: (c) => c.repeat()).shimmer(duration: 1200.ms);
      }),
    );
  }
}

/// The headline UX: whichever pool has spendable funds sitting in the
/// "wrong" place gets a single obvious button, no menu diving required.
class _QuickActions extends ConsumerWidget {
  final Balances? balances;
  const _QuickActions({required this.balances});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final b = balances;
    return Row(
      children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () => context.pushSend(),
            icon: const Icon(Icons.arrow_upward),
            label: const Text('Send'),
          ),
        ),
        const SizedBox(width: YSpacing.md),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () => context.pushReceive(),
            icon: const Icon(Icons.arrow_downward),
            label: const Text('Receive'),
          ),
        ),
        if (b != null && b.hasUnshielded) ...[
          const SizedBox(width: YSpacing.md),
          Expanded(
            child: ElevatedButton.icon(
              onPressed: () => runShieldFlow(context, ref,
                  direction: ShieldDirection.shield),
              icon: const Icon(Icons.shield),
              label: const Text('Shield all'),
            ),
          ),
        ],
      ],
    );
  }
}

