import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:math';
import '../../core/providers.dart';
import '../../core/biometrics/biometric_gate.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

/// Shows the recovery phrase once, requires the user to prove they wrote
/// it down by picking the correct words for a few random positions, then
/// marks backup confirmed. Getting the quiz wrong sends them back to the
/// phrase instead of forward — never accept "I'll do it later" for this
/// step, since it's the only recovery path for shielded funds.
class SeedBackupScreen extends ConsumerStatefulWidget {
  final String seedPhrase;
  final VoidCallback onConfirmed;
  const SeedBackupScreen(
      {super.key, required this.seedPhrase, required this.onConfirmed});

  @override
  ConsumerState<SeedBackupScreen> createState() => _SeedBackupScreenState();
}

class _SeedBackupScreenState extends ConsumerState<SeedBackupScreen> {
  bool _revealed = false;
  bool _iveWrittenItDown = false;

  @override
  Widget build(BuildContext context) {
    final words = widget.seedPhrase.split(' ');

    return Scaffold(
      appBar: AppBar(title: const Text('Back up your wallet')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(YSpacing.lg),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              YEnter(
                child: const Text(
                  'These 24 words are the only way to recover your funds. '
                  'Anyone with them can spend your Ycash. Write them down and '
                  'store them offline — never as a screenshot or in the cloud.',
                  style: TextStyle(color: YColors.textSecondary),
                ),
              ),
              const SizedBox(height: YSpacing.lg),
              Expanded(
                child: _revealed
                    ? _WordGrid(words: words)
                    : Center(
                        child: YEnter(
                          delay: const Duration(milliseconds: 80),
                          child: ElevatedButton.icon(
                            onPressed: _reveal,
                            icon: const Icon(Icons.visibility_outlined),
                            label: const Text('Reveal recovery phrase'),
                          ),
                        ),
                      ),
              ),
              if (_revealed) ...[
                YEnter(
                  delay: const Duration(milliseconds: 200),
                  child: CheckboxListTile(
                    value: _iveWrittenItDown,
                    onChanged: (v) =>
                        setState(() => _iveWrittenItDown = v ?? false),
                    title: const Text("I've written this down safely"),
                    controlAffinity: ListTileControlAffinity.leading,
                  ),
                ),
                YEnter(
                  delay: const Duration(milliseconds: 240),
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _iveWrittenItDown
                          ? () => _startVerificationQuiz(words)
                          : null,
                      child: const Text('Continue'),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _reveal() async {
    final gate = ref.read(biometricGateProvider);
    final auth = await gate.authenticate(GateReason.revealSeedOrKeys);
    if (auth.authenticated) {
      setState(() => _revealed = true);
    } else {
      // Same haptic warn used for every other auth failure in the app
      // (settings, wipe wallet, etc.) — previously this was the one gate
      // check that failed silently with no buzz.
      YHaptics.warn();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(auth.error ?? 'Authentication required')),
        );
      }
    }
  }

  Future<void> _startVerificationQuiz(List<String> words) async {
    final rnd = Random();
    final positions = (List<int>.generate(words.length, (i) => i)..shuffle(rnd))
        .take(3)
        .toList()
      ..sort();

    for (final pos in positions) {
      final correct = words[pos];
      final distractors = (List<String>.from(words)..remove(correct))
        ..shuffle(rnd);
      final options = [correct, ...distractors.take(2)]..shuffle(rnd);

      if (!mounted) return;
      final picked = await showModalBottomSheet<String>(
        context: context,
        backgroundColor: YColors.spaceSurfaceRaised,
        isDismissible: false,
        builder: (ctx) => Padding(
          padding: const EdgeInsets.all(YSpacing.lg),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('What is word #${pos + 1}?',
                  style: Theme.of(ctx).textTheme.titleMedium),
              const SizedBox(height: YSpacing.md),
              ...options.map((w) => Padding(
                    padding: const EdgeInsets.only(bottom: YSpacing.sm),
                    child: SizedBox(
                      width: double.infinity,
                      child: OutlinedButton(
                        onPressed: () => Navigator.of(ctx).pop(w),
                        child: Text(w),
                      ),
                    ),
                  )),
            ],
          ),
        ),
      );

      if (picked != correct) {
        YHaptics.warn();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text("That's not quite right — let's check the phrase again")));
          setState(() => _revealed = true); // send them back to re-read it
        }
        return;
      }
    }

    // Previously this call was unguarded: if the storage write failed,
    // the "Continue" tap just did nothing with no explanation, leaving
    // the user unsure whether their backup was actually confirmed. Now a
    // failure surfaces an error and leaves the quiz state intact so
    // pressing "Continue" again is a real retry.
    try {
      final vault = ref.read(seedVaultProvider);
      await vault.markBackupConfirmed();
      widget.onConfirmed();
    } catch (e) {
      YHaptics.warn();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content:
                Text('Could not confirm your backup. Please try again.')));
      }
    }
  }
}

class _WordGrid extends StatelessWidget {
  final List<String> words;
  const _WordGrid({required this.words});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: YSpacing.sm,
        crossAxisSpacing: YSpacing.sm,
        childAspectRatio: 3.4,
      ),
      itemCount: words.length,
      // Staggered so the grid reads as filling in rather than the whole
      // phrase snapping onto the screen at once — capped step so 24 words
      // doesn't turn into a multi-second reveal.
      itemBuilder: (context, i) => YEnter.staggered(
        index: i,
        step: const Duration(milliseconds: 15),
        child: Semantics(
          // "Word 1: apple" instead of a screen reader sounding out the
          // raw "1.  apple" punctuation.
          label: 'Word ${i + 1}: ${words[i]}',
          excludeSemantics: true,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.symmetric(horizontal: YSpacing.md),
            decoration: BoxDecoration(
              color: YColors.spaceSurface,
              borderRadius: BorderRadius.circular(YRadius.button),
            ),
            child: Text.rich(
              TextSpan(children: [
                TextSpan(
                    text: '${i + 1}.  ',
                    style: const TextStyle(color: YColors.textMuted)),
                TextSpan(
                    text: words[i],
                    style: const TextStyle(fontWeight: FontWeight.w600)),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
