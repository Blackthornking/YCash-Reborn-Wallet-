import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

class WelcomeScreen extends StatelessWidget {
  final VoidCallback onCreateNew;
  final VoidCallback onRestore;
  const WelcomeScreen(
      {super.key, required this.onCreateNew, required this.onRestore});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(YSpacing.xl),
          child: Column(
            children: [
              const Spacer(),
              // Previously this screen animated with raw .animate() calls,
              // which — unlike YEnter — don't check the OS "reduce motion"
              // setting, so a person who'd opted out of motion still got
              // the full fade/scale/slide sequence on the very first
              // screen they see.
              YEnter(
                child: SvgPicture.asset(
                  'assets/branding/logo.svg',
                  width: 120,
                  height: 120,
                  // Purely decorative brand mark — the "Ycash" text right
                  // below already identifies the app, so this shouldn't
                  // show up as a second, unlabeled node to a screen reader.
                  excludeFromSemantics: true,
                ),
              ),
              const SizedBox(height: YSpacing.lg),
              // Heading + tagline merged into one semantics node so a
              // screen reader announces them as a single intro statement
              // ("Ycash. Private by default...") instead of two separate
              // stops.
              YEnter(
                delay: const Duration(milliseconds: 100),
                child: Semantics(
                  label: 'Ycash. Private by default. Shielded funds, one '
                      'tap away.',
                  excludeSemantics: true,
                  child: Column(
                    children: [
                      Text('Ycash',
                          style: Theme.of(context)
                              .textTheme
                              .headlineMedium
                              ?.copyWith(fontWeight: FontWeight.w700)),
                      const SizedBox(height: YSpacing.sm),
                      const Text(
                        'Private by default. Shielded funds, one tap away.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: YColors.textSecondary),
                      ),
                    ],
                  ),
                ),
              ),
              const Spacer(),
              YEnter(
                delay: const Duration(milliseconds: 220),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: onCreateNew,
                    child: const Text('Create a new wallet'),
                  ),
                ),
              ),
              const SizedBox(height: YSpacing.md),
              YEnter(
                delay: const Duration(milliseconds: 280),
                child: SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: onRestore,
                    child: const Text('Restore from recovery phrase'),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
