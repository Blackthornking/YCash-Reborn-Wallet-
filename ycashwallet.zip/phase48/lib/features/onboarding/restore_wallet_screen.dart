import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/providers.dart';
import '../../design/tokens.dart';

class RestoreWalletScreen extends ConsumerStatefulWidget {
  final void Function(String seedPhrase) onRestored;
  const RestoreWalletScreen({super.key, required this.onRestored});

  @override
  ConsumerState<RestoreWalletScreen> createState() =>
      _RestoreWalletScreenState();
}

class _RestoreWalletScreenState extends ConsumerState<RestoreWalletScreen> {
  final _controller = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Restore wallet')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(YSpacing.lg),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Enter your 24-word recovery phrase, separated by spaces.',
                style: TextStyle(color: YColors.textSecondary),
              ),
              const SizedBox(height: YSpacing.lg),
              TextField(
                controller: _controller,
                maxLines: 4,
                decoration: const InputDecoration(
                  hintText: 'word1 word2 word3 ...',
                  border: OutlineInputBorder(),
                ),
              ),
              if (_error != null) ...[
                const SizedBox(height: YSpacing.sm),
                Text(_error!, style: const TextStyle(color: YColors.danger)),
              ],
              const SizedBox(height: YSpacing.lg),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _busy ? null : _restore,
                  child: _busy
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Text('Restore'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _restore() async {
    final phrase = _controller.text.trim();
    final wordCount = phrase.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).length;
    if (wordCount != 24) {
      setState(() => _error = 'Expected 24 words, got $wordCount');
      return;
    }

    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final engine = ref.read(engineProvider);
      await engine.openOrCreateWallet(restoreSeedPhrase: phrase);
      final vault = ref.read(seedVaultProvider);
      await vault.write(phrase);
      await vault.markBackupConfirmed(); // they already have it backed up elsewhere
      widget.onRestored(phrase);
    } catch (e) {
      setState(() => _error = 'Could not restore: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }
}
