import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/providers.dart';
import '../../design/widgets.dart';
import 'welcome_screen.dart';
import 'restore_wallet_screen.dart';
import 'seed_backup_screen.dart';
import 'biometric_enroll_screen.dart';

/// Drives the onboarding sequence as a plain widget stack rather than named
/// go_router routes, since every step depends on state produced by the
/// previous one (the seed phrase, then backup confirmation) and passing
/// that through router extras is easy to get subtly wrong. Once onboarding
/// is done, [onFinished] hands control back to the app router for the
/// normal home/send/receive navigation.
class OnboardingFlow extends ConsumerStatefulWidget {
  final VoidCallback onFinished;
  const OnboardingFlow({super.key, required this.onFinished});

  @override
  ConsumerState<OnboardingFlow> createState() => _OnboardingFlowState();
}

enum _Step { welcome, creating, seedBackup, restore, biometric }

class _OnboardingFlowState extends ConsumerState<OnboardingFlow> {
  _Step _step = _Step.welcome;
  String? _seedPhrase;
  Object? _createError;

  @override
  Widget build(BuildContext context) {
    switch (_step) {
      case _Step.welcome:
        return WelcomeScreen(
          onCreateNew: _createNew,
          onRestore: () => setState(() => _step = _Step.restore),
        );
      case _Step.creating:
        // Previously a bare spinner with no error branch at all: if wallet
        // creation, seed export, or the vault write threw, the user was
        // stuck here forever. Now a failure surfaces a retry-capable
        // error with a way back out.
        return Scaffold(
          body: SafeArea(
            child: Center(
              child: _createError != null
                  ? Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        YErrorState(
                          message: 'Could not create your wallet: '
                              '$_createError',
                          onRetry: _createNew,
                        ),
                        TextButton(
                          onPressed: () => setState(() {
                            _step = _Step.welcome;
                            _createError = null;
                          }),
                          child: const Text('Start over'),
                        ),
                      ],
                    )
                  : const YBusyState(label: 'Creating your wallet…'),
            ),
          ),
        );
      case _Step.seedBackup:
        return SeedBackupScreen(
          seedPhrase: _seedPhrase!,
          onConfirmed: () => setState(() => _step = _Step.biometric),
        );
      case _Step.restore:
        return RestoreWalletScreen(
          onRestored: (_) => setState(() => _step = _Step.biometric),
        );
      case _Step.biometric:
        return BiometricEnrollScreen(onDone: widget.onFinished);
    }
  }

  Future<void> _createNew() async {
    setState(() {
      _step = _Step.creating;
      _createError = null;
    });
    final engine = ref.read(engineProvider);
    try {
      await engine.openOrCreateWallet(); // generates a fresh seed internally
      final seed = await engine.exportSeedPhrase();
      final vault = ref.read(seedVaultProvider);
      await vault.write(seed);
      if (!mounted) return;
      setState(() {
        _seedPhrase = seed;
        _step = _Step.seedBackup;
      });
    } catch (e) {
      YHaptics.warn();
      if (!mounted) return;
      setState(() => _createError = e);
    }
  }
}
