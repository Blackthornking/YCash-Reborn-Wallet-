import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/providers.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

/// Last onboarding step: turn on biometric confirmation, or set a PIN if
/// the device has no biometrics enrolled. The app never launches into the
/// wallet with neither in place — [onDone] should only be reachable from
/// one of the two branches below.
class BiometricEnrollScreen extends ConsumerStatefulWidget {
  final VoidCallback onDone;
  const BiometricEnrollScreen({super.key, required this.onDone});

  @override
  ConsumerState<BiometricEnrollScreen> createState() =>
      _BiometricEnrollScreenState();
}

class _BiometricEnrollScreenState extends ConsumerState<BiometricEnrollScreen> {
  bool _checkingDevice = true;
  bool _biometricsAvailable = false;
  final _pinController = TextEditingController();
  final _pinConfirmController = TextEditingController();
  String? _pinError;

  @override
  void initState() {
    super.initState();
    _checkDevice();
  }

  Future<void> _checkDevice() async {
    final gate = ref.read(biometricGateProvider);
    final available = await gate.canUseBiometrics;
    if (!mounted) return;
    setState(() {
      _biometricsAvailable = available;
      _checkingDevice = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Secure your wallet')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(YSpacing.lg),
          child: _checkingDevice
              ? const Center(
                  child: YBusyState(label: 'Checking device security'))
              : _biometricsAvailable
                  ? _BiometricBranch(onDone: widget.onDone)
                  : _pinSetupBranch(),
        ),
      ),
    );
  }

  Widget _pinSetupBranch() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const YEnter(
          child: Text(
            'This device has no fingerprint or face unlock set up. Set an '
            "app PIN instead — you'll need it to send, shield, unshield, or "
            'view your recovery phrase.',
            style: TextStyle(color: YColors.textSecondary),
          ),
        ),
        const SizedBox(height: YSpacing.lg),
        YEnter(
          delay: const Duration(milliseconds: 80),
          child: TextField(
            controller: _pinController,
            obscureText: true,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Choose a PIN'),
          ),
        ),
        const SizedBox(height: YSpacing.md),
        YEnter(
          delay: const Duration(milliseconds: 120),
          child: TextField(
            controller: _pinConfirmController,
            obscureText: true,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Confirm PIN'),
          ),
        ),
        if (_pinError != null) ...[
          const SizedBox(height: YSpacing.sm),
          // liveRegion so the validation failure gets announced as soon as
          // it appears, matching the pattern used for form errors
          // elsewhere in the app (send screen, change-PIN dialog).
          Semantics(
            liveRegion: true,
            child: Text(_pinError!,
                style: const TextStyle(color: YColors.danger)),
          ),
        ],
        const SizedBox(height: YSpacing.lg),
        YEnter(
          delay: const Duration(milliseconds: 160),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton(
                onPressed: _savePin, child: const Text('Set PIN')),
          ),
        ),
      ],
    );
  }

  Future<void> _savePin() async {
    final pin = _pinController.text;
    if (pin.length < 4) {
      YHaptics.warn();
      setState(() => _pinError = 'PIN must be at least 4 digits');
      return;
    }
    if (pin != _pinConfirmController.text) {
      YHaptics.warn();
      setState(() => _pinError = "PINs don't match");
      return;
    }
    // Previously an unhandled failure here (e.g. secure storage refusing
    // the write) left the user stuck on "Set PIN" with no feedback and no
    // way to tell whether anything had happened — the same dead-end class
    // of bug fixed for the equivalent call in the settings change-PIN flow.
    setState(() => _pinError = null);
    try {
      final gate = ref.read(biometricGateProvider);
      await gate.setPin(pin);
      widget.onDone();
    } catch (e) {
      YHaptics.warn();
      if (mounted) {
        setState(() => _pinError = 'Could not save your PIN. Please try again.');
      }
    }
  }
}

class _BiometricBranch extends ConsumerWidget {
  final VoidCallback onDone;
  const _BiometricBranch({required this.onDone});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Icon + explanation merged into one semantics node — the
        // fingerprint glyph carries no meaning on its own, so previously
        // it was announced as a bare unlabeled icon right before the
        // sentence that actually explains it.
        YEnter(
          child: Semantics(
            label: "You'll confirm sends, shields, unshields, and viewing "
                'your recovery phrase with your fingerprint or face.',
            excludeSemantics: true,
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.fingerprint,
                    size: 64, color: YColors.shieldedPrimary),
                SizedBox(height: YSpacing.lg),
                Text(
                  "You'll confirm sends, shields, unshields, and viewing "
                  'your recovery phrase with your fingerprint or face.',
                  style: TextStyle(color: YColors.textSecondary),
                ),
              ],
            ),
          ),
        ),
        const Spacer(),
        YEnter(
          delay: const Duration(milliseconds: 120),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton(
                onPressed: onDone, child: const Text('Enable & continue')),
          ),
        ),
      ],
    );
  }
}
