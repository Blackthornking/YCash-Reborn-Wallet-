import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:decimal/decimal.dart';
import '../../core/providers.dart';
import '../../core/biometrics/biometric_gate.dart';
import '../../core/crypto_bridge/ycash_engine.dart';
import '../../core/models/ycash_config.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';

class SendScreen extends ConsumerStatefulWidget {
  const SendScreen({super.key});

  @override
  ConsumerState<SendScreen> createState() => _SendScreenState();
}

class _SendScreenState extends ConsumerState<SendScreen> {
  final _addressController = TextEditingController();
  final _amountController = TextEditingController();
  final _memoController = TextEditingController();
  String _feeTier = 'standard';
  bool _busy = false;
  String? _error;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Send')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(YSpacing.lg),
          children: [
            // Field styling (fill, border, focus ring) now comes from the
            // shared InputDecorationTheme in design/tokens.dart instead of
            // each field hand-rolling its own OutlineInputBorder.
            TextField(
              controller: _addressController,
              decoration: InputDecoration(
                labelText: 'Recipient address',
                suffixIcon: IconButton(
                  icon: const Icon(Icons.qr_code_scanner),
                  tooltip: 'Scan QR code',
                  onPressed: _scanQr,
                ),
              ),
            ),
            const SizedBox(height: YSpacing.md),
            TextField(
              controller: _amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'Amount (YEC)'),
            ),
            const SizedBox(height: YSpacing.md),
            TextField(
              controller: _memoController,
              maxLines: 2,
              decoration: const InputDecoration(
                labelText: 'Memo (optional, shielded only)',
              ),
            ),
            const SizedBox(height: YSpacing.lg),
            const Text('Network fee', style: TextStyle(color: YColors.textSecondary)),
            const SizedBox(height: YSpacing.sm),
            Wrap(
              spacing: YSpacing.sm,
              children: YcashConfig.feeTiers.keys.map((tier) {
                final selected = tier == _feeTier;
                return ChoiceChip(
                  label: Text(tier),
                  selected: selected,
                  onSelected: (_) => setState(() => _feeTier = tier),
                );
              }).toList(),
            ),
            if (_error != null) ...[
              const SizedBox(height: YSpacing.md),
              Semantics(
                liveRegion: true,
                child: Text(_error!, style: const TextStyle(color: YColors.danger)),
              ),
            ],
            const SizedBox(height: YSpacing.xl),
            ElevatedButton(
              onPressed: _busy ? null : _reviewAndSend,
              child: _busy
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Review'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _scanQr() async {
    final result = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => const _QrScanScreen()),
    );
    if (result != null) {
      setState(() => _addressController.text = result);
    }
  }

  Future<void> _reviewAndSend() async {
    setState(() => _error = null);

    final address = _addressController.text.trim();
    if (address.isEmpty) {
      setState(() => _error = 'Enter a recipient address');
      return;
    }
    Decimal amountYec;
    try {
      amountYec = Decimal.parse(_amountController.text.trim());
    } catch (_) {
      setState(() => _error = 'Enter a valid amount');
      return;
    }
    final amountZatoshi = (amountYec * Decimal.fromInt(100000000)).toBigInt().toInt();

    setState(() => _busy = true);
    try {
      final engine = ref.read(engineProvider);
      final plan = await engine.planSend(
        toAddress: address,
        amountZatoshi: amountZatoshi,
        memo: _memoController.text.trim().isEmpty ? null : _memoController.text.trim(),
        feeTier: _feeTier,
      );

      if (!mounted) return;
      final confirmed = await showModalBottomSheet<bool>(
        context: context,
        backgroundColor: YColors.spaceSurfaceRaised,
        shape: const RoundedRectangleBorder(
          borderRadius:
              BorderRadius.vertical(top: Radius.circular(YRadius.card)),
        ),
        builder: (ctx) => _SendReviewSheet(address: address, plan: plan),
      );
      if (confirmed != true) return;

      final gate = ref.read(biometricGateProvider);
      final auth = await gate.authenticate(GateReason.confirmSend);
      if (!auth.authenticated) {
        if (!mounted) return;
        setState(() => _error = auth.error ?? 'Authentication required');
        return;
      }

      final txId = await engine.broadcastPlannedTx(plan);
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Sent — tx $txId')));
        Navigator.of(context).pop();
      }
    } catch (e) {
      setState(() => _error = 'Send failed: $e');
      YHaptics.warn();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }
}

class _SendReviewSheet extends StatelessWidget {
  final String address;
  final TxPlan plan;
  const _SendReviewSheet({required this.address, required this.plan});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(YSpacing.lg),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Review send', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: YSpacing.md),
          // The sheet itself already slides up (Material's modal bottom
          // sheet transition); previously its contents just snapped in
          // instantly on top of that. Staggering each row's fade-in gives
          // the numbers a moment to land instead of arriving all at once.
          YEnter(
            child: Text('To: $address',
                style: const TextStyle(color: YColors.textSecondary),
                overflow: TextOverflow.ellipsis),
          ),
          const SizedBox(height: YSpacing.sm),
          YEnter(
            delay: const Duration(milliseconds: 60),
            child: _row('Amount', '${plan.amountZatoshi / 1e8} YEC'),
          ),
          YEnter(
            delay: const Duration(milliseconds: 100),
            child: _row('Network fee', '${plan.feeZatoshi / 1e8} YEC'),
          ),
          YEnter(
            delay: const Duration(milliseconds: 140),
            child: _row(
                'Total', '${(plan.amountZatoshi + plan.feeZatoshi) / 1e8} YEC'),
          ),
          const SizedBox(height: YSpacing.lg),
          YEnter(
            delay: const Duration(milliseconds: 180),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: const Text('Confirm with biometrics'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _row(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: YSpacing.xs),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(color: YColors.textSecondary)),
            Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      );
}

class _QrScanScreen extends StatefulWidget {
  const _QrScanScreen();

  @override
  State<_QrScanScreen> createState() => _QrScanScreenState();
}

class _QrScanScreenState extends State<_QrScanScreen> {
  final _controller = MobileScannerController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan address')),
      body: Stack(
        fit: StackFit.expand,
        children: [
          MobileScanner(
            controller: _controller,
            onDetect: (capture) {
              if (capture.barcodes.isEmpty) return;
              final value = capture.barcodes.first.rawValue;
              if (value != null) {
                Navigator.of(context).pop(value);
              }
            },
            // Previously a bare camera preview with no fallback — a
            // denied permission or unavailable camera just showed a
            // black rectangle. Now it's the same retry-capable error
            // state used everywhere else in the app.
            errorBuilder: (context, error, child) => YErrorState(
              message: 'Could not access the camera.',
              onRetry: () => _controller.start(),
              icon: Icons.no_photography_outlined,
            ),
          ),
          // A plain viewfinder square so it's obvious where to line up
          // the code, instead of an unbounded full-screen camera feed.
          const IgnorePointer(child: Center(child: _ScanFrame())),
          Positioned(
            left: YSpacing.xl,
            right: YSpacing.xl,
            bottom: YSpacing.xxl,
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: YSpacing.lg, vertical: YSpacing.sm),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.55),
                borderRadius: BorderRadius.circular(YRadius.pill),
              ),
              child: const Text(
                'Point your camera at a YCash address QR code',
                textAlign: TextAlign.center,
                style: TextStyle(color: YColors.textPrimary),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ScanFrame extends StatelessWidget {
  const _ScanFrame();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 240,
      height: 240,
      decoration: BoxDecoration(
        border: Border.all(
            color: YColors.shieldedPrimary.withValues(alpha: 0.9), width: 2),
        borderRadius: BorderRadius.circular(YRadius.card),
      ),
    );
  }
}
