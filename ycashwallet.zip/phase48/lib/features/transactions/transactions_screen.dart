import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../core/providers.dart';
import '../../core/crypto_bridge/ycash_engine.dart';
import '../../design/tokens.dart';
import '../../design/widgets.dart';
import 'tx_detail_screen.dart';

enum _Filter { all, shielded, transparent }

class TransactionsScreen extends ConsumerStatefulWidget {
  const TransactionsScreen({super.key});

  @override
  ConsumerState<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends ConsumerState<TransactionsScreen> {
  _Filter _filter = _Filter.all;

  @override
  Widget build(BuildContext context) {
    final txsAsync = ref.watch(transactionHistoryProvider);

    // Same convention as the home dashboard: a haptic buzz on the first
    // failed load tells the user something went wrong without them
    // having to notice a stalled list on their own.
    ref.listen<AsyncValue<List<TxRecord>>>(transactionHistoryProvider,
        (previous, next) {
      if (next.hasError && !(previous?.hasError ?? false)) {
        YHaptics.warn();
      }
    });

    return Scaffold(
      appBar: AppBar(title: const Text('Activity')),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: YSpacing.lg, vertical: YSpacing.sm),
              child: Wrap(
                spacing: YSpacing.sm,
                children: [
                  ChoiceChip(
                    label: const Text('All'),
                    selected: _filter == _Filter.all,
                    onSelected: (_) => setState(() => _filter = _Filter.all),
                  ),
                  ChoiceChip(
                    label: const Text('Shielded'),
                    selected: _filter == _Filter.shielded,
                    onSelected: (_) =>
                        setState(() => _filter = _Filter.shielded),
                  ),
                  ChoiceChip(
                    label: const Text('Transparent'),
                    selected: _filter == _Filter.transparent,
                    onSelected: (_) =>
                        setState(() => _filter = _Filter.transparent),
                  ),
                ],
              ),
            ),
            Expanded(
              child: txsAsync.when(
                data: (txs) {
                  final filtered = txs.where((t) {
                    switch (_filter) {
                      case _Filter.all:
                        return true;
                      case _Filter.shielded:
                        return t.isShielded;
                      case _Filter.transparent:
                        return !t.isShielded;
                    }
                  }).toList()
                    ..sort((a, b) => b.timestamp.compareTo(a.timestamp));

                  if (filtered.isEmpty) {
                    // Distinguish "nothing ever happened" from "nothing
                    // matches this filter" — previously both cases showed
                    // the same flat "No transactions yet" text.
                    final filterLabel = switch (_filter) {
                      _Filter.all => null,
                      _Filter.shielded => 'shielded',
                      _Filter.transparent => 'transparent',
                    };
                    return Center(
                      child: YEmptyState(
                        icon: Icons.receipt_long_outlined,
                        title: filterLabel == null
                            ? 'No transactions yet'
                            : 'No $filterLabel transactions yet',
                        subtitle: filterLabel == null
                            ? 'Sent and received activity will show up here.'
                            : 'Switch filters to see other activity.',
                      ),
                    );
                  }

                  return ListView.separated(
                    padding: const EdgeInsets.all(YSpacing.lg),
                    itemCount: filtered.length,
                    separatorBuilder: (_, __) =>
                        const SizedBox(height: YSpacing.sm),
                    itemBuilder: (context, i) => YEnter.staggered(
                      index: i,
                      child: _TxTile(tx: filtered[i]),
                    ),
                  );
                },
                loading: () =>
                    const Center(child: YBusyState(label: 'Loading activity')),
                // Previously a bare `Text('Could not load activity: $e')`
                // with no way back short of leaving the screen — now
                // offers an explicit retry alongside the haptic nudge above.
                error: (e, _) => Center(
                  child: YErrorState(
                    message: 'Could not load activity.',
                    onRetry: () => ref.invalidate(transactionHistoryProvider),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TxTile extends StatelessWidget {
  final TxRecord tx;
  const _TxTile({required this.tx});

  @override
  Widget build(BuildContext context) {
    final outgoing = tx.amountZatoshi < 0;
    final amount = (tx.amountZatoshi.abs() / 1e8).toStringAsFixed(4);
    final pool = tx.isShielded ? 'shielded' : 'transparent';

    void openDetail() => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => TxDetailScreen(tx: tx)),
        );

    // Previously the icon, "Sent"/"Received", date, and amount were four
    // separate semantics nodes, so a screen reader stepped through each
    // one individually. Merging them into one labelled, tappable node
    // reads as a single coherent item: "Sent 0.1234 YEC, shielded
    // transaction, 5 September 2026 at 3:45 PM".
    final semanticLabel =
        '${outgoing ? 'Sent' : 'Received'} $amount YEC, $pool transaction, '
        '${DateFormat.yMMMMd().add_jm().format(tx.timestamp)}';

    return Semantics(
      button: true,
      excludeSemantics: true,
      label: semanticLabel,
      onTap: openDetail,
      child: InkWell(
        borderRadius: BorderRadius.circular(YRadius.card),
        onTap: openDetail,
        child: Container(
          padding: const EdgeInsets.all(YSpacing.md),
          decoration: BoxDecoration(
            color: YColors.spaceSurface,
            borderRadius: BorderRadius.circular(YRadius.card),
          ),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: tx.isShielded
                    ? YColors.shieldedPrimary.withValues(alpha: 0.15)
                    : YColors.transparentAccent.withValues(alpha: 0.15),
                child: Icon(
                  outgoing ? Icons.arrow_upward : Icons.arrow_downward,
                  color: tx.isShielded
                      ? YColors.shieldedPrimary
                      : YColors.transparentAccent,
                  size: 18,
                ),
              ),
              const SizedBox(width: YSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(outgoing ? 'Sent' : 'Received',
                        style: const TextStyle(fontWeight: FontWeight.w600)),
                    Text(
                      DateFormat.yMMMd().add_jm().format(tx.timestamp),
                      style: const TextStyle(
                          color: YColors.textMuted, fontSize: 12),
                    ),
                  ],
                ),
              ),
              Text(
                '${outgoing ? '-' : '+'}$amount YEC',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: outgoing ? YColors.textPrimary : YColors.success,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
