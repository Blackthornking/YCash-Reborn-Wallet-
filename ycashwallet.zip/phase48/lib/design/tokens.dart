import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Design tokens for Ycash Reborn.
///
/// Single source of truth for color, type, spacing and motion so every
/// screen looks like it belongs to the same futuristic system instead of
/// hand-tuned per-widget styling.
class YColors {
  YColors._();

  // Backgrounds
  static const Color spaceDeep = Color(0xFF0B0F2B);
  static const Color spaceSurface = Color(0xFF151A3D);
  static const Color spaceSurfaceRaised = Color(0xFF1E2450);

  // Accents
  static const Color shieldedPrimary = Color(0xFF5B7CFA); // shielded pool
  static const Color shieldedSecondary = Color(0xFF8C5CF5);
  static const Color transparentAccent = Color(0xFFF5A65B); // transparent pool
  static const Color success = Color(0xFF4ADE80);
  static const Color danger = Color(0xFFF5605B);

  // Text
  static const Color textPrimary = Color(0xFFEAF0FF);
  static const Color textSecondary = Color(0xFF9AA6D6);
  static const Color textMuted = Color(0xFF6B76A8);

  static const LinearGradient shieldedGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [shieldedPrimary, shieldedSecondary],
  );
}

class YSpacing {
  YSpacing._();
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 16;
  static const double lg = 24;
  static const double xl = 32;
  static const double xxl = 48;
}

class YRadius {
  YRadius._();
  static const double card = 20;
  static const double button = 16;
  static const double pill = 999;
}

class YMotion {
  YMotion._();
  static const Duration fast = Duration(milliseconds: 150);
  static const Duration base = Duration(milliseconds: 300);
  static const Duration slow = Duration(milliseconds: 500);
  static const Curve standard = Curves.easeOutCubic;
}

ThemeData buildYcashTheme() {
  final baseText = GoogleFonts.spaceGroteskTextTheme();

  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: YColors.spaceDeep,
    colorScheme: const ColorScheme.dark(
      primary: YColors.shieldedPrimary,
      secondary: YColors.transparentAccent,
      surface: YColors.spaceSurface,
      error: YColors.danger,
    ),
    textTheme: baseText.apply(
      bodyColor: YColors.textPrimary,
      displayColor: YColors.textPrimary,
    ),
    cardTheme: CardThemeData(
      color: YColors.spaceSurface,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(YRadius.card),
      ),
    ),
    // Before this existed, every screen invented its own field styling —
    // some with a bare default OutlineInputBorder that didn't match the
    // dark space-surface look, some with no border at all. One theme
    // entry now gives every TextField in the app the same filled
    // surface, subtle rest-state border, and shielded-accent focus ring.
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: YColors.spaceSurface,
      contentPadding: const EdgeInsets.symmetric(
          horizontal: YSpacing.md, vertical: YSpacing.md),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(YRadius.button),
        borderSide: BorderSide(color: Colors.white.withValues(alpha: 0.08)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(YRadius.button),
        borderSide: BorderSide(color: Colors.white.withValues(alpha: 0.08)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(YRadius.button),
        borderSide: const BorderSide(color: YColors.shieldedPrimary, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(YRadius.button),
        borderSide: const BorderSide(color: YColors.danger),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(YRadius.button),
        borderSide: const BorderSide(color: YColors.danger, width: 1.5),
      ),
      labelStyle: const TextStyle(color: YColors.textSecondary),
      hintStyle: const TextStyle(color: YColors.textMuted),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: YColors.shieldedPrimary,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(
          vertical: YSpacing.md,
          horizontal: YSpacing.lg,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(YRadius.button),
        ),
        textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
      ),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      foregroundColor: YColors.textPrimary,
    ),
  );
}
