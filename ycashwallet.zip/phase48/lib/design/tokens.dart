import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Design tokens for the YCash black-and-gold identity.
class YColors {
  YColors._();

  // Backgrounds — deep black with warm charcoal surfaces.
  static const Color spaceDeep = Color(0xFF050505);
  static const Color spaceSurface = Color(0xFF101010);
  static const Color spaceSurfaceRaised = Color(0xFF1A1710);

  // Gold identity from the YCash shield artwork.
  static const Color shieldedPrimary = Color(0xFFFFC94A);
  static const Color shieldedSecondary = Color(0xFFD98A08);
  static const Color transparentAccent = Color(0xFFF4B63A);
  static const Color goldLight = Color(0xFFFFE7A0);
  static const Color goldDark = Color(0xFF8F5A00);
  static const Color success = Color(0xFF7BD88F);
  static const Color danger = Color(0xFFFF6B5F);

  // Text — warm white and muted champagne instead of the old blue tint.
  static const Color textPrimary = Color(0xFFFFF7E3);
  static const Color textSecondary = Color(0xFFD8C79B);
  static const Color textMuted = Color(0xFF9A8B68);

  static const LinearGradient shieldedGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [goldLight, shieldedPrimary, shieldedSecondary],
  );

  static const LinearGradient goldGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [goldLight, shieldedPrimary, goldDark],
  );
}

class YSpacing {
  YSpacing._();
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 16;
  static const double lg = 24;
  static const double xl = 32;
  static const double xxl = 48;
}

class YRadius {
  YRadius._();
  static const double card = 20;
  static const double button = 16;
  static const double pill = 999;
}

class YMotion {
  YMotion._();
  static const Duration fast = Duration(milliseconds: 150);
  static const Duration base = Duration(milliseconds: 300);
  static const Duration slow = Duration(milliseconds: 500);
  static const Curve standard = Curves.easeOutCubic;
}

ThemeData buildYcashTheme() {
  final baseText = GoogleFonts.spaceGroteskTextTheme();

  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: YColors.spaceDeep,
    colorScheme: const ColorScheme.dark(
      primary: YColors.shieldedPrimary,
      onPrimary: Color(0xFF181000),
      secondary: YColors.goldLight,
      onSecondary: Color(0xFF181000),
      surface: YColors.spaceSurface,
      onSurface: YColors.textPrimary,
      error: YColors.danger,
    ),
    textTheme: baseText.apply(
      bodyColor: YColors.textPrimary,
      displayColor: YColors.textPrimary,
    ),
    cardTheme: CardThemeData(
      color: YColors.spaceSurface,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(YRadius.card),
        side: const BorderSide(color: Color(0xFF3B2A08)),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: YColors.spaceSurfaceRaised,
      contentPadding: const EdgeInsets.symmetric(
          horizontal: YSpacing.md, vertical: YSpacing.md),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(YRadius.button),
        borderSide: const BorderSide(color: Color(0xFF3B2A08)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(YRadius.button),
        borderSide: const BorderSide(color: Color(0xFF3B2A08)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(YRadius.button),
        borderSide: const BorderSide(color: YColors.shieldedPrimary, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(YRadius.button),
        borderSide: const BorderSide(color: YColors.danger),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(YRadius.button),
        borderSide: const BorderSide(color: YColors.danger, width: 1.5),
      ),
      labelStyle: const TextStyle(color: YColors.textSecondary),
      hintStyle: const TextStyle(color: YColors.textMuted),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: YColors.shieldedPrimary,
        foregroundColor: const Color(0xFF181000),
        padding: const EdgeInsets.symmetric(
          vertical: YSpacing.md,
          horizontal: YSpacing.lg,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(YRadius.button),
        ),
        textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: YColors.goldLight,
        side: const BorderSide(color: YColors.goldDark),
        padding: const EdgeInsets.symmetric(vertical: YSpacing.md, horizontal: YSpacing.lg),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(YRadius.button)),
      ),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      foregroundColor: YColors.textPrimary,
    ),
    dividerColor: const Color(0xFF3B2A08),
    progressIndicatorTheme: const ProgressIndicatorThemeData(
      color: YColors.shieldedPrimary,
      linearTrackColor: YColors.spaceSurfaceRaised,
    ),
  );
}
