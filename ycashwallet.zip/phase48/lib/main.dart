import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app/app.dart';
import 'core/crypto_bridge/ycash_core_ffi_engine.dart';
import 'core/providers.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(
    ProviderScope(
      overrides: [
        engineProvider.overrideWithValue(YcashCoreFfiEngine()),
      ],
      child: const YcashRebornApp(),
    ),
  );
}
