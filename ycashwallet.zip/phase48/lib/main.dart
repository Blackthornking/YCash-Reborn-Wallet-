import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'app/app.dart';
// TODO(phase 3 completion): import the real engine once
// packages/ycash_core_ffi (trimmed Rust backend) is built, e.g.:
// import 'package:ycash_core/ycash_core_ffi_engine.dart';

void main() {
  runApp(
    ProviderScope(
      overrides: [
        // engineProvider.overrideWithValue(YcashCoreFfiEngine()),
      ],
      child: const YcashRebornApp(),
    ),
  );
}
