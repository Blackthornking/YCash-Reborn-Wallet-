import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../biometrics/biometric_gate.dart';

/// Stores the wallet's recovery phrase in Keychain/Keystore-backed secure
/// storage. This class never hands back the seed without a caller having
/// already passed [BiometricGate] — [read] takes the gate result as proof
/// of that, rather than re-implementing its own auth check, so there is
/// exactly one place in the app that decides "is this authenticated".
class SeedVault {
  SeedVault({FlutterSecureStorage? storage})
      : _storage = storage ?? const FlutterSecureStorage();

  final FlutterSecureStorage _storage;
  static const _seedKey = 'ycash.wallet.seed_phrase';
  static const _backupConfirmedKey = 'ycash.wallet.backup_confirmed';

  Future<void> write(String seedPhrase) =>
      _storage.write(key: _seedKey, value: seedPhrase);

  /// Returns the seed phrase only if [auth] indicates a successful
  /// biometric/PIN check. Throws otherwise — callers must not be able to
  /// accidentally bypass this by forgetting an `if`.
  Future<String> read(BiometricAuthResult auth) async {
    if (!auth.authenticated) {
      throw StateError('SeedVault.read called without a passed auth gate');
    }
    final seed = await _storage.read(key: _seedKey);
    if (seed == null) throw StateError('No seed phrase stored');
    return seed;
  }

  Future<void> markBackupConfirmed() =>
      _storage.write(key: _backupConfirmedKey, value: 'true');

  Future<bool> get isBackupConfirmed async =>
      (await _storage.read(key: _backupConfirmedKey)) == 'true';

  Future<void> wipe() async {
    await _storage.delete(key: _seedKey);
    await _storage.delete(key: _backupConfirmedKey);
  }
}
