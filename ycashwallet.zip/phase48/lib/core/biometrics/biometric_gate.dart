import 'package:local_auth/local_auth.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';

/// The reasons a caller can ask [BiometricGate] to authenticate for.
///
/// Keeping this an enum (rather than a free-text string) means every call
/// site is explicit about *why* it's gating, which makes it easy to audit
/// "does every sensitive action actually go through the gate?" later.
enum GateReason {
  revealSeedOrKeys,
  confirmSend,
  confirmShield,
  confirmUnshield,
  changeSecuritySettings,
  wipeWallet,
}

class BiometricAuthResult {
  final bool authenticated;
  final String? error;
  const BiometricAuthResult(this.authenticated, [this.error]);
}

/// Single chokepoint for every sensitive action in the app.
///
/// No screen should call `local_auth` directly. If a screen needs to reveal
/// a seed phrase, confirm a send, or confirm a shield/unshield, it calls
/// [BiometricGate.authenticate] and only proceeds on success. If the device
/// has no biometrics enrolled, this falls back to an app-managed PIN — it
/// never silently lets an action through ungated.
class BiometricGate {
  BiometricGate({LocalAuthentication? localAuth, FlutterSecureStorage? storage})
      : _localAuth = localAuth ?? LocalAuthentication(),
        _storage = storage ?? const FlutterSecureStorage();

  final LocalAuthentication _localAuth;
  final FlutterSecureStorage _storage;

  static const _pinHashKey = 'ycash.security.pin_hash';

  Future<bool> get canUseBiometrics async {
    try {
      final supported = await _localAuth.isDeviceSupported();
      final canCheck = await _localAuth.canCheckBiometrics;
      return supported && canCheck;
    } catch (_) {
      return false;
    }
  }

  Future<bool> get hasPinFallback async =>
      (await _storage.read(key: _pinHashKey)) != null;

  String _reasonText(GateReason reason) {
    switch (reason) {
      case GateReason.revealSeedOrKeys:
        return 'Authenticate to view your recovery phrase';
      case GateReason.confirmSend:
        return 'Authenticate to send funds';
      case GateReason.confirmShield:
        return 'Authenticate to shield funds';
      case GateReason.confirmUnshield:
        return 'Authenticate to unshield funds';
      case GateReason.changeSecuritySettings:
        return 'Authenticate to change security settings';
      case GateReason.wipeWallet:
        return 'Authenticate to erase this wallet';
    }
  }

  /// Attempts biometric authentication for [reason]. Callers should treat
  /// [BiometricAuthResult.authenticated] as the *only* signal to proceed —
  /// never assume success just because no exception was thrown.
  Future<BiometricAuthResult> authenticate(GateReason reason) async {
    if (await canUseBiometrics) {
      try {
        final ok = await _localAuth.authenticate(
          localizedReason: _reasonText(reason),
          options: const AuthenticationOptions(
            stickyAuth: true,
            biometricOnly: false, // allow device passcode as OS-level fallback
          ),
        );
        if (ok) return const BiometricAuthResult(true);
        return const BiometricAuthResult(false, 'Authentication failed');
      } catch (e) {
        return BiometricAuthResult(false, e.toString());
      }
    }

    // No biometrics available on this device: require the app PIN instead
    // of skipping the gate. The PIN entry UI calls [verifyPin] with what
    // the user typed; this branch just signals the caller to show it.
    return const BiometricAuthResult(
      false,
      'no_biometrics_use_pin', // sentinel: UI shows PIN sheet, then calls verifyPin
    );
  }

  Future<void> setPin(String pin) async {
    final hash = sha256.convert(utf8.encode(pin)).toString();
    await _storage.write(key: _pinHashKey, value: hash);
  }

  Future<bool> verifyPin(String pin) async {
    final stored = await _storage.read(key: _pinHashKey);
    if (stored == null) return false;
    final hash = sha256.convert(utf8.encode(pin)).toString();
    return stored == hash;
  }
}
