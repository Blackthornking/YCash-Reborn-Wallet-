import 'dart:async';

import 'package:ycash_core/ycash_core.dart';

import 'ycash_engine.dart';

/// Production adapter between the Flutter domain interface and the Rust ABI.
///
/// Only operations backed by verified native functionality are enabled.
/// Spending, transaction construction and address derivation deliberately
/// fail closed until the exact Ycash consensus/key compatibility tests pass.
class YcashCoreFfiEngine implements YcashEngine {
  YcashCoreFfiEngine({YcashCoreNative? native})
      : _native = native ?? YcashCoreNative.instance;

  final YcashCoreNative _native;
  bool _opened = false;

  @override
  Future<void> openOrCreateWallet({String? restoreSeedPhrase}) async {
    if (restoreSeedPhrase == null || restoreSeedPhrase.trim().isEmpty) {
      _native.createWallet();
    } else {
      _native.restoreWallet(restoreSeedPhrase.trim());
    }
    _opened = true;
  }

  @override
  Future<String> exportSeedPhrase() async {
    if (!_opened) {
      throw StateError('Wallet is not open');
    }
    return _native.exportMnemonic();
  }

  @override
  Future<void> wipeWallet() async {
    _native.wipeWallet();
    _opened = false;
  }

  Never _notReady(String operation) {
    throw UnsupportedError(
      '$operation is disabled until exact YCash cryptographic compatibility '
      'and consensus tests pass.',
    );
  }

  @override
  Future<Balances> getBalances() async => const Balances(
        shieldedZatoshi: 0,
        transparentZatoshi: 0,
      );

  @override
  Stream<SyncStatus> watchSyncStatus() =>
      Stream.value(const SyncStatus(
        syncedHeight: 0,
        chainTipHeight: 0,
        isSyncing: false,
      ));

  @override
  Future<String> getShieldedAddress() async => _notReady('Shielded addresses');

  @override
  Future<String> getTransparentAddress() async =>
      _notReady('Transparent addresses');

  @override
  Future<TxPlan> planSend({
    required String toAddress,
    required int amountZatoshi,
    String? memo,
    required String feeTier,
  }) async =>
      _notReady('Sending');

  @override
  Future<String> broadcastPlannedTx(TxPlan plan) async =>
      _notReady('Broadcasting transactions');

  @override
  Future<TxPlan> planShield({int? amountZatoshi}) async =>
      _notReady('Shielding');

  @override
  Future<TxPlan> planUnshield({int? amountZatoshi}) async =>
      _notReady('Unshielding');

  @override
  Future<List<TxRecord>> getTransactionHistory() async => const [];
}
