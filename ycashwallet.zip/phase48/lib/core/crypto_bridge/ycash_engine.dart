/// The typed Dart-side contract for the Rust crypto/sync engine.
///
/// This file intentionally contains no cryptography. It defines the shape
/// of what the trimmed `ycash_core_ffi` package (built from the existing,
/// proven Sapling code — Orchard, UA, Ledger and Zcash-mainnet/testnet
/// branches removed) exposes to the Flutter app. Implementations live in
/// `packages/ycash_core_ffi`; everything in `lib/` talks to this interface,
/// never to raw FFI calls, so the security-critical boundary stays in one
/// auditable place.
library ycash_engine;

class Balances {
  final int shieldedZatoshi;
  final int transparentZatoshi;
  const Balances(
      {required this.shieldedZatoshi, required this.transparentZatoshi});

  int get totalZatoshi => shieldedZatoshi + transparentZatoshi;
  bool get hasUnshielded => transparentZatoshi > 0;
  bool get hasShielded => shieldedZatoshi > 0;
}

class SyncStatus {
  final int syncedHeight;
  final int chainTipHeight;
  final bool isSyncing;
  const SyncStatus(
      {required this.syncedHeight,
      required this.chainTipHeight,
      required this.isSyncing});

  double get progress =>
      chainTipHeight == 0 ? 0 : syncedHeight / chainTipHeight;
}

class TxPlan {
  final int feeZatoshi;
  final int amountZatoshi;
  final Balances resultingBalances;
  const TxPlan(
      {required this.feeZatoshi,
      required this.amountZatoshi,
      required this.resultingBalances});
}

class TxRecord {
  final String txId;
  final DateTime timestamp;
  final int amountZatoshi; // signed: negative = outgoing
  final bool isShielded;
  final String? memo;
  const TxRecord({
    required this.txId,
    required this.timestamp,
    required this.amountZatoshi,
    required this.isShielded,
    this.memo,
  });
}

abstract class YcashEngine {
  Future<void> openOrCreateWallet({String? restoreSeedPhrase});
  Future<String> exportSeedPhrase(); // caller must have passed BiometricGate first
  Future<Balances> getBalances();
  Stream<SyncStatus> watchSyncStatus();
  Future<void> wipeWallet(); // deletes the local synced-chain database

  Future<String> getShieldedAddress();
  Future<String> getTransparentAddress();

  Future<TxPlan> planSend(
      {required String toAddress,
      required int amountZatoshi,
      String? memo,
      required String feeTier});
  Future<String> broadcastPlannedTx(TxPlan plan); // returns txid

  /// Builds a plan to move funds from transparent -> shielded pool.
  /// [amountZatoshi] null means "shield everything spendable".
  Future<TxPlan> planShield({int? amountZatoshi});

  /// Builds a plan to move funds from shielded -> transparent pool.
  Future<TxPlan> planUnshield({int? amountZatoshi});

  Future<List<TxRecord>> getTransactionHistory();
}
