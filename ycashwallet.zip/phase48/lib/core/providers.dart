import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'crypto_bridge/ycash_engine.dart';
import 'biometrics/biometric_gate.dart';
import 'secure_storage/seed_vault.dart';
import 'settings_store/settings_store.dart';

/// Provide the real engine implementation at app startup, e.g.:
///   runApp(ProviderScope(
///     overrides: [engineProvider.overrideWithValue(YcashCoreFfiEngine())],
///     child: const YcashRebornApp(),
///   ));
final engineProvider = Provider<YcashEngine>((ref) {
  throw UnimplementedError(
      'engineProvider must be overridden with the real ycash_core_ffi engine at startup');
});

final biometricGateProvider = Provider<BiometricGate>((ref) => BiometricGate());

final seedVaultProvider = Provider<SeedVault>((ref) => SeedVault());

final settingsStoreProvider = Provider<SettingsStore>((ref) => SettingsStore());

final transactionHistoryProvider = FutureProvider<List<TxRecord>>((ref) {
  final engine = ref.watch(engineProvider);
  return engine.getTransactionHistory();
});

final balancesProvider = StreamProvider<Balances>((ref) async* {
  final engine = ref.watch(engineProvider);
  // Simple poll loop; swap for a native push stream once the FFI layer
  // exposes one. Kept deliberately dumb here so it's obviously correct.
  //
  // A bare `yield await engine.getBalances();` here meant a single failed
  // poll (e.g. the lightwalletd RPC times out) threw out of this async*
  // generator, which permanently ends the stream — every subsequent poll
  // that would otherwise have succeeded is lost, and the UI is stuck
  // showing that one error forever with no way to recover short of an app
  // restart. `yield* Stream.error(...)` forwards a single error event to
  // listeners *without* ending the generator, so the loop keeps polling.
  while (true) {
    try {
      yield await engine.getBalances();
    } catch (e, st) {
      yield* Stream<Balances>.error(e, st);
    }
    await Future.delayed(const Duration(seconds: 5));
  }
});

final syncStatusProvider = StreamProvider<SyncStatus>((ref) {
  final engine = ref.watch(engineProvider);
  return engine.watchSyncStatus();
});
