import 'package:shared_preferences/shared_preferences.dart';
import '../models/ycash_config.dart';

/// Holds ordinary (non-secret) app settings — sync server URL, display
/// preferences. Deliberately separate from [SeedVault]: nothing sensitive
/// should ever end up in `shared_preferences`, so keeping this class's
/// scope to "things that are fine to read from a backup or a rooted
/// device" is the whole point of it existing as its own type.
class SettingsStore {
  static const _serverUrlKey = 'ycash.settings.server_url';
  static const _localCurrencyKey = 'ycash.settings.local_currency';

  Future<String> getServerUrl() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_serverUrlKey) ?? YcashConfig.defaultLightwalletd;
  }

  Future<void> setServerUrl(String url) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_serverUrlKey, url);
  }

  Future<void> resetServerUrl() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_serverUrlKey);
  }

  Future<String> getLocalCurrency() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_localCurrencyKey) ?? 'USD';
  }

  Future<void> setLocalCurrency(String code) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_localCurrencyKey, code);
  }
}
