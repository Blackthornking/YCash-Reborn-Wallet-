# Phase 19 Status — Real Backend Integration Preparation

## Completed in this package
- Vendored the user-supplied `zcash-sync` source as a reference snapshot.
- Recorded SHA-256 provenance for supplied upstream archives.
- Added a Rust backend-state model separating reference code from validated production cryptography.
- Preserved Sapling-only policy and explicitly rejects Orchard enablement.
- Spending remains hard-disabled until deterministic Ycash vectors and exact Ycash-patched upstream revisions are validated.

## Not claimed as complete
This package does **not** claim that the generic `librustzcash-master` archive is Ycash-compatible for real funds.
It does **not** enable signing or proving.

## Required next evidence
1. Exact immutable revisions from Ycash-maintained forks.
2. Ycash deterministic mnemonic -> Sapling key -> `ys...` address vectors.
3. Compact-block trial-decryption vectors.
4. Transaction acceptance vectors against Ycash infrastructure.
5. Nullifier migration tests for inherited Sapling funds.
