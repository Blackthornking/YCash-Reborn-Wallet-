# Android

Regenerate the standard Flutter Android host with:

    flutter create --platforms=android .

Then integrate the Rust native library build into the generated Android project.
Do not replace generated Flutter embedding files with custom placeholders.
