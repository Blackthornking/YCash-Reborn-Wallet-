package com.ycashfoundation.ycashreborn

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
