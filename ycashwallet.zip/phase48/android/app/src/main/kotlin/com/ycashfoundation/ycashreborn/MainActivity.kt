package com.ycashfoundation.ycashreborn

import android.app.Activity

class MainActivity : Activity()
