plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ycashfoundation.ycashreborn"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ycashfoundation.ycashreborn"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.13.0"
    }
}

dependencies {
    implementation("org.jetbrains.kotlin:kotlin-stdlib")
}
