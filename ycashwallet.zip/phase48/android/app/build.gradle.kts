plugins {
    id("com.android.application")
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.ycashfoundation.ycashreborn"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        applicationId = "com.ycashfoundation.ycashreborn"
        minSdk = 26
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }
}

flutter {
    source = "../.."
}

// Built-in Kotlin (AGP 9+) compiles Kotlin sources without the
// org.jetbrains.kotlin.android plugin. jvmTarget already defaults to
// android.compileOptions.targetCompatibility (17, set above), but it's set
// explicitly here to match Flutter's own AGP 9 templates.
kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}


val rustDir = rootProject.file("../packages/ycash_core_ffi/rust")
val rustJniDir = project.file("src/main/jniLibs")

val buildRustNative by tasks.registering(Exec::class) {
    group = "build"
    description = "Builds the Ycash Rust cdylib for Android ABIs."
    workingDir = rustDir
    doFirst { rustJniDir.mkdirs() }
    commandLine(
        "bash", "-lc",
        "cargo ndk -t arm64-v8a -t armeabi-v7a -t x86_64 -o " +
            rustJniDir.absolutePath + " build --release"
    )
}

tasks.matching { it.name == "preBuild" }.configureEach {
    dependsOn(buildRustNative)
}
