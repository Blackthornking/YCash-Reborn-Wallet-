use tonic::transport::{Channel, ClientTlsConfig, Endpoint};
use url::Url;

pub mod proto {
    tonic::include_proto!("cash.z.wallet.sdk.rpc");
}

#[derive(Debug, Clone)]
pub struct LightwalletEndpoint {
    pub url: Url,
}

impl LightwalletEndpoint {
    pub fn parse(value: &str) -> anyhow::Result<Self> {
        let url = Url::parse(value)?;
        if url.scheme() != "https" {
            anyhow::bail!("production lightwallet endpoints must use https");
        }
        Ok(Self { url })
    }

    pub async fn connect(&self) -> anyhow::Result<proto::compact_tx_streamer_client::CompactTxStreamerClient<Channel>> {
        let endpoint = Endpoint::from_shared(self.url.to_string())?
            .tls_config(ClientTlsConfig::new())?;
        let channel = endpoint.connect().await?;
        Ok(proto::compact_tx_streamer_client::CompactTxStreamerClient::new(channel))
    }
}

pub mod grpc;
