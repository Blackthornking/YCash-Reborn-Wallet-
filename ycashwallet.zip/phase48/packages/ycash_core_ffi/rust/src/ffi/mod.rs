//! C ABI for the Flutter/Dart host.
//!
//! The ABI intentionally exposes only wallet lifecycle operations that are
//! implemented and tested in this crate. Transaction signing and address
//! derivation remain unavailable until Ycash compatibility vectors pass.

use crate::network::YcashMainnet;
use crate::wallet::WalletEngine;
use std::ffi::{CStr, CString};
use std::os::raw::c_char;
use std::ptr;
use std::sync::{Mutex, OnceLock};
use zeroize::Zeroizing;

struct WalletState {
    mnemonic: Option<Zeroizing<String>>,
}

static STATE: OnceLock<Mutex<WalletState>> = OnceLock::new();

fn state() -> &'static Mutex<WalletState> {
    STATE.get_or_init(|| Mutex::new(WalletState { mnemonic: None }))
}

fn c_string(value: impl AsRef<str>) -> *mut c_char {
    CString::new(value.as_ref()).unwrap_or_else(|_| CString::new("internal string error").unwrap()).into_raw()
}

fn error_out(error: *mut *mut c_char, message: impl AsRef<str>) {
    if !error.is_null() {
        unsafe { *error = c_string(message); }
    }
}

#[no_mangle]
pub extern "C" fn ycash_engine_version() -> *mut c_char {
    c_string(crate::ENGINE_VERSION)
}

#[no_mangle]
pub extern "C" fn ycash_wallet_create(error: *mut *mut c_char) -> u8 {
    let engine = WalletEngine::new(YcashMainnet::config());
    match engine.create_wallet() {
        Ok((mnemonic, _seed)) => match state().lock() {
            Ok(mut guard) => {
                guard.mnemonic = Some(Zeroizing::new(mnemonic.expose_for_backup().to_owned()));
                1
            }
            Err(_) => {
                error_out(error, "wallet state lock failed");
                0
            }
        },
        Err(e) => {
            error_out(error, e.to_string());
            0
        }
    }
}

#[no_mangle]
pub extern "C" fn ycash_wallet_restore(
    phrase: *const c_char,
    error: *mut *mut c_char,
) -> u8 {
    if phrase.is_null() {
        error_out(error, "seed phrase was null");
        return 0;
    }

    let phrase = match unsafe { CStr::from_ptr(phrase) }.to_str() {
        Ok(v) => v,
        Err(_) => {
            error_out(error, "seed phrase was not valid UTF-8");
            return 0;
        }
    };

    let engine = WalletEngine::new(YcashMainnet::config());
    match engine.restore_wallet(phrase, "") {
        Ok((mnemonic, _seed)) => match state().lock() {
            Ok(mut guard) => {
                guard.mnemonic = Some(Zeroizing::new(mnemonic.expose_for_backup().to_owned()));
                1
            }
            Err(_) => {
                error_out(error, "wallet state lock failed");
                0
            }
        },
        Err(e) => {
            error_out(error, e.to_string());
            0
        }
    }
}

#[no_mangle]
pub extern "C" fn ycash_wallet_export_mnemonic(error: *mut *mut c_char) -> *mut c_char {
    match state().lock() {
        Ok(guard) => match &guard.mnemonic {
            Some(m) => c_string(m.as_str()),
            None => {
                error_out(error, "wallet has not been created or restored");
                ptr::null_mut()
            }
        },
        Err(_) => {
            error_out(error, "wallet state lock failed");
            ptr::null_mut()
        }
    }
}

#[no_mangle]
pub extern "C" fn ycash_wallet_wipe() {
    if let Ok(mut guard) = state().lock() {
        guard.mnemonic = None;
    }
}

#[no_mangle]
pub extern "C" fn ycash_string_free(value: *mut c_char) {
    if !value.is_null() {
        unsafe { drop(CString::from_raw(value)); }
    }
}
