//! Stable FFI-safe DTOs. Cryptographic secrets never cross into Dart.
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EngineInfo {
    pub api_version: u32,
    pub network: &'static str,
    pub sapling_address_hrp: &'static str,
    pub read_only_sync_ready: bool,
    pub spending_enabled: bool,
}

pub fn engine_info() -> EngineInfo {
    EngineInfo {
        api_version: 3,
        network: "ycash-mainnet",
        sapling_address_hrp: "ys",
        read_only_sync_ready: true,
        spending_enabled: false,
    }
}
