#!/usr/bin/env python3
from pathlib import Path
import re, sys

lock = Path("YCASH_UPSTREAM_LOCK.toml")
if not lock.exists():
    print("ERROR: YCASH_UPSTREAM_LOCK.toml not found")
    sys.exit(1)

text = lock.read_text()
bad = re.findall(r'(?:branch|rev)\s*=\s*"(?:main|master)"', text)
if bad:
    print("ERROR: floating upstream references detected")
    sys.exit(1)

repos = ["sapling-crypto-ycash", "librustzcash-nu61", "zcash-sync"]
missing=[r for r in repos if r not in text]
if missing:
    print("ERROR: missing upstream records:", ", ".join(missing))
    sys.exit(1)

print("Ycash upstream lock policy passed")
