#include <iostream>
int main() {
  std::cout << "Ycash Reborn Linux host scaffold. Regenerate with Flutter before release.\n";
  return 0;
}
