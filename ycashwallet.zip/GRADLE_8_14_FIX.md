# Android CI Gradle fix

**Superseded:** the workflow now pins Gradle 9.3.1 (to match AGP 9.1.0) as
part of the full AGP 9 / built-in Kotlin migration - see
`AGP9_NEWDSL_FIX.md`. The original 8.14 pin described below is kept for
history.

The GitHub Actions workflow regenerates the Android host using the installed Flutter SDK and then explicitly updates the Gradle wrapper distribution to Gradle 8.14.

This addresses the failure:

`Your project's Gradle version (8.9.0) is lower than Flutter's minimum supported version of 8.14.0`.

The workflow also runs `flutter analyze` before APK builds so Dart analysis errors stop the build earlier.
