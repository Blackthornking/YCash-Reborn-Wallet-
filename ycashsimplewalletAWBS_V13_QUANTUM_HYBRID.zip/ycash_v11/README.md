# Ycash Simple Wallet

A clean, Ycash-only Android wallet built as a new project rather than a modification/import layer for previous wallet apps.

## Scope
- Create a new 24-word Ycash wallet
- Restore a 24-word Ycash wallet
- Shielded receive address + QR
- Send YEC
- Transaction history
- Ycash-native compact-block sync
- Modern batched Sapling trial decryption
- Warp-style bounded transport/scan overlap
- No swaps, contacts, multi-coin abstractions, Orchard, unified addresses, or legacy wallet import

## Sync design
Ycash parameters are explicit: coin type 347, Sapling activation 419200, Ycash fork 570000, default lightwalletd `https://lite.ycash.xyz:9067`.

The first mobile profile is intentionally conservative: 512 compact blocks per batch and 4 crypto workers. The native synchronizer keeps network work bounded and commits wallet state in height order. The project can later add adaptive batching after real-device benchmarks.

## Storage boundary
This app uses a new application-support directory (`ycash-simple-wallet`) and a new secure-storage key. It does not attempt to open, migrate, or modify the previous YcashWalletOne wallet database.

## Security note
This is a development build architecture, not a claim of production audit status. Spending and sync must be tested against Ycash mainnet vectors and real devices before release.

## Quantum Vault V2

The wallet protects its recovery seed with a hybrid post-quantum envelope: **AES-256-GCM + HKDF-SHA-256 + ML-KEM-1024 + Argon2id**, with optional biometric unlock during onboarding. ML-KEM-1024 is used for post-quantum key establishment/wrapping; AES-256-GCM remains the bulk authenticated-encryption layer. Existing Ycash transaction and signature formats are unchanged.
