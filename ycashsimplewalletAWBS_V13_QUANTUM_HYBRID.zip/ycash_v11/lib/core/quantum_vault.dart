import 'dart:convert';
import 'dart:math';

import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';
import 'package:pqcrypto/pqcrypto.dart';

/// Quantum Vault v2: AES-256-GCM + Argon2id + ML-KEM-1024.
///
/// The wallet seed is encrypted by a random 256-bit DEK using AES-256-GCM.
/// The DEK is wrapped with an ML-KEM-1024 shared secret (FIPS 203, security
/// category 5). The ML-KEM decapsulation key is itself encrypted under the
/// user's Argon2id-derived PIN key, or under the OS-protected biometric key.
///
/// This is a hybrid KEM/DEM envelope: ML-KEM establishes the wrapping key and
/// AES-256-GCM protects the actual wallet secret. The on-chain Ycash key and
/// transaction/signature formats are not changed.
class QuantumVault {
  static const _recordKey = 'ycash.quantum_vault.v1';
  static const _legacySeedKey = 'ycash.simple.seed';
  static const _aadV1 = 'Ycash-QuantumVault-v1';
  static const _aadV2 = 'Ycash-QuantumVault-v2-MLKEM1024-AES256GCM';
  static const _version = 2;
  static const _kdf = 'Argon2id';
  static const _kem = 'ML-KEM-1024';
  static const _aeadName = 'AES-256-GCM';
  static const _memoryKiB = 32768;
  static const _iterations = 2;
  static const _parallelism = 2;
  static const _keyBytes = 32;

  final FlutterSecureStorage storage;
  final LocalAuthentication auth;
  final AesGcm _aead = AesGcm.with256bits();
  final Random _random = Random.secure();
  final Hkdf _hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);
  final PqcKem _mlKem = PqcKem.kyber1024;

  QuantumVault({FlutterSecureStorage? storage, LocalAuthentication? auth})
      : storage = storage ?? const FlutterSecureStorage(),
        auth = auth ?? LocalAuthentication();

  Future<bool> exists() async {
    final record = await storage.read(key: _recordKey);
    if (record != null && record.isNotEmpty) return true;
    return (await storage.read(key: _legacySeedKey))?.isNotEmpty == true;
  }

  Future<bool> hasBiometricUnlock() async {
    final record = await _readRecord();
    return record?['biometricWrappedKemSecretKey'] != null;
  }

  Future<bool> biometricAvailable() async {
    try {
      return await auth.canCheckBiometrics &&
          (await auth.getAvailableBiometrics()).isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  Future<bool> isCurrentVersion() async {
    final record = await _readRecord();
    return record?['version'] == _version;
  }

  Future<void> setup({
    required String seed,
    required String pin,
    required bool biometric,
  }) async {
    _validatePin(pin);
    if (seed.trim().isEmpty) throw StateError('Cannot vault an empty seed.');

    // Random 256-bit data-encryption key.
    final dek = _randomBytes(_keyBytes);

    // Encrypt the actual wallet seed with AES-256-GCM.
    final encryptedSeed = await _encrypt(seed.codeUnits, dek, aad: _aadV2);

    // Generate a fresh NIST FIPS 203 ML-KEM-1024 keypair and encapsulate a
    // shared secret to ourselves. The shared secret is only used to derive the
    // AES key that wraps the DEK; ML-KEM is not used as a bulk cipher.
    final (publicKey, kemSecretKey) = _mlKem.generateKeyPair();
    final (ciphertext, sharedSecret) = _mlKem.encapsulate(publicKey);
    final kemWrapKey = await _deriveKemWrapKey(sharedSecret);
    final kemWrappedDek = await _encrypt(dek, kemWrapKey, aad: _aadV2);

    // The ML-KEM decapsulation key is still sensitive. Protect it with the
    // Argon2id-derived PIN key so possession of the vault blob is insufficient.
    final salt = _randomBytes(16);
    final argon = _argon2();
    final pinKey = await argon.deriveKeyFromPassword(password: pin, nonce: salt);
    final encryptedKemSecretKey = await _encrypt(
      kemSecretKey,
      await pinKey.extractBytes(),
      aad: _aadV2,
    );

    String? biometricWrappedKemSecretKey;
    if (biometric) {
      final available = await biometricAvailable();
      if (!available) {
        throw StateError(
          'Biometric unlock was selected, but no enrolled biometric is available.',
        );
      }

      // local_auth provides the explicit onboarding confirmation. The key is
      // kept in platform secure storage; the biometric prompt is required
      // before the key is read on unlock.
      final authenticated = await auth.authenticate(
        localizedReason: 'Confirm biometrics to protect your Ycash Quantum Vault',
        biometricOnly: true,
        sensitiveTransaction: true,
        persistAcrossBackgrounding: true,
      );
      if (!authenticated) throw StateError('Biometric setup was cancelled.');

      final biometricKey = _randomBytes(_keyBytes);
      await storage.write(
        key: '${_recordKey}.biometricKey',
        value: base64UrlEncode(biometricKey),
      );
      biometricWrappedKemSecretKey = jsonEncode(
        await _encrypt(kemSecretKey, biometricKey, aad: _aadV2),
      );
    }

    final record = <String, dynamic>{
      'version': _version,
      'kdf': _kdf,
      'memoryKiB': _memoryKiB,
      'iterations': _iterations,
      'parallelism': _parallelism,
      'salt': base64UrlEncode(salt),
      'kem': _kem,
      'kemPublicKey': base64UrlEncode(publicKey),
      'kemCiphertext': base64UrlEncode(ciphertext),
      'kemWrappedDek': jsonEncode(kemWrappedDek),
      'pinWrappedKemSecretKey': jsonEncode(encryptedKemSecretKey),
      'biometricWrappedKemSecretKey': biometricWrappedKemSecretKey,
      'encryptedSeed': jsonEncode(encryptedSeed),
      'aead': _aeadName,
      'aad': _aadV2,
    };

    await storage.write(key: _recordKey, value: jsonEncode(record));
    await storage.delete(key: _legacySeedKey);
  }

  Future<String> unlockWithPin(String pin) async {
    _validatePin(pin);
    final record = await _requireRecord();
    final version = (record['version'] as num?)?.toInt() ?? 1;
    if (version == 1) return _unlockV1WithPin(record, pin);
    if (version != _version) throw StateError('Unsupported Quantum Vault version.');

    final salt = base64Url.decode(record['salt'] as String);
    final pinKey = await _argon2FromRecord(record)
        .deriveKeyFromPassword(password: pin, nonce: salt);
    final kemSecretKey = await _decryptJson(
      record['pinWrappedKemSecretKey'] as String,
      await pinKey.extractBytes(),
      aad: _aadV2,
    );
    return _unlockV2Seed(record, kemSecretKey);
  }

  Future<String> unlockWithBiometric() async {
    final record = await _requireRecord();
    final version = (record['version'] as num?)?.toInt() ?? 1;
    if (version == 1) return _unlockV1WithBiometric(record);
    if (version != _version) throw StateError('Unsupported Quantum Vault version.');

    if (record['biometricWrappedKemSecretKey'] == null) {
      throw StateError('Biometric unlock is not enabled for this wallet.');
    }

    final ok = await auth.authenticate(
      localizedReason: 'Unlock your Ycash Quantum Vault',
      biometricOnly: true,
      sensitiveTransaction: true,
      persistAcrossBackgrounding: true,
    );
    if (!ok) throw StateError('Biometric authentication was cancelled.');

    final raw = await storage.read(key: '${_recordKey}.biometricKey');
    if (raw == null) throw StateError('Biometric vault key is unavailable.');
    final biometricKey = base64Url.decode(raw);
    final kemSecretKey = await _decryptJson(
      record['biometricWrappedKemSecretKey'] as String,
      biometricKey,
      aad: _aadV2,
    );
    return _unlockV2Seed(record, kemSecretKey);
  }

  Future<String> migrateLegacySeed(
    String pin, {
    bool biometric = false,
  }) async {
    final legacy = await storage.read(key: _legacySeedKey);
    if (legacy == null || legacy.isEmpty) {
      throw StateError('No legacy wallet seed found.');
    }
    await setup(seed: legacy, pin: pin, biometric: biometric);
    return legacy;
  }

  Future<void> delete() async {
    await storage.delete(key: _recordKey);
    await storage.delete(key: '${_recordKey}.biometricKey');
    await storage.delete(key: _legacySeedKey);
  }

  Future<String> _unlockV2Seed(
    Map<String, dynamic> record,
    List<int> kemSecretKey,
  ) async {
    final ciphertext = base64Url.decode(record['kemCiphertext'] as String);
    final sharedSecret = _mlKem.decapsulate(kemSecretKey, ciphertext);
    final kemWrapKey = await _deriveKemWrapKey(sharedSecret);
    final dek = await _decryptJson(
      record['kemWrappedDek'] as String,
      kemWrapKey,
      aad: _aadV2,
    );
    return _decodeSeed(
      await _decryptJson(record['encryptedSeed'] as String, dek, aad: _aadV2),
    );
  }

  Future<String> _unlockV1WithPin(
    Map<String, dynamic> record,
    String pin,
  ) async {
    final salt = base64Url.decode(record['salt'] as String);
    final argon = Argon2id(
      memory: (record['memoryKiB'] as num).toInt(),
      iterations: (record['iterations'] as num).toInt(),
      parallelism: (record['parallelism'] as num).toInt(),
      hashLength: _keyBytes,
    );
    final pinKey = await argon.deriveKeyFromPassword(password: pin, nonce: salt);
    final dek = await _decryptJson(
      record['pinWrappedKey'] as String,
      await pinKey.extractBytes(),
      aad: _aadV1,
    );
    return _decodeSeed(
      await _decryptJson(record['encryptedSeed'] as String, dek, aad: _aadV1),
    );
  }

  Future<String> _unlockV1WithBiometric(Map<String, dynamic> record) async {
    final wrapped = record['biometricWrappedKey'];
    if (wrapped == null) throw StateError('Biometric unlock is not enabled.');
    final ok = await auth.authenticate(
      localizedReason: 'Unlock your Ycash Quantum Vault',
      biometricOnly: true,
      sensitiveTransaction: true,
      persistAcrossBackgrounding: true,
    );
    if (!ok) throw StateError('Biometric authentication was cancelled.');
    final raw = await storage.read(key: '${_recordKey}.biometricKey');
    if (raw == null) throw StateError('Biometric key is unavailable.');
    final biometricKey = base64Url.decode(raw);
    final dek = await _decryptJson(wrapped as String, biometricKey, aad: _aadV1);
    return _decodeSeed(
      await _decryptJson(record['encryptedSeed'] as String, dek, aad: _aadV1),
    );
  }

  Argon2id _argon2() => Argon2id(
        memory: _memoryKiB,
        iterations: _iterations,
        parallelism: _parallelism,
        hashLength: _keyBytes,
      );

  Argon2id _argon2FromRecord(Map<String, dynamic> record) => Argon2id(
        memory: (record['memoryKiB'] as num).toInt(),
        iterations: (record['iterations'] as num).toInt(),
        parallelism: (record['parallelism'] as num).toInt(),
        hashLength: _keyBytes,
      );

  Future<List<int>> _deriveKemWrapKey(List<int> sharedSecret) async {
    final key = await _hkdf.deriveKey(
      secretKey: SecretKey(sharedSecret),
      nonce: utf8.encode('Ycash-QuantumVault-MLKEM1024-salt-v2'),
      info: utf8.encode('Ycash Quantum Vault DEK wrapping AES-256-GCM v2'),
    );
    return key.extractBytes();
  }

  Future<Map<String, dynamic>?> _readRecord() async {
    final raw = await storage.read(key: _recordKey);
    if (raw == null || raw.isEmpty) return null;
    final value = jsonDecode(raw);
    if (value is! Map) throw StateError('Invalid Quantum Vault record.');
    return Map<String, dynamic>.from(value);
  }

  Future<Map<String, dynamic>> _requireRecord() async =>
      await _readRecord() ??
      (throw StateError('Quantum Vault is not initialized.'));

  Future<Map<String, dynamic>> _encrypt(
    List<int> plaintext,
    List<int> keyBytes, {
    required String aad,
  }) async {
    final box = await _aead.encrypt(
      plaintext,
      secretKey: SecretKey(keyBytes),
      nonce: _aead.newNonce(),
      associatedData: utf8.encode(aad),
    );
    return {
      'nonce': base64UrlEncode(box.nonce),
      'cipherText': base64UrlEncode(box.cipherText),
      'mac': base64UrlEncode(box.mac.bytes),
    };
  }

  Future<List<int>> _decryptJson(
    String encoded,
    List<int> keyBytes, {
    required String aad,
  }) async {
    final value = jsonDecode(encoded);
    if (value is! Map) throw StateError('Invalid encrypted vault payload.');
    final box = SecretBox(
      base64Url.decode(value['cipherText'] as String),
      nonce: base64Url.decode(value['nonce'] as String),
      mac: Mac(base64Url.decode(value['mac'] as String)),
    );
    try {
      return await _aead.decrypt(
        box,
        secretKey: SecretKey(keyBytes),
        associatedData: utf8.encode(aad),
      );
    } on SecretBoxAuthenticationError {
      throw StateError('Invalid PIN or corrupted Quantum Vault.');
    }
  }

  String _decodeSeed(List<int> bytes) {
    final seed = String.fromCharCodes(bytes);
    if (seed.trim().isEmpty) throw StateError('Quantum Vault contains an empty seed.');
    return seed;
  }

  List<int> _randomBytes(int n) =>
      List<int>.generate(n, (_) => _random.nextInt(256));

  void _validatePin(String pin) {
    if (!RegExp(r'^\d{6,12}$').hasMatch(pin)) {
      throw StateError('Vault PIN must contain 6–12 digits.');
    }
  }
}
