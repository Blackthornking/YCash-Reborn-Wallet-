import 'package:flutter/material.dart';
import '../core/wallet.dart';
import '../design/tokens.dart';

class VaultLock extends StatefulWidget {
  final SimpleWallet wallet;
  final VoidCallback onDone;
  const VaultLock({super.key, required this.wallet, required this.onDone});
  @override State<VaultLock> createState() => _VaultLockState();
}
class _VaultLockState extends State<VaultLock> {
  final pin = TextEditingController();
  bool busy=false, biometric=false;
  String? error;
  @override void initState(){super.initState(); _check();}
  Future<void> _check() async { final b=await widget.wallet.vault.hasBiometricUnlock(); if(mounted)setState(()=>biometric=b); }
  Future<void> _pin() async {
    setState((){busy=true;error=null;});
    try { await widget.wallet.unlockWithPin(pin.text); if(mounted)widget.onDone(); }
    catch(e){if(mounted)setState(()=>error='Unlock failed. Check your PIN.');}
    finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> _bio() async {
    setState((){busy=true;error=null;});
    try { await widget.wallet.unlockWithBiometric(); if(mounted)widget.onDone(); }
    catch(e){if(mounted)setState(()=>error=e.toString());}
    finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    const Icon(Icons.lock_outline,size:72), const SizedBox(height:24),
    const Text('Quantum Vault',textAlign:TextAlign.center,style:TextStyle(fontSize:34,fontWeight:FontWeight.w800)),
    const SizedBox(height:8), const Text('Unlock your wallet to access the signing keys.',textAlign:TextAlign.center,style:TextStyle(color:YColors.textSecondary)),
    const SizedBox(height:32),
    TextField(controller:pin,keyboardType:TextInputType.number,obscureText:true,maxLength:12,onSubmitted:(_)=>_pin(),decoration:const InputDecoration(labelText:'Vault PIN')),
    if(error!=null) Padding(padding:const EdgeInsets.only(bottom:12),child:Text(error!,textAlign:TextAlign.center,style:const TextStyle(color:YColors.danger))),
    ElevatedButton(onPressed:busy?null:_pin,child:Text(busy?'Unlocking…':'Unlock with PIN')),
    if(biometric) ...[const SizedBox(height:10), OutlinedButton.icon(onPressed:busy?null:_bio,icon:const Icon(Icons.fingerprint),label:const Text('Unlock with biometrics'))],
  ]))));
}
