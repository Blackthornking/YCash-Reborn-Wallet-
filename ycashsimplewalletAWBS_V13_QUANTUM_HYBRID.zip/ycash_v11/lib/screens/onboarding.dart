import 'package:flutter/material.dart';
import '../core/wallet.dart';
import '../design/tokens.dart';

class Onboarding extends StatefulWidget {
  final SimpleWallet wallet; final VoidCallback onDone;
  const Onboarding({super.key,required this.wallet,required this.onDone});
  @override State<Onboarding> createState()=>_OnboardingState();
}
class _OnboardingState extends State<Onboarding>{
  bool restore=false,busy=false,biometric=false; String? error; final seed=TextEditingController();
  final pin=TextEditingController(); final pinConfirm=TextEditingController();
  bool biometricAvailable=false;
  /// Optional: roughly when this wallet was first used. Because the server
  /// answers GetTreeState, the wallet can start from any height with a
  /// correct commitment tree -- so knowing this turns a ~2.46 million block
  /// scan from the 2019 fork into a short one. Left null means "I don't
  /// know", which scans everything.
  DateTime? firstUsed;

  Future<void> pickDate() async {
    final now=DateTime.now();
    final picked=await showDatePicker(
      context:context,
      initialDate:firstUsed ?? DateTime(now.year-1,now.month,now.day),
      firstDate:DateTime(2019,7,1),
      lastDate:now,
      helpText:'When did you first use this wallet?',
    );
    if(picked!=null) setState(()=>firstUsed=picked);
  }
  Future<void> go(Future<void> Function() f) async {setState(()=>busy=true); try{await f();if(mounted)widget.onDone();}catch(e){if(mounted)setState(()=>error=e.toString());}finally{if(mounted)setState(()=>busy=false);}}
  @override void initState(){super.initState(); _checkBiometric();}
  Future<void> _checkBiometric() async { final ok=await widget.wallet.vault.biometricAvailable(); if(mounted)setState(()=>biometricAvailable=ok); }
  Widget _pinFields()=>Column(children:[
    TextField(controller:pin,keyboardType:TextInputType.number,obscureText:true,maxLength:12,decoration:const InputDecoration(labelText:'Vault PIN (6–12 digits)')),
    TextField(controller:pinConfirm,keyboardType:TextInputType.number,obscureText:true,maxLength:12,decoration:const InputDecoration(labelText:'Confirm Vault PIN')),
    if(biometricAvailable) SwitchListTile(contentPadding:EdgeInsets.zero,value:biometric,onChanged:(v)=>setState(()=>biometric=v),title:const Text('Enable biometric unlock'),subtitle:const Text('Use fingerprint or face unlock after setup.')),
  ]);
  Future<void> _create()=>go(() async {if(pin.text!=pinConfirm.text)throw StateError('PINs do not match.'); await widget.wallet.create(pin:pin.text,biometric:biometric);});
  Future<void> _restore()=>go(() async {if(pin.text!=pinConfirm.text)throw StateError('PINs do not match.'); await widget.wallet.restore(seed.text,firstUsed:firstUsed,pin:pin.text,biometric:biometric);});
  @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:Padding(padding:const EdgeInsets.all(24),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const Spacer(), Image.asset('assets/branding/ycash_logo.png',width:64), const SizedBox(height:24),
    const Text('Ycash',style:TextStyle(fontSize:42,fontWeight:FontWeight.w800)),const SizedBox(height:8),
    const Text('A simple Ycash wallet. Send, receive and sync.',style:TextStyle(fontSize:17,color:YColors.textSecondary)),
    const SizedBox(height:36),
    if(restore) ...[
      TextField(controller:seed,maxLines:4,decoration:const InputDecoration(labelText:'24-word recovery phrase')),
      const SizedBox(height:12),
      if(error!=null) Text(error!,style:const TextStyle(color:YColors.danger)),
      const SizedBox(height:12),
      _pinFields(),
      const SizedBox(height:8),
      const Text('Scanning the whole chain from the 2019 Ycash fork takes hours. If you know roughly when you first used this wallet, pick a date a little before that and it will only scan from there.',style:TextStyle(fontSize:13,color:YColors.textSecondary)),
      const SizedBox(height:8),
      Row(children:[
        Expanded(child:Text(firstUsed==null ? 'Scan from the Ycash fork (slow)' : 'Scan from ${firstUsed!.toIso8601String().split("T").first}')),
        TextButton(onPressed:busy?null:pickDate,child:const Text('Choose date')),
        if(firstUsed!=null) TextButton(onPressed:busy?null:()=>setState(()=>firstUsed=null),child:const Text('Clear')),
      ]),
      const SizedBox(height:12),
      SizedBox(width:double.infinity,child:ElevatedButton(onPressed:busy?null:_restore,child:Text(busy?'Opening…':'Restore wallet'))),
      TextButton(onPressed:busy?null:()=>setState(()=>restore=false),child:const Text('Back')),
    ] else ...[
      _pinFields(),
      if(error!=null) Text(error!,style:const TextStyle(color:YColors.danger)),
      SizedBox(width:double.infinity,child:ElevatedButton(onPressed:busy?null:_create,child:Text(busy?'Creating…':'Create new wallet'))),
      SizedBox(width:double.infinity,child:OutlinedButton(onPressed:busy?null:()=>setState(()=>restore=true),child:const Text('Restore wallet'))),
    ],
    const Spacer(),
    const Text('Ycash-only • Sapling • no swaps • no legacy wallet import',style:TextStyle(fontSize:12,color:YColors.textMuted)),
  ]))));
}
