import 'package:flutter/material.dart';
import '../core/wallet.dart';
import '../design/tokens.dart';

class VaultSetup extends StatefulWidget {
  final SimpleWallet wallet;
  final VoidCallback onDone;
  const VaultSetup({super.key, required this.wallet, required this.onDone});
  @override State<VaultSetup> createState() => _VaultSetupState();
}

class _VaultSetupState extends State<VaultSetup> {
  final pin = TextEditingController();
  final confirm = TextEditingController();
  bool biometric = false, busy = false;
  String? error;
  bool biometricAvailable = false;

  @override void initState() { super.initState(); _checkBiometric(); }
  Future<void> _checkBiometric() async {
    final ok = await widget.wallet.vault.biometricAvailable();
    if (mounted) setState(() => biometricAvailable = ok);
  }
  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      if (pin.text != confirm.text) throw StateError('PINs do not match.');
      await widget.wallet.migrateLegacyToVault(pin: pin.text, biometric: biometric);
      if (mounted) widget.onDone();
    } catch (e) { if (mounted) setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Padding(padding: const EdgeInsets.all(24), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Spacer(),
        const Icon(Icons.shield_outlined, size: 64),
        const SizedBox(height: 20),
        const Text('Protect your wallet', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        const Text('Set a 6–12 digit Quantum Vault PIN. Your recovery seed will be encrypted before the wallet opens.', style: TextStyle(color: YColors.textSecondary)),
        const SizedBox(height: 24),
        TextField(controller: pin, keyboardType: TextInputType.number, obscureText: true, maxLength: 12, decoration: const InputDecoration(labelText: 'Vault PIN')),
        TextField(controller: confirm, keyboardType: TextInputType.number, obscureText: true, maxLength: 12, decoration: const InputDecoration(labelText: 'Confirm PIN')),
        if (biometricAvailable) SwitchListTile(contentPadding: EdgeInsets.zero, value: biometric, onChanged: (v) => setState(() => biometric = v), title: const Text('Enable biometric unlock'), subtitle: const Text('Use fingerprint or face unlock after setup.')),
        if (error != null) Text(error!, style: const TextStyle(color: YColors.danger)),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: ElevatedButton(onPressed: busy ? null : submit, child: Text(busy ? 'Securing…' : 'Secure wallet')),
        ),
        const Spacer(),
      ],
    ))),
  );
}
