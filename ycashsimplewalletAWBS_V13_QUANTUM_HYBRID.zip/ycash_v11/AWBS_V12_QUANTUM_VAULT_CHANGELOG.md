# AWBS V12 Quantum Vault — Hybrid PQ Upgrade

## V12.1

- Added ML-KEM-1024 (FIPS 203, security category 5) to the vault envelope.
- Added HKDF-SHA-256 domain-separated derivation from the ML-KEM shared secret.
- Retained AES-256-GCM as the bulk encryption/authentication primitive.
- Random 256-bit DEK encrypts the wallet seed.
- Argon2id-derived PIN key protects the ML-KEM decapsulation key.
- Optional biometric path protects a separate ML-KEM decapsulation-key copy.
- New vaults and legacy-seed migrations use Quantum Vault v2.
- Existing Quantum Vault v1 records remain readable for backward compatibility.
- No Ycash transaction format, key serialization, verification behavior, or 1140-byte signature format was changed.

## Security note

ML-KEM is a key-encapsulation mechanism, not a bulk cipher. The design therefore uses ML-KEM-1024 to establish the wrapping secret and AES-256-GCM to encrypt the seed/DEK payload. The PQC implementation is not itself FIPS 140 validated; deployment should be security-audited before production claims of certification.
