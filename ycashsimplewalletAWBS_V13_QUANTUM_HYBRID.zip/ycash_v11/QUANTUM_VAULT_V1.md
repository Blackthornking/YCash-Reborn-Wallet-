# Quantum Vault V2

The wallet now uses a hybrid KEM/DEM envelope:

- AES-256-GCM encrypts the wallet seed with a fresh random 256-bit DEK.
- ML-KEM-1024 (FIPS 203, NIST security category 5) establishes a 32-byte shared secret.
- HKDF-SHA-256 derives the AES-256 key used to wrap the DEK from the ML-KEM shared secret.
- Argon2id derives a 256-bit PIN key that encrypts the ML-KEM decapsulation key.
- Optional biometric unlock gates a separate protected copy of the ML-KEM decapsulation key.
- Vault version 2 is backward-readable for the previous v1 vault format. New vaults and legacy-seed migrations use v2.

The ML-KEM layer protects key establishment / wrapping; it does not replace AES-GCM for bulk encryption. The Ycash on-chain transaction format and the 1140-byte signature invariant are unchanged.

## Security boundary

The biometric flow still uses `local_auth` as the user-facing authentication gate and the OS secure-storage facility for the protected biometric key. A production security audit and device-level verification are required before claiming hardware/FIPS certification.
