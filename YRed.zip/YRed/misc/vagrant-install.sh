cat << EOF2 | fdisk /dev/sda
n
3


w
EOF2
btrfs device add -f /dev/sda3 /
pacman -Syu --noconfirm
pacman -S --noconfirm git
# TODO: update this URL to point at your own YRed repository once you've
# pushed it to GitHub (this file originally cloned the upstream YWallet repo).
git clone https://github.com/YOUR_GITHUB_USERNAME/YRed.git
(cd YRed; git checkout $1; git submodule update --init; ./install-dev.sh)
