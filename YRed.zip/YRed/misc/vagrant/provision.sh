# TODO: update this URL to point at your own YRed repository once you've
# pushed it to GitHub (this file originally cloned the upstream YWallet repo).
git clone https://github.com/YOUR_GITHUB_USERNAME/YRed.git $HOME/yred
cd $HOME/yred
git checkout $1
git submodule update --init --recursive
source misc/vagrant/build-ubuntu.sh $PWD
