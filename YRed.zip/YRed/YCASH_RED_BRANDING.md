# YCASH RED Branding
Integrated the futuristic YCASH RED logo into Flutter assets, Android launcher icons and Android splash images.
The wallet cryptographic engine is unchanged by these branding changes.
