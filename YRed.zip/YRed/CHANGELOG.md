# Changelog

> The history below (through the "Modernization changes" and "YCASH RED
> Branding" work) is inherited from the upstream
> [YWallet](https://github.com/hhanh00/zwallet) project this fork is based
> on. Commit/compare links point at the upstream repository and are kept
> as-is for reference. Future YRed-specific entries should be added above
> this note.

## [1.15.3](https://github.com/hhanh00/zwallet/compare/v1.15.2...v1.15.3) (2026-06-04)


### Bug Fixes

* update zcash-sync submodule (fix NU6.2 circuit version detection) ([4cabaad](https://github.com/hhanh00/zwallet/commit/4cabaad2d6b49f2208415633222b18ebd246588f))

## [1.15.2](https://github.com/hhanh00/zwallet/compare/v1.15.1...v1.15.2) (2026-06-03)


### Bug Fixes

* update zcash-sync submodule and Cargo.lock deps (halo2 0.5 alignment) ([e2b7bdc](https://github.com/hhanh00/zwallet/commit/e2b7bdc37a43fd089d79a6bc80c69039d9b5d452))

## [1.15.1](https://github.com/hhanh00/zwallet/compare/v1.15.0...v1.15.1) (2026-06-03)


### Bug Fixes

* update orchard to rev 9862176 (has new_for_version) for CI build ([7f2c976](https://github.com/hhanh00/zwallet/commit/7f2c976934d7b0ecf0ec8615c6d17e9397e9c9c7))

## [1.15.0](https://github.com/hhanh00/zwallet/compare/v1.14.3...v1.15.0) (2026-06-03)


### Features

* NU6.2 support — runtime circuit version selection ([f350251](https://github.com/hhanh00/zwallet/commit/f35025149bbd399a76bc3e792b1b254df8e09e2b))

## [1.14.3](https://github.com/hhanh00/zwallet/compare/v1.14.2...v1.14.3) (2026-05-24)


### Bug Fixes

* add deprecation notice alert ([c0e2aeb](https://github.com/hhanh00/zwallet/commit/c0e2aebc4930c6d06759b6e428b4ad18ba9136da))
* make deprecation notice appear after splash screen ([d349845](https://github.com/hhanh00/zwallet/commit/d349845b0f23b4ce3d51d39dd3ac17c488cdaa47))

## [1.14.2](https://github.com/hhanh00/zwallet/compare/v1.14.1...v1.14.2) (2026-01-23)


### Bug Fixes

* parse tex address in extract_receivers ([fed0228](https://github.com/hhanh00/zwallet/commit/fed022863f624013659e387266a35e192dc53a6f))

## [1.14.1](https://github.com/hhanh00/zwallet/compare/v1.14.0...v1.14.1) (2025-11-27)


### Bug Fixes

* android build 16k pages ([#245](https://github.com/hhanh00/zwallet/issues/245)) ([69d9691](https://github.com/hhanh00/zwallet/commit/69d969115b00a37f68f1897fa8e9ad8e7496dee3))
* remove swaps and voting ([#248](https://github.com/hhanh00/zwallet/issues/248)) ([153d0d5](https://github.com/hhanh00/zwallet/commit/153d0d588fc82e264618f1c842ea720f1643446a))

## [1.14.1](https://github.com/hhanh00/zwallet/compare/v1.14.0...v1.14.1) (2025-11-27)


### Bug Fixes

* android build 16k pages ([#245](https://github.com/hhanh00/zwallet/issues/245)) ([69d9691](https://github.com/hhanh00/zwallet/commit/69d969115b00a37f68f1897fa8e9ad8e7496dee3))

## [1.14.0](https://github.com/hhanh00/zwallet/compare/v1.13.8...v1.14.0) (2025-11-26)


### Features

* support for NU6.1 ([#243](https://github.com/hhanh00/zwallet/issues/243)) ([f48ecc9](https://github.com/hhanh00/zwallet/commit/f48ecc9672e57eab3337a7e0b5fea44c765e9c8d))

## [1.13.8](https://github.com/hhanh00/zwallet/compare/v1.13.7...v1.13.8) (2025-11-25)


### Bug Fixes

* update for NU6.1 ([#240](https://github.com/hhanh00/zwallet/issues/240)) ([1744ea8](https://github.com/hhanh00/zwallet/commit/1744ea8f14f633b71dc612fc7dd1f9ddade10a59))

## [1.13.7](https://github.com/hhanh00/zwallet/compare/v1.13.6...v1.13.7) (2025-10-20)


### Bug Fixes

* appimage ([#237](https://github.com/hhanh00/zwallet/issues/237)) ([dc5f9df](https://github.com/hhanh00/zwallet/commit/dc5f9dfc3dd6d06dd16304cccb177101aeb1d987))

## [1.13.6](https://github.com/hhanh00/zwallet/compare/v1.13.5...v1.13.6) (2025-10-20)


### Bug Fixes

* upgrade appimage definition ([#235](https://github.com/hhanh00/zwallet/issues/235)) ([7712190](https://github.com/hhanh00/zwallet/commit/7712190ef88474802420d046244a0ebcc04d53b2))

## [1.13.5](https://github.com/hhanh00/zwallet/compare/v1.13.4...v1.13.5) (2025-10-19)


### Bug Fixes

* build on ubuntu 24 ([#233](https://github.com/hhanh00/zwallet/issues/233)) ([539ee08](https://github.com/hhanh00/zwallet/commit/539ee08a621f8e08d04e6bc55da2e3b037270377))

## [1.13.4](https://github.com/hhanh00/zwallet/compare/v1.13.3...v1.13.4) (2025-04-10)


### Bug Fixes

* (vote) scroll on keyboard pop up ([#228](https://github.com/hhanh00/zwallet/issues/228)) ([8c8d060](https://github.com/hhanh00/zwallet/commit/8c8d06025d51650ef05f51e5767764523c16668e))

## [1.13.3](https://github.com/hhanh00/zwallet/compare/v1.13.2...v1.13.3) (2025-04-02)


### Bug Fixes

* remove failing proto build due to deprecated cmake ([827c5f1](https://github.com/hhanh00/zwallet/commit/827c5f1522cbf987c58d3f9fc082db39faf16fbd))
* sweep seed at account index != 0 ([#222](https://github.com/hhanh00/zwallet/issues/222)) ([827c5f1](https://github.com/hhanh00/zwallet/commit/827c5f1522cbf987c58d3f9fc082db39faf16fbd))

## [1.13.0](https://github.com/hhanh00/zwallet/compare/v1.12.0...v1.13.0) (2025-03-25)


### Features

* add button to reset tutorials ([#215](https://github.com/hhanh00/zwallet/issues/215)) ([054ce0d](https://github.com/hhanh00/zwallet/commit/054ce0db8a928bb898d4f29334df00b0ad8d0220))
* add tutorial showcases ([#214](https://github.com/hhanh00/zwallet/issues/214)) ([ec7f706](https://github.com/hhanh00/zwallet/commit/ec7f706cc1de73cfb46a11e408dd0ae6a261a3d7))
* more error handling on connection failures, etc ([#212](https://github.com/hhanh00/zwallet/issues/212)) ([daefc55](https://github.com/hhanh00/zwallet/commit/daefc558a84fb737b44bfd14f9f2d9af527f409d))


### Bug Fixes

* ios data dir ([daefc55](https://github.com/hhanh00/zwallet/commit/daefc558a84fb737b44bfd14f9f2d9af527f409d))
* tutorial messages ([#216](https://github.com/hhanh00/zwallet/issues/216)) ([812f26d](https://github.com/hhanh00/zwallet/commit/812f26d17c94b3869024001a4ec85d1db22f06e3))

## [1.12.0](https://github.com/hhanh00/zwallet/compare/v1.11.0...v1.12.0) (2025-03-24)


### Features

* add release please git action ([#190](https://github.com/hhanh00/zwallet/issues/190)) ([ccca220](https://github.com/hhanh00/zwallet/commit/ccca220bf0fac6150a06b5deef07aa1e6b791c09))
* create vote db ([#180](https://github.com/hhanh00/zwallet/issues/180)) ([6a0bc29](https://github.com/hhanh00/zwallet/commit/6a0bc29addb84ad5e7f7cb76bd2af56fcf2f9cfd))
* custom election picker ([#210](https://github.com/hhanh00/zwallet/issues/210)) ([688a6e8](https://github.com/hhanh00/zwallet/commit/688a6e89dc50d2058af71949ce92d82c8937bafb))
* download placeholder ([#182](https://github.com/hhanh00/zwallet/issues/182)) ([1c42e34](https://github.com/hhanh00/zwallet/commit/1c42e34574bb186bc17bdc70880801fb40f59ba4))
* download reference data ([#183](https://github.com/hhanh00/zwallet/issues/183)) ([ca76184](https://github.com/hhanh00/zwallet/commit/ca76184d62083d3d3507ba8b9a780047a6a39d23))
* integrate flutter rust bridge ([#178](https://github.com/hhanh00/zwallet/issues/178)) ([8bf4e63](https://github.com/hhanh00/zwallet/commit/8bf4e638a4a6097fbf7cb137b89c81565f5af45b))
* new election ([#179](https://github.com/hhanh00/zwallet/issues/179)) ([e7bbe17](https://github.com/hhanh00/zwallet/commit/e7bbe17a2505024ec8a0afd41c34c973f171090e))
* resolve vote addresses to candidates ([#187](https://github.com/hhanh00/zwallet/issues/187)) ([8225c67](https://github.com/hhanh00/zwallet/commit/8225c6791cc583ea162c8d7a91530dab6d386562))
* show election file path on overview page ([#209](https://github.com/hhanh00/zwallet/issues/209)) ([c911650](https://github.com/hhanh00/zwallet/commit/c9116506b677c649dc77cea079b755b5aeb57ca9))
* show election id on overview page ([#189](https://github.com/hhanh00/zwallet/issues/189)) ([f27a632](https://github.com/hhanh00/zwallet/commit/f27a6324af3c4ab9136fe7a5f4787b00719395e1))
* show past votes ([#186](https://github.com/hhanh00/zwallet/issues/186)) ([7091f0d](https://github.com/hhanh00/zwallet/commit/7091f0d04ec498ba3fa1b17281cc1511fab67a60))
* submit vote ([#185](https://github.com/hhanh00/zwallet/issues/185)) ([171f182](https://github.com/hhanh00/zwallet/commit/171f182e88b25c34443b9180477c15f2ea2b463d))
* update build doc ([#169](https://github.com/hhanh00/zwallet/issues/169)) ([0ffd5b4](https://github.com/hhanh00/zwallet/commit/0ffd5b4fd08d0fd7fa48aeacf43bc8b5b6941b78))
* update ci ([#176](https://github.com/hhanh00/zwallet/issues/176)) ([c5c6dc6](https://github.com/hhanh00/zwallet/commit/c5c6dc62391d755bdfbbb008c75df5af3867a934))
* update version to 1.9.0 ([#192](https://github.com/hhanh00/zwallet/issues/192)) ([c65d0f1](https://github.com/hhanh00/zwallet/commit/c65d0f18ca6a8463e70f5cf2fa8482697ec254c0))
* vote delegation ([#188](https://github.com/hhanh00/zwallet/issues/188)) ([7301e88](https://github.com/hhanh00/zwallet/commit/7301e8827774128d6e707815c99b03cebf9aecf6))
* vote overview ([#181](https://github.com/hhanh00/zwallet/issues/181)) ([262c39a](https://github.com/hhanh00/zwallet/commit/262c39af94cbf67cc45eb3f8feba48d84019aa9c))
* vote page with balance ([#184](https://github.com/hhanh00/zwallet/issues/184)) ([ffcc386](https://github.com/hhanh00/zwallet/commit/ffcc3862308d6f1ffb9216b1cee0429b607e2448))


### Bug Fixes

* add -fno-check-stack to ios build ([#197](https://github.com/hhanh00/zwallet/issues/197)) ([d61bad0](https://github.com/hhanh00/zwallet/commit/d61bad05dfeabffd947e892fe6405ac3c7f5a884))
* android build ([#194](https://github.com/hhanh00/zwallet/issues/194)) ([835536a](https://github.com/hhanh00/zwallet/commit/835536a62eab6f2cf20108d91a1b7079cac74c59))
* android build ([#202](https://github.com/hhanh00/zwallet/issues/202)) ([f327d75](https://github.com/hhanh00/zwallet/commit/f327d754ed5a2b7199c227cbbb6fc29310ac8e14))
* app_link not working ([738275a](https://github.com/hhanh00/zwallet/commit/738275a2ad468a256ff73dcddc8219e052eef2ad))
* Changing account does not update budget & wallet pnl ([f38ab38](https://github.com/hhanh00/zwallet/commit/f38ab38c636d4ebfc572be7f2d88c9245d4f7bcb))
* download error handling ([#207](https://github.com/hhanh00/zwallet/issues/207)) ([f0dadac](https://github.com/hhanh00/zwallet/commit/f0dadacb2784cc7889fde533b1e7520f55bb4e9e))
* Edit contact page does not pop ([0a71061](https://github.com/hhanh00/zwallet/commit/0a7106160061420dd4a54f05f42837819c07c499))
* error handling on new election form ([#208](https://github.com/hhanh00/zwallet/issues/208)) ([fa83326](https://github.com/hhanh00/zwallet/commit/fa833262c5507f9bdbe5fc21412c6d460c654b75))
* file picker on ios ([#199](https://github.com/hhanh00/zwallet/issues/199)) ([dad3840](https://github.com/hhanh00/zwallet/commit/dad384083b0339596230fcaa5043dfd9e09a4465))
* https connections ([#206](https://github.com/hhanh00/zwallet/issues/206)) ([3a6cdf9](https://github.com/hhanh00/zwallet/commit/3a6cdf9bcb42ec153c617bf25b26a7c2b0daf01c))
* ios build ([#195](https://github.com/hhanh00/zwallet/issues/195)) ([9e5dbdc](https://github.com/hhanh00/zwallet/commit/9e5dbdc5a713c1b69bc0cc5e3eaf0661c01a5568))
* remove ledger code ([#204](https://github.com/hhanh00/zwallet/issues/204)) ([e8fb412](https://github.com/hhanh00/zwallet/commit/e8fb412f22df96f87fd2d069daf742c91334b4d2))
* update url launcher (fixes issue on ios) ([#198](https://github.com/hhanh00/zwallet/issues/198)) ([435c07d](https://github.com/hhanh00/zwallet/commit/435c07da9a2df68cb23d12c08d1ff4af7ab72589))
* zip317 sapling min 2 ([91d8807](https://github.com/hhanh00/zwallet/commit/91d880745ca71eaff20571effaf9ef3cde4f53ec))

## [1.11.0](https://github.com/hhanh00/zwallet/compare/v1.10.1...v1.11.0) (2025-03-24)


### Features

* show election file path on overview page ([#209](https://github.com/hhanh00/zwallet/issues/209)) ([c911650](https://github.com/hhanh00/zwallet/commit/c9116506b677c649dc77cea079b755b5aeb57ca9))


### Bug Fixes

* download error handling ([#207](https://github.com/hhanh00/zwallet/issues/207)) ([f0dadac](https://github.com/hhanh00/zwallet/commit/f0dadacb2784cc7889fde533b1e7520f55bb4e9e))
* error handling on new election form ([#208](https://github.com/hhanh00/zwallet/issues/208)) ([fa83326](https://github.com/hhanh00/zwallet/commit/fa833262c5507f9bdbe5fc21412c6d460c654b75))
* https connections ([#206](https://github.com/hhanh00/zwallet/issues/206)) ([3a6cdf9](https://github.com/hhanh00/zwallet/commit/3a6cdf9bcb42ec153c617bf25b26a7c2b0daf01c))
* remove ledger code ([#204](https://github.com/hhanh00/zwallet/issues/204)) ([e8fb412](https://github.com/hhanh00/zwallet/commit/e8fb412f22df96f87fd2d069daf742c91334b4d2))

## [1.10.1](https://github.com/hhanh00/zwallet/compare/v1.10.0...v1.10.1) (2025-03-23)


### Bug Fixes

* android build ([#202](https://github.com/hhanh00/zwallet/issues/202)) ([f327d75](https://github.com/hhanh00/zwallet/commit/f327d754ed5a2b7199c227cbbb6fc29310ac8e14))

## [1.10.0](https://github.com/hhanh00/zwallet/compare/v1.9.0...v1.10.0) (2025-03-23)


### Features

* add release please git action ([#190](https://github.com/hhanh00/zwallet/issues/190)) ([ccca220](https://github.com/hhanh00/zwallet/commit/ccca220bf0fac6150a06b5deef07aa1e6b791c09))
* create vote db ([#180](https://github.com/hhanh00/zwallet/issues/180)) ([6a0bc29](https://github.com/hhanh00/zwallet/commit/6a0bc29addb84ad5e7f7cb76bd2af56fcf2f9cfd))
* download placeholder ([#182](https://github.com/hhanh00/zwallet/issues/182)) ([1c42e34](https://github.com/hhanh00/zwallet/commit/1c42e34574bb186bc17bdc70880801fb40f59ba4))
* download reference data ([#183](https://github.com/hhanh00/zwallet/issues/183)) ([ca76184](https://github.com/hhanh00/zwallet/commit/ca76184d62083d3d3507ba8b9a780047a6a39d23))
* integrate flutter rust bridge ([#178](https://github.com/hhanh00/zwallet/issues/178)) ([8bf4e63](https://github.com/hhanh00/zwallet/commit/8bf4e638a4a6097fbf7cb137b89c81565f5af45b))
* new election ([#179](https://github.com/hhanh00/zwallet/issues/179)) ([e7bbe17](https://github.com/hhanh00/zwallet/commit/e7bbe17a2505024ec8a0afd41c34c973f171090e))
* resolve vote addresses to candidates ([#187](https://github.com/hhanh00/zwallet/issues/187)) ([8225c67](https://github.com/hhanh00/zwallet/commit/8225c6791cc583ea162c8d7a91530dab6d386562))
* show election id on overview page ([#189](https://github.com/hhanh00/zwallet/issues/189)) ([f27a632](https://github.com/hhanh00/zwallet/commit/f27a6324af3c4ab9136fe7a5f4787b00719395e1))
* show past votes ([#186](https://github.com/hhanh00/zwallet/issues/186)) ([7091f0d](https://github.com/hhanh00/zwallet/commit/7091f0d04ec498ba3fa1b17281cc1511fab67a60))
* submit vote ([#185](https://github.com/hhanh00/zwallet/issues/185)) ([171f182](https://github.com/hhanh00/zwallet/commit/171f182e88b25c34443b9180477c15f2ea2b463d))
* update build doc ([#169](https://github.com/hhanh00/zwallet/issues/169)) ([0ffd5b4](https://github.com/hhanh00/zwallet/commit/0ffd5b4fd08d0fd7fa48aeacf43bc8b5b6941b78))
* update ci ([#176](https://github.com/hhanh00/zwallet/issues/176)) ([c5c6dc6](https://github.com/hhanh00/zwallet/commit/c5c6dc62391d755bdfbbb008c75df5af3867a934))
* update version to 1.9.0 ([#192](https://github.com/hhanh00/zwallet/issues/192)) ([c65d0f1](https://github.com/hhanh00/zwallet/commit/c65d0f18ca6a8463e70f5cf2fa8482697ec254c0))
* vote delegation ([#188](https://github.com/hhanh00/zwallet/issues/188)) ([7301e88](https://github.com/hhanh00/zwallet/commit/7301e8827774128d6e707815c99b03cebf9aecf6))
* vote overview ([#181](https://github.com/hhanh00/zwallet/issues/181)) ([262c39a](https://github.com/hhanh00/zwallet/commit/262c39af94cbf67cc45eb3f8feba48d84019aa9c))
* vote page with balance ([#184](https://github.com/hhanh00/zwallet/issues/184)) ([ffcc386](https://github.com/hhanh00/zwallet/commit/ffcc3862308d6f1ffb9216b1cee0429b607e2448))


### Bug Fixes

* add -fno-check-stack to ios build ([#197](https://github.com/hhanh00/zwallet/issues/197)) ([d61bad0](https://github.com/hhanh00/zwallet/commit/d61bad05dfeabffd947e892fe6405ac3c7f5a884))
* android build ([#194](https://github.com/hhanh00/zwallet/issues/194)) ([835536a](https://github.com/hhanh00/zwallet/commit/835536a62eab6f2cf20108d91a1b7079cac74c59))
* app_link not working ([738275a](https://github.com/hhanh00/zwallet/commit/738275a2ad468a256ff73dcddc8219e052eef2ad))
* Changing account does not update budget & wallet pnl ([f38ab38](https://github.com/hhanh00/zwallet/commit/f38ab38c636d4ebfc572be7f2d88c9245d4f7bcb))
* Edit contact page does not pop ([0a71061](https://github.com/hhanh00/zwallet/commit/0a7106160061420dd4a54f05f42837819c07c499))
* file picker on ios ([#199](https://github.com/hhanh00/zwallet/issues/199)) ([dad3840](https://github.com/hhanh00/zwallet/commit/dad384083b0339596230fcaa5043dfd9e09a4465))
* ios build ([#195](https://github.com/hhanh00/zwallet/issues/195)) ([9e5dbdc](https://github.com/hhanh00/zwallet/commit/9e5dbdc5a713c1b69bc0cc5e3eaf0661c01a5568))
* update url launcher (fixes issue on ios) ([#198](https://github.com/hhanh00/zwallet/issues/198)) ([435c07d](https://github.com/hhanh00/zwallet/commit/435c07da9a2df68cb23d12c08d1ff4af7ab72589))
* zip317 sapling min 2 ([91d8807](https://github.com/hhanh00/zwallet/commit/91d880745ca71eaff20571effaf9ef3cde4f53ec))

## [1.9.0](https://github.com/hhanh00/zwallet/compare/v1.8.1...v1.9.0) (2025-03-23)


### Features

* add release please git action ([#190](https://github.com/hhanh00/zwallet/issues/190)) ([ccca220](https://github.com/hhanh00/zwallet/commit/ccca220bf0fac6150a06b5deef07aa1e6b791c09))
* create vote db ([#180](https://github.com/hhanh00/zwallet/issues/180)) ([6a0bc29](https://github.com/hhanh00/zwallet/commit/6a0bc29addb84ad5e7f7cb76bd2af56fcf2f9cfd))
* download placeholder ([#182](https://github.com/hhanh00/zwallet/issues/182)) ([1c42e34](https://github.com/hhanh00/zwallet/commit/1c42e34574bb186bc17bdc70880801fb40f59ba4))
* download reference data ([#183](https://github.com/hhanh00/zwallet/issues/183)) ([ca76184](https://github.com/hhanh00/zwallet/commit/ca76184d62083d3d3507ba8b9a780047a6a39d23))
* integrate flutter rust bridge ([#178](https://github.com/hhanh00/zwallet/issues/178)) ([8bf4e63](https://github.com/hhanh00/zwallet/commit/8bf4e638a4a6097fbf7cb137b89c81565f5af45b))
* new election ([#179](https://github.com/hhanh00/zwallet/issues/179)) ([e7bbe17](https://github.com/hhanh00/zwallet/commit/e7bbe17a2505024ec8a0afd41c34c973f171090e))
* resolve vote addresses to candidates ([#187](https://github.com/hhanh00/zwallet/issues/187)) ([8225c67](https://github.com/hhanh00/zwallet/commit/8225c6791cc583ea162c8d7a91530dab6d386562))
* show election id on overview page ([#189](https://github.com/hhanh00/zwallet/issues/189)) ([f27a632](https://github.com/hhanh00/zwallet/commit/f27a6324af3c4ab9136fe7a5f4787b00719395e1))
* show past votes ([#186](https://github.com/hhanh00/zwallet/issues/186)) ([7091f0d](https://github.com/hhanh00/zwallet/commit/7091f0d04ec498ba3fa1b17281cc1511fab67a60))
* submit vote ([#185](https://github.com/hhanh00/zwallet/issues/185)) ([171f182](https://github.com/hhanh00/zwallet/commit/171f182e88b25c34443b9180477c15f2ea2b463d))
* update build doc ([#169](https://github.com/hhanh00/zwallet/issues/169)) ([0ffd5b4](https://github.com/hhanh00/zwallet/commit/0ffd5b4fd08d0fd7fa48aeacf43bc8b5b6941b78))
* update ci ([#176](https://github.com/hhanh00/zwallet/issues/176)) ([c5c6dc6](https://github.com/hhanh00/zwallet/commit/c5c6dc62391d755bdfbbb008c75df5af3867a934))
* vote delegation ([#188](https://github.com/hhanh00/zwallet/issues/188)) ([7301e88](https://github.com/hhanh00/zwallet/commit/7301e8827774128d6e707815c99b03cebf9aecf6))
* vote overview ([#181](https://github.com/hhanh00/zwallet/issues/181)) ([262c39a](https://github.com/hhanh00/zwallet/commit/262c39af94cbf67cc45eb3f8feba48d84019aa9c))
* vote page with balance ([#184](https://github.com/hhanh00/zwallet/issues/184)) ([ffcc386](https://github.com/hhanh00/zwallet/commit/ffcc3862308d6f1ffb9216b1cee0429b607e2448))
