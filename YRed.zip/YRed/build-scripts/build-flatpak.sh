#!/bin/sh

flatpak-builder --user --install --force-clean build-dir com.yred.wallet.yml
flatpak build-export /root/repo build-dir
flatpak build-bundle /root/repo yred.flatpak com.yred.wallet
