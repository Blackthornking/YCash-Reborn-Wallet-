# Modernization changes

This package modernizes Android/Flutter build infrastructure while intentionally avoiding changes to wallet logic, cryptographic code, seed handling, serialization, or transaction behavior.

Updated:
- Flutter declarative Gradle Plugin DSL
- Java 17 compatibility
- Kotlin/Android Gradle Plugin build plumbing
- Gradle wrapper
- Centralized repositories
- file_picker dependency from the prior update

The next step is to run the GitHub Actions build and fix any project-specific compiler errors one at a time.
