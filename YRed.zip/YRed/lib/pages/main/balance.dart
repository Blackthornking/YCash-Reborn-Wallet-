import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';

import '../../appsettings.dart';
import '../../store2.dart';
import '../../accounts.dart';
import '../../coin/coins.dart';
import '../utils.dart';

class BalanceWidget extends StatefulWidget {
  final int mode;
  final void Function()? onMode;
  BalanceWidget(this.mode, {this.onMode, super.key});
  @override
  State<StatefulWidget> createState() => BalanceState();
}

class BalanceState extends State<BalanceWidget> {
  @override
  void initState() {
    super.initState();
    Future(marketPrice.update);
  }

  String _formatFiat(double x) =>
      decimalFormat(x, 2, symbol: appSettings.currency);

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    final mode = widget.mode;

    final color = mode == 0
        ? t.colorScheme.secondary
        : mode == 1
            ? t.colorScheme.primaryContainer
            : t.colorScheme.primary;

    return Observer(builder: (context) {
      aaSequence.settingsSeqno;
      aa.height;
      aa.currency;
      appStore.flat;

      final hideBalance = hide(appStore.flat);
      if (hideBalance) return SizedBox();

      final c = coins[aa.coin];
      final balHi = decimalFormat((balance ~/ 100000) / 1000.0, 3);
      final balLo = (balance % 100000).toString().padLeft(5, '0');
      final fiat = marketPrice.price;
      final balFiat = fiat?.let((fx) => balance * fx / ZECUNIT);
      final txtFiat = fiat?.let(_formatFiat);
      final txtBalFiat = balFiat?.let(_formatFiat);

      Widget amountCard(String label, int value, IconData icon, Color accent,
          {String? subtitle}) {
        final hi = decimalFormat((value ~/ 100000) / 1000.0, 3);
        final lo = (value % 100000).toString().padLeft(5, '0');
        return Container(
          width: double.infinity,
          margin: const EdgeInsets.symmetric(vertical: 6),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: t.colorScheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: accent.withValues(alpha: .75)),
            boxShadow: [BoxShadow(color: accent.withValues(alpha: .12), blurRadius: 18)],
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Icon(icon, color: accent), const SizedBox(width: 8),
              Text(label, style: t.textTheme.labelLarge?.apply(color: accent))]),
            const SizedBox(height: 8),
            Row(crossAxisAlignment: CrossAxisAlignment.baseline, textBaseline: TextBaseline.alphabetic,
              children: [Text(c.symbol, style: t.textTheme.bodyLarge), const SizedBox(width: 8),
                Text(hi, style: t.textTheme.headlineMedium), Text(lo, style: t.textTheme.bodySmall)]),
            if (subtitle != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(subtitle)),
          ]),
        );
      }

      final shielded = aa.poolBalances.sapling + aa.poolBalances.orchard;
      final transparent = aa.poolBalances.transparent;
      return GestureDetector(
        onTap: widget.onMode,
        child: Column(children: [
          amountCard('SHIELDED BALANCE', shielded, Icons.shield, Colors.redAccent,
              subtitle: 'PRIVATE • PROTECTED'),
          amountCard('TRANSPARENT BALANCE', transparent, Icons.visibility, Colors.orangeAccent,
              subtitle: 'PUBLIC ON BLOCKCHAIN'),
          const SizedBox(height: 8),
          Text('TOTAL BALANCE', style: t.textTheme.labelLarge),
          Text(amountToString2(totalBalance), style: t.textTheme.titleLarge),
          if (txtBalFiat != null) Padding(padding: const EdgeInsets.only(top: 4), child: Text(txtBalFiat)),
          if (txtFiat != null) Text('1 ${c.ticker} = $txtFiat'),
        ]),
      );
    });
  }

  bool hide(bool flat) {
    switch (appSettings.autoHide) {
      case 0:
        return true;
      case 1:
        return flat;
      default:
        return false;
    }
  }

  int get balance {
    switch (widget.mode) {
      case 0:
      case 4:
        return totalBalance;
      case 1:
        return aa.poolBalances.transparent;
      case 2:
        return aa.poolBalances.sapling;
      case 3:
        return aa.poolBalances.orchard;
    }
    throw 'Unreachable';
  }

  int get totalBalance =>
      aa.poolBalances.transparent +
      aa.poolBalances.sapling +
      aa.poolBalances.orchard;

  int get otherBalance => totalBalance - balance;
}
