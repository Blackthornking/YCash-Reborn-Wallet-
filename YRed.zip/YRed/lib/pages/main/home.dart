import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';

import '../../generated/intl/messages.dart';
import '../../appsettings.dart';
import '../../store2.dart';
import '../../accounts.dart';
import '../../coin/coins.dart';
import '../utils.dart';
import 'balance.dart';
import 'sync_status.dart';
import 'qr_address.dart';
import '../more/pool.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Observer(builder: (context) {
      final key = ValueKey(aaSequence.seqno);
      return HomePageInner(key: key);
    });
  }
}

class HomePageInner extends StatefulWidget {
  HomePageInner({super.key});
  @override
  State<StatefulWidget> createState() => _HomeState();
}

class _HomeState extends State<HomePageInner> {
  final key = GlobalKey<BalanceState>();
  int addressMode = coins[aa.coin].defaultAddrMode;

  @override
  void initState() {
    super.initState();
    syncStatus2.update();
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return Scaffold(
        floatingActionButton: GestureDetector(
            onLongPress: () => _send(true),
            child: FloatingActionButton(
              onPressed: () => _send(false),
              child: Icon(Icons.send),
            )),
        body: SingleChildScrollView(
          child: Center(
            child: Observer(
              builder: (context) {
                aaSequence.seqno;
                aa.poolBalances;
                syncStatus2.changed;

                return Column(
                  children: [
                    SyncStatusWidget(),
                    Gap(8),
                    Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16),
                        child: Column(children: [
                          AddressCarousel(
                            onAddressModeChanged: (m) =>
                                setState(() => addressMode = m),
                          ),
                          Gap(8),
                          BalanceWidget(
                            addressMode,
                            key: key,
                          ),
                          Gap(16),
                          _privacyActions(context),
                          Gap(12),
                          if (!aa.saved)
                            OutlinedButton(
                                onPressed: _backup,
                                child: Text(s.backupMissing))
                        ])),
                  ],
                );
              },
            ),
          ),
        ));
  }


  Widget _privacyActions(BuildContext context) {
    final pb = aa.poolBalances;
    final shielded = pb.sapling + pb.orchard;
    final transparent = pb.transparent;
    final total = shielded + transparent;
    final privacyPct = total == 0 ? 100 : (shielded * 100 ~/ total);
    final hasTransparent = transparent > 0;

    return Column(children: [
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF14070A),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFFF1744).withValues(alpha: .70)),
          boxShadow: const [BoxShadow(color: Color(0x33000000), blurRadius: 18)],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Row(children: [
            Icon(Icons.security, color: Color(0xFFFF1744)),
            SizedBox(width: 8),
            Text('PRIVACY COMMAND CENTER', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2, color: Color(0xFFFF1744))),
          ]),
          const SizedBox(height: 14),
          Text('PRIVACY STATUS: $privacyPct%', style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: privacyPct / 100,
              minHeight: 10,
              color: hasTransparent ? const Color(0xFFFF1744) : Colors.greenAccent,
              backgroundColor: const Color(0xFF3A1A20),
            ),
          ),
          const SizedBox(height: 10),
          Text(hasTransparent
              ? 'TRANSPARENT FUNDS DETECTED — shielding is recommended for stronger on-chain privacy.'
              : 'ALL DETECTED FUNDS ARE IN SHIELDED POOLS.'),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFFD50032)),
              icon: const Icon(Icons.shield),
              label: const Text('SHIELD'),
              onPressed: transparent > 0 ? () => _openTransfer(context, shield: true) : null,
            )),
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton.icon(
              icon: const Icon(Icons.visibility_off),
              label: const Text('UNSHIELD'),
              onPressed: shielded > 0 ? () => _openTransfer(context, shield: false) : null,
            )),
          ]),
          const SizedBox(height: 10),
          const Text('Pool transfers always require fresh PIN or biometric authentication before transaction planning.',
              style: TextStyle(fontSize: 12, color: Color(0xFFB0A0A4))),
        ]),
      )
    ]);
  }

  Future<void> _openTransfer(BuildContext context, {required bool shield}) async {
    final authed = await authBarrier(context, dismissable: true);
    if (!authed) return;
    if (!shield) {
      final proceed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('PRIVACY WARNING'),
          content: const Text('Moving YEC from a shielded pool to a transparent pool can make transaction information publicly visible on the blockchain. Continue only if you understand the privacy impact.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('CANCEL')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('CONTINUE')),
          ],
        ),
      );
      if (proceed != true) return;
    }
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => PoolTransferPage(initialFrom: shield ? 1 : 2, initialTo: shield ? 2 : 1),
    ));
  }

  _send(bool custom) async {
    final protectSend = appSettings.protectSend;
    if (protectSend) {
      final authed = await authBarrier(context, dismissable: true);
      if (!authed) return;
    }
    final c = custom ? 1 : 0;
    GoRouter.of(context).push('/account/quick_send?custom=$c');
  }

  _backup() {
    GoRouter.of(context).push('/more/backup');
  }
}
