import 'dart:math';

import 'package:flutter/material.dart';

/// A small, dependency-free replacement for the `flutter_palette` package.
///
/// `flutter_palette` (and the `flutter_color_models` package it depends on)
/// has not been updated in years and is no longer compatible with current
/// versions of Flutter, which added new required members to `Color`
/// (`a`, `b`, `g`, `r`, `colorSpace`, `toARGB32`). Rather than depend on an
/// abandoned package, this class reimplements the small subset of behaviour
/// this app needs (`ColorPalette.polyad`) using Flutter's built-in
/// [HSVColor].
class ColorPalette {
  final List<Color> colors;

  ColorPalette(this.colors);

  int get length => colors.length;

  Color operator [](int index) => colors[index];

  /// Generates [numberOfColors] colors spread evenly around the color wheel
  /// starting from [color], with a small amount of random variability in
  /// hue, saturation and brightness. Mirrors the old
  /// `ColorPalette.polyad(color, numberOfColors: ..., hueVariability: ...)`
  /// API closely enough to be a drop-in replacement for this app's needs.
  factory ColorPalette.polyad(
    Color color, {
    required int numberOfColors,
    double hueVariability = 0,
    double saturationVariability = 0,
    double brightnessVariability = 0,
  }) {
    final base = HSVColor.fromColor(color);
    final rnd = Random();
    double jitter(double amount) => (rnd.nextDouble() * 2 - 1) * amount;

    final n = max(numberOfColors, 1);
    final hueStep = 360 / n;
    final generated = List<Color>.generate(n, (i) {
      var hue = (base.hue + i * hueStep + jitter(hueVariability)) % 360;
      if (hue < 0) hue += 360;
      final saturation = (base.saturation + jitter(saturationVariability) / 100)
          .clamp(0.0, 1.0);
      final value = (base.value + jitter(brightnessVariability) / 100)
          .clamp(0.0, 1.0);
      return HSVColor.fromAHSV(base.alpha, hue, saturation, value).toColor();
    });
    return ColorPalette(generated);
  }
}
