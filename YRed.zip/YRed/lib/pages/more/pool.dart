import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:warp_api/data_fb_generated.dart';
import 'package:warp_api/warp_api.dart';

import '../../appsettings.dart';
import '../../pages/widgets.dart';
import '../../accounts.dart';
import '../../generated/intl/messages.dart';
import '../settings.dart';
import '../utils.dart';

class PoolTransferPage extends StatefulWidget {
  final int? initialFrom;
  final int? initialTo;
  PoolTransferPage({this.initialFrom, this.initialTo, super.key});
  @override
  State<StatefulWidget> createState() => _PoolTransferState();
}

class _PoolTransferState extends State<PoolTransferPage>
    with WithLoadingAnimation {
  late final s = S.of(context);
  final memoController = TextEditingController(text: appSettings.memo);
  final splitController = TextEditingController(text: amountToString2(0));
  late final List<double> balances;
  int amount = 0;
  int from = 1;
  int to = 2;

  @override
  void initState() {
    super.initState();
    from = widget.initialFrom ?? from;
    to = widget.initialTo ?? to;
    final pb = aa.poolBalances;
    balances = [pb.transparent, pb.sapling, pb.orchard]
        .map((b) => b / ZECUNIT)
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final spendable = aa.poolBalances.get(from);
    return Scaffold(
      appBar: AppBar(
          title: Text(from == 1 ? 'SHIELD YEC' : 'UNSHIELD YEC'),
          actions: [IconButton(onPressed: ok, icon: Icon(Icons.check))]),
      body: wrapWithLoading(
        SingleChildScrollView(
          child: FormBuilder(
            child: Column(
              children: [
                HorizontalBarChart(balances),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    children: [
                      if (from == 1)
                        const Padding(
                          padding: EdgeInsets.all(12),
                          child: Text(
                            'TRANSPARENT → SHIELDED',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Color(0xFFD50032)),
                          ),
                        )
                      else
                        const Padding(
                          padding: EdgeInsets.all(12),
                          child: Text(
                            'SHIELDED → TRANSPARENT',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Color(0xFFFF9800)),
                          ),
                        ),
                      FieldUA(
                        from,
                        name: 'from',
                        label: s.fromPool,
                        onChanged: (v) => setState(() {
                          from = v!;
                        }),
                        radio: true,
                      ),
                      FieldUA(
                        to,
                        name: 'to',
                        label: s.toPool,
                        onChanged: (v) => setState(() {
                          to = v!;
                        }),
                        radio: true,
                      ),
                      Gap(16),
                      AmountPicker(
                        Amount(amount, false),
                        spendable: spendable,
                        onChanged: (a) => setState(() => amount = a!.value),
                      ),
                      Gap(16),
                      FormBuilderTextField(
                        name: 'memo',
                        decoration: InputDecoration(label: Text(s.memo)),
                        controller: memoController,
                        maxLines: 10,
                      ),
                      FormBuilderTextField(
                          name: 'split',
                          decoration:
                              InputDecoration(label: Text(s.maxAmountPerNote)),
                          controller: splitController,
                          keyboardType:
                              TextInputType.numberWithOptions(decimal: true),
                          validator: FormBuilderValidators.compose([
                            FormBuilderValidators.numeric(),
                            FormBuilderValidators.min(0, inclusive: false),
                          ]))
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  ok() async {
    // Unshielding is intentionally guarded by an explicit privacy acknowledgement.
    if (from != 1 && to == 1) {
      final acknowledged = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          title: const Text('CONFIRM PRIVACY CHANGE'),
          content: const Text('This transaction moves funds from a shielded pool to a transparent pool. Transparent addresses and transaction amounts can be publicly visible. Review the destination and amount carefully.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('CANCEL')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('I UNDERSTAND')),
          ],
        ),
      );
      if (acknowledged != true) return;
    }

    // Fresh authentication is required immediately before transaction planning.
    final authed = await authBarrier(context, dismissable: true);
    if (!authed) return;

    final splitAmount = stringToAmount(splitController.text);
    load(() async {
      try {
        final plan = await WarpApi.transferPools(
          aa.coin,
          aa.id,
          from,
          to,
          amount,
          false,
          memoController.text,
          splitAmount,
          appSettings.anchorOffset,
          coinSettings.feeT,
        );
        GoRouter.of(context).push('/account/txplan?tab=more', extra: plan);
      } on String catch (e) {
        await showMessageBox2(context, s.error, e);
      }
    });
  }
}

class HorizontalBarChart extends StatelessWidget {
  final List<double> values;
  final double height;

  HorizontalBarChart(this.values, {this.height = 32});

  @override
  Widget build(BuildContext context) {
    final palette = getPalette(Theme.of(context).primaryColor, values.length);

    final sum = values.fold<double>(0, ((acc, v) => acc + v));
    final stacks = values.asMap().entries.map((e) {
      final i = e.key;
      final color = palette[i];
      final v = NumberFormat.compact().format(values[i]);
      final flex = sum != 0 ? max((values[i] / sum * 100).round(), 1) : 1;
      return Flexible(
          child: Container(
              child: Center(
                  child: Text(v,
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white))),
              color: color,
              height: height),
          flex: flex);
    }).toList();

    return IntrinsicHeight(
        child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch, children: stacks));
  }
}

extension PoolBalanceExtension on PoolBalanceT {
  int get(int p) {
    switch (p) {
      case 1:
        return transparent;
      case 2:
        return sapling;
      case 4:
        return orchard;
    }
    throw 'Invalid pool';
  }
}
