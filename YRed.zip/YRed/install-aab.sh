#!/bin/sh

adb uninstall com.yred.wallet
bundletool build-apks --overwrite --bundle=build/app/outputs/bundle/release/app-release.aab --output=/tmp/app.apks --ks=docker/yred.jks --ks-key-alias=yred --ks-pass=pass:$JKS_PASSWORD
bundletool install-apks --adb=$ANDROID_SDK_ROOT/platform-tools/adb --apks=/tmp/app.apks
