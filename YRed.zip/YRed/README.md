# YRed

> A shielded Ycash wallet, built on the fast, battle-tested YWallet sync engine.

YRed is a fork of the open-source [YWallet](https://github.com/hhanh00/zwallet)
project by Hanh Huynh Huu, released under the MIT license. The wallet's
cryptographic and blockchain-sync engine (Rust, Warp Sync) is unmodified from
upstream -- this fork focuses on a red-themed interface, a Ycash-first
experience, and a couple of new privacy-focused UI flows (see
[MODERNIZATION_NOTES.md](MODERNIZATION_NOTES.md) and
[YCASH_RED_BRANDING.md](YCASH_RED_BRANDING.md) for specifics).

**This project is not affiliated with or endorsed by the original YWallet
author.** All credit for the underlying sync engine and wallet architecture
goes to them; see [LICENSE.md](LICENSE.md) for the required MIT attribution.

## Main Features

- Warp Sync: processes thousands of blocks per second
- **Transparent** and **Shielded** Address support
- Scalable design: supports hundreds of thousands of transactions and notes
- Low requirements: Android 7.0+, 2 GB of RAM

## Other Features

- Multi-account
- Watch-only account from a viewing key
- Import seed phrase (ZIP 32 compliant) or secret key
- One-touch transparent account shielding
- Automatic shielding above a configurable threshold
- "Privacy Command Center" home-screen widget showing your shielded vs.
  transparent balance split, with guided shield/unshield actions and a
  privacy-impact confirmation before unshielding
- Diversified ("snap") addresses
- Fiat currency equivalents (USD, EUR, JPY, and more)
- Coin control (select which notes to spend)
- Specify spending amount in fiat or YEC
- Prepare unsigned transactions for cold-storage spending
- Broadcast raw transactions
- Multiple-recipient payments
- Transaction history
- Encrypted memos
- Account balance history and P/L charts
- Contact address book
- Color and dark/light themes
- QR code scanner support
- Localization in English, Spanish, French, Portuguese (more to come)

## Privacy

- No data upload -- all information is recoverable from your seed phrase or secret key
- Customizable `lightwalletd` server URL
- Fresh PIN/biometric authentication required before any pool transfer

## Building

See [BUILD.md](BUILD.md) for build instructions. This fork's build tooling
is inherited from upstream YWallet's; a few release-packaging scripts under
`misc/`, `docker/`, and `build-scripts/` still contain `TODO` placeholders
(GitHub URLs, Docker Hub image names, signing identities) that assume you'll
be publishing your own releases under your own accounts -- update those
before using them. See `MODERNIZATION_NOTES.md` for what's already been
modernized (Gradle/Java/Kotlin toolchain, etc.).

## License

MIT -- see [LICENSE.md](LICENSE.md). This retains the original copyright
notice from the upstream YWallet project, as required by the license.
