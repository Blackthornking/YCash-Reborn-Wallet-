# How to Build

This fork doesn't ship a `.github/workflows` CI pipeline -- you'll need to
set up your own (or build locally). The `build-scripts/` directory has the
platform build scripts to use as a starting point either way.

For example, for Linux
```
export $(cat build.env | xargs)
PATH=$PATH:$PWD/flutter/bin
./build-scripts/build-linux.sh $FLUTTER_VERSION
```

Other platforms have more dependencies, but the idea is the same.

Good luck
