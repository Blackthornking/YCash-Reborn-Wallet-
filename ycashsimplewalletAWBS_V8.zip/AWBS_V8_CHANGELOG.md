# AWBS V8

## Implemented

- Raised the native AWBS hard ceiling from 10,000 to **15,000 compact blocks**.
- Added an explicit tuning ladder: 1,000 / 2,000 / 4,000 / 6,000 / 8,000 / 10,000 / 12,000 / 15,000.
- AWBS now moves between ladder rungs based on measured batch time instead of producing arbitrary intermediate sizes.
- Added a bounded prefetch budget so larger batches automatically reduce prefetch depth; 15,000-block batches use only two in-flight ranges.
- Transparent-address scanning now reuses the sync round's existing gRPC HTTP/2 channel instead of creating a new TCP/TLS connection per address.
- Transparent transaction decoding errors now propagate as controlled scan errors rather than panicking with `Transaction::read(...).unwrap()`.
- Full transaction decoding errors are also propagated rather than unwrapping network-supplied transaction bytes.
- Dart/native batch-size validation now accepts up to 15,000.

## Invariants

- Wallet/tree commits remain ordered.
- Reorg invalidation still clears stale prefetched ranges before resuming.
- No wallet serialization or transaction/signature format was intentionally changed by these performance changes.

## Validation note

The source package was statically inspected after modification. This environment does not contain the Rust/Flutter toolchains, so a native Android build and real-device throughput benchmark must still be run externally before claiming a measured 15,000 blocks/sec throughput.
