#!/usr/bin/env bash
#
# Fetch the Sapling proving parameters.
#
# These are ONLY needed to create and sign transactions. Syncing, balances,
# addresses and history all work without them -- the wallet opens and reaches
# the chain tip normally, and only the Send screen will report that proving
# parameters are unavailable.
#
# They are ~51 MB combined, which is why they are not committed. Running this
# script drops them into vendor/yecshell-lib/zcash-params/, where rust-embed
# compiles them into libycash_core.so at build time.
#
# The hashes below are the ones zecwalletlitelib/yecshell verify against in
# LightClient::set_sapling_params.

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST="$ROOT/packages/ycash_core_ffi/rust/vendor/yecshell-lib/zcash-params"

OUTPUT_HASH="2f0ebbcbb9bb0bcffe95a397e7eba89c29eb4dde6191c339db88570e3f3fb0e4"
SPEND_HASH="8e48ffd23abb3a5fd9c5589204f32d9c31285a04b78096ba40a79b75677efc13"

BASE="https://download.z.cash/downloads"

mkdir -p "$DEST"

fetch() {
  local name="$1" want="$2" out="$DEST/$name"

  if [ -f "$out" ] && echo "$want  $out" | sha256sum -c --status 2>/dev/null; then
    echo "ok: $name already present"
    return 0
  fi

  echo "downloading $name ..."
  curl -fL --retry 3 -o "$out.tmp" "$BASE/$name"

  local got
  got="$(sha256sum "$out.tmp" | cut -d' ' -f1)"
  if [ "$got" != "$want" ]; then
    rm -f "$out.tmp"
    echo "ERROR: $name hash mismatch (expected $want, got $got)" >&2
    exit 1
  fi

  mv "$out.tmp" "$out"
  echo "ok: $name"
}

fetch "sapling-output.params" "$OUTPUT_HASH"
fetch "sapling-spend.params"  "$SPEND_HASH"

echo
echo "Sapling parameters installed in $DEST"
echo "Rebuild the APK to embed them; sending will then be enabled."
