# Scanner V2

## Change
The YCash-specific accelerated Sapling batch scanner now retains prepared
`PreparedIncomingViewingKey` values and passes the persistent slice directly to
`zcash_note_encryption::batch::try_compact_note_decryption`.

## V1 issue
V1 rebuilt a temporary `Vec<PreparedIncomingViewingKey>` on every
`match_outputs()` call by cloning every prepared IVK.

## V2 improvement
V2 stores:
- the prepared IVKs in one persistent vector;
- a parallel vector of original wallet/account indexes.

The hot path no longer clones every prepared IVK for each batch-match call.

## Compatibility
No protocol, serialization, key format, note format, KDF, or decryption rule
was changed. The same YCash-pinned Sapling batch decryption routine is used,
with the same ordering and account-index mapping.

## Validation requirement
This source change must be followed by the project's full Rust/Flutter build
and cryptographic regression suite. A Rust compiler was not available in the
build environment used to prepare this archive, so no successful cargo build
is claimed here.
