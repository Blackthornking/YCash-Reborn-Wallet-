import 'package:flutter/material.dart';
import 'core/wallet.dart';
import 'screens/home.dart';
import 'screens/onboarding.dart';
import 'screens/fatal_error.dart';

class YcashSimpleApp extends StatefulWidget { const YcashSimpleApp({super.key}); @override State<YcashSimpleApp> createState()=>_AppState(); }
class _AppState extends State<YcashSimpleApp> with WidgetsBindingObserver {
  final wallet=SimpleWallet();
  bool? exists;
  String? startupError;

  /// Held rather than created inline in [build]. `FutureBuilder(future:
  /// wallet.openSaved(), ...)` written directly in build() starts a *new*
  /// wallet open on every single rebuild -- including the rebuild triggered
  /// by the error screen's own retry button -- so a slow or failing open
  /// could stack several concurrent native opens against the same wallet
  /// file. Creating it once and reusing it means one open per attempt.
  Future<void>? _openFuture;

  @override void initState(){super.initState(); WidgetsBinding.instance.addObserver(this); _check();}

  @override void dispose(){WidgetsBinding.instance.removeObserver(this); super.dispose();}

  /// Flush the wallet to disk on the way out.
  ///
  /// This app has no foreground service, so scanning effectively only runs
  /// while it is on screen, and Android freezes then reclaims the process
  /// whenever it likes. Without this, everything scanned since the last
  /// periodic checkpoint was thrown away every time the app was backgrounded
  /// -- which is why a long restore appeared to start over each time.
  @override void didChangeAppLifecycleState(AppLifecycleState state){
    if(state==AppLifecycleState.paused ||
       state==AppLifecycleState.hidden ||
       state==AppLifecycleState.detached){
      wallet.saveNow();
    }
  }

  Future<void> _check() async {
    setState(()=>startupError=null);
    try {
      final e=await wallet.hasWallet();
      if(mounted)setState(()=>exists=e);
    } catch (err, stack) {
      // Without this, an exception here (native library load failure,
      // secure-storage plugin not registered, anything) left `exists` at
      // null forever -- initState calls _check() without awaiting or
      // catching it, so nothing ever called setState again, and the app
      // sat on the loading spinner below permanently with no visible
      // indication anything had gone wrong.
      debugPrint('Startup check failed: $err\n$stack');
      if(mounted)setState(()=>startupError='$err\n\n$stack');
    }
  }

  void _retryOpen(){ setState(()=>_openFuture=null); }

  @override Widget build(BuildContext c){
    if(startupError!=null) return FatalErrorScreen(message:startupError!, onRetry:_check);
    if(exists==null) return const MaterialApp(home:Scaffold(body:Center(child:CircularProgressIndicator())));
    return MaterialApp(
      title:'Ycash',
      debugShowCheckedModeBanner:false,
      theme:ThemeData(useMaterial3:true,brightness:Brightness.dark,scaffoldBackgroundColor:const Color(0xFF080807)),
      home: exists! ? FutureBuilder(future:_openFuture??=wallet.openSaved(),builder:(c,s){
        if(s.hasError){
          return FatalErrorScreen(
            message:'Could not connect to a Ycash server and open the saved wallet:\n\n${s.error}',
            onRetry:_retryOpen,
          );
        }
        if(s.connectionState!=ConnectionState.done){
          return const Scaffold(body:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
            CircularProgressIndicator(),
            SizedBox(height:20),
            Text('Connecting to the Ycash network…'),
          ])));
        }
        return Home(wallet:wallet,onWiped:(){ setState((){ exists=false; _openFuture=null; }); });
      }) : Onboarding(wallet:wallet,onDone:()=>setState(()=>exists=true)),
    );
  }
}
