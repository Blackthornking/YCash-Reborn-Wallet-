package com.ycashfoundation.ycashsimple

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
