# AWBS V4

## High-throughput sync pipeline

V4 connects the adaptive batch scheduler to the real Ycash lightwallet sync path.

### Changes

- Fixed the V3 scanner-pool wiring: the selected CPU worker count now creates the actual shared `ThreadPool` used by Sapling scanning and transparent-address work.
- Replaced the V3 fetch-worker bottleneck where every range was driven through `SharedGrpcConnection`'s runtime mutex.
- Added concurrent range fetching using clones of the already-connected tonic HTTP/2 `Channel`.
- Each independent fetch is driven by its own lightweight Tokio runtime, allowing multiple HTTP/2 streams to make progress concurrently.
- Increased bounded prefetch depth from 3 to 8 ranges.
- Kept the existing persistent connection and per-range 90-second timeout.
- Kept chain-order processing: ranges may arrive concurrently, but wallet scanning remains sequential and reorg-safe.
- Kept the existing Ycash cryptographic scanner and wallet state rules unchanged.
- Kept the existing transaction-ID handling unchanged.
- V4 default entry point is 4,000-block batches with 8 scanner workers; AWBS can adapt the next batch up to the existing 10,000-block ceiling.

### Safety boundaries

V4 does not invent notes, witnesses, nullifiers, transactions, or wallet state. It only changes scheduling, transport concurrency, and worker-pool wiring around the existing cryptographic scanner.

### Benchmark requirement

20,000 blocks/sec is a performance target, not a claimed result. The shipped benchmark must measure sustained throughput on the target device and endpoint before that target is considered achieved.
